<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

if (file_exists(dirname(__FILE__).'/vendor/autoload.php')) {
    require_once(dirname(__FILE__).'/vendor/autoload.php');
}

require_once(dirname(__FILE__).'/classes/DssClass.php');
require_once(dirname(__FILE__).'/classes/DssActionLogClass.php');
require_once(dirname(__FILE__).'/classes/DssCategoriesClass.php');
require_once(dirname(__FILE__).'/classes/DssSuppliersClass.php');
require_once(dirname(__FILE__).'/classes/DssManufacturersClass.php');
require_once(dirname(__FILE__).'/classes/DssDropshippersClass.php');
require_once(dirname(__FILE__).'/classes/DssAddressClass.php');
require_once(dirname(__FILE__).'/classes/DssEmployeeClass.php');
require_once(dirname(__FILE__).'/classes/DssEventsClass.php');
require_once(dirname(__FILE__).'/classes/DssOrderClass.php');
require_once(dirname(__FILE__).'/classes/DssPaymentClass.php');
require_once(dirname(__FILE__).'/classes/DssPaymentsHistoryClass.php');
require_once(dirname(__FILE__).'/classes/DssPaymentsTokenClass.php');
require_once(dirname(__FILE__).'/classes/DssProductGroupsClass.php');
require_once(dirname(__FILE__).'/classes/DssSpecificWholesalePriceClass.php');
require_once(dirname(__FILE__).'/classes/DssSpecificWholesalePriceRuleClass.php');
require_once(dirname(__FILE__).'/classes/DssStatisticsClass.php');
require_once(dirname(__FILE__).'/classes/DssCartClass.php');

class DropShipSystem extends Module
{
    public $html = '';

    private $errors = array();

    const INSTALL_SQL_FILE = 'install.sql';

    public function __construct()
    {
        $this->name = 'dropshipsystem';
        $this->tab = 'administration';
        $this->version = '1.0.54';
        $this->author = 'PrestaBiz';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        $this->module_key = '3929c4db0adf8969a7a13e097940752b';
        $this->author_address = '0x4308df77CBA86275a2Efb859F3230F4217fb4FfE';
        $this->bootstrap = true;

        $this->controllers = array('webservice', 'mydropshipaccount', 'downloads', 'cron');

        $this->push_filename = _PS_CACHE_DIR_.'push/dropshipsystem';
        $this->allow_push = true;
        $this->push_time_limit = 180;

        parent::__construct();

        $this->displayName = $this->l('Dropship System');
        $this->description = $this->l('Complete system for the management of the dropship with PrestaShop. With this module you can integrate and offer dropship system to the customers and/or resellers of your store to increase sales and revenues.');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall this module?');

        $id_shop = (int)$this->context->shop->id;

        $clients = array(
            array(
                'name' => 'dropshipclient_presta',
                'version' => '1.0.41',
                'date' => '20210601'
            ),
        );

        Configuration::updateValue('DSS_CLIENTS', serialize($clients));

        // Generate Security Token if not exists
        if (!Configuration::get('DSS_SECURE_KEY', null, null, $id_shop)) {
            Configuration::updateValue('DSS_SECURE_KEY', Tools::strtoupper(Tools::passwdGen(16)), false, null, $id_shop);
        }
    }

    public function install($keep = true)
    {
        $id_shop = (int)$this->context->shop->id;
        $id_def_lang = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);

        if (!$this->copyOverrideFolder()) {
            $this->warnings[] = $this->l('Cannot copy the overrides folders. Please contact our support.');
            return false;
        }

        if ($keep) {
            if (!file_exists(dirname(__FILE__).'/sql/'.self::INSTALL_SQL_FILE)) {
                return false;
            } elseif (!$sql = Tools::file_get_contents(dirname(__FILE__).'/sql/'.self::INSTALL_SQL_FILE)) {
                return false;
            }
            $sql = str_replace(array('PREFIX_', 'ENGINE_TYPE', '_ID_SHOP_'), array(_DB_PREFIX_, _MYSQL_ENGINE_, $this->context->shop->id), $sql);
            $sql = preg_split("/;\s*[\r\n]+/", trim($sql));

            foreach ($sql as $query) {
                if (!Db::getInstance(_PS_USE_SQL_SLAVE_)->execute(trim($query))) {
                    $this->writeLog($query);
                    //return false;
                }
            }
        }

        $first_page_text = array();
        $footer_text = array();
        foreach (Language::getLanguages(false) as $lang) {
            $first_page_text[(int)$lang['id_lang']] = '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>';
            $footer_text[(int)$lang['id_lang']] = 'Copyright – Drop Shipping WebService - Documentazione Ver. 1.0<br>
                 Tutti i diritti riservati. E\' vietata qualsiasi forma di divulgazione a terzi di tali servizi/specifiche.';
        }

        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            $admin_parent_cart_rule = (int)Tab::getIdFromClassName('AdminPriceRule');
            $admin_parent_preferences = (int)Tab::getIdFromClassName('AdminParentPreferences');
        } else {
            $admin_parent_cart_rule = (int)Tab::getIdFromClassName('AdminParentCartRules');
            $admin_parent_preferences = (int)Tab::getIdFromClassName('CONFIGURE');
        }

        if (!parent::install() ||
            !$this->installRewriteURL() ||
            !$this->registerHook('header') ||
            !$this->registerHook('rightColumn') ||
            !$this->registerHook('leftColumn') ||
            !$this->registerHook('adminCustomers') ||
            !$this->registerHook('displayAdminAfterHeader') ||
            !$this->registerHook('displayAdminProductsExtra') ||
            !$this->registerHook('displayBackOfficeHeader') ||
            !$this->registerHook('displayCustomerAccount') ||
            !$this->registerHook('displayMyAccountBlock') ||
            !$this->registerHook('AdminStatsModules') ||
            !$this->registerHook('actionAdminOrdersListingFieldsModifier') ||
            !$this->registerHook('actionAdminControllerSetMedia') ||
            !$this->registerHook('actionCarrierUpdate') ||
            !$this->registerHook('actionCategoryAdd') ||
            !$this->registerHook('actionCategoryUpdate') ||
            !$this->registerHook('actionCategoryDelete') ||
            !$this->registerHook('actionProductAdd') ||
            !$this->registerHook('actionProductUpdate') ||
            !$this->registerHook('actionProductDelete') ||
            !$this->registerHook('actionProductOutOfStock') ||
            !$this->registerHook('actionUpdateQuantity') ||
            !$this->registerHook('actionEmailSendBefore') ||
            !$this->registerHook('registerGDPRConsent') ||
            !$this->registerHook('actionDeleteGDPRCustomer') ||
            !$this->registerHook('actionExportGDPRData') ||
            !$this->makeHTAccessFile() ||
            !$this->createOrderState() ||
            !$this->createCustomerGroups() ||
            !$this->createCreditProducts() ||
            !$this->createSuppliersManufacturersGroups() ||
            !Configuration::updateValue('DSS_VERSION', $this->version) ||
            !Configuration::updateValue('DSS_NEW_VERSION', $this->version) ||
            !Configuration::updateValue('DSS_WSM_FIRST_PAGE_TEXT', $first_page_text, true, null, $id_shop) ||
            !Configuration::updateValue('DSS_WSM_FOOTER_TEXT', $footer_text, true, null, $id_shop) ||
            !Configuration::updateValue('DSS_ENABLE_FASTSYNC', 1, false, null, $id_shop) ||
            !Configuration::updateValue('DSS_WHOLESALE_BASE_PRICE', 1, false, null, $id_shop) ||
            !Configuration::updateValue('DSS_MASK_REAL_QUANTITY_VALUE', 10, false, null, $id_shop) ||
            !$this->installModuleTab('AdminDropShip', array($id_def_lang => 'Dropshippers'), (int)Tab::getIdFromClassName('AdminParentCustomer'), 1) ||
            !$this->installModuleTab('AdminDropShipSpecificWholesalePriceRule', array($id_def_lang => $this->l('Catalog Wholesale Price Rules')), $admin_parent_cart_rule, 2) ||
            !$this->installModuleTab('AdminDropShipConfig', array($id_def_lang => $this->l('Dropship System Config')), $admin_parent_preferences, 5) ||
            !$this->installModuleTab('AdminDropShipCreditHistory', array($id_def_lang => $this->l('Dropshippers Credit History')), -1, 0, 0)) {
                return false;
        }

        if (version_compare(_PS_VERSION_, '1.7.6', '>=')) {
            if (!$this->registerHook('actionCategoryGridDefinitionModifier') ||
                !$this->registerHook('actionCategoryGridQueryBuilderModifier') ||
                !$this->registerHook('actionCategoryFormBuilderModifier') ||
                !$this->registerHook('actionAfterCreateCategoryFormHandler') ||
                !$this->registerHook('actionAfterUpdateCategoryFormHandler') ||
                !$this->registerHook('actionSupplierGridDefinitionModifier') ||
                !$this->registerHook('actionSupplierGridQueryBuilderModifier') ||
                !$this->registerHook('actionSupplierFormBuilderModifier') ||
                !$this->registerHook('actionAfterCreateSupplierFormHandler') ||
                !$this->registerHook('actionAfterUpdateSupplierFormHandler') ||
                !$this->registerHook('actionManufacturerGridDefinitionModifier') ||
                !$this->registerHook('actionManufacturerGridQueryBuilderModifier') ||
                !$this->registerHook('actionManufacturerFormBuilderModifier') ||
                !$this->registerHook('actionAfterCreateManufacturerFormHandler') ||
                !$this->registerHook('actionAfterUpdateManufacturerFormHandler')
               ) {
                return false;
            }
        } else {
            if (!$this->registerHook('actionAdminCategoriesListingFieldsModifier') ||
                !$this->registerHook('actionAdminCategoriesFormModifier') ||
                !$this->registerHook('actionAdminCategoriesControllerSaveAfter') ||
                !$this->registerHook('actionAdminSuppliersListingFieldsModifier') ||
                !$this->registerHook('actionAdminSuppliersFormModifier') ||
                !$this->registerHook('actionAdminSuppliersControllerSaveAfter') ||
                !$this->registerHook('actionAdminManufacturersListingFieldsModifier') ||
                !$this->registerHook('actionAdminManufacturersFormModifier') ||
                !$this->registerHook('actionAdminManufacturersControllerSaveAfter')
               ) {
                return false;
            }
        }

        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            if (!$this->registerHook('displayProductButtons') ||
                !$this->updateHookPosition('displayProductButtons', 0, 0)) {
                return false;
            }
        } else {
            if (!$this->registerHook('displayProductAdditionalInfo') ||
                !$this->updateHookPosition('displayProductAdditionalInfo', 0, 0)) {
                return false;
            }
        }

        if (version_compare(_PS_VERSION_, '1.6', '>=')) {
            if (!$this->registerHook('dashboardData') ||
                !$this->registerHook('dashboardZoneTwo')) {
                return false;
            }
            $id_hook = Hook::get('dashboardZoneTwo');
            for ($i = 0; $i < 50; $i++) {
                $this->updatePosition($id_hook, 0, 0);
            }
        }

        return true;
    }

    public function uninstall($keep = true)
    {
        $id_shop = (int)$this->context->shop->id;

        $orderState = new OrderState();
        $orderState->id = Configuration::get('PS_OS_DROPSHIP', null, null, $id_shop);
        @unlink(dirname(__FILE__).'/../../img/os/'.(int)$orderState->id.'.gif');
        if (!$orderState->delete()) {
            return false;
        }
        unset($orderState);
        $orderState = new OrderState();
        $orderState->id = Configuration::get('PS_OS_DROPSHIP_CREDIT_SUCCESS', null, null, $id_shop);
        @unlink(dirname(__FILE__).'/../../img/os/'.(int)$orderState->id.'.gif');
        if (!$orderState->delete()) {
            return false;
        }
        unset($orderState);

        if (!parent::uninstall() ||
            ($keep && !$this->uninstallRewriteURL() ||
            !$this->unregisterHook('registerGDPRConsent') ||
            !$this->unregisterHook('actionDeleteGDPRCustomer') ||
            !$this->unregisterHook('actionExportGDPRData') ||
            !$this->removeCreditProducts() ||
            !$this->uninstallDB()) ||
            !Configuration::deleteByName('DSS_VERSION') ||
            !Configuration::deleteByName('PS_OS_DROPSHIP') ||
            !Configuration::deleteByName('PS_OS_DROPSHIP_CREDIT_SUCCESS') ||
            !$this->uninstallModuleTab('AdminDropShip') ||
            !$this->uninstallModuleTab('AdminDropShipSpecificWholesalePriceRule') ||
            !$this->uninstallModuleTab('AdminDropShipConfig') ||
            !$this->uninstallModuleTab('AdminDropShipCreditHistory')) {
                return false;
        }
        return true;
    }

    public function reset()
    {
        if (!$this->uninstall(false)) {
            return false;
        }
        if (!$this->install(false)) {
            return false;
        }
        return true;
    }

    public function copyOverrideFolder()
    {
        $version_override_folder = _PS_MODULE_DIR_.$this->name.'/overrides/'.Tools::substr(str_replace('.', '', _PS_VERSION_), 0, 2);
        $override_folder = _PS_MODULE_DIR_.$this->name.'/override';

        if (file_exists($override_folder) && is_dir($override_folder)) {
            $this->recursiveRmdir($override_folder);
        }

        if (is_dir($version_override_folder)) {
            $this->copyDir($version_override_folder, $override_folder);
        }

        return true;
    }

    protected function copyDir($src, $dst)
    {
        if (is_dir($src)) {
            $dir = opendir($src);
            @mkdir($dst);
            while (false !== ($file = readdir($dir))) {
                if (($file != '.') && ($file != '..')) {
                    if (is_dir($src.'/'.$file)) {
                        $this->copyDir($src.'/'.$file, $dst.'/'.$file);
                    } else {
                        copy($src.'/'.$file, $dst.'/'.$file);
                    }
                }
            }
            closedir($dir);
        }
    }

    protected function recursiveRmdir($dir)
    {
        if (is_dir($dir)) {
            $objects = scandir($dir);
            foreach ($objects as $object) {
                if ($object != "." && $object != "..") {
                    if (filetype($dir."/".$object) == "dir") {
                        $this->recursiveRmdir($dir."/".$object);
                    } else {
                        unlink($dir."/".$object);
                    }
                }
            }
            reset($objects);
            rmdir($dir);
        }
    }

    protected function uninstallDB()
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('
            DROP TABLE IF EXISTS
            `'._DB_PREFIX_.'dss_action_log`,
            `'._DB_PREFIX_.'dss_address`,
            `'._DB_PREFIX_.'dss_categories`,
            `'._DB_PREFIX_.'dss_dropshipper`,
            `'._DB_PREFIX_.'dss_employee`,
            `'._DB_PREFIX_.'dss_events`,
            `'._DB_PREFIX_.'dss_order`,
            `'._DB_PREFIX_.'dss_payments_history`,
            `'._DB_PREFIX_.'dss_paypal_order`,
            `'._DB_PREFIX_.'dss_product_groups`,
            `'._DB_PREFIX_.'dss_specific_wholesale_price`,
            `'._DB_PREFIX_.'dss_specific_wholesale_price_rule`,
            `'._DB_PREFIX_.'dss_specific_wholesale_price_rule_condition`,
            `'._DB_PREFIX_.'dss_specific_wholesale_price_rule_condition_group`,
            `'._DB_PREFIX_.'dss_suppliers`,
            `'._DB_PREFIX_.'dss_manufacturers`;
        ');
    }

    public function installModuleTab($tabClass, $tabName, $idTabParent, $tabPosition = 0, $active = 1)
    {
        @copy(_PS_MODULE_DIR_.$this->name.'/logo.png', _PS_IMG_DIR_.'t/'.$tabClass.'.png');
        $tab = new Tab();
        $tab->active = $active;
        $tab->name = $tabName;
        $tab->class_name = $tabClass;
        $tab->module = $this->name;
        $tab->id_parent = (int)$idTabParent;
        if ($tab->add()) {
            if ($tabPosition) {
                $tab->position = $tabPosition;
                if ($tab->update()) {
                    $tab->cleanPositions($idTabParent);
                }
            }
        }
        return true;
    }
     
    private function uninstallModuleTab($tabClass)
    {
        $idTab = (int)Tab::getIdFromClassName($tabClass);
        if (!$idTab) {
            $tab = new Tab($idTab);
            $tab->delete();
            @unlink(_PS_IMG_DIR_.'t/'.$tabClass.'.png');
        }
        return true;
    }

    private function installRewriteURL()
    {
        $link_ws = 'module-dropshipsystem-webservice';
        $langs = Language::getLanguages(false);

        $id_meta_ws = (int)$this->getIdMetaByPage($link_ws);
        if ($id_meta_ws) {
            foreach ($langs as $lang) {
                if (!Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('UPDATE `'._DB_PREFIX_.'meta_lang` SET `title` = \'Web Service\', `url_rewrite` = \'ws\' WHERE `id_meta` = '.(int)$id_meta_ws.' AND `id_lang` = '.(int)$lang['id_lang'])) {
                    return false;
                }
            }
        } else {
            if (Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('INSERT IGNORE INTO `'._DB_PREFIX_.'meta` (`page`) VALUES (\''.pSQL($link_ws).'\')')) {
                $id_meta_ws = (int)$this->getIdMetaByPage($link_ws);
                foreach ($langs as $lang) {
                    if (!Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('INSERT INTO `'._DB_PREFIX_.'meta_lang` (`id_meta`, `id_lang`, `title`, `url_rewrite`) VALUES ('.(int)$id_meta_ws.', '.(int)$lang['id_lang'].', \'Web Service\', \'ws\')')) {
                        return false;
                    }
                }
            } else {
                return false;
            }
        }

        $htaccess = array(dirname(__FILE__).'/downloads/.htaccess', dirname(__FILE__).'/downloads/clients/.htaccess');
        foreach ($htaccess as $hta) {
            if (!$write_fd = @fopen($hta, 'w')) {
                return false;
            }
            fwrite($write_fd, "Order Deny,Allow\n");
            fwrite($write_fd, "Deny from all\n\n");
            fwrite($write_fd, "# .htaccess automaticaly generated by DropShip System Server module\n");
            fclose($write_fd);
        }

        return true;
    }

    private function getIdMetaByPage($page)
    {
        $sql = 'SELECT `id_meta` FROM `'._DB_PREFIX_.'meta` WHERE `page` = "'.pSQL($page).'"';
        $row = Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow($sql);
        return $row['id_meta'];
    }

    private function uninstallRewriteURL()
    {
        $id_shop = (int)$this->context->shop->id;
        $id_meta_ws = (int)$this->getIdMetaByPage('module-dropshipsystem-webservice');
        $htaccess = dirname(__FILE__).'/../../.htaccess';

        if (!Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('DELETE FROM `'._DB_PREFIX_.'meta` WHERE `id_meta` = '.(int)$id_meta_ws)) {
            return false;
        }
        if (!Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('DELETE FROM `'._DB_PREFIX_.'meta_lang` WHERE `id_meta` = '.(int)$id_meta_ws)) {
            return false;
        }

        if (file_exists($htaccess)) {
            if (!Tools::generateHtaccess(
                $htaccess,
                (int)Configuration::get('PS_REWRITING_SETTINGS', null, null, $id_shop),
                (int)Configuration::get('PS_HTACCESS_CACHE_CONTROL', null, null, $id_shop),
                Configuration::get('PS_HTACCESS_SPECIFIC', null, null, $id_shop),
                (int)Configuration::get('PS_HTACCESS_DISABLE_MULTIVIEWS', null, null, $id_shop)
            )) {
                return false;
            }
        }

        return true;
    }

    public function createOrderState()
    {
        foreach (Shop::getShops(false) as $shop) {
            if (!Configuration::get('PS_OS_DROPSHIP', null, null, $shop['id_shop'])) {
                $orderState = new OrderState();
                $orderState->module_name = $this->name;
                $orderState->name = array();
                $orderState->template = array();
                foreach (Language::getLanguages(false) as $language) {
                    if (Tools::strtolower($language['iso_code']) == 'it') {
                        $orderState->name[$language['id_lang']] = 'In attesa di pagamento dropship';
                    } else {
                        $orderState->name[$language['id_lang']] = 'Waiting dropship payment';
                    }
                    $orderState->template[$language['id_lang']] = 'dss_order_conf';
                }
    
                $orderState->send_email = true;
                $orderState->color = '#ff9439';
                $orderState->hidden = false;
                $orderState->delivery = false;
                $orderState->logable = true;
                $orderState->invoice = false;
                $orderState->unremovable = true;
    
                if ($orderState->add()) {
                    $source = dirname(__FILE__).'/logo.gif';
                    $destination = dirname(__FILE__).'/../../img/os/'.(int)$orderState->id.'.gif';
                    @copy($source, $destination);
                } else {
                    return false;
                }
                Configuration::updateValue('PS_OS_DROPSHIP', (int)$orderState->id, false, null, $shop['id_shop']);
            }
            if (!Configuration::get('PS_OS_DROPSHIP_CREDIT_SUCCESS', null, null, $shop['id_shop'])) {
                $orderState = new OrderState();
                $orderState->module_name = $this->name;
                $orderState->name = array();
                $orderState->template = array();
                foreach (Language::getLanguages(false) as $language) {
                    if (Tools::strtolower($language['iso_code']) == 'it') {
                        $orderState->name[$language['id_lang']] = 'Credito caricato';
                    } else {
                        $orderState->name[$language['id_lang']] = 'Credit recharged';
                    }
                    $orderState->template[$language['id_lang']] = 'dss_credit_conf';
                }
    
                $orderState->send_email = true;
                $orderState->color = '#18b43a';
                $orderState->hidden = false;
                $orderState->delivery = true;
                $orderState->logable = true;
                $orderState->invoice = true;
                $orderState->unremovable = true;
    
                if ($orderState->add()) {
                    $source = dirname(__FILE__).'/logo.gif';
                    $destination = dirname(__FILE__).'/../../img/os/'.(int)$orderState->id.'.gif';
                    @copy($source, $destination);
                } else {
                    return false;
                }
                Configuration::updateValue('PS_OS_DROPSHIP_CREDIT_SUCCESS', (int)$orderState->id, false, null, $shop['id_shop']);
            }
        }

        $template_dir = dirname(__FILE__).'/mails/';
        foreach (Language::getLanguages(false) as $language) {
            $iso_code = $language['iso_code'];
            $templates = scandir($template_dir.$iso_code);
            foreach ($templates as $template) {
                if (!strncmp(strrev($template), 'lmth.', 5) || !strncmp(strrev($template), 'txt.', 4)) {
                    @copy($template_dir.$iso_code.'/'.$template, $template_dir.'../../../mails/'.$iso_code.'/'.$template);
                    foreach ($this->getAllThemes() as $theme) {
                        if (!file_exists($template_dir.'../../../themes/'.$theme->directory.'/mails')) {
                            @mkdir($template_dir.'../../../themes/'.$theme->directory.'/mails');
                        }
                        if (!file_exists($template_dir.'../../../themes/'.$theme->directory.'/mails/'.$iso_code)) {
                            @mkdir($template_dir.'../../../themes/'.$theme->directory.'/mails/'.$iso_code);
                        }
                        @copy($template_dir.$iso_code.'/'.$template, $template_dir.'../../../themes/'.$theme->directory.'/mails/'.$iso_code.'/'.$template);
                    }
                }
            }
        }
        return true;
    }

    public function getAllThemes()
    {
        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            return Theme::getThemes();
        } else {
            $theme_builder = new PrestaShop\PrestaShop\Core\Addon\Theme\ThemeManagerBuilder($this->context, Db::getInstance());
            $list = $theme_builder->buildRepository()->getList();
            $themes = array();
            foreach ($list as $theme) {
                $stdTheme = new stdClass();
                $stdTheme->directory = $theme->getName();
                $stdTheme->id = Tools::strtoupper($theme->getName());
                $themes[] = $stdTheme;
            }
            return $themes;
        }
    }

    private function createCustomerGroups()
    {
        $dss = new DssClass();

        $dss_groups = array(
            array('name' => 'Dropshipper 1', 'reduction' => 0, 'price_display_method' => 1, 'show_prices' => 1),
            array('name' => 'Dropshipper 2', 'reduction' => 0, 'price_display_method' => 1, 'show_prices' => 1),
            array('name' => 'Dropshipper 3', 'reduction' => 0, 'price_display_method' => 1, 'show_prices' => 1),
        );

        foreach (Shop::getShops(false) as $shop) {
            $id_def_lang = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $shop['id_shop']);

            foreach ($dss_groups as $dss_group) {
                $id_group = (int)$dss->getGroupIDByName((string)$dss_group['name'], $id_def_lang, $shop['id_shop']);

                if (isset($id_group) && $id_group) {
                    $group = new Group($id_group);
                } else {
                    $group = new Group();
                }

                $group->name[$id_def_lang] = (string)$dss_group['name'];
                $group->reduction = (float)round($dss_group['reduction'], 2);
                $group->price_display_method = (int)$dss_group['price_display_method'];
                $group->show_prices = (int)$dss_group['show_prices'];

                if (isset($id_group) && $id_group) {
                    if (!$group->update()) {
                        return false;
                    }
                } else {
                    if (!$group->add()) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    private function createCreditProducts()
    {
        $dss = new DssClass();

        $credits = array(
            array('price' => '1', 'reference' => 'drop_recharge_0', 'name' => 'Credit Recharge 1 (Only for test)', 'rewrite' => 'droprecharge1', 'active' => 0),
            array('price' => '100', 'reference' => 'drop_recharge_1', 'name' => 'Credit Recharge 100', 'rewrite' => 'droprecharge100', 'active' => 1),
            array('price' => '250', 'reference' => 'drop_recharge_2', 'name' => 'Credit Recharge 250', 'rewrite' => 'droprecharge250', 'active' => 1),
            array('price' => '500', 'reference' => 'drop_recharge_3', 'name' => 'Credit Recharge 500', 'rewrite' => 'droprecharge500', 'active' => 1),
            array('price' => '1000', 'reference' => 'drop_recharge_4', 'name' => 'Credit Recharge 1000', 'rewrite' => 'droprecharge1000', 'active' => 1),
            array('price' => '2000', 'reference' => 'drop_recharge_5', 'name' => 'Credit Recharge 2000', 'rewrite' => 'droprecharge2000', 'active' => 1),
            array('price' => '3000', 'reference' => 'drop_recharge_6', 'name' => 'Credit Recharge 3000', 'rewrite' => 'droprecharge3000', 'active' => 1),
            array('price' => '4000', 'reference' => 'drop_recharge_7', 'name' => 'Credit Recharge 4000', 'rewrite' => 'droprecharge4000', 'active' => 1),
            array('price' => '5000', 'reference' => 'drop_recharge_8', 'name' => 'Credit Recharge 5000', 'rewrite' => 'droprecharge5000', 'active' => 1),
        );

        $id_shop_list = Shop::getContextListShopID();
        foreach (Shop::getShops(false) as $shop) {
            $id_def_lang = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $shop['id_shop']);
            $id_category_default = (int)Configuration::get('PS_HOME_CATEGORY', null, null, $shop['id_shop']);

            $groups = array();
            foreach (Group::getGroups($id_def_lang, (int)$shop['id_shop']) as $group) {
                $groups[] = $group['id_group'];
            }

            $category = new Category();
            $category->name[$id_def_lang] = 'Dropship Credit Category';
            $category->link_rewrite[$id_def_lang] = 'dropship-credit-category';
            $category->is_root_category = false;
            $category->id_parent = $id_category_default;
            $category->groupBox = $groups;
            $category->active = 0;
            $category->doNotRegenerateNTree = 1;
            if ($category->add()) {
                $id_category_default = (int)$category->id;
            }

            $product_credits = array();
            foreach ($credits as $credit) {
                try {
                    $_product = $dss->getProductIDByReference($credit['reference'], $shop['id_shop']);
                    $id_product = (int)$_product['id_product'];

                    if (isset($id_product) && $id_product) {
                        $product = new Product($id_product);
                    } else {
                        $product = new Product();
                    }

                    $product->id_category_default = (int)$id_category_default;
                    $product->online_only = 1;
                    $product->quantity = 100000000;
                    $product->minimal_quantity = 1;
                    $product->price = (float)round($credit['price'], 6);
                    $product->id_tax_rules_group = 0;
                    $product->reference = pSQL($credit['reference']);
                    $product->active = (int)$credit['active'];
                    $product->available_for_order = 1;
                    $product->redirect_type = '404';
                    $product->out_of_stock = 2;
                    $product->visibility = 'none';
                    $product->is_virtual = 1;
                    $product->name[$id_def_lang] = (string)$credit['name'];
                    $product->link_rewrite[$id_def_lang] = (string)$credit['rewrite'];
                    if (isset($id_product) && $id_product) {
                        $product->update();

                        if (!$product->updateCategories(array($id_category_default), true)) {
                            $product->addToCategories(array($id_category_default));
                        }
                    } else {
                        if ($product->add()) {
                            $id_product = (int)$product->id;
                            $product->addToCategories(array($id_category_default));
                        }
                    }

                    StockAvailable::setQuantity((int)$id_product, 0, (int)$product->quantity, $id_shop_list);

                    $product_credits[] = array('reference' => (string)$credit['reference'], 'id_product' => (int)$id_product);
                } catch (Exception $e) {
                    $this->writeLog('ERROR: Error set credit products : '.$e->getMessage());
                    return false;
                }
            }
            Configuration::updateValue('DSS_CREDIT_PRODUCTS', serialize($product_credits), false, null, $shop['id_shop']);
        }
        Category::regenerateEntireNtree();

        return true;
    }

    private function createSuppliersManufacturersGroups()
    {
        foreach (Shop::getShops(false) as $shop) {
            $id_def_lang = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $shop['id_shop']);
            $groupdef = array(Configuration::get('PS_UNIDENTIFIED_GROUP', null, null, $shop['id_shop']), Configuration::get('PS_GUEST_GROUP', null, null, $shop['id_shop']), Configuration::get('PS_CUSTOMER_GROUP', null, null, $shop['id_shop']));
            foreach (Group::getGroups($id_def_lang, (int)$shop['id_shop']) as $group) {
                if (!in_array($group['id_group'], $groupdef)) {
                    foreach (Supplier::getSuppliers() as $supplier) {
                        if ((int)$supplier['id_supplier']) {
                            $dss_supplier = new DssSuppliersClass();
                            $existsupplier = $dss_supplier->existsSupplierGroup((int)$supplier['id_supplier'], (int)$shop['id_shop'], (int)$group['id_group']);
                            if (!$existsupplier) {
                                $dss_supplier->id_supplier = (int)$supplier['id_supplier'];
                                $dss_supplier->id_shop = (int)$shop['id_shop'];
                                $dss_supplier->group = (int)$group['id_group'];
                                $dss_supplier->save();
                            }
                        }
                    }
                    foreach (Manufacturer::getManufacturers() as $manufacturer) {
                        if ((int)$manufacturer['id_manufacturer']) {
                            $dss_manufacturer = new DssManufacturersClass();
                            $existmanufacturer = $dss_manufacturer->existsManufacturerGroup((int)$manufacturer['id_manufacturer'], (int)$shop['id_shop'], (int)$group['id_group']);
                            if (!$existmanufacturer) {
                                $dss_manufacturer->id_manufacturer = (int)$manufacturer['id_manufacturer'];
                                $dss_manufacturer->id_shop = (int)$shop['id_shop'];
                                $dss_manufacturer->group = (int)$group['id_group'];
                                $dss_manufacturer->save();
                            }
                        }
                    }
                }
            }
        }
        return true;
    }

    private function removeCreditProducts()
    {
        return true;
    }

    private function makeHTAccessFile()
    {
        $htaccess = array(dirname(__FILE__).'/downloads/.htaccess', dirname(__FILE__).'/downloads/clients/.htaccess');
        foreach ($htaccess as $hta) {
            if (!file_exists($hta)) {
                if (!$write_fd = @fopen($hta, 'w')) {
                    return false;
                }
                fwrite($write_fd, "Order Deny,Allow\n");
                fwrite($write_fd, "Deny from all\n\n");
                fwrite($write_fd, "# .htaccess automaticaly generated by DropShip System Server module\n");
                fclose($write_fd);
            }
        }
        return true;
    }

    public function updateHookPosition($hook_name, $way, $position)
    {
        $id_hook = Hook::getIdByName($hook_name);
        return $this->updatePosition($id_hook, $way, $position);
    }

    public function getContent()
    {
        Tools::redirectAdmin(
            $this->context->link->getAdminLink('AdminDropShipConfig', true)
        );
        parent::getContent();
    }

    public function renderDashConfigForm()
    {
        $id_shop = (int)$this->context->shop->id;

        $fields_form = array(
            'form' => array(
                'input' => array(),
                'submit' => array(
                    'title' => $this->l('Save'),
                    'class' => 'btn btn-default pull-right submit_dash_config',
                    'reset' => array(
                        'title' => $this->l('Cancel'),
                        'class' => 'btn btn-default cancel_dash_config',
                    )
                )
            ),
        );

        $inputs = array(
//            array(
//              'type' => 'checkboxlist',
//              'label' => $this->l('Default filters'),
//              'config_name' => 'DSS_FILTER'
//            ),
            array(
                'type' => 'select',
                'label' => $this->l('Number of events to display'),
                'config_name' => 'DSS_NBR_SHOW_EVENTS'
            ),
            array(
                'type' => 'select',
                'label' => $this->l('Number of "Recent Dropship Orders" to display'),
                'config_name' => 'DSS_NBR_SHOW_LAST_ORDER'
            ),
            array(
                'type' => 'select',
                'label' => $this->l('Number of "Best Dropshippers" to display'),
                'config_name' => 'DSS_NBR_SHOW_BEST_DROPSHIPPERS'
            ),
        );

        $filters = array();
        $filters[] = array('id' => 'INFO', 'type' => 'info',  'name' => $this->l('Info'));
        $filters[] = array('id' => 'ALERT', 'type' => 'alert', 'name' => $this->l('Alert'));
        $filters[] = array('id' => 'ERROR', 'type' => 'error', 'name' => $this->l('Error'));

        foreach ($inputs as $input) {
            if ($input['type'] == 'checkboxlist') {
                $fields_form['form']['input'][] = array(
                    'type' => 'checkboxlist',
                    'label' => $input['label'],
                    'name' => $input['config_name'],
                    'values' => array(
                        'query' => $filters,
                        'id' => 'id',
                        'name' => 'name',
                        'type' => 'type'
                    )
                );
            } elseif ($input['type'] == 'select') {
                $fields_form['form']['input'][] = array(
                    'type' => 'select',
                    'label' => $input['label'],
                    'name' => $input['config_name'],
                    'options' => array(
                        'query' => array(
                            array('id' => 5, 'name' => 5),
                            array('id' => 10, 'name' => 10),
                            array('id' => 20, 'name' => 20),
                            array('id' => 50, 'name' => 50),
                        ),
                        'id' => 'id',
                        'name' => 'name',
                    )
                );
            }
        }

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table =  $this->table;
        $helper->module = $this;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', null, null, $id_shop) ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', null, null, $id_shop) : 0;
        $this->fields_form = array();
        $helper->id = (int)Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitDashConfig';
        $helper->tpl_vars = array(
            'fields_value' => $this->getDashConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form));
    }

    public function getTableEvents()
    {
        $id_shop = (int)$this->context->shop->id;

        $header = array(
            array('title' => $this->l('Date'), 'class' => 'text-left'),
            array('title' => $this->l('Type'), 'class' => 'text-center'),
            array('title' => $this->l('Message'), 'class' => 'text-left'),
        );

        $limit = (int)Configuration::get('DSS_NBR_SHOW_EVENTS', null, null, $id_shop) ? (int)Configuration::get('DSS_NBR_SHOW_EVENTS', null, null, $id_shop) : 10;

        $sql = 'SELECT `ev`.*, `e`.`firstname`, `e`.`lastname` 
                FROM `'._DB_PREFIX_.'dss_events` `ev` 
                '.Shop::addSqlAssociation('dss_events', 'ev').'
                LEFT JOIN `'._DB_PREFIX_.'employee` `e` ON (`e`.`id_employee` = `ev`.`handled_by`) 
                '.Shop::addSqlAssociation('employee', 'e', false).'
                WHERE `ev`.`type` = \''.((int)Configuration::get('DSS_FILTER_INFO', null, null, $id_shop) ? 'info' : 'none').'\' 
                OR `ev`.`type` = \''.((int)Configuration::get('DSS_FILTER_ALERT', null, null, $id_shop) ? 'alert' : 'none').'\' 
                OR `ev`.`type` = \''.((int)Configuration::get('DSS_FILTER_ERROR', null, null, $id_shop) ? 'error' : 'none').'\' 
                ORDER BY `ev`.`date` DESC '.((int)$limit ? 'LIMIT 0, '.(int)$limit : '');

        $events = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        $body = array();
        foreach ($events as $event) {
            if ($event['type'] == 'info') {
                $type_desc = $this->l('Info');
                $type_class = 'label-info';
            } elseif ($event['type'] == 'alert') {
                $type_desc = $this->l('Alert');
                $type_class = 'label-warning';
            } elseif ($event['type'] == 'error') {
                $type_desc = $this->l('Error');
                $type_class = 'label-danger';
            }

            $tr = array();
            $tr[] = array(
                'id' => 'date',
                'value' => '<a href="'.$event['link'].'">'.$event['date'].'</a>',
                'class' => 'fixed-width-xl text-left',
            );
            $tr[] = array(
                'id' => 'type',
                'value' => (string)$type_desc,
                'class' => 'fixed-width-sm text-center',
                'wrapper_start' => '<span class="label '.$type_class.'">',
                'wrapper_end' => '<span>',
            );
            $tr[] = array(
                'id' => 'message',
                'value' => $event['message'],
                'class' => 'text-left',
            );

            $body[] = $tr;
        }

        return array('header' => $header, 'body' => $body);
    }

    public function getTableRecentOrders()
    {
        $id_shop = (int)$this->context->shop->id;

        $header = array(
            array('title' => $this->l('Customer Name'), 'class' => 'text-left'),
            array('title' => $this->l('Products'), 'class' => 'text-center'),
            array('title' => $this->l('Total').' '.$this->l('Tax excl.'), 'class' => 'text-center'),
            array('title' => $this->l('Date'), 'class' => 'text-center'),
            array('title' => $this->l('Status'), 'class' => 'text-center'),
            array('title' => '', 'class' => 'text-right'),
        );

        $limit = (int)Configuration::get('DSS_NBR_SHOW_LAST_ORDER', null, null, $id_shop) ? (int)Configuration::get('DSS_NBR_SHOW_LAST_ORDER', null, null, $id_shop) : 10;
        
        $sql = 'SELECT *, (
                    SELECT osl.`name`
                    FROM `'._DB_PREFIX_.'order_state_lang` osl
                    WHERE osl.`id_order_state` = o.`current_state`
                    AND osl.`id_lang` = '.(int)$this->context->language->id.'
                    LIMIT 1
                ) AS `state_name`, o.`date_add` AS `date_add`, o.`date_upd` AS `date_upd`
                FROM `'._DB_PREFIX_.'orders` o
                INNER JOIN `'._DB_PREFIX_.'dss_order` do ON (do.`id_order` = o.`id_order`)
                LEFT JOIN `'._DB_PREFIX_.'customer` c ON (c.`id_customer` = o.`id_customer`)
                WHERE 1
                    '.Shop::addSqlRestriction(false, 'o').'
                ORDER BY o.`date_add` DESC
                '.((int)$limit ? 'LIMIT 0, '.(int)$limit : '');

        $orders = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        $body = array();
        foreach ($orders as $order) {
            $currency = Currency::getCurrency((int)$order['id_currency']);
            $tr = array();
            $tr[] = array(
                'id' => 'firstname_lastname',
                'value' => '<a href="'.$this->context->link->getAdminLink('AdminCustomers', true).'&id_customer='.$order['id_customer'].'&viewcustomer">'.Tools::htmlentitiesUTF8($order['firstname']).' '.Tools::htmlentitiesUTF8($order['lastname']).'</a>',
                'class' => 'text-left',
            );
            $tr[] = array(
                'id' => 'total_products',
                'value' => count(OrderDetail::getList((int)$order['id_order'])),
                'class' => 'text-center',
            );
            $tr[] = array(
                'id' => 'total_paid',
                'value' => Tools::displayPrice((float)$order['total_paid'], $currency),
                'class' => 'text-center',
                'wrapper_start' => $order['valid'] ? '<span class="badge badge-success">' : '',
                'wrapper_end' => '<span>',
            );
            $tr[] = array(
                'id' => 'date_add',
                'value' => Tools::displayDate($order['date_add']),
                'class' => 'text-center',
            );
            $tr[] = array(
                'id' => 'status',
                'value' => Tools::htmlentitiesUTF8($order['state_name']),
                'class' => 'text-center',
            );
            $tr[] = array(
                'id' => 'details',
                'value' => '',
                'class' => 'text-right',
                'wrapper_start' => '<a class="btn btn-default" href="index.php?tab=AdminOrders&id_order='.(int)$order['id_order'].'&vieworder&token='.Tools::getAdminTokenLite('AdminOrders').'" title="'.$this->l('Details').'"><i class="icon-search"></i>',
                'wrapper_end' => '</a>'
            );

            $body[] = $tr;
        }

        return array('header' => $header, 'body' => $body);
    }

    public function getTableBestDropshippers($date_from, $date_to)
    {
        $id_shop = (int)$this->context->shop->id;

        $header = array(
            array(
                'id' => 'customer',
                'title' => $this->l('Customer'),
                'class' => 'text-left',
            ),
            array(
                'id' => 'total_orders',
                'title' => $this->l('Orders'),
                'class' => 'text-center',
            ),
            array(
                'id' => 'total_products',
                'title' => $this->l('Products'),
                'class' => 'text-center',
            ),
            array(
                'id' => 'sales',
                'title' => $this->l('Sales'),
                'class' => 'text-center',
            ),
            array(
                'id' => 'net_profit',
                'title' => $this->l('Net profit'),
                'class' => 'text-center',
            )
        );

        $sql = 'SELECT DISTINCT
                c.`id_customer`,
                COALESCE(c.`company`, c.`lastname` + " " + c.`firstname`) AS customer_name,
                COUNT(dsso.`id_dss_order`) as total_orders,
                SUM((SELECT SUM(`product_quantity`) 
                FROM `'._DB_PREFIX_.'order_detail`
                WHERE `id_order` = o.`id_order`)) as total_products,
                SUM(o.`total_products` / o.`conversion_rate`) as sales,
                SUM((SELECT SUM(`product_quantity` * `purchase_supplier_price` / o.`conversion_rate`)
                FROM `'._DB_PREFIX_.'order_detail`
                WHERE `id_order` = o.`id_order`)) as expenses
            FROM `'._DB_PREFIX_.'dss_order` dsso
            INNER JOIN `'._DB_PREFIX_.'orders` o ON dsso.`id_order` = o.`id_order`
            LEFT JOIN `'._DB_PREFIX_.'customer` c ON c.`id_customer` = o.`id_customer`
            WHERE o.`invoice_date` BETWEEN "'.pSQL($date_from).' 00:00:00" AND "'.pSQL($date_to).' 23:59:59"
            AND o.`valid` = 1
            '.Shop::addSqlRestriction(false, 'o').'
            GROUP BY c.`id_customer`
            ORDER BY `total_products` DESC
            LIMIT '.(int)Configuration::get('DSS_NBR_SHOW_BEST_DROPSHIPPERS', null, null, $id_shop);

        $customers = Db::getInstance()->ExecuteS($sql);

        $body = array();
        foreach ($customers as $customer) {
            $customer_obj = new Customer((int)$customer['id_customer'], false, $this->context->language->id);
            if (!Validate::isLoadedObject($customer_obj)) {
                continue;
            }

            $body[] = array(
                array(
                    'id' => 'customer',
                    'value' => '<a href="'.$this->context->link->getAdminLink('AdminCustomers', true).'&id_customer='.$customer_obj->id.'&viewcustomer">'.Tools::htmlentitiesUTF8($customer['customer_name']).'</a>',
                    'class' => 'text-center'
                ),
                array(
                    'id' => 'total_orders',
                    'value' => (int)$customer['total_orders'],
                    'class' => 'text-center'
                ),
                array(
                    'id' => 'total_products',
                    'value' => (int)$customer['total_products'],
                    'class' => 'text-center'
                ),
                array(
                    'id' => 'sales',
                    'value' => Tools::displayPrice($customer['sales']),
                    'class' => 'text-center'
                ),
                array(
                    'id' => 'net_profit',
                    'value' => Tools::displayPrice($customer['sales'] - $customer['expenses']),
                    'class' => 'text-center'
                )
            );
        }

        return array('header' => $header, 'body' => $body);
    }

    public function getDashConfigFieldsValues()
    {
        $id_shop = (int)$this->context->shop->id;

        return array(
            'DSS_FILTER_INFO' => (int)Configuration::get('DSS_FILTER_INFO', null, null, $id_shop),
            'DSS_FILTER_ALERT' => (int)Configuration::get('DSS_FILTER_ALERT', null, null, $id_shop),
            'DSS_FILTER_ERROR' => (int)Configuration::get('DSS_FILTER_ERROR', null, null, $id_shop),
            'DSS_NBR_SHOW_EVENTS' => (int)Configuration::get('DSS_NBR_SHOW_EVENTS', null, null, $id_shop),
            'DSS_NBR_SHOW_LAST_ORDER' => (int)Configuration::get('DSS_NBR_SHOW_LAST_ORDER', null, null, $id_shop),
            'DSS_NBR_SHOW_BEST_DROPSHIPPERS' => (int)Configuration::get('DSS_NBR_SHOW_BEST_DROPSHIPPERS', null, null, $id_shop),
        );
    }

    public function clearSmartyCache()
    {
        Tools::enableCache();
        Tools::clearCache($this->context->smarty);
        Tools::restoreCacheSettings();
    }

    public function cronTask()
    {
        $ret = 0;
        $dss = new DssClass();
        $ret = $dss->doCatalogs();

        return $ret;
    }

    private function searchArray($id_product, $array)
    {
        $ret = false;
        if (isset($array) && is_array($array)) {
            foreach ($array as $arr) {
                if ((int)$id_product == $arr['id_product']) {
                    $ret = true;
                    break;
                }
            }
        }
        return (bool)$ret;
    }

    private function updateCreditProducts($params)
    {
        if ($this->context->controller->controller_type == 'admin' && $this->context->controller->controller_name == 'AdminProducts') {
            $id_shop = (int)$this->context->shop->id;
            $id_product = (int)$params['id_product'];
            $is_credit_product = (int)Tools::getValue('is_credit_product');
            $groups = Tools::getValue('groupBox');
            $product_credits = unserialize(Configuration::get('DSS_CREDIT_PRODUCTS', null, null, $id_shop));

            if (isset($groups) && $groups) {
                foreach ($groups as $group) {
                    $dss_groups = new DssProductGroupsClass();
                    $dss_group_exist = $dss_groups->existsProductGroup((int)$id_product, (int)$group);
                    if ($dss_group_exist) {
                        continue;
                    }
                    $dss_groups->id_product = (int)$id_product;
                    $dss_groups->id_shop = (int)$id_shop;
                    $dss_groups->group = (int)$group;
                    $dss_groups->add();
                }
            }
            DssProductGroupsClass::clearProductGroups((int)$id_product, $groups);

            if ($is_credit_product) {
                if (!$this->searchArray((int)$id_product, $product_credits)) {
                    $product_credits[] = array('reference' => (string)$params['product']->reference, 'id_product' => (int)$id_product);
                }
            } else {
                if ($this->searchArray((int)$id_product, $product_credits)) {
                    $arr = array();
                    foreach ($product_credits as $product_credit) {
                        if ((int)$product_credit['id_product'] != (int)$id_product) {
                            $arr[] = array('reference' => (string)$product_credit['reference'], 'id_product' => (int)$product_credit['id_product']);
                        }
                    }
                    $product_credits = $arr;
                }
            }
            Configuration::updateValue('DSS_CREDIT_PRODUCTS', serialize(array_unique($product_credits, SORT_REGULAR)), false, null, $id_shop);
        }
    }

    public function getXmlRss()
    {
        //$id_shop = (int)$this->context->shop->id;
        $id_lang = (int)$this->context->language->id;

        $_news = array();
        $response = DssClass::getData();

        if (!empty($response)) {
            $doc = new DOMDocument('1.0', 'UTF-8');
            @$doc->loadXML($response);

            $version = isset($doc->getElementsByTagName('version')->item(0)->nodeValue) ? $doc->getElementsByTagName('version')->item(0)->nodeValue : $this->version;
            $newslist = $doc->getElementsByTagName('news');

            if (version_compare($this->version, $version, '<')) {
                Configuration::updateValue('DSS_NEW_VERSION', $version);
            }
            $i = 0;
            $suffix = ($this->context->language->iso_code == 'it') ? 'it' : 'en';
            $max_date = date('d/m/Y');
            foreach ($newslist as $news) {
                $date = $news->getElementsByTagName('date')->item(0)->nodeValue;
                $title = $news->getElementsByTagName('title_'.$suffix)->item(0)->nodeValue;
                $text = $news->getElementsByTagName('text_'.$suffix)->item(0)->nodeValue;

                $_news[] = array(
                    'isnew' => ((empty($this->context->cookie->dss_news) || $this->context->cookie->dss_news <= $date) ? true : false),
                    'date' => Tools::displayDate($date, $id_lang),
                    'title' => $title,
                    'text' => nl2br($text)
                );

                if ($i == 0) {
                    $max_date = $date;
                    $i++;
                }
            }

            $this->context->smarty->assign(array(
                'news' => $_news,
            ));

            $html = $this->context->smarty->fetch(dirname(__FILE__).'/views/templates/admin/news.tpl');

            $this->context->cookie->dss_news = $max_date.' 00:00:00';
            
            return $html;
        }
        return '';
    }

    /* HOOKS */
    public function hookActionAdminControllerSetMedia($params)
    {
        unset($params);
        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            if (Tools::getIsset('updateproduct') || Tools::getIsset('addproduct')) {
                //$this->context->controller->addJqueryUi('ui.sortable');
                $this->context->controller->addJS($this->_path.'views/js/wholesale_prices16.js');
            }
        } else {
            if ($this->context->controller->controller_name == 'AdminProducts') {
                $this->context->controller->addJS($this->_path.'views/js/wholesale_prices17.js');
            }
        }
    }

    public function hookDisplayBackOfficeHeader($params)
    {
        $id_shop = (int)$this->context->shop->id;

        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            $this->context->controller->addCSS($this->_path.'views/css/font-awesome/font-awesome.css', 'all');
            $this->context->controller->addCSS($this->_path.'views/css/dss_admin.css', 'all');
        } else {
            $this->context->controller->addCSS($this->_path.'views/css/dss_admin17.css', 'all');
        }

        $this->context->controller->addJquery();
        if (Tools::getValue('controller') == 'AdminManufacturers' ||
            Tools::getValue('controller') == 'AdminSuppliers') {
            $this->context->controller->addJS($this->_path.'views/js/groups.js');
        }
        if ((int)Configuration::get('DSS_NOTIFY_DROPSHIPPERS', null, null, $id_shop) == 1) {
            Media::addJsDef(array(
                'dss_notif_token' => Tools::getAdminTokenLite('AdminDropShipConfig'),
                'dss_notif_url' => $this->context->link->getAdminLink('AdminDropShipConfig'),
            ));
            if (version_compare(_PS_VERSION_, '1.7', '<')) {
                $this->context->controller->addJS($this->_path.'views/js/notification.js');
            } else {
                if (defined('_PS_BO_DEFAULT_THEME_') && _PS_BO_DEFAULT_THEME_
                    && @filemtime(_PS_BO_ALL_THEMES_DIR_._PS_BO_DEFAULT_THEME_.DIRECTORY_SEPARATOR.'template')) {
                    $default_theme_name = _PS_BO_DEFAULT_THEME_;
                }
                if (!@filemtime(_PS_BO_ALL_THEMES_DIR_.$default_theme_name.DIRECTORY_SEPARATOR.'template')) {
                    $default_theme_name = 'default';
                }
                if (defined('_PS_ADMIN_DIR_')) {
                    $admin_webpath = str_ireplace(_PS_CORE_DIR_, '', _PS_ADMIN_DIR_);
                    $admin_webpath = preg_replace('/^'.preg_quote(DIRECTORY_SEPARATOR, '/').'/', '', $admin_webpath);
                }
                $this->context->controller->addCSS($this->_path.'views/css/bootstrap/dss-bootstrap.css', 'all');
                $this->context->controller->addJS(__PS_BASE_URI__.$admin_webpath.'/themes/'.$default_theme_name.'/js/vendor/moment-with-langs.min.js');
                $this->context->controller->addJS($this->_path.'views/js/notification17.js');
            }
        }
    }

    public function hookHeader($params)
    {
        $this->context->controller->addCSS($this->_path.'views/css/bootstrap/dss-bootstrap.css', 'all');
        $this->context->controller->addCSS($this->_path.'views/css/font-awesome/font-awesome.css', 'all');
        $this->context->controller->addJS($this->_path.'views/js/bootstrap/bootstrap.min.js');

        if ($this->context->controller->php_self == 'product' || (isset($this->context->controller->page_name) && $this->context->controller->page_name == 'module-dropshipsystem-mydropshipaccount')) {
            Media::addJsDef(array(
                'token' => Tools::getToken(false),
                'dss_ajaxurl' => $this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount', array(), true),
            ));
            if (version_compare(_PS_VERSION_, '1.7', '<')) {
                $this->context->controller->addJS($this->_path.'views/js/cart16.js');
            } else {
                $this->context->controller->addJS($this->_path.'views/js/cart17.js');
            }
        }

        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            $this->context->controller->addCSS($this->_path.'views/css/dss.css', 'all');
        } else {
            $this->context->controller->addCSS($this->_path.'views/css/dss17.css', 'all');
        }

        Media::addJsDef(array(
            'dropship_link' => $this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount'),
        ));
    }

    public function hookDashboardData($params)
    {
        $table_events = $this->getTableEvents();
        $table_recent_orders = $this->getTableRecentOrders();
        $table_best_dropshippers = $this->getTableBestDropshippers($params['date_from'], $params['date_to']);

        $messages = $this->getXmlRss();

        return array(
            'data_table' => array(
                'dss_table_events' => $table_events,
                'dss_table_recent_orders' => $table_recent_orders,
                'dss_table_best_dropshippers' => $table_best_dropshippers,
            ),
            'data_value' => array(
                'messages' => $messages,
            )
        );
    }

    public function hookDashboardZoneTwo($params)
    {
        $id_shop = (int)$this->context->shop->id;

        $this->context->smarty->assign(
            array(
                'DSS_FILTER_INFO' => (int)Configuration::get('DSS_FILTER_INFO', null, null, $id_shop),
                'DSS_FILTER_ALERT' => (int)Configuration::get('DSS_FILTER_ALERT', null, null, $id_shop),
                'DSS_FILTER_ERROR' => (int)Configuration::get('DSS_FILTER_ERROR', null, null, $id_shop),
                'DSS_NBR_SHOW_EVENTS' => (int)Configuration::get('DSS_NBR_SHOW_EVENTS', null, null, $id_shop),
                'DSS_NBR_SHOW_LAST_ORDER' => (int)Configuration::get('DSS_NBR_SHOW_LAST_ORDER', null, null, $id_shop),
                'DSS_NBR_SHOW_BEST_DROPSHIPPERS' => (int)Configuration::get('DSS_NBR_SHOW_BEST_DROPSHIPPERS', null, null, $id_shop),
                'date_from' => Tools::displayDate($params['date_from']),
                'date_to' => Tools::displayDate($params['date_to']),
                'dss_ajaxurl' => $this->context->link->getAdminLink('AdminDropShipConfig'),
                'dss_token' => Tools::getAdminTokenLite('AdminDropShipConfig'),
                'dssdash_config_form' => $this->renderDashConfigForm(),
            )
        );
        $this->context->controller->addJS($this->_path.'views/js/dashboard.js');

        return $this->display(__FILE__, 'dashboard_zone_two.tpl');
    }

    public function hookDisplayAdminAfterHeader()
    {
        $id_shop = (int)$this->context->shop->id;
        if ((int)Configuration::get('DSS_NOTIFY_DROPSHIPPERS', null, null, $id_shop) == 1) {
            if (version_compare(_PS_VERSION_, '1.7', '<')) {
                return $this->display(__FILE__, 'header_badge.tpl');
            } else {
                return $this->display(__FILE__, '1.7/header_badge.tpl');
            }
        }
    }

    public function hookDisplayAdminProductsExtra($params)
    {
        if (!isset($params['id_product'])) {
            $id_product = (int)Tools::getValue('id_product');
        } else {
            $id_product = (int)$params['id_product'];
        }

        if (version_compare(_PS_VERSION_, '1.7', '>=') === true) {
            $tpl1 = $this->context->smarty->createTemplate(
                dirname(__FILE__).'/views/templates/hook/1.7/product_extra.tpl'
            );
        } else {
            $tpl1 = $this->context->smarty->createTemplate(
                dirname(__FILE__).'/views/templates/hook/product_wholesale_prices.tpl'
            );
            $tpl2 = $this->context->smarty->createTemplate(
                dirname(__FILE__).'/views/templates/hook/product_extra.tpl'
            );
        }

        $product = new Product((int)$id_product);

        if ($product->id) {
            $id_shop = (int)$this->context->shop->id;
            $shops = Shop::getShops();
            $countries = Country::getCountries($this->context->language->id);
            $currencies = Currency::getCurrencies();
            $attributes = $product->getAttributesGroups((int)$this->context->language->id);

            $groups = array();
            $psgroups = Group::getGroups($this->context->language->id, $id_shop);
            $groupdef = array(Configuration::get('PS_UNIDENTIFIED_GROUP', null, null, $id_shop), Configuration::get('PS_GUEST_GROUP', null, null, $id_shop), Configuration::get('PS_CUSTOMER_GROUP', null, null, $id_shop));
            foreach ($psgroups as $group) {
                if (!in_array($group['id_group'], $groupdef)) {
                    $groups[] = array('id_group' => $group['id_group'], 'name' => $group['name']);
                }
            }

            $product_credits = unserialize(Configuration::get('DSS_CREDIT_PRODUCTS', null, null, $id_shop));

            $is_credit_product = 0;
            if ($this->searchArray($id_product, $product_credits)) {
                $is_credit_product = 1;
            }

            $selected_groups = array();
            $exlgrps = DssProductGroupsClass::getProductGroups((int)$id_product);
            foreach ($groups as $group) {
                $id_group = (int)$group['id_group'];
                foreach ($exlgrps as $exlgrp) {
                    if ((int)$exlgrp['group'] == (int)$id_group) {
                        $selected_groups[$id_group] = 1;
                        continue;
                    }
                }
            }

            $combinations = array();
            foreach ($attributes as $attribute) {
                $combinations[$attribute['id_product_attribute']]['id_product_attribute'] = $attribute['id_product_attribute'];
                if (!isset($combinations[$attribute['id_product_attribute']]['attributes'])) {
                    $combinations[$attribute['id_product_attribute']]['attributes'] = '';
                }
                $combinations[$attribute['id_product_attribute']]['attributes'] .= $attribute['attribute_name'].' - ';

                $combinations[$attribute['id_product_attribute']]['price'] = Tools::displayPrice(
                    Tools::convertPrice(
                        Product::getPriceStatic((int)$product->id, false, $attribute['id_product_attribute']),
                        $this->context->currency
                    ),
                    $this->context->currency
                );
            }
            foreach ($combinations as &$combination) {
                $combination['attributes'] = rtrim($combination['attributes'], ' - ');
            }

            if (version_compare(_PS_VERSION_, '1.7', '>=') === true) {
                //$tpl1->assign('specificWholesalePriceModificationForm', $this->_displaySpecificWholesalePriceModificationForm17(
                //    $product, $this->context->currency, $shops, $currencies, $countries, $groups)
                //);
                $tpl1->assign(array(
                    'id_product' => (int)$id_product,
                    'is_credit_product' => (int)$is_credit_product,
                    'shops' => $shops,
                    'admin_one_shop' => count($this->context->employee->getAssociatedShops()) == 1,
                    'currencies' => $currencies,
                    'countries' => $countries,
                    'groups' => $groups,
                    'combinations' => $combinations,
                    'multi_shop' => Shop::isFeatureActive(),
                    'base_url' => __PS_BASE_URI__,
                    'selected_groups' => $selected_groups,
                    'dss_products_url' => 'index.php?controller=AdminProducts&token='.Tools::getAdminTokenLite('AdminProducts'),
                    'dss_ajaxurl' => $this->context->link->getAdminLink('AdminDropShipSpecificWholesalePriceRule'),
                    'dss_token' => Tools::getAdminTokenLite('AdminDropShipSpecificWholesalePriceRule')
                ));

                return $tpl1->fetch();
            } else {
                $tpl1->assign(array(
                    'specificWholesalePriceModificationForm' => $this->_displaySpecificWholesalePriceModificationForm($product, $this->context->currency, $shops, $currencies, $countries, $groups),
                    'id_product' => (int)$id_product,
                    'shops' => $shops,
                    'admin_one_shop' => count($this->context->employee->getAssociatedShops()) == 1,
                    'currencies' => $currencies,
                    'countries' => $countries,
                    'groups' => $groups,
                    'combinations' => $combinations,
                    'multi_shop' => Shop::isFeatureActive(),
                    'base_url' => __PS_BASE_URI__,
                ));

                $tpl2->assign(array(
                    'id_product' => (int)$id_product,
                    'is_credit_product' => (int)$is_credit_product,
                    'groups' => $groups,
                    'selected_groups' => $selected_groups,
                    'base_url' => __PS_BASE_URI__,
                    'dss_back_link' => $this->context->link->getAdminLink('AdminProducts'),
                ));

                return $tpl1->fetch().$tpl2->fetch();
            }
        } else {
            if (version_compare(_PS_VERSION_, '1.7', '>=') === true) {
                $tpl1->assign(array('id_product' => 0));

                return $tpl1->fetch();
            } else {
                $tpl1->assign(array('id_product' => 0));
                $tpl2->assign(array('id_product' => 0));

                return $tpl1->fetch().$tpl2->fetch();
            }
        }
    }

    protected function _displaySpecificWholesalePriceModificationForm($product, $defaultCurrency, $shops, $currencies, $countries, $groups)
    {
        $page = (int)Tools::getValue('page');
        $content = '';
        $specific_prices = DssSpecificWholesalePriceClass::getByProductId((int)$product->id);

        $tmp = array();
        foreach ($shops as $shop) {
            $tmp[$shop['id_shop']] = $shop;
        }
        $shops = $tmp;
        $tmp = array();
        foreach ($currencies as $currency) {
            $tmp[$currency['id_currency']] = $currency;
        }
        $currencies = $tmp;

        $tmp = array();
        foreach ($countries as $country) {
            $tmp[$country['id_country']] = $country;
        }
        $countries = $tmp;

        $tmp = array();
        foreach ($groups as $group) {
            $tmp[$group['id_group']] = $group;
        }
        $groups = $tmp;

        $length_before = Tools::strlen($content);
        if (is_array($specific_prices) && count($specific_prices)) {
            $i = 0;
            foreach ($specific_prices as $specific_price) {
                $id_currency = $specific_price['id_currency'] ? $specific_price['id_currency'] : $defaultCurrency->id;
                if (!isset($currencies[$id_currency])) {
                    continue;
                }

                if ($specific_price['value'] <> 0) {
                    $value = $specific_price['value'].' %';
                } else {
                    $value = '--';
                }

                if ($specific_price['from'] == '0000-00-00 00:00:00' && $specific_price['to'] == '0000-00-00 00:00:00') {
                    $period = $this->l('Unlimited');
                } else {
                    $period = $this->l('From').' '.($specific_price['from'] != '0000-00-00 00:00:00' ? $specific_price['from'] : '0000-00-00 00:00:00').'<br />'.$this->l('To').' '.($specific_price['to'] != '0000-00-00 00:00:00' ? $specific_price['to'] : '0000-00-00 00:00:00');
                }
                if ($specific_price['id_product_attribute']) {
                    $combination = new Combination((int)$specific_price['id_product_attribute']);
                    $attributes = $combination->getAttributesName((int)$this->context->language->id);
                    $attributes_name = '';
                    foreach ($attributes as $attribute) {
                        $attributes_name .= $attribute['name'].' - ';
                    }
                    $attributes_name = rtrim($attributes_name, ' - ');
                } else {
                    $attributes_name = $this->l('All combinations');
                }

                if (!$specific_price['id_shop'] || in_array($specific_price['id_shop'], Shop::getContextListShopID())) {
                    $content .= '
					<tr '.($i % 2 ? 'class="alt_row"' : '').'>
						<td>'.$attributes_name.'</td>';

                    $can_delete_specific_prices = true;
                    if (Shop::isFeatureActive()) {
                        $id_shop_swp = $specific_price['id_shop'];
                        $can_delete_specific_prices = (count($this->context->employee->getAssociatedShops()) > 1 && !$id_shop_swp) || $id_shop_swp;
                        $content .= '
						<td>'.($id_shop_swp ? $shops[$id_shop_swp]['name'] : $this->l('All shops')).'</td>';
                    }
                    $content .= '
						<td>'.($specific_price['id_currency'] ? $currencies[$specific_price['id_currency']]['name'] : $this->l('All currencies')).'</td>
						<td>'.($specific_price['id_country'] ? $countries[$specific_price['id_country']]['name'] : $this->l('All countries')).'</td>
						<td>'.($specific_price['id_group'] ? $groups[$specific_price['id_group']]['name'] : $this->l('All groups')).'</td>
						<td>'.number_format($value, 2, '.', ' ').' %</td>
						<td>'.$period.'</td>
						<td>'.($can_delete_specific_prices ? '<a class="btn btn-default" name="delete_link" href="index.php?tab=AdminProducts&id_product='.(int)Tools::getValue('id_product').'&action=deleteSpecificWholesalePrice&id_specific_wholesale_price='.(int)($specific_price['id_dss_specific_wholesale_price']).'&token='.Tools::getValue('token').'"><i class="icon-trash"></i></a>' : '').'</td>
					</tr>';
                    $i++;
                }
            }
        }

        if ($length_before === Tools::strlen($content)) {
            $content .= '
				<tr>
					<td class="text-center" colspan="13"><i class="icon-warning-sign"></i>&nbsp;'.$this->l('No specific prices.').'</td>
				</tr>';
        }

        $content .= '
				</tbody>
			</table>
			</div>
			<div class="panel-footer">
				<a href="'.$this->context->link->getAdminLink('AdminProducts').($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '').'" class="btn btn-default"><i class="process-icon-cancel"></i> '.$this->l('Cancel').'</a>
				<button id="product_form_submit_btn"  type="submit" name="submitAddproduct" class="btn btn-default pull-right" disabled="disabled"><i class="process-icon-loading"></i> '.$this->l('Save') .'</button>
				<button id="product_form_submit_btn"  type="submit" name="submitAddproductAndStay" class="btn btn-default pull-right" disabled="disabled"><i class="process-icon-loading"></i> '.$this->l('Save and stay') .'</button>
			</div>
		</div>';

        $content .= '
		<script type="text/javascript">
			var currencies = new Array();
			currencies[0] = new Array();
			currencies[0]["sign"] = "'.$defaultCurrency->sign.'";
			currencies[0]["format"] = '.(int)$defaultCurrency->format.';
			';
        foreach ($currencies as $currency) {
            $content .= '
				currencies['.$currency['id_currency'].'] = new Array();
				currencies['.$currency['id_currency'].']["sign"] = "'.$currency['sign'].'";
				currencies['.$currency['id_currency'].']["format"] = '.(int)$currency['format'].';
				';
        }
        $content .= '
		</script>
		';

        return $content;
    }

    public function hookAdminStatsModules()
    {
        $forms = new DssStatisticsClass();

        $this->html = '
            <!--<script type="text/javascript">$(\'#calendar\').slideToggle();</script>-->
			<div class="panel-heading">'.$this->displayName.'</div>
            <ul class="nav nav-tabs" role="tablist">
                <li class="nav-item active">
                    <a id="wholesale-pricelist-tab" class="nav-link active" data-toggle="tab" href="#wholesale-pricelist" role="tab" aria-controls="wholesale-pricelist" aria-selected="true">'.$this->l('Wholesale Pricelist').'</a>
                </li>
            </ul>
            <div class="tab-content">
                <div id="wholesale-pricelist" class="tab-pane fade show active in" role="tabpanel" aria-labelledby="wholesale-pricelist-tab">
                '.$forms->getWholesalePriceStatsForm().'
                </div>
            </div>';

        return $this->html;
    }

    public function hookActionCategoryGridDefinitionModifier($params)
    {
        $definition = $params['definition'];
        $translator = $this->getTranslator();

        $definition
            ->getColumns()
            ->addAfter(
                'active',
                (new \PrestaShop\PrestaShop\Core\Grid\Column\Type\Common\ToggleColumn('dss_category_active'))
                ->setName($translator->trans('Dropship', array(), 'Modules.DropshipSystem.Admin'))
                ->setOptions(
                    array(
                        'field' => 'dss_category_active',
                        'primary_field' => 'id_category',
                        'route' => 'dropshipsystem_toggle_dss_category_active',
                        'route_param_name' => 'categoryId',
                    )
                )
            );

//        $definition->getFilters()->add(
//            (new \PrestaShop\PrestaShop\Core\Product\Search\Filter('dss_category_active', \PrestaShopBundle\Form\Admin\Type\YesAndNoChoiceType::class))
//            ->setAssociatedColumn('dss_category_active')
//        );
    }

    public function hookActionCategoryGridQueryBuilderModifier($params)
    {
        $searchQueryBuilder = $params['search_query_builder'];

        $searchCriteria = $params['search_criteria'];

        $searchQueryBuilder->addSelect(
            '`dssc`.`dss_category_active`, CONCAT(`dssc`.`dss_category_code_parent`, \' - \', `dssc`.`dss_category_code`) AS `dss_unique_code`'
        );

        $searchQueryBuilder->leftJoin(
            'c',
            '`'.pSQL(_DB_PREFIX_).'dss_categories`',
            'dssc',
            'dssc.`id_category` = c.`id_category`'
        );

//        if ('dss_category_active' === $searchCriteria->getOrderBy()) {
//            $searchQueryBuilder->orderBy('dssc.`dss_category_active`', $searchCriteria->getOrderWay());
//        }
//
//        foreach ($searchCriteria->getFilters() as $filterName => $filterValue) {
//            if ('dss_category_active' === $filterName) {
//                $searchQueryBuilder->andWhere('dssc.`dss_category_active` = :dss_category_active');
//                $searchQueryBuilder->setParameter('dss_category_active', $filterValue);
//
//                if (!$filterValue) {
//                    $searchQueryBuilder->orWhere('dssc.`dss_category_active` IS NULL');
//                }
//            }
//        }
    }

    public function hookActionAdminCategoriesListingFieldsModifier($params)
    {
        $params['fields']['dss_category_active'] = array(
            'title' => $this->l('Dropship'),
            'active' => 'dropshipstatus',
            'type' => 'bool',
            'class' => 'fixed-width-xs',
            'align' => 'center',
            'ajax' => true,
            'orderby' => false
        );
        $params['fields']['dss_unique_code'] = array(
            'title' => $this->l('Unique Code'),
            'class' => 'fixed-width-xs',
            'orderby' => false
        );

        if (isset($params['select']) && Tools::strlen($params['select']) > 0) {
            $params['select'] .= ', CONCAT(`dssc`.`dss_category_code_parent`, \' - \', `dssc`.`dss_category_code`) AS `dss_unique_code`';
            $params['join'] .= 'LEFT JOIN `'._DB_PREFIX_.'dss_categories` `dssc` 
                ON `dssc`.`id_category` = a.`id_category`'.Shop::addSqlRestrictionOnLang('dssc');
        }
    }

    public function hookActionCategoryFormBuilderModifier($params)
    {
        if ($params['route'] == 'admin_categories_edit') {
            $parent_code = (string)DssCategoriesClass::getDSSParentCode(true, (int)$params['data']['id_parent'], (int)$params['id']);
        } else {
            $parent_code = (string)DssCategoriesClass::getDSSParentCode();
        }

        $dssc = Db::getInstance()->getRow('
            SELECT `dss_category_active`, `dss_category_code`
            FROM `'._DB_PREFIX_.'dss_categories`
            WHERE `id_category` = '.(int)$params['id'].Shop::addSqlRestrictionOnLang());

        $formBuilder = $params['form_builder'];

        $formBuilder->add(
            'dss_category_active',
            \PrestaShopBundle\Form\Admin\Type\SwitchType::class,
            array(
                'label' => $this->l('Active dropship'),
                'required' => false,
                'choices' => array(
                    'OFF' => 0,
                    'ON' => 1,
                ),
                'data' => (int)$dssc['dss_category_active']
            )
        );

        $formBuilder->add(
            'dss_category_code',
            \Symfony\Component\Form\Extension\Core\Type\TextType::class,
            array(
                'label' => $this->l('Category unique code'),
                'help' => $this->l('Category parent code').': '.(string)$parent_code,
                'required' => false,
                'data' => (string)$dssc['dss_category_code']
            )
        );

        $formBuilder->add(
            'dss_category_code_parent',
            \Symfony\Component\Form\Extension\Core\Type\HiddenType::class,
            array(
                'data' => (string)$parent_code
            )
        );

        $formBuilder->setData($params['data'], $params);
    }

    public function hookActionAdminCategoriesFormModifier($params)
    {
        if ((int)Tools::getIsset('addcategory')) {
            $parent_code = (string)DssCategoriesClass::getDSSParentCode(true);
        } else {
            $parent_code = (string)DssCategoriesClass::getDSSParentCode();
        }

        $dss_fields = array(
            array(
                'type' => 'switch',
                'label' => $this->l('Active dropship'),
                'name' => 'dss_category_active',
                'required' => false,
                'is_bool' => true,
                'values' => array(
                    array(
                        'id' => 'dss_category_active_on',
                        'value' => 1,
                        'label' => $this->l('Enabled')
                    ),
                    array(
                        'id' => 'dss_category_active_off',
                        'value' => 0,
                        'label' => $this->l('Disabled')
                    )
                )
            ),
            array(
                'type' => 'hidden',
                'value' => $parent_code,
                'name' => 'dss_category_code_parent',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Category unique code'),
                'name' => 'dss_category_code',
                'prefix' => $parent_code,
                'class' => 'fixed-width-lg',
                'hint' => $this->l('Invalid characters:').' <>;=#{}',
            ),
        );

        $params['fields'][0]['form']['input'] = array_merge($params['fields'][0]['form']['input'], $dss_fields);

        $dssc = Db::getInstance()->getRow('
            SELECT `dss_category_active`, `dss_category_code`
            FROM `'._DB_PREFIX_.'dss_categories`
            WHERE `id_category` = '.(int)Tools::getValue('id_category').Shop::addSqlRestrictionOnLang());

        $params['fields_value']['dss_category_active'] = (string)$dssc['dss_category_active'];
        $params['fields_value']['dss_category_code_parent'] = (string)$parent_code;
        $params['fields_value']['dss_category_code'] = (string)$dssc['dss_category_code'];
    }

    public function hookActionAfterCreateCategoryFormHandler($params)
    {
        $this->hookActionAdminCategoriesControllerSaveAfter($params);
    }

    public function hookActionAfterUpdateCategoryFormHandler($params)
    {
        $this->hookActionAdminCategoriesControllerSaveAfter($params);
    }

    public function hookActionAdminCategoriesControllerSaveAfter($params)
    {
        if (isset($params['form_data'])) {
            $id_category = (int)$params['id'];
            $dss_active = isset($params['form_data']['dss_category_active']) ? (int)$params['form_data']['dss_category_active'] : 0;
            $dss_category_code = isset($params['form_data']['dss_category_code']) ? trim((string)$params['form_data']['dss_category_code']) : '';
            $dss_category_code_parent = isset($params['form_data']['dss_category_code_parent']) ? trim((string)$params['form_data']['dss_category_code_parent']) : '';
        } else {
            $id_category = (int)Tools::getValue('id_category');
            //$id_parent = (int)Tools::getValue('id_parent');
            $dss_active = (int)Tools::getValue('dss_category_active');
            $dss_category_code = trim((string)Tools::getValue('dss_category_code'));
            $dss_category_code_parent = trim((string)Tools::getValue('dss_category_code_parent'));
        }

        $dss_category_id = (int)DssCategoriesClass::getDssCategoryID($id_category);
        if (!$dss_category_id) {
            $dss_categories = new DssCategoriesClass();
        } else {
            $dss_categories = new DssCategoriesClass($dss_category_id);
        }
        $dss_categories->id_shop = (int)$this->context->shop->id;
        $dss_categories->id_category = (int)$id_category;
        $dss_categories->dss_category_active = (int)$dss_active;
        $dss_categories->dss_category_code = (string)$dss_category_code;
        $dss_categories->dss_category_code_parent = (string)$dss_category_code_parent;
        if ($dss_active) {
            if (Tools::strlen($dss_category_code) > 0) {
                $code_exist = (int)Db::getInstance()->getValue('
                    SELECT COUNT(*) AS n
                    FROM `'._DB_PREFIX_.'category` `c`
                    '.Shop::addSqlAssociation('category', 'c').'
                    INNER JOIN `'._DB_PREFIX_.'dss_categories` `dssc`
                    ON `c`.`id_category` = `dssc`.`id_category`'.Shop::addSqlRestrictionOnLang('dssc').'
                    WHERE `dssc`.`id_category` <> '.(int)$id_category.' AND `dssc`.`dss_category_code` = \''.pSql($dss_category_code).'\'');
                if (!$code_exist) {
                    if ($dss_categories->save()) {
                        Db::getInstance()->execute('
                            UPDATE `'._DB_PREFIX_.'dss_categories`
                            SET `dss_category_code_parent` = \''.pSql($dss_category_code).'\'
                            WHERE `dss_category_active` = 1
                            AND `id_category` IN (SELECT `c`.`id_category` 
                                FROM `'._DB_PREFIX_.'category` `c`
                                '.Shop::addSqlAssociation('category', 'c').'
                                WHERE `c`.`id_parent` = '.(int)$id_category.'
                            )'.Shop::addSqlRestrictionOnLang());
                    } else {
                        $this->context->controller->errors[] = $this->l('Error saving dropship category');
                    }
                } else {
                    $this->context->controller->errors[] = $this->l('Code already exist. Dropship code must be unique.');
                }
            } else {
                $this->context->controller->errors[] = $this->l('Can\'t enable dropship status with empty unique code');
            }
        } else {
            if ($dss_categories->save()) {
                Db::getInstance()->execute('
                    UPDATE `'._DB_PREFIX_.'dss_categories`
                    SET `dss_category_code_parent` = NULL
                    WHERE `id_category` IN (SELECT `c`.`id_category` 
                        FROM `'._DB_PREFIX_.'category` `c`
                        '.Shop::addSqlAssociation('category', 'c').'
                        WHERE `c`.`id_parent` = '.(int)$id_category.'
                    )'.Shop::addSqlRestrictionOnLang());
            } else {
                $this->context->controller->errors[] = $this->l('Error saving dropship category');
            }
        }
        DssCategoriesClass::clearOrphans();
    }

    public function hookActionSupplierGridDefinitionModifier($params)
    {
//        $definition = $params['definition'];
//
//        $translator = $this->getTranslator();
//        ajax_dss_manufacturer_link
//        $definition
//            ->getColumns()
//            ->addAfter(
//            'active',
//            (new \PrestaShop\PrestaShop\Core\Grid\Column\Type\Common\ToggleColumn('enabled_manufacturer'))
//                ->setName($translator->trans('Dropship', array(), 'Modules.DropshipSystem.Admin'))
//                ->setOptions(array(
//                    'field' => 'enabled_manufacturer',
//                    'primary_field' => 'id_manufacturer',
//                    'route' => 'dropshipsystem_toggle_enabled_manufacturer',
//                    'route_param_name' => 'manufacturerId',
//                ))
//            );

//        $definition->getFilters()->add(
//            (new \PrestaShop\PrestaShop\Core\Product\Search\Filter('enabled_manufacturer', \PrestaShopBundle\Form\Admin\Type\YesAndNoChoiceType::class))
//            ->setAssociatedColumn('enabled_manufacturer')
//        );
    }

    public function hookActionSupplierGridQueryBuilderModifier($params)
    {
//        $searchQueryBuilder = $params['search_query_builder'];
//
//        $searchCriteria = $params['search_criteria'];
//
//        $searchQueryBuilder->addSelect(
//            'COUNT(dssm.`id_manufacturer`) AS enabled_manufacturer'
//        );
//
//        $searchQueryBuilder->leftJoin(
//            'm',
//            '`'.pSQL(_DB_PREFIX_).'dss_manufacturers`',
//            'dssm',
//            'dssm.`id_manufacturer` = m.`id_manufacturer`'
//        );

//        if ('dss_category_active' === $searchCriteria->getOrderBy()) {
//            $searchQueryBuilder->orderBy('dssc.`dss_category_active`', $searchCriteria->getOrderWay());
//        }
//
//        foreach ($searchCriteria->getFilters() as $filterName => $filterValue) {
//            if ('dss_category_active' === $filterName) {
//                $searchQueryBuilder->andWhere('dssc.`dss_category_active` = :dss_category_active');
//                $searchQueryBuilder->setParameter('dss_category_active', $filterValue);
//
//                if (!$filterValue) {
//                    $searchQueryBuilder->orWhere('dssc.`dss_category_active` IS NULL');
//                }
//            }
//        }
    }

    public function hookActionAdminSuppliersListingFieldsModifier($params)
    {
        if (isset($params['select'])) {
            if (isset($params['fields']['id_supplier'])) {
                $params['fields']['enabled_supplier'] = array(
                    'title' => $this->l('Dropship'),
                    'active' => 'dropshipgroups',
                    'type' => 'bool',
                    'class' => 'fixed-width-xs ajax_dss_supplier_link',
                    'align' => 'center',
                    'ajax' => false,
                    'orderby' => false,
                    'search' => false,
                );

                if (isset($params['select']) && Tools::strlen($params['select']) > 0) {
                    $params['select'] .= ', COUNT(dsss.`id_supplier`) AS enabled_supplier';
                    $params['join'] .= 'LEFT JOIN `'._DB_PREFIX_.'dss_suppliers` `dsss` 
                        ON `dsss`.`id_supplier` = a.`id_supplier`'.Shop::addSqlRestrictionOnLang('dsss');
                }
            }
        }
    }

    public function hookActionSupplierFormBuilderModifier($params)
    {
//        if ($params['route'] == 'admin_manufacturers_edit') {
//            $parent_code = (string)DssCategoriesClass::getDSSParentCode(true, (int)$params['data']['id_parent'], (int)$params['id']);
//        } else {
//            $parent_code = (string)DssCategoriesClass::getDSSParentCode();
//        }
//
//        $dssc = Db::getInstance()->getRow('
//            SELECT `dss_category_active`, `dss_category_code`
//            FROM `'._DB_PREFIX_.'dss_categories`
//            WHERE `id_category` = '.(int)$params['id'].Shop::addSqlRestrictionOnLang());
//
//        $formBuilder = $params['form_builder'];
//
//        $formBuilder->add('dss_category_active',
//            \PrestaShopBundle\Form\Admin\Type\SwitchType::class, [
//            'label' => $this->l('Active dropship'),
//            'required' => false,
//            'choices' => [
//                'OFF' => 0,
//                'ON' => 1,
//            ],
//            'data' => (int)$dssc['dss_category_active']
//        ]);
//
//        $formBuilder->add('dss_category_code',
//            \Symfony\Component\Form\Extension\Core\Type\TextType::class, [
//            'label' => $this->l('Category unique code'),
//            'help' => $this->l('Category parent code').': '.(string)$parent_code,
//            'required' => false,
//            'data' => (string)$dssc['dss_category_code']
//        ]);
//
//        $formBuilder->add('dss_category_code_parent',
//            \Symfony\Component\Form\Extension\Core\Type\HiddenType::class, [
//            'data' => (string)$parent_code
//        ]);
//
//        $formBuilder->setData($params['data'], $params);
    }

    public function hookActionAdminSuppliersFormModifier($params)
    {
        if (!$this->context) {
            $this->context = Context::getContext();
        }
        //$id_supplier = (int)Tools::getValue('id_supplier');
        $id_shop = (int)$this->context->shop->id;
        $groups = Group::getGroups($this->context->language->id, $id_shop);

        $dss_fields = array(
            array(
                'type' => 'group',
                'label' => $this->l('Enabled group'),
                'name' => 'groupBox',
                'values' => $groups,
            ),
        );

        $params['fields'][0]['form']['input'] = array_merge($params['fields'][0]['form']['input'], $dss_fields);

        $dss_groups = Db::getInstance()->executeS('
            SELECT `group`
            FROM `'._DB_PREFIX_.'dss_suppliers`
            WHERE `id_supplier` = '.(int)Tools::getValue('id_supplier').Shop::addSqlRestrictionOnLang());

        $supplier_groups_ids = array();
        foreach ($dss_groups as $dss_group) {
            $supplier_groups_ids[] = (int)$dss_group['group'];
        }
        if (empty($supplier_groups_ids)) {
            $preselected = array(Configuration::get('PS_UNIDENTIFIED_GROUP', null, null, $id_shop), Configuration::get('PS_GUEST_GROUP', null, null, $id_shop), Configuration::get('PS_CUSTOMER_GROUP', null, null, $id_shop));
            $supplier_groups_ids = array_merge($supplier_groups_ids, $preselected);
        }
        foreach ($groups as $group) {
            $params['fields_value']['groupBox_'.$group['id_group']] = Tools::getValue('groupBox_'.$group['id_group'], (in_array($group['id_group'], $supplier_groups_ids)));
        }
    }

    public function hookActionAfterCreateSupplierFormHandler($params)
    {
        //$this->hookActionAdminSuppliersControllerSaveAfter($params);
    }

    public function hookActionAfterUpdateSupplierFormHandler($params)
    {
        //$this->hookActionAdminSuppliersControllerSaveAfter($params);
    }

    public function hookActionAdminSuppliersControllerSaveAfter($params)
    {
        $id_shop = (int)$this->context->shop->id;
        $id_supplier = (int)Tools::getValue('id_supplier');
        $groups = Tools::getValue('groupBox');

        if (isset($groups) && $groups) {
            foreach ($groups as $group) {
                $dss_groups = new DssSuppliersClass();
                $dss_group_exist = $dss_groups->existsSupplierGroup((int)$id_supplier, (int)$group);
                if ($dss_group_exist) {
                    continue;
                }
                $dss_groups->id_supplier = (int)$id_supplier;
                $dss_groups->id_shop = (int)$id_shop;
                $dss_groups->group = (int)$group;
                $dss_groups->add();
            }
        }
        DssSuppliersClass::clearSupplierGroups($id_supplier, $groups);
    }

    public function hookActionManufacturerGridDefinitionModifier($params)
    {
//        $definition = $params['definition'];
//
//        $translator = $this->getTranslator();
//        ajax_dss_manufacturer_link
//        $definition
//            ->getColumns()
//            ->addAfter(
//            'active',
//            (new \PrestaShop\PrestaShop\Core\Grid\Column\Type\Common\ToggleColumn('enabled_manufacturer'))
//                ->setName($translator->trans('Dropship', array(), 'Modules.DropshipSystem.Admin'))
//                ->setOptions(array(
//                    'field' => 'enabled_manufacturer',
//                    'primary_field' => 'id_manufacturer',
//                    'route' => 'dropshipsystem_toggle_enabled_manufacturer',
//                    'route_param_name' => 'manufacturerId',
//                ))
//            );

//        $definition->getFilters()->add(
//            (new \PrestaShop\PrestaShop\Core\Product\Search\Filter('enabled_manufacturer', \PrestaShopBundle\Form\Admin\Type\YesAndNoChoiceType::class))
//            ->setAssociatedColumn('enabled_manufacturer')
//        );
    }

    public function hookActionManufacturerGridQueryBuilderModifier($params)
    {
//        $searchQueryBuilder = $params['search_query_builder'];
//
//        $searchCriteria = $params['search_criteria'];
//
//        $searchQueryBuilder->addSelect(
//            'COUNT(dssm.`id_manufacturer`) AS enabled_manufacturer'
//        );
//
//        $searchQueryBuilder->leftJoin(
//            'm',
//            '`'.pSQL(_DB_PREFIX_).'dss_manufacturers`',
//            'dssm',
//            'dssm.`id_manufacturer` = m.`id_manufacturer`'
//        );

//        if ('dss_category_active' === $searchCriteria->getOrderBy()) {
//            $searchQueryBuilder->orderBy('dssc.`dss_category_active`', $searchCriteria->getOrderWay());
//        }
//
//        foreach ($searchCriteria->getFilters() as $filterName => $filterValue) {
//            if ('dss_category_active' === $filterName) {
//                $searchQueryBuilder->andWhere('dssc.`dss_category_active` = :dss_category_active');
//                $searchQueryBuilder->setParameter('dss_category_active', $filterValue);
//
//                if (!$filterValue) {
//                    $searchQueryBuilder->orWhere('dssc.`dss_category_active` IS NULL');
//                }
//            }
//        }
    }

    public function hookActionAdminManufacturersListingFieldsModifier($params)
    {
        if (isset($params['fields']['id_manufacturer'])) {
            $params['fields']['enabled_manufacturer'] = array(
                'title' => $this->l('Dropship'),
                'active' => 'dropshipgroups',
                'type' => 'bool',
                'class' => 'fixed-width-xs ajax_dss_manufacturer_link',
                'align' => 'center',
                'ajax' => false,
                'orderby' => false,
                'search' => false,
            );

            if (isset($params['select']) && Tools::strlen($params['select']) > 0) {
                $params['select'] .= ', COUNT(dssm.`id_manufacturer`) AS enabled_manufacturer';
                $params['join'] .= ' LEFT JOIN `'._DB_PREFIX_.'dss_manufacturers` dssm 
                    ON dssm.`id_manufacturer` = a.`id_manufacturer`'.Shop::addSqlRestrictionOnLang('dssm');
            }
        }
    }

    public function hookActionManufacturerFormBuilderModifier($params)
    {
//        if ($params['route'] == 'admin_manufacturers_edit') {
//            $parent_code = (string)DssCategoriesClass::getDSSParentCode(true, (int)$params['data']['id_parent'], (int)$params['id']);
//        } else {
//            $parent_code = (string)DssCategoriesClass::getDSSParentCode();
//        }
//
//        $dssc = Db::getInstance()->getRow('
//            SELECT `dss_category_active`, `dss_category_code`
//            FROM `'._DB_PREFIX_.'dss_categories`
//            WHERE `id_category` = '.(int)$params['id'].Shop::addSqlRestrictionOnLang());
//
//        $formBuilder = $params['form_builder'];
//
//        $formBuilder->add('dss_category_active',
//            \PrestaShopBundle\Form\Admin\Type\SwitchType::class, [
//            'label' => $this->l('Active dropship'),
//            'required' => false,
//            'choices' => [
//                'OFF' => 0,
//                'ON' => 1,
//            ],
//            'data' => (int)$dssc['dss_category_active']
//        ]);
//
//        $formBuilder->add('dss_category_code',
//            \Symfony\Component\Form\Extension\Core\Type\TextType::class, [
//            'label' => $this->l('Category unique code'),
//            'help' => $this->l('Category parent code').': '.(string)$parent_code,
//            'required' => false,
//            'data' => (string)$dssc['dss_category_code']
//        ]);
//
//        $formBuilder->add('dss_category_code_parent',
//            \Symfony\Component\Form\Extension\Core\Type\HiddenType::class, [
//            'data' => (string)$parent_code
//        ]);
//
//        $formBuilder->setData($params['data'], $params);
    }

    public function hookActionAdminManufacturersFormModifier($params)
    {
        if (!$this->context) {
            $this->context = Context::getContext();
        }
        //$id_manufacturer = (int)Tools::getValue('id_manufacturer');
        $id_shop = (int)$this->context->shop->id;
        $groups = Group::getGroups($this->context->language->id, $id_shop);

        $dss_fields = array(
            array(
                'type' => 'group',
                'label' => $this->l('Enabled group'),
                'name' => 'groupBox',
                'values' => $groups,
            ),
        );

        $params['fields'][0]['form']['input'] = array_merge($params['fields'][0]['form']['input'], $dss_fields);

        $dss_groups = Db::getInstance()->executeS('
            SELECT `group`
            FROM `'._DB_PREFIX_.'dss_manufacturers`
            WHERE `id_manufacturer` = '.(int)Tools::getValue('id_manufacturer').Shop::addSqlRestrictionOnLang());

        $manufacturer_groups_ids = array();
        foreach ($dss_groups as $dss_group) {
            $manufacturer_groups_ids[] = (int)$dss_group['group'];
        }
        if (empty($manufacturer_groups_ids)) {
            $preselected = array(Configuration::get('PS_UNIDENTIFIED_GROUP', null, null, $id_shop), Configuration::get('PS_GUEST_GROUP', null, null, $id_shop), Configuration::get('PS_CUSTOMER_GROUP', null, null, $id_shop));
            $manufacturer_groups_ids = array_merge($manufacturer_groups_ids, $preselected);
        }
        foreach ($groups as $group) {
            $params['fields_value']['groupBox_'.$group['id_group']] = Tools::getValue('groupBox_'.$group['id_group'], (in_array($group['id_group'], $manufacturer_groups_ids)));
        }
    }

    public function hookActionAfterCreateManufacturerFormHandler($params)
    {
        //$this->hookActionAdminManufacturersControllerSaveAfter($params);
    }

    public function hookActionAfterUpdateManufacturerFormHandler($params)
    {
        //$this->hookActionAdminManufacturersControllerSaveAfter($params);
    }

    public function hookActionAdminManufacturersControllerSaveAfter($params)
    {
        $id_shop = (int)$this->context->shop->id;
        $id_manufacturer = (int)Tools::getValue('id_manufacturer');
        $groups = Tools::getValue('groupBox');

        if (isset($groups) && $groups) {
            foreach ($groups as $group) {
                $dss_groups = new DssManufacturersClass();
                $dss_group_exist = $dss_groups->existsManufacturerGroup((int)$id_manufacturer, (int)$group);
                if ($dss_group_exist) {
                    continue;
                }
                $dss_groups->id_manufacturer = (int)$id_manufacturer;
                $dss_groups->id_shop = (int)$id_shop;
                $dss_groups->group = (int)$group;
                $dss_groups->add();
            }
        }
        DssManufacturersClass::clearManufacturerGroups($id_manufacturer, $groups);
    }

    public function hookActionAdminOrdersListingFieldsModifier($params)
    {
        if (isset($params['select']) && isset($params['fields']['id_order'])) {
            foreach (array_keys($params['fields']) as $dss_key => $dss_value) {
                if ($dss_value == 'company') {
                    break;
                }
            }
            $dss_part1 = array_slice($params['fields'], 0, $dss_key + 1);
            $dss_part2 = array_slice($params['fields'], $dss_key + 1);
            $dss_part1['dss_dropshipper'] = array(
                'title' => $this->l('Dropshipper'),
                'class' => 'fixed-width-xs',
                'filter_key' => 'cus!company',
            );
            $dss_part1['dss_order_ref'] = array(
                'title' => $this->l('Ref. Dropship'),
                'class' => 'fixed-width-xs',
                'filter_key' => 'dsso!order_reference',
            );
            $params['fields'] = array_merge($dss_part1, $dss_part2);

            $params['select'] .= ', a.`reference`, cus.`company` AS `dropshipper`, dsso.`order_reference` AS `dropshipper_order_reference` ';
            $params['join'] .= ' LEFT JOIN `'._DB_PREFIX_.'dss_order` dsso ON dsso.`id_order` = a.`id_order`
                LEFT JOIN `'._DB_PREFIX_.'dss_dropshipper` dssd ON dssd.`id_dss_dropshipper` = dsso.`id_dropshipper`
                LEFT JOIN `'._DB_PREFIX_.'customer` cus ON cus.`id_customer` = dssd.`id_customer` ';
        }
    }

    public function hookActionEmailSendBefore($params)
    {
        $id_shop = (int)$this->context->shop->id;

        if (!isset($params['to'])) {
            return true;
        }

        $res = true;
        if ((int)Configuration::get('DSS_CUSTOMER_MAILS', null, null, $id_shop) == 0) {
            $customers = Customer::getCustomersByEmail((string)$params['to']);
            if (isset($customers) && !empty($customers)) {
                foreach ($customers as $customer) {
                    if ((int)$customer['active'] == 1) {
                        $exist = (int)DssDropshippersClass::isCloneDropshipperCustomerByEmail((string)$params['to']);
                        if ($exist > 0) {
                            $res = false;
                            break;
                        }
                    }
                }
            }
        }
        return $res;
    }

    public function hookActionCategoryAdd($params)
    {
        if (!isset($params['category']->id_category)) {
            return false;
        }

        $id_reference = (int)$params['category']->id_category;
        if ($id_reference) {
            $params['dss_action_type'] = 'categories';
            $params['dss_action_id_reference'] = $id_reference;
            $this->setActionUpdate($params);
        }
    }

    public function hookActionCategoryUpdate($params)
    {
        if (!isset($params['category']->id_category)) {
            return false;
        }

        $id_reference = (int)$params['category']->id_category;
        if ($id_reference) {
            $params['dss_action_type'] = 'categories';
            $params['dss_action_id_reference'] = $id_reference;
            $this->setActionUpdate($params);
        }
    }

    public function hookActionCategoryDelete($params)
    {
        if (!isset($params['category']->id_category)) {
            return false;
        }

        $id_reference = (int)$params['category']->id_category;
        if ($id_reference) {
            $params['dss_action_type'] = 'categories';
            $params['dss_action_id_reference'] = $id_reference;
            $this->setActionUpdate($params);
        }
    }

    public function hookActionProductAdd($params)
    {
        if (!isset($params['id_product'])) {
            return false;
        }

        $this->updateCreditProducts($params);

        $id_product = (int)$params['id_product'];
        if ($id_product) {
            $params['dss_action_type'] = 'products';
            $params['dss_action_id_reference'] = $id_product;
            $this->setActionUpdate($params);
            if (Tools::getIsset('submitPriceWholesaleAddition')) {
                $dssswp = new DssSpecificWholesalePriceClass();
                $errors =$dssswp->setSpecificWholesalePrice($id_product);
                unset($dssswp);
                if (count($errors) > 0) {
                    $this->context->controller->errors[] = $errors;
                }
            }
        }
    }

    public function hookActionProductUpdate($params)
    {
        if (!isset($params['id_product'])) {
            return false;
        }

        $this->updateCreditProducts($params);

        $id_product = (int)$params['id_product'];
        if ($id_product) {
            $params['dss_action_type'] = 'products';
            $params['dss_action_id_reference'] = $id_product;
            $this->setActionUpdate($params);
            if (Tools::getIsset('submitPriceWholesaleAddition')) {
                $errors = array();
                $dssswp = new DssSpecificWholesalePriceClass();
                $errors = $dssswp->setSpecificWholesalePrice($id_product);
                unset($dssswp);
                if (count($errors) > 0) {
                    $this->context->controller->errors[] = $errors;
                }
            }
        }
    }

    public function hookActionProductDelete($params)
    {
        if (!isset($params['id_product'])) {
            return false;
        }

        $this->updateCreditProducts($params);

        $id_reference = (int)$params['id_product'];
        if ($id_reference) {
            $params['dss_action_type'] = 'products';
            $params['dss_action_id_reference'] = $id_reference;
            $params['dss_action_reference'] = $params['product']->reference;
            $params['dss_action_action'] = 'delete';
            $this->setActionUpdate($params);
        }
    }

    public function hookActionProductOutOfStock($params)
    {
        if (!isset($params['id_product'])) {
            return false;
        }

        $id_reference = (int)$params['id_product'];
        if ($id_reference) {
            $params['dss_action_type'] = 'products';
            $params['dss_action_id_reference'] = $id_reference;
            $this->setActionUpdate($params);
        }
    }

    public function hookActionUpdateQuantity($params)
    {
        if (!isset($params['id_product'])) {
            return false;
        }

        $id_reference = (int)$params['id_product'];
        if ($id_reference) {
            $params['dss_action_type'] = 'quantities';
            $params['dss_action_id_reference'] = $id_reference;
            $this->setActionUpdate($params);
        }
    }

    private function setActionUpdate($params)
    {
        $t = microtime(true) * 10000;

        $action = new DssActionLogClass();
        $action->id_dss_action = $t;
        $action->type = $params['dss_action_type'];
        $action->id_reference = (int)$params['dss_action_id_reference'];
        $action->reference = isset($params['dss_action_reference']) ? (string)$params['dss_action_reference'] : null;
        $action->action = isset($params['dss_action_action']) ? (string)$params['dss_action_action'] : null;
        $action->clearDuplicates();
        $action->save();
        usleep(100);
        return true;
    }

    public function hookActionCarrierUpdate($params)
    {
        $this->hookUpdateCarrier($params);
    }

    public function hookUpdateCarrier($params)
    {
        if (version_compare(_PS_VERSION_, '1.5', '>=') && Shop::isFeatureActive()) {
            $shops = Shop::getShops(true, null, false);
        } else {
            $shops = array(
                0 => array(
                    'id_shop' => null,
                    'id_shop_group' => null
                )
            );
        }

        foreach ($shops as $shop) {
            for ($i = 1; $i < 4; $i++) {
                $dss_carrier = (int)Configuration::get('DSS_SHIPPING_METHOD_'.$i, null, $shop['id_shop_group'], $shop['id_shop']);
                if ($dss_carrier) {
                    if ($dss_carrier == $params['id_carrier']) {
                        $dss_carrier = $params['carrier']->id;
                        Configuration::updateValue('DSS_SHIPPING_METHOD_'.$i, $dss_carrier, false, $shop['id_shop_group'], $shop['id_shop']);
                    }
                }
            }
        }
    }

    public function hookAdminCustomers($params)
    {
        $customer = new Customer((int)$params['id_customer']);
        if (!Validate::isLoadedObject($customer)) {
            die(Tools::displayError());
        }

        $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID((int)$customer->id);
        $dropshipper = new DssDropshippersClass();
        if ($id_dropshipper) {
            $dropshipper = new $dropshipper($id_dropshipper);
        }

        $this->context->smarty->assign(array(
            'customer' => $customer,
            'id_dropshipper' => $id_dropshipper,
            'dropshipper' => $dropshipper,
            'form' => Tools::safeOutput($_SERVER['REQUEST_URI']),
            'currency' => $this->context->currency
        ));

        $this->html = $this->context->smarty->fetch(dirname(__FILE__).'/views/templates/admin/admin_customer.tpl');

        return $this->html;
    }

    public function hookDisplayProductButtons($params)
    {
        return $this->hookDisplayProductAdditionalInfo($params);
    }

    public function hookDisplayProductAdditionalInfo($params)
    {
        $id_shop = (int)$this->context->shop->id;
        $id_lang = (int)$this->context->language->id;

        if (!$this->active) {
            return;
        }
        if (Configuration::get('PS_CATALOG_MODE', null, null, $id_shop)) {
            return;
        }

        $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
        if ($id_dropshipper) {
            $dropshipper = new DssDropshippersClass($id_dropshipper);

            if ($dropshipper->direct_order == 1) {
                //$product = (array)$params['product'];
                //if (version_compare(_PS_VERSION_, '1.7', '<')) {
                //    $product['id_product'] = (int)$product['id'];
                //}

                if (version_compare(_PS_VERSION_, '1.7', '<')) {
                    $product = isset($params['product']) ? $params['product'] : null;
                } else {
                    $id_product = (int)$params['product']['id'];
                    $product = new Product((int)$id_product);
                }

                if (!isset($product)) {
                    $product = new Product((int)Tools::getValue('id_product'));
                }

                if (!isset($product)) {
                    return;
                } else {
                    $product = (array)$product;
                    if (!isset($product['id_product'])) {
                        $product['id_product'] = (int)$product['id'];
                    }
                }

                $address = new Address($dropshipper->id_address_invoice);
                $dropshipper->id_country = (int)$address->id_country;
                unset($address);

                $group = $this->context->customer->id_default_group;

                $dss_cart = new DssCartClass();
                $res = $dss_cart->getProduct($product, $dropshipper, $id_lang, $group);

                $price = (float)$res['price'];

                if (version_compare(_PS_VERSION_, '1.7', '<')) {
                    $prd = new Product((int)$product['id_product'], true, $id_lang);
                    $this->context->smarty->assign(
                        array(
                            'product' => $prd,
                            'allow_oosp' => $prd->isAvailableWhenOutOfStock((int)$prd->out_of_stock),
                        )
                    );
                }

                $this->context->smarty->assign(
                    array(
                        'dss_hidden_price' => (int)$dropshipper->hidden_product_prices,
                        'dss_product_price' => (float)$price,
                        'dss_formatted_product_price' => (string)Tools::displayPrice((float)$price),
                        'dss_cart_url' => $this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount', array('action' => 'neworder'))
                    )
                );

                if (version_compare(_PS_VERSION_, '1.7', '<')) {
                    return $this->display(__FILE__, 'product-add-to-cart.tpl');
                } else {
                    return $this->display(__FILE__, '1.7/product-add-to-cart.tpl');
                }
            }
        }
    }

    public function hookCustomerAccount($params)
    {
        $id_shop = (int)$this->context->shop->id;
        $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID((int)$this->context->customer->id);
        $dropshipper = new DssDropshippersClass($id_dropshipper);

        $this->context->smarty->assign(
            array(
                'dropshipper' => $dropshipper,
                'allow_dropshippers_registration' => (int)Configuration::get('DSS_DROPSHIPPERS_REGISTRATION', null, null, $id_shop)
            )
        );

        //$this->context->controller->addCSS(($this->_path).'views/css/dss.css', 'all');

        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            return $this->display(__FILE__, 'my-account.tpl');
        } else {
            return $this->display(__FILE__, '1.7/my-account.tpl');
        }
    }

    public function hookDisplayMyAccountBlock($params)
    {
        return $this->hookCustomerAccount($params);
    }

    public function hookRightColumn($params)
    {
        return $this->hookLeftColumn($params);
    }

    public function hookLeftColumn($params)
    {
        $id_shop = (int)$this->context->shop->id;

        $this->context->smarty->assign(
            array(
                'DSS_DOWNLOAD_BLOCK_ENABLE' => (int)Configuration::get('DSS_DOWNLOAD_BLOCK_ENABLE', null, null, $id_shop),
                'DSS_FILE_CATEGORIES_ENABLE' => (int)Configuration::get('DSS_FILE_CATEGORIES_ENABLE', null, null, $id_shop),
                'DSS_FILE_PRODUCTS_ENABLE' => (int)Configuration::get('DSS_FILE_PRODUCTS_ENABLE', null, null, $id_shop),
                'DSS_FILE_PRICELIST_ENABLE' => (int)Configuration::get('DSS_FILE_PRICELIST_ENABLE', null, null, $id_shop),
                'DSS_FILE_ALL_ENABLE' => (int)Configuration::get('DSS_FILE_ALL_ENABLE', null, null, $id_shop),
            )
        );

        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            return $this->display(__FILE__, 'dropship-block.tpl');
        } else {
            return $this->display(__FILE__, '1.7/dropship-block.tpl');
        }
    }

    public function hookActionDeleteGDPRCustomer($customer)
    {
        if (!empty($customer['email']) && Validate::isEmail($customer['email'])) {
            $data = new DssDropshippersClass();
            $res = $data->deleteDropshipperByEmail($customer['email']);

            if ($res) {
                return Tools::jsonEncode(true);
            }
            return Tools::jsonEncode($this->l('Dropship : Unable to delete the customer personal data.'));
        }
    }

    public function hookActionExportGDPRData($customer)
    {
        if (!Tools::isEmpty($customer['email']) && Validate::isEmail($customer['email'])) {
            $data = new DssDropshippersClass();
            $res = $data->export($customer['email']);

            if (!$res) {
                return Tools::jsonEncode($this->l('Dropship : Unable to export the customer personal data.'));
            }

            if (count($res) > 0) {
                return Tools::jsonEncode($res);
            }
        }
    }

    public function writeLog($string)
    {
        $file = fopen(_PS_MODULE_DIR_.'dropshipsystem/logs/log-'.date('Ymd').'.txt', 'a');

        if (is_object($string)) {
            $string = (array)$string;
        }

        if (is_array($string)) {
            if (!empty($string)) {
                $string = '['.date('Y-m-d H:i:s').'] '.print_r($string, true);
                fwrite($file, $string."\r\n");
            }
        } else {
            if (!empty($string)) {
                $string = '['.date('Y-m-d H:i:s').'] '.$string;
                fwrite($file, $string."\r\n");
            }
        }

        fclose($file);
    }
}
