<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class DropShipSystemCronModuleFrontController extends ModuleFrontController
{
    public function __construct()
    {
        parent::__construct();
    }

    public function initContent()
    {
        //parent::initContent();

        $dss = new DropShipSystem();
        if ($dss->active) {
            if (Tools::getIsset('secure_key')) {
                if (Tools::getIsset('id_shop')) {
                    Shop::setContext(Shop::CONTEXT_SHOP, (int)Tools::getValue('id_shop'));
                } else {
                    Shop::setContext(Shop::CONTEXT_SHOP, (int)Configuration::get('PS_SHOP_DEFAULT'));
                }
                $id_shop = $this->context->shop->id;
                $secure_key = Configuration::get('DSS_SECURE_KEY', null, null, $id_shop);
                if (!empty($secure_key) && $secure_key == Tools::getValue('secure_key')) {
                    //$debug = 0;
                    //if ((int)Configuration::get('DSS_DEBUG_MODE') == 1) {
                    //    $debug = 1;
                    //}

                    if (!$dss->cronTask()) {
                        die('Nothing to do');
                    } else {
                        die('OK');
                    }
                } else {
                    die('Wrong security key');
                }
            } else {
                die('Security key missing');
            }
        } else {
            die('Module is not active');
        }
    }
}
