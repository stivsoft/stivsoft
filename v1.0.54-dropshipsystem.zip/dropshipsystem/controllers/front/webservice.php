<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

ini_set('default_charset', 'utf-8');
ini_set('max_execution_time', 0);

header('Expires: Sun, 01 Jan 2014 00:00:00 GMT');
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

include_once(_PS_MODULE_DIR_.'dropshipsystem/dropshipsystem.php');

if (!defined('_PS_VERSION_')) {
    exit;
}

class DropShipSystemWebServiceModuleFrontController extends ModuleFrontController
{
    public $display_column_left = false;
    public $ssl = true;
    public $debug = false;
    
    protected $_html = "";
    protected $dss;
    protected $dropshippers;

    protected $id_home_category;
    protected $id_default_lang;
    protected $id_default_currency;
    protected $ps_tax;
    protected $prices_vat;
    protected $wholesale_base_price;
    protected $base_price;

    protected $customer_wholesale_discount = 0;
    protected $customer_discount;

    /*
    - 1 Errori sistema -
        1000 Invalid action
        1001 Error during call webservice
        1002 Username parameter not specified
        1003 Password parameter not specified
        1004 API Secret parameter not specified
        1005 Action parameter not specified
        1006 Username format is invalid (email address is required)
        1010 Your account isn't available at this time, please contact us
        1011 Authentication failed
        1012 Invalid Dropshipper profile
        1013 Dropshipper profile is disabled
        1014 Dropshipper profile is expired
        1015 Dropshipper without billing profile
        1016 Connection is not allowed from this host
        1017 Connection is not allowed at this time
        1020 Category parameter not specified
        1021 Items parameter not specified

    - 2 Errori categorie -
        2000 Invalid category

    - 3 Errori quantità -

    - 4 Errori prodotti -

    - 5 Errori ordini -
        5000 Invalid order reference
        5001 Invalid product xxx
        5002 Product xxx is not available for order
        5003 Quantity value for product xxx is not valid
        5004 Quantity not available for product xxx
        5005 Minimal quantity not reached for xxx
        5006 Insufficient funds for order
        5007 Error during set new credit
        5008 Error retrive gateway payment link
        5009 Error retrive payment link
        5010 Error with payment authentication
        5011 Order reference not specified
        5012 Payment already processed for order
        5013 Error retrive payment checkout
        5014 Error during payment confirmation
        5015 Order has been already fully payed
        5016 Authorized import is major of total order import
        5017 Error during create order
        5018 Unespected payment status
        5019 You are not authorized to get this order
        5020 Missing data: xxx
        5020 Invalid data: xxx
        5021 Products not specified
        5022 Some product are not available: xxx
        5023 Error adding product to cart
        5024 Error during create customer
        5025 Daily order limit exceded
        5026 Monthly order limit exceded
        5027 Error adding cart rule
        5028 Error saving delivery address
        5029 Error saving invoice address
        5030 Error during updating customer

    - 6 Errori fast sync -
        6000 Version parameter not specified
    */

    public function initContent()
    {
        parent::initContent();

        //global $link;

        $this->context = Context::getContext();
        $shop = $this->context->shop;
        $id_shop = (int)$shop->id;

        $this->debug = (int)Configuration::get('DSS_DEBUG', null, null, $id_shop);

        Shop::setContext(Shop::CONTEXT_SHOP, $id_shop);

        $this->_html = "";
        if (!(int)Tools::getValue('mode')) {
            ob_clean();

            //$gzip = strpos($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip') !== false;
            //if ($gzip) {
            //    header('Content-Encoding: gzip');
            //}

            header("content-type: text/xml; charset: UTF-8; Connection: close");
            header('Vary: Accept-Encoding');
            $this->_html = "<?xml version='1.0' encoding='UTF-8'?>\n";
        }

        $req_username = null;
        $req_password = null;
        $req_secret = null;
        $req_action = null;

        $this->customer_wholesale_discount = 0;
        $this->customer_discount = 0;

        $this->dss = new DssClass();

        $this->id_home_category = (int)Configuration::get('PS_HOME_CATEGORY', null, null, $id_shop);
        $this->id_default_lang = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);
        $this->id_default_currency = (int)Configuration::get('PS_CURRENCY_DEFAULT', null, null, $id_shop);
        $this->ps_tax = (int)Configuration::get('PS_TAX', null, null, $id_shop);

        $langs = Language::getLanguages();

        if (Tools::getIsset('action')) {
            $req_action = (string)Tools::strtolower(Tools::getValue('action'));
        } else {
            $this->showError('1005', 'Action parameter not specified');
        }

        $categories_code = null;
        if (Tools::getIsset('categories')) {
            $categories_code = explode(',', Tools::getValue('categories'));
        }

        if ($req_action == 'payment') {
            if (Tools::getIsset('ref')) {
                $req_order = (string)Tools::getValue('ref');
            } else {
                $this->showError('5011', 'Order reference not specified');
            }

            $redirect_url = (string)DssOrderClass::getPaymentGatewayLinkByOrderReference($req_order);

            Tools::redirect($redirect_url, __PS_BASE_URI__, null, 'HTTP/1.1 301 Moved Permanently');
            die;
        } elseif ($req_action == 'payment-cancel') {
            if (Tools::getIsset('ref')) {
                $req_order = (string)Tools::getValue('ref');
            } else {
                $this->showError('5011', 'Order reference not specified');
            }

            $shop_name = $this->context->shop->name;
            $id_order = (int)DssOrderClass::getOrderIDByReference($req_order);
            $id_dss_order = (int)DssOrderClass::getDssOrderIDByOrderID($id_order);
            if ($id_dss_order) {
                $dss_order = new DssOrderClass($id_dss_order);
                $payment_link = (string)$dss_order->payment_link;
                $total = (float)$dss_order->total;

                $this->context->smarty->assign(array(
                    'iscredit' => false,
                    'shop_name' => $shop_name,
                    'status' => 'cancel',
                    'id_order' => $id_order,
                    'reference' => $req_order,
                    'payment_link' => $payment_link,
                    'contact_url' => $this->context->link->getPageLink('contact', true),
                    'total' => $total
                ));
            } else {
                $this->context->smarty->assign(array(
                    'iscredit' => false,
                    'status' => 'error',
                    'message' => $this->module->l('Order not found', 'dropshipsystem'),
                    'contact_url' => $this->context->link->getPageLink('contact', true),
                ));
            }

            if (version_compare(_PS_VERSION_, '1.7', '<')) {
                return $this->setTemplate('payment-result.tpl');
            } else {
                return $this->setTemplate('module:dropshipsystem/views/templates/front/1.7/payment-result.tpl');
            }
        } elseif ($req_action == 'payment-return') {
            if (Tools::getIsset('ref')) {
                $req_order = (string)Tools::getValue('ref');
            } else {
                $this->showError('5011', 'Order reference not specified');
            }

            $shop_name = (string)$this->context->shop->name;

            $payclass = DssPaymentClass::getInstance();

            if (!$payclass->getAuth()) {
                DssEventsClass::setEvent('error', $this->module->l('Error with payment gateway account. Please check credentials.', 'dropshipsystem'));
                $this->showError('5013', 'Error retrive payment gateway checkout');
            }

            $params = array(
                'token' => (string)Tools::getValue('token'),
            );

            $payres = $payclass->processPayment($params);
            unset($payclass);

            if ($payres['success']) {
                $id_currency = (int)Currency::getIdByIsoCode($payres['currency']);
                $currency = new Currency($id_currency);

                $payment_amount = (float)$payres['amount'];
                $payment_date = $payres['payment_date'];
                $payment_transaction = (string)$payres['transaction_id'];
                $payment_token = (string)$payres['token'];

                $payment_order = new DssPaymentsTokenClass($payment_token);

                $order = new Order((int)$payment_order->id_order);

                if (isset($order)) {
                    $total_payed_amount = 0;
                    $order_payments = OrderPayment::getByOrderReference($order->reference);
                    foreach ($order_payments as $order_payment) {
                        $total_payed_amount += (float)$order_payment->amount;
                    }

                    if ($payment_amount > 0 && $total_payed_amount < $payment_amount) {
                        $id_currency = (int)Currency::getIdByIsoCode($payment_order->currency);
                        $currency = new Currency($id_currency);

                        $history = new OrderHistory();
                        $history->id_order = (int)$order->id;
                        $history->changeIdOrderState((int)Configuration::get('PS_OS_PAYMENT', null, null, $id_shop), $history->id_order);
                        $history->addWithemail();
                        $history->save();

                        DssOrderClass::setOrderPaymentTransaction($order, $payment_transaction);

                        unset($order);

                        $order = new Order((int)$payment_order->id_order);
                        $id_dss_order = DssOrderClass::getDssOrderIDByOrderID($order->id);
                        $dss_order = new DssOrderClass($id_dss_order);
                        //$order_state = new OrderState((int)$order->current_state);

                        $payment_link = (string)$dss_order->getPaymentLink($order->id);
                        $tracking_link = '';

                        $this->context->smarty->assign(
                            array(
                                'iscredit' => false,
                                'status' => 'success',
                                'shop_name' => $shop_name,
                                'id_order' => (int)$order->id,
                                'reference' => (string)$order->reference,
                                'payment_link' => $payment_link,
                                'contact_url' => $this->context->link->getPageLink('contact', true),
                                'currency' => (string)$currency->iso_code,
                                'total' => (float)$order->total_paid_tax_incl
                            )
                        );

                        DssEventsClass::setEvent('info', sprintf($this->module->l('New payment for order %s, Total %s', 'dropshipsystem'), $order->reference, Tools::displayPrice($order->total_paid_tax_excl, $currency)));

                        if (is_callable(array('Tools', 'changeFileMTime'))) {
                            Tools::changeFileMTime($this->module->push_filename);
                        }

                        if (version_compare(_PS_VERSION_, '1.7', '<')) {
                            return $this->setTemplate('payment-result.tpl');
                        } else {
                            return $this->setTemplate('module:dropshipsystem/views/templates/front/1.7/payment-result.tpl');
                        }
                        /*
                        $this->_html .= "<order>";
                        $this->_html .= "<id>".(int)$order->id."</id>";
                        $this->_html .= "<reference>".(string)$order->reference."</reference>";
                        $this->_html .= "<date>".(string)$order->date_add."</date>";
                        $this->_html .= "<shipping_method>".(int)$dss_order->shipping_method."</shipping_method>";
                        $this->_html .= "<total_products>".(string)$order->total_products."</total_products>";
                        $this->_html .= "<total_shipping>".(string)$order->total_shipping_tax_excl."</total_shipping>";
                        $this->_html .= "<total_discounts>".(string)$order->total_discounts_tax_excl."</total_discounts>";
                        $this->_html .= "<total>".(string)$order->total_paid_tax_excl."</total>";
                        $this->_html .= "<currency>".(string)$currency->iso_code."</currency>";
                        //$this->_html .= "<carrier>".(string)$order_carrier->name."</carrier>";
                        $this->_html .= "<current_state>PAYMENT_SUCCESS</current_state>";
                        //$this->_html .= "<current_state>".(string)$order_state->name[(int)Context::getContext()->language->id]."</current_state>";
                        $this->_html .= "<payment_link><![CDATA[".(string)$payment_link."]]></payment_link>";
                        $this->_html .= "<tracking_link><![CDATA[".(string)$tracking_link."]]></tracking_link>";
                        $this->_html .= "</order>";
                        */
                    } else {
                        if ($total_payed_amount < $payment_amount) {
                            $this->showError('5016', 'Authorized import is major of total order import');
                        } elseif ($total_payed_amount == $payment_amount) {
                            $this->showError('5015', 'Order has been already fully payed');
                        }
                    }
                }
            } else {
                DssEventsClass::setEvent('error', sprintf($this->module->l('PAYMENT ERROR: %s', 'dropshipsystem'), (string)$payres['error']));

                $payment_token = (string)$payres['token'];
                $payment_order = new DssPaymentsTokenClass($payment_token);
                $id_currency = (int)Currency::getIdByIsoCode($payres['currency']);
                $currency = new Currency($id_currency);

                $order = new Order((int)$payment_order->id_order);
                $id_dss_order = DssOrderClass::getDssOrderIDByOrderID($order->id);
                $dss_order = new DssOrderClass($id_dss_order);

                $payment_link = (string)$dss_order->getPaymentLink($order->id);

                $this->context->smarty->assign(
                    array(
                        'status' => 'success',
                        'shop_name' => $shop_name,
                        'iscredit' => 0,
                        'id_order' => (int)$order->id,
                        'reference' => (string)$order->reference,
                        'payment_link' => $payment_link,
                        'currency' => (string)$currency->iso_code,
                        'total' => (float)$order->total_paid_tax_incl,
                        'message' => sprintf($this->module->l('PAYMENT ERROR: %s', 'dropshipsystem'), (string)$payres['error']),
                        'contact_url' => $this->context->link->getPageLink('contact', true),
                    )
                );

                if (version_compare(_PS_VERSION_, '1.7', '<')) {
                    return $this->setTemplate('payment-result.tpl');
                } else {
                    return $this->setTemplate('module:dropshipsystem/views/templates/front/1.7/payment-result.tpl');
                }
            }
            die;
        }

        if (Tools::getIsset('u')) {
            $req_username = Tools::getValue('u');
            if (!Validate::isEmail($req_username)) {
                $this->showError('1006', 'Username format is invalid (email address is required)');
            }
        } else {
            $this->showError('1002', 'Username parameter not specified');
        }

        if (Tools::getIsset('p')) {
            $req_password = Tools::getValue('p');
        } else {
            $this->showError('1003', 'Password parameter not specified');
        }

        if (Tools::getIsset('s')) {
            $req_secret = Tools::getValue('s');
        } else {
            $this->showError('1004', 'API Secret parameter not specified');
        }

        $this->prices_vat = (float)Configuration::get('DSS_PRICES_VAT', null, null, $id_shop);

        $this->dropshippers = new DssDropshippersClass();
        $customer = new Customer();
        $customer->getByEmail(trim($req_username), trim($req_password));

        $id_customer = (int)$customer->id;
        $group = $customer->id_default_group;

        if (isset($customer->active) && !$customer->active) {
            DssEventsClass::setEvent('alert', sprintf($this->module->l('Customer id %s cannot access because is not active', 'dropshipsystem'), $customer->id));
            $this->showError('1010', 'Your account isn\'t available at this time, please contact us');
        } elseif (!$customer || !$customer->id) {
            DssEventsClass::setEvent('alert', sprintf($this->module->l('Authentication failed for customer %s', 'dropshipsystem'), $req_username));
            $this->showError('1011', 'Authentication failed');
        } else {
            $dss_auth = (object)DssDropshippersClass::getUser((int)$customer->id, $req_secret);

            if (isset($dss_auth->id_dss_dropshipper) && (int)$dss_auth->id_dss_dropshipper) {
                $id_dropshipper = (int)$dss_auth->id_dss_dropshipper;
                //$id_shop = (int)$dss_auth->id_shop;
                $allowed_domains = @unserialize($dss_auth->allowed_domains);
                if (is_array($allowed_domains) && count($allowed_domains) > 0) {
                    $referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
                    $referer = parse_url($referer);
                    if (!in_array((string)$referer['host'], $allowed_domains)) {
                        DssEventsClass::setEvent('alert', sprintf($this->module->l('Connection is not allowed from host %s using username %s', 'dropshipsystem'), (string)$referer['host'], (string)$req_username));
                        $this->showError('1016', 'Connection is not allowed from this host');
                    }
                }

                $allowed_time = @unserialize($dss_auth->allowed_time);
                if (is_array($allowed_time) && count($allowed_time) > 0) {
                    $tz = (string)Configuration::get('PS_TIMEZONE', null, null, $id_shop);
                    $dt = new DateTime('now', new DateTimeZone($tz));
                    $time = strtotime($dt->format('1970-01-01 H:i:00').' UTC');
                    if ((int)$allowed_time[0] <= (int)$allowed_time[1]) {
                        if (((int)$time >= 0 && (int)$time < (int)$allowed_time[0]) ||
                            ((int)$time > (int)$allowed_time[1] && (int)$time <= 86400)) {
                            DssEventsClass::setEvent('alert', sprintf($this->module->l('Connection is not allowed at this time for dropshipper id %d', 'dropshipsystem'), (int)$id_dropshipper));
                            $this->showError('1017', 'Connection is not allowed at this time');
                        }
                    } else {
                        if ((int)$time >= (int)$allowed_time[1] && (int)$time < (int)$allowed_time[0]) {
                            DssEventsClass::setEvent('alert', sprintf($this->module->l('Connection is not allowed at this time for dropshipper id %d', 'dropshipsystem'), (int)$id_dropshipper));
                            $this->showError('1017', 'Connection is not allowed at this time');
                        }
                    }
                }

                if ($dss_auth->active == 1) {
                    if (empty($dss_auth->date_end) || (int)strtotime($dss_auth->date_end) >= time()) {
                        $this->dropshippers = new $this->dropshippers((int)$id_dropshipper);
                        $this->dropshippers->setLastConnectionDate();

                        $_country = new Address($this->dropshippers->id_address_invoice);
                        $this->dropshippers->id_country = (int)$_country->id_country;
                        unset($_country);

                        $this->wholesale_base_price = (int)Configuration::get('DSS_WHOLESALE_BASE_PRICE', null, null, $id_shop);
                        $this->base_price = (int)Configuration::get('DSS_BASE_PRICE', null, null, $id_shop);
                        $this->customer_wholesale_discount = (float)$this->dropshippers->wholesale_reduction;
                        $this->customer_discount = (float)$this->dropshippers->reduction;

                        $context = Context::getContext();

                        if (version_compare(_PS_VERSION_, '1.7', '<')) {
                            $context->cookie->id_compare = isset($context->cookie->id_compare) ? $context->cookie->id_compare: CompareProduct::getIdCompareByIdCustomer($customer->id);
                        }

                        $context->cookie->id_customer = (int)$id_customer;
                        $context->cookie->customer_lastname = $customer->lastname;
                        $context->cookie->customer_firstname = $customer->firstname;
                        $context->cookie->logged = 1;
                        $customer->logged = 1;
                        $context->cookie->is_guest = $customer->isGuest();
                        $context->cookie->passwd = $customer->passwd;
                        $context->cookie->email = $customer->email;

                        $context->customer = $customer;
                        $context->dropshippers = $this->dropshippers;
                    } else {
                        DssEventsClass::setEvent('alert', sprintf($this->module->l('Dropshipper id %s is expired', 'dropshipsystem'), $id_dropshipper));
                        $this->showError('1014', 'Dropshipper profile is expired');
                    }
                } else {
                    DssEventsClass::setEvent('alert', sprintf($this->module->l('Dropshipper id %s is disabled', 'dropshipsystem'), $id_dropshipper));
                    $this->showError('1013', 'Dropshipper profile is disabled');
                }
            } else {
                DssEventsClass::setEvent('alert', sprintf($this->module->l('Invalid dropshipper profile for customer id', 'dropshipsystem'), $customer->id));
                $this->showError('1012', 'Invalid Dropshipper profile');
            }
        }

        $_cat = new Category($this->id_home_category);
        $home_level = (int)$_cat->level_depth;
        unset($_cat);

        if ($req_action == 'apitest') {
            $this->context->smarty->assign(array(
                'action' => 'apitest',
                'is_logged' => $customer->logged,
            ));

            $this->_html .= $this->context->smarty->fetch(dirname(__FILE__).'/../../views/templates/front/webservice.tpl');
        } elseif ($req_action == 'getclients') {
            $_clients = unserialize((string)Configuration::get('DSS_CLIENTS'));
            $clients = array();
            foreach ($_clients as $_client) {
                $clients[] = array(
                    'name' => (string)$_client['name'],
                    'version' => (string)$_client['version'],
                    'date' => (string)$_client['date']
                );
            }
            $this->context->smarty->assign(array(
                'action' => 'getclients',
                'is_logged' => $customer->logged,
                'clients' => $clients
            ));

            $this->_html .= $this->context->smarty->fetch(dirname(__FILE__).'/../../views/templates/front/webservice.tpl');
        } elseif ($req_action == 'getinfo') {
            $shop_name = $this->context->shop->name;
            $currency = new Currency($this->id_default_currency);
            $categories = $this->dss->getGroupCategories($group);

            $enable_fastsync = (int)Configuration::get('DSS_ENABLE_FASTSYNC', null, null, $id_shop);

//            $this->context->smarty->assign(array(
//                'action' => 'getinfo',
//                'langs' => $langs,
//                'shop_name' => $shop_name,
//                'currency' => $currency,
//                'dropshippers' => $this->dropshippers,
//                'categories' => $categories
//            ));
//
//            $this->_html .= $this->context->smarty->fetch(dirname(__FILE__).'/../../views/templates/front/webservice.tpl');

            $this->_html .= '<infos>';
            foreach ($langs as $key => $lang) {
                $this->_html .= "<lang id=\"".(int)$key."\" iso=\"".(string)$lang['iso_code']."\">".(string)$lang['name']."</lang>";
            }
            $this->_html .= '<shop_name><![CDATA['.(string)$shop_name.']]></shop_name>';
            $this->_html .= '<currency>'.(string)$currency->iso_code.'</currency>';
            $this->_html .= '<country>'.(string)$this->context->country->iso_code.'</country>';
            $this->_html .= '<account_type>'.((int)$this->dropshippers->feed_type ? 'C' : 'R').'</account_type>';
            $this->_html .= '<payment_type>'.(string)$this->dropshippers->payment_type.'</payment_type>';
            $this->_html .= '<current_credit>'.(float)$this->dropshippers->credit.'</current_credit>';
            //$this->_html .= '<tax_percent>'.(float)$this->dropshippers->customer_tax_value.'</tax_percent>';
            $this->_html .= '<last_order>'.(string)$this->dropshippers->last_order.'</last_order>';
            $this->_html .= '<expiration_date>'.(empty($this->dropshippers->date_end) ? '' : (string)$this->dropshippers->date_end).'</expiration_date>';
            $this->_html .= '<categories>'.(int)count($categories).'</categories>';
            $this->_html .= '<products>'.(int)$this->dss->countProducts($categories_code).'</products>';
            $this->_html .= '<fastsync>'.(int)$enable_fastsync.'</fastsync>';
            $this->_html .= '<shipping_methods>';
            for ($i = 1; $i < 4; $i++) {
                $id_carrier = (int)Configuration::get('DSS_SHIPPING_METHOD_'.$i, null, null, $id_shop);
                $carrier = new Carrier($id_carrier);
                $this->_html .= '<shipping id="'.$i.'">';
                $this->_html .= '<name><![CDATA['.(string)$carrier->name.']]></name>';
                $this->_html .= '</shipping>';
            }
            $this->_html .= '</shipping_methods>';

            $attribute_group = AttributeGroup::getAttributesGroups((int)$context->language->id);
            $this->_html .= "<attributes_groups>";
            foreach ($attribute_group as $att_grp) {
                $this->_html .= "<attribute_group>";
                $this->_html .= "<name><![CDATA[".(string)$att_grp['name']."]]></name>";
                if (!$this->dropshippers->simple_feed) {
                    $this->_html .= "<public_name><![CDATA[".(string)$att_grp['public_name']."]]></public_name>";
                    $this->_html .= "<is_color>".(int)$att_grp['is_color_group']."</is_color>";
                    $this->_html .= "<group_type>".(string)$att_grp['group_type']."</group_type>";
                }
                $this->_html .= "</attribute_group>";
            }
            $this->_html .= "</attributes_groups>";
            $this->_html .= '</infos>';
        } elseif ($req_action == 'sync') {
            $version = null;
            $limit = 100;
            if (Tools::getIsset('version')) {
                $version = (int)Tools::getValue('version');
                if (!$version) {
                    $version = 1;
                }
            }
            if (Tools::getIsset('limit')) {
                $limit = (int)Tools::getValue('limit');
                if (!$limit) {
                    $limit = 100;
                }
            }
            if (isset($version)) {
                $actionlog = new DssActionLogClass();
                $actions = $actionlog->getSync($version, $group, $limit);

                $this->_html .= '<sync>';
                if (isset($actions) && !empty($actions)) {
                    foreach ($actions as $action) {
                        if ((string)$action['type'] == 'categories') {
                            $_cat = new Category((int)$action['id_reference']);
                            $this->getCategoriesFeed(array((array)$_cat), $langs, $home_level, false, (int)$action['id_dss_action']);
                        } elseif ((string)$action['type'] == 'quantities') {
                            $this->getQuantitiesFeed(array($action['id_reference']), (int)$action['id_dss_action'], (int)$id_shop);
                        } elseif ((string)$action['type'] == 'products') {
                            if (!is_null($action['action']) && !is_null($action['reference'])) {
                                $this->getProductsActionFeed((int)$action['id_dss_action'], (string)$action['action'], (string)$action['reference']);
                            } else {
                                $this->getProductsFeed(array($action['id_reference']), $langs, (int)$action['id_dss_action'], (int)$group, (int)$id_shop);
                            }
                        }
                    }
                }
                $this->_html .= '</sync>';
            } else {
                $this->showError('6000', 'Version parameter not specified');
            }
        } elseif ($req_action == 'getcategories') {
            //$categories = Category::getCategories((int)Context::getContext()->language->id, true, true);
            $categories = Category::getNestedCategories($this->id_home_category, false, true, $group);

            $this->_html .= '<categories>';
            if (isset($categories[$this->id_home_category]['children']) && count($categories[$this->id_home_category]['children']) > 0) {
                $this->getCategoriesFeed($categories[$this->id_home_category]['children'], $langs, $home_level, true);
            }
            $this->_html .= '</categories>';
        } elseif ($req_action == 'getquantities') {
            $categoryid = null;
            if (Tools::getIsset('categoryid')) {
                $categoryid = (string)Tools::getValue('categoryid');
            }

            if (isset($categoryid)) {
                $id_category = (int)$this->dss->getCategoryIDByReference($categoryid);
                if ($id_category == 0) {
                    $this->showError('2000', 'Invalid category');
                }
                //$products = Product::getProducts((int)$context->language->id, 0, 0, 'id_product', 'asc', $id_category);
                $products = $this->dss->getSimpleProducts((int)$context->language->id, $group, $id_category);
            } else {
                $products = $this->dss->getSimpleProducts((int)$context->language->id, $group);
            }

            $this->_html .= '<quantities>';
            $this->getQuantitiesFeed($products, 0, (int)$id_shop);
            $this->_html .= '</quantities>';
        } elseif ($req_action == 'checkproducts') {
            if (Tools::getIsset('items')) {
                $items = (string)Tools::getValue('items');
            } else {
                $this->showError('1021', 'Items parameter not specified');
            }

            $this->_html .= '<products>';
            $items = explode(',', $items);
            if (isset($items) && is_array($items)) {
                foreach ($items as $item) {
                    $_product = $this->dss->getProductIDByReference(urldecode(trim((string)$item)), $this->context->shop->id);
                    $product = new Product((int)$_product['id_product'], true, (int)$context->language->id);
                    $id_stock_available = (int)StockAvailable::getStockAvailableIdByProductId((int)$_product['id_product'], (int)$_product['id_product_attribute'], (int)$context->shop->id);

                    $this->_html .= "<product>";
                    $this->_html .= "<reference><![CDATA[".trim((string)$item)."]]></reference>";
                    if ($id_stock_available) {
                        $stock_available = new StockAvailable($id_stock_available);
                        if ($stock_available->quantity <= 0 && (int)Configuration::get('PS_ORDER_OUT_OF_STOCK', null, null, $id_shop) == 1) {
                            $stock_available->quantity = 999999;
                        }
                        $this->_html .= "<quantity>".(int)$stock_available->quantity."</quantity>";
                        $this->_html .= "<available_for_order>".(bool)$product->available_for_order."</available_for_order>";
                        $this->_html .= "<available_date>".$product->available_date."</available_date>";
                    } else {
                        $this->_html .= "<error>Invalid product</error>";
                    }
                    $this->_html .= "</product>";
                    unset($product);
                }
            }
            $this->_html .= '</products>';
        } elseif ($req_action == 'getproducts') {
            $categoryid = null;
            if (Tools::getIsset('categoryid')) {
                $categoryid = trim((string)Tools::getValue('categoryid'));
            } else {
                $this->showError('1020', 'Category parameter not specified');
            }

            $only_active = false;
            if ((int)Configuration::get('DSS_REMOVE_DISABLED_PRODUCTS_FROM_FEED', null, null, $id_shop) == 1) {
                $only_active = true;
            }

            $id_category = (int)$this->dss->getCategoryIDByReference($categoryid);
            if ($id_category == 0) {
                $this->showError('2000', 'Invalid category');
            }

            $products = $this->dss->getProducts((int)$context->language->id, 0, 0, 'id_product', 'asc', $id_category, $only_active, $group);

            $this->_html .= '<products>';
            $this->getProductsFeed($products, $langs, 0, $group, $id_shop);
            $this->_html .= '</products>';
        } elseif ($req_action == 'getorder') {
            if (Tools::getIsset('ref')) {
                $req_order = (string)Tools::getValue('ref');
            } else {
                $this->showError('5011', 'Order reference not specified');
            }

            $id_order = (int)DssOrderClass::getOrderIDByReference($req_order);

            if ($id_order > 0) {
                $id_customer = (int)DssOrderClass::verifyOrderOwner($id_dropshipper, $id_order);

                $order = new Order($id_order);

                if ((int)$order->id_customer == $id_customer) {
                    $id_dss_order = DssOrderClass::getDssOrderIDByOrderID($order->id);
                    $dss_order = new DssOrderClass($id_dss_order);
                    //$order_state = new OrderState((int)$order->current_state);
                    $currency = new Currency($order->id_currency);

                    $payment_link = (string)$dss_order->getPaymentLink($order->id);

                    $tracking_link = '';
                    $order_carriers = $order->getShipping();
                    if (isset($order_carriers) && $order_carriers) {
                        foreach ($order_carriers as $order_carrier) {
                            if (Tools::strlen($order_carrier['tracking_number'])> 0) {
                                $tracking_link = str_replace('@', (string)$order_carrier['tracking_number'], (string)$order_carrier['url']);
                            }
                        }
                    }

                    if ((int)$order->current_state == (int)Configuration::get('PS_OS_DROPSHIP', null, null, $id_shop) ||
                        (int)$order->current_state == (int)Configuration::get('PS_OS_BANKWIRE', null, null, $id_shop) ||
                        (int)$order->current_state == (int)Configuration::get('PS_OS_CHEQUE', null, null, $id_shop)) {
                        $status_desc = 'PENDING_PAYMENT';
                    } elseif ((int)$order->current_state == (int)Configuration::get('PS_OS_PAYMENT', null, null, $id_shop)) {
                        $status_desc = 'PAYMENT_SUCCESS';
                    } elseif ((int)$order->current_state == (int)Configuration::get('PS_OS_PREPARATION', null, null, $id_shop)) {
                        $status_desc = 'PREPARATION_IN_PROGRESS';
                    } elseif ((int)$order->current_state == (int)Configuration::get('PS_OS_SHIPPING', null, null, $id_shop)) {
                        $status_desc = 'SHIPPING_IN_PROGRESS';
                    } elseif ((int)$order->current_state == (int)Configuration::get('PS_OS_DELIVERED', null, null, $id_shop)) {
                        $status_desc = 'DELIVERED';
                    } elseif ((int)$order->current_state == (int)Configuration::get('PS_OS_CANCELED', null, null, $id_shop)) {
                        $status_desc = 'CANCELLED';
                    } elseif ((int)$order->current_state == (int)Configuration::get('PS_OS_REFUND', null, null, $id_shop)) {
                        $status_desc = 'REFUNDED';
                    } elseif ((int)$order->current_state == (int)Configuration::get('PS_OS_OUTOFSTOCK_PAID', null, null, $id_shop)) {
                        $status_desc = 'OUTOFSTOCK_PAID';
                    } elseif ((int)$order->current_state == (int)Configuration::get('PS_OS_OUTOFSTOCK_UNPAID', null, null, $id_shop)) {
                        $status_desc = 'OUTOFSTOCK_UNPAID';
                    } elseif ((int)$order->current_state == (int)Configuration::get('PS_OS_ERROR', null, null, $id_shop)) {
                        $status_desc = 'ERROR';
                    } else {
                        $status_desc = 'UNKNOW_STATUS';
                        $order_status = DssOrderClass::getOrderStates((int)$context->language->id, (int)$order->current_state);
                        if (isset($order_status)) {
                            if ((int)$order_status['paid'] == 1 && (int)$order_status['shipped'] == 0 && (int)$order_status['delivery'] == 0) {
                                $status_desc = 'PAYMENT_SUCCESS';
                            } elseif ((int)$order_status['paid'] == 1 && (int)$order_status['shipped'] == 1 && (int)$order_status['delivery'] == 0) {
                                $status_desc = 'SHIPPING_IN_PROGRESS';
                            } elseif ((int)$order_status['paid'] == 1 && (int)$order_status['shipped'] == 1 && (int)$order_status['delivery'] == 1) {
                                $status_desc = 'DELIVERED';
                            }
                        }
                    }

                    $this->_html .= "<order>";
                    $this->_html .= "<id>".(int)$order->id."</id>";
                    $this->_html .= "<reference>".(string)$order->reference."</reference>";
                    $this->_html .= "<date>".(string)$order->date_add."</date>";
                    $this->_html .= "<shipping_method>".(int)$dss_order->shipping_method."</shipping_method>";
                    $this->_html .= "<total_products>".(string)$order->total_products."</total_products>";
                    $this->_html .= "<total_shipping>".(string)$order->total_shipping_tax_excl."</total_shipping>";
                    $this->_html .= "<total_discounts>".(string)$order->total_discounts_tax_excl."</total_discounts>";
                    $this->_html .= "<total>".(string)$order->total_paid_tax_excl."</total>";
                    $this->_html .= "<currency>".(string)$currency->iso_code."</currency>";
                    //$this->_html .= "<carrier>".(string)$order_carrier->name."</carrier>";
                    $this->_html .= "<current_state>".(string)$status_desc."</current_state>";
                    //$this->_html .= "<current_state>".(string)$order_state->name[(int)Context::getContext()->language->id]."</current_state>";
                    $this->_html .= "<payment_link><![CDATA[".(string)$payment_link."]]></payment_link>";
                    $this->_html .= "<tracking_link><![CDATA[".(string)$tracking_link."]]></tracking_link>";
                    $this->_html .= "</order>";
                } else {
                    $this->showError('5019', 'You are not authorized to get this order');
                }
            } else {
                $this->showError('5000', 'Invalid order reference');
            }
        } elseif ($req_action == 'setorder') {
            $total_discounts = 0;
            $total_products_tax_excl = 0;
            $total_products_tax_incl = 0;
            $total_shipping = 0;
            $total_shipping_extra_fee = 0;
            //$total_paid = 0;
            $carrier_tax_rate = 0;
            $order_reference = null;

            $dss = new DropShipSystem();
            $dss->writeLog('-------------------------------------');
            $dss->writeLog('------------- NEW ORDER -------------');
            $dss->writeLog('-------------------------------------');

            try {
                $this->context->dropshippers = $this->dropshippers;

                $xmldata = urldecode(Tools::getValue('xmldata'));

                if ($this->debug) {
                    $this->showError('9001', 'XMLDATA string', $xmldata);
                }

                $o_xml_data = new SimpleXMLElement($xmldata, LIBXML_NOCDATA);

                $payment_status = isset($o_xml_data->payment_status) ? (string)$o_xml_data->payment_status : null;
                $payment_method = isset($o_xml_data->payment_method) ? (string)$o_xml_data->payment_method : null;
                $shipping_method = (int)$o_xml_data->shipping_method;
                //$shipping_id = (int)Tools::getValue('shipping_id');

                $dss->writeLog('PAYMENT STATUS: '.$payment_status);
                $dss->writeLog('PAYMENT METHOD: '.$payment_method);
                $dss->writeLog('SHIPPING METHOD: '.$shipping_method);

                $shipping_company = (string)$o_xml_data->shipping_company;
                $shipping_lastname = (string)$o_xml_data->shipping_lastname;
                $shipping_firstname = (string)$o_xml_data->shipping_firstname;
                $shipping_address1 = (string)$o_xml_data->shipping_address1;
                $shipping_address2 = (string)$o_xml_data->shipping_address2;
                $shipping_cap = (string)$o_xml_data->shipping_cap;
                $shipping_city = (string)$o_xml_data->shipping_city;
                $shipping_country = (string)$o_xml_data->shipping_country;
                $shipping_state = (string)$o_xml_data->shipping_state;
                $shipping_phone = (string)$o_xml_data->shipping_phone;
                $shipping_mobile = (string)$o_xml_data->shipping_mobile;

                $dss->writeLog('SHIPPING DATA CAPTURED');

                if ((int)$this->dropshippers->feed_type == 1) {
                    $order_reference = (string)$o_xml_data->reference;

                    $invoice_company = (string)$o_xml_data->invoice_company;
                    $invoice_lastname = (string)$o_xml_data->invoice_lastname;
                    $invoice_firstname = (string)$o_xml_data->invoice_firstname;
                    $invoice_address1 = (string)$o_xml_data->invoice_address1;
                    $invoice_address2 = (string)$o_xml_data->invoice_address2;
                    $invoice_cap = (string)$o_xml_data->invoice_cap;
                    $invoice_city = (string)$o_xml_data->invoice_city;
                    $invoice_country = (string)$o_xml_data->invoice_country;
                    $invoice_state = (string)$o_xml_data->invoice_state;
                    $invoice_phone = (string)$o_xml_data->invoice_phone;
                    $invoice_mobile = (string)$o_xml_data->invoice_mobile;

                    $customer_lastname = (string)$o_xml_data->customer_lastname;
                    $customer_firstname = (string)$o_xml_data->customer_firstname;
                    $customer_email = (string)$o_xml_data->customer_email;

                    $dss->writeLog('INVOICE DATA CAPTURED');

                    //$total_discounts = (float)$o_xml_data->total_discounts;
                    //$total_products = (float)$o_xml_data->total_products;
                    $total_shipping = (float)$o_xml_data->total_shipping;
                    $total_shipping_extra_fee = (float)$o_xml_data->total_shipping_extra_fee;
                    //$total_paid = (float)$o_xml_data->total_paid;
                    $carrier_tax_rate = (float)$o_xml_data->carrier_tax_rate;

                    $dss->writeLog('SHIPPING METHOD: '.$shipping_method);
                }

                $order_products = $o_xml_data->products;
                $discounts = isset($o_xml_data->discounts) ? $o_xml_data->discounts : null;
                $messages = isset($o_xml_data->messages) ? $o_xml_data->messages : null;
                $comments = (string)$o_xml_data->comments;

                if ((int)$this->dropshippers->feed_type == 1) {
                    if (empty($customer_lastname)) {
                        $this->showError('5020', 'Missing data: Customer Last Name');
                    }
                    if (empty($customer_firstname)) {
                        $this->showError('5020', 'Missing data: Customer First Name');
                    }
                    if (empty($customer_email)) {
                        $this->showError('5020', 'Missing data: Customer Email');
                    }
                }

                if (empty($shipping_lastname)) {
                    $this->showError('5020', 'Missing data: Shipping Last Name');
                }
                if (empty($shipping_firstname)) {
                    $this->showError('5020', 'Missing data: Shipping First Name');
                }
                if (empty($shipping_address1)) {
                    $this->showError('5020', 'Missing data: Shipping Address');
                }
                if (empty($shipping_cap)) {
                    $this->showError('5020', 'Missing data: Shipping Zip/Cap');
                }
                if (empty($shipping_city)) {
                    $this->showError('5020', 'Missing data: Shipping City');
                }
                if (empty($shipping_country)) {
                    $this->showError('5020', 'Missing data: Shipping Country');
                }

                if ((int)$this->dropshippers->feed_type == 1) {
                    if (empty($invoice_lastname)) {
                        $this->showError('5020', 'Missing data: Invoice Last Name');
                    }
                    if (empty($invoice_firstname)) {
                        $this->showError('5020', 'Missing data: Invoice First Name');
                    }
                    if (empty($invoice_address1)) {
                        $this->showError('5020', 'Missing data: Invoice Address');
                    }
                    if (empty($invoice_cap)) {
                        $this->showError('5020', 'Missing data: Invoice Zip/Cap');
                    }
                    if (empty($invoice_city)) {
                        $this->showError('5020', 'Missing data: Invoice City');
                    }
                    if (empty($invoice_country)) {
                        $this->showError('5020', 'Missing data: Invoice Country');
                    }
                }

                $allowOrdersZeroQty = (int)Configuration::get('DSS_ALLOW_ORDERS_ZERO_QTY');

                $check_out_of_stock = array(0);
                if (Configuration::get('PS_ORDER_OUT_OF_STOCK') == 0) {
                    $check_out_of_stock[] = 2;
                }

                $_state = new State((int)Configuration::get('PS_SHOP_STATE_ID', null, null, $id_shop));

                $shop_name = (string)$this->context->shop->name;
                $shop_address = (string)Configuration::get('PS_SHOP_ADDR1', null, null, $id_shop);
                $shop_city = (string)Configuration::get('PS_SHOP_CITY', null, null, $id_shop);
                $shop_cap = (string)Configuration::get('PS_SHOP_CODE', null, null, $id_shop);
                $shop_coutry = (string)Country::getIsoById((int)Configuration::get('PS_SHOP_COUNTRY_ID', null, null, $id_shop));
                $shop_state = (string)$_state->iso_code;
                $shop_phone = (string)Configuration::get('PS_SHOP_PHONE', null, null, $id_shop);

                $shop_logo = 'http'.(Configuration::get('PS_SSL_ENABLED', null, null, $id_shop) ? 's' : '').'://'.
                                    Tools::getShopDomain(false, true).__PS_BASE_URI__.'img/'.(string)Configuration::get('PS_LOGO', null, null, $id_shop);
                unset($_state);

                $id_country_delivery = Country::getByIso($shipping_country);
                if (!$id_country_delivery) {
                    $this->showError('5021', 'Invalid data: Shipping Country');
                }

                $id_state_delivery = 0;
                if ($id_country_delivery && Country::containsStates($id_country_delivery)) {
                    if (empty($shipping_state)) {
                        $this->showError('5020', 'Missing data: Shipping State');
                    }

                    $id_state_delivery = State::getIdByIso($shipping_state, $id_country_delivery);

                    if (!$id_state_delivery) {
                        $this->showError('5021', 'Invalid data: Shipping State');
                    }
                }

                if ((int)$this->dropshippers->feed_type == 1) {
                    $id_country_invoice = Country::getByIso($invoice_country);
                    if (!$id_country_invoice) {
                        $this->showError('5021', 'Invalid data: Invoice Country');
                    }

                    $id_state_invoice = 0;
                    if ($id_country_invoice && Country::containsStates($id_country_invoice)) {
                        if (empty($invoice_state)) {
                            $this->showError('5020', 'Missing data: Invoice State');
                        }
                        $id_state_invoice = State::getIdByIso($invoice_state, $id_country_invoice);
                        if (!$id_state_invoice) {
                            $this->showError('5021', 'Invalid data: Invoice State');
                        }
                    }
                }

                $delivery_alias = md5(serialize(array(
                    'DRP '.(int)$id_dropshipper,
                    $shipping_company,
                    $shipping_lastname,
                    $shipping_firstname,
                    $shipping_address1,
                    $shipping_address2,
                    $shipping_cap,
                    $shipping_city,
                    $id_country_delivery,
                    $id_state_delivery,
                    $shipping_phone,
                    $shipping_mobile)));

                /* Find the carrier id */
                $id_default_carrier = (int)Configuration::get('DSS_SHIPPING_METHOD_'.$shipping_method, null, null, $id_shop);
                if (!(int)$id_default_carrier) {
                    $this->showError('5004', 'Invalid shipping method');
                }

                $dss->writeLog('ID DEFAULT CARRIER: '.$id_default_carrier);

                if ((int)$this->dropshippers->feed_type == 1) {
                    $context = Context::getContext();
                    $context->customer->logout();
                    //$context->customer->mylogout();

                    $customer = new Customer();
                    if (Validate::isEmail($customer_email)) {
                        $authentication = $customer->getByEmail($customer_email);
                        if (!$authentication || !$customer->id) {
                            $customer = new Customer();
                            $customer->firstname = $customer_firstname;
                            $customer->lastname = $customer_lastname;
                            $customer->email = $customer_email;
                            if (version_compare(_PS_VERSION_, '1.7', '>=') === true) {
                                $ServiceLocator = new PrestaShop\PrestaShop\Adapter\ServiceLocator;
                                $crypto = $ServiceLocator::get('\\PrestaShop\\PrestaShop\\Core\\Crypto\\Hashing');
                                if ($crypto instanceof PrestaShop\PrestaShop\Core\Crypto\Hashing || $crypto instanceof Hashing) {
                                    $customer->passwd = $crypto->hash(uniqid(rand(), true));
                                }
                            } else {
                                $customer->passwd = md5(uniqid(rand(), true));
                            }
                            $customer->active = 1;

                            if (!$customer->add()) {
                                $customer->addGroups(array($group));
                                $this->showError('5024', 'Error during create customer');
                            }
                        } elseif ($authentication && $customer->id) {
                            if (!DssClass::isHashedPassword($customer->passwd)) {
                                if (version_compare(_PS_VERSION_, '1.7', '>=') === true) {
                                    $ServiceLocator = new PrestaShop\PrestaShop\Adapter\ServiceLocator;
                                    $crypto = $ServiceLocator::get('\\PrestaShop\\PrestaShop\\Core\\Crypto\\Hashing');
                                    if ($crypto instanceof Hashing) {
                                        $customer->passwd = $crypto->hash($customer->passwd);
                                    }
                                } else {
                                    if (!Validate::isMd5($customer->passwd)) {
                                        $customer->passwd = md5($customer->passwd);
                                    }
                                }
                            }

                            if (!$customer->update()) {
                                $this->showError('5030', 'Error during updating customer');
                            }
                            $customer->id_risk = 0;
                        }

                        if (version_compare(_PS_VERSION_, '1.7', '<')) {
                            $context->cookie->id_compare = isset($context->cookie->id_compare) ? $context->cookie->id_compare: CompareProduct::getIdCompareByIdCustomer($customer->id);
                        }

                        $context->cookie->id_customer = (int)$customer->id;
                        $context->cookie->customer_lastname = $customer->lastname;
                        $context->cookie->customer_firstname = $customer->firstname;
                        $context->cookie->logged = 1;
                        $customer->logged = 1;
                        $context->cookie->is_guest = $customer->isGuest();
                        $context->cookie->passwd = $customer->passwd;
                        $context->cookie->email = $customer->email;

                        $context->cookie->is_dropshipper_customer = 1;

                        $context->customer = $customer;

                        $dss->writeLog('AUTHENTICATED WITH CUSTOMER ID: '.$customer->id);
                    } else {
                        $this->showError('5020', 'Invalid data: Customer Email');
                    }
                }

                /* Check if delivery address exist otherwise make new one */
                $id_address_delivery = (int)DssAddressClass::getAddressIdByAlias((string)$delivery_alias, (int)$customer->id);
                if (!$id_address_delivery) {
                    $address_delivery = new Address((int)$id_address_delivery);
                } else {
                    $address_delivery = new Address();
                }

                /* Creare or update the shipping address */
                $address_delivery->id_customer = (int)$customer->id;
                $address_delivery->company = (string)$shipping_company;
                $address_delivery->lastname = (string)$shipping_lastname;
                $address_delivery->firstname = (string)$shipping_firstname;
                $address_delivery->address1 = (string)$shipping_address1;
                $address_delivery->address2 = (string)$shipping_address2;
                $address_delivery->postcode = (string)$shipping_cap;
                $address_delivery->city = (string)$shipping_city;
                $address_delivery->id_country = (int)$id_country_delivery;
                $address_delivery->id_state = (int)$id_state_delivery;
                $address_delivery->phone = (string)$shipping_phone;
                $address_delivery->phone_mobile = (string)$shipping_mobile;
                $address_delivery->other = (string)$comments;
                $address_delivery->alias = (string)$delivery_alias;
                $address_delivery->active = 1;
                $address_delivery->deleted = 1;

                if (!$id_address_delivery) {
                    if (!$address_delivery->add()) {
                        $this->showError('5028', 'Error saving delivery address');
                    }
                    $id_address_delivery = $address_delivery->id;

                    $dss_address = new DssAddressClass();
                    $dss_address->id_dss_dropshipper = $id_dropshipper;
                    $dss_address->alias = $delivery_alias;
                    $dss_address->id_address = $id_address_delivery;
                    $dss_address->save();
                } else {
                    $address_delivery->update();
                }

                $dss->writeLog('ADDRESS DELIVERY ID: '.$id_address_delivery);

                if ((int)$this->dropshippers->feed_type == 1) {
                    /* Secondary site */

                    $invoice_alias = md5(serialize(array(
                        'DRP '.(int)$id_dropshipper,
                        $invoice_company,
                        $invoice_lastname,
                        $invoice_firstname,
                        $invoice_address1,
                        $invoice_address2,
                        $invoice_cap,
                        $invoice_city,
                        $id_country_invoice,
                        $id_state_invoice,
                        $invoice_phone,
                        $invoice_mobile)));

                    /* Check if invoice address exist otherwise make new one */
                    $id_address_invoice = (int)DssAddressClass::getAddressIdByAlias((string)$invoice_alias, (int)$customer->id);
                    if (!$id_address_invoice) {
                        $address_invoice = new Address((int)$id_address_invoice);
                    } else {
                        $address_invoice = new Address();
                    }

                    /* Creare or update the invoice address */
                    $address_invoice->id_customer = (int)$customer->id;
                    $address_invoice->company = (string)$invoice_company;
                    $address_invoice->lastname = (string)$invoice_lastname;
                    $address_invoice->firstname = (string)$invoice_firstname;
                    $address_invoice->address1 = (string)$invoice_address1;
                    $address_invoice->address2 = (string)$invoice_address2;
                    $address_invoice->postcode = (string)$invoice_cap;
                    $address_invoice->city = (string)$invoice_city;
                    $address_invoice->id_country = (int)$id_country_invoice;
                    $address_invoice->id_state = (int)$id_state_invoice;
                    $address_invoice->phone = (string)$invoice_phone;
                    $address_invoice->phone_mobile = (string)$invoice_mobile;
                    $address_invoice->alias = (string)$invoice_alias;
                    $address_invoice->active = 1;
                    $address_invoice->deleted = 1;

                    if (!$id_address_invoice) {
                        if (!$address_invoice->add()) {
                            $this->showError('5029', 'Error saving invoice address');
                        }
                        $id_address_invoice = $address_invoice->id;

                        $dss_address = new DssAddressClass();
                        $dss_address->id_dss_dropshipper = $id_dropshipper;
                        $dss_address->alias = $invoice_alias;
                        $dss_address->id_address = $id_address_invoice;
                        $dss_address->save();
                    } else {
                        $address_invoice->update();
                    }
                } else {
                    /* Reseller site */
                    if (!$id_address_invoice = (int)$this->dropshippers->id_address_invoice) {
                        DssEventsClass::setEvent('error', sprintf($this->module->l('Dropshipper id %s without billing profile.', 'dropshipsystem'), $id_dropshipper));
                        $this->showError('1015', 'Dropshipper without billing profile');
                    }
                }

                $dss->writeLog('ADDRESS INVOICE ID: '.$id_address_invoice);

                /* Check for products */
                if (empty($order_products->product)) {
                    $this->showError('5021', 'Products not specified');
                } else {
                    $product_list = array();
                    $unavailable_products = array();
                    foreach ($order_products->product as $order_product) {
                        $data = $this->dss->getProductIDByReference((string)$order_product->reference, $this->context->shop->id);
                        $id_product = (int)$data['id_product'];
                        $id_product_attribute = (int)$data['id_product_attribute'];
                        $quantity = (int)$order_product->quantity;

                        /* Check if customer quantity is valid */
                        if (!$quantity) {
                            $this->showError('5003', 'Quantity value for product '.(string)$order_product->reference.' is not valid');
                            break;
                        }

                        $dss->writeLog('--------');
                        $dss->writeLog('PRODUCT ID: '.$id_product);
                        $dss->writeLog('PRODUCT ATTRIBUTE ID: '.$id_product_attribute);
                        $dss->writeLog('QUANTITY: '.$quantity);

                        $id_stock_available = (int)StockAvailable::getStockAvailableIdByProductId($id_product, $id_product_attribute, $this->context->shop->id);
                        if ($id_stock_available) {
                            $stock_available = new StockAvailable($id_stock_available);
                            if ($stock_available->quantity <= 0 && !in_array(2, $check_out_of_stock)) {
                                $stock_available->quantity = 999999;
                            }
                            if ($quantity > $stock_available->quantity) {
                                $unavailable_products[] = (string)$order_product->reference;
                            } else {
                                $product_to_add = new Product((int)$id_product, true, $this->id_default_lang);

                                /* Check if product is valid */
                                if (!$product_to_add->id || !$product_to_add->active) {
                                    $this->showError('5001', 'Invalid product '.(string)$order_product->reference);
                                    break;
                                }

                                /* Check if product is available for order */
                                if (!$product_to_add->available_for_order) {
                                    $this->showError('5002', 'Product '.(string)$order_product->reference.' is not available for order');
                                    break;
                                }

                                /* Check the quantity availability */
                                //if ($id_product_attribute > 0 && is_numeric($id_product_attribute)) {
                                //    if (!$product_to_add->isAvailableWhenOutOfStock($product_to_add->out_of_stock) && !Attribute::checkAttributeQty((int)$id_product_attribute, (int)$quantity)) {
                                        /* There is not enough product attribute in stock - set customer qty to current stock on hand */
                                        //$quantity = getAttributeQty($idProductAttribute);

                                //        $this->showError('5004', 'Quantity not available for product '.$_product);
                                //        break;
                                //    }
                                //} elseif (!$product_to_add->checkQty((int)$quantity)) {
                                    /* There is not enough product in stock - set customer qty to current stock on hand */
                                    //$quantity = $producToAdd->getQuantity($idProduct);

                                //    $this->showError('5004', 'Quantity not available for product '.$_product);
                                //    break;
                                //}

                                $key = $id_product.'-'.$id_product_attribute;

                                if (isset($product_list[$key])) {
                                    $product_list[$key]['quantity'] += (int)$quantity;
                                } else {
                                    $specific_wholesale_price = 0;
                                    if ((int)$this->dropshippers->feed_type == 1) {
                                        $product_price = (float)$order_product->price;
                                        $product_tax_rate = (float)$order_product->tax_rate;
                                    } else {
                                        $objProd = new Product($id_product);
                                        if ($this->wholesale_base_price == 0) {
                                            $product_price = (float)$objProd->wholesale_price;
                                        } else if ($this->wholesale_base_price == 1) {
                                            $product_price = (float)Product::getPriceStatic($id_product, false, $id_product_attribute);
                                        }
                                        $product_tax_rate = (float)$objProd->getTaxesRate(new Address($id_address_invoice));
                                        unset($objProd);

                                        $specific_wholesale_price = DssSpecificWholesalePriceClass::getSpecificWholesalePrice(
                                            (int)$id_product,
                                            (int)$this->context->customer->id_shop,
                                            (int)$this->context->currency->id,
                                            (int)$this->dropshippers->id_country,
                                            (int)$group,
                                            (int)$id_product_attribute
                                        );
                                    }

                                    if ($specific_wholesale_price) {
                                        $product_price = (float)$product_price * ((100 + (float)$specific_wholesale_price['value']) / 100);
                                    } else {
                                        $product_price = (float)$product_price * ((100 + (float)$this->dropshippers->wholesale_reduction) / 100);
                                    }

                                    $product_list[$key] = array(
                                        'quantity' => (int)$quantity,
                                        'price' => (float)$product_price,
                                        'tax_rate' => (float)$product_tax_rate
                                    );
                                    $total_products_tax_excl += ($product_price * $quantity);
                                    $total_products_tax_incl += ($product_price * $quantity) + (((($product_price * $quantity) / 100) * (float)$product_tax_rate));

                                    $dss->writeLog('PRODUCT TAX EXCL: '.$total_products_tax_excl);
                                    $dss->writeLog('PRODUCT TAX INCL: '.$total_products_tax_incl);
                                }
                            }
                        }
                    }
                    $dss->writeLog('--------');
                    if (count($unavailable_products) > 0) {
                        $this->showError('5022', 'Some products are not available: '.implode(', ', $unavailable_products));
                    }
                    if ((int)$this->dropshippers->feed_type == 1) {
                        //$total_tax_excl = $total_products_tax_excl + $total_shipping + $total_shipping_extra_fee;
                        $total_tax_incl = $total_products_tax_incl + ($total_shipping + (($total_shipping / 100) * (float)$carrier_tax_rate)) + $total_shipping_extra_fee;
                    }
                }

                $currency = new Currency((int)Configuration::get('PS_CURRENCY_DEFAULT', null, null, $id_shop));

                /* Make new cart */
                $cart = new Cart();
                $cart->id_customer = (int)$customer->id;
                $cart->id_address_invoice = (int)$id_address_invoice;
                $cart->id_address_delivery = (int)$id_address_delivery;
                $cart->id_lang = (int)$customer->id_lang;
                $cart->id_currency = (int)$currency->id;
                $cart->is_guest = (int)$customer->is_guest;
                $cart->id_carrier = (int)$id_default_carrier;
                if (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=')) {
                    $cart->delivery_option = json_encode(array($id_address_delivery => $id_default_carrier.','));
                } else {
                    $cart->delivery_option = serialize(array($id_address_delivery => $id_default_carrier.','));
                }
                $cart->secure_key = $customer->secure_key;

                if ($cart->add()) {
                    /* add product to cart */
                    foreach ($order_products->product as $order_product) {
                        $data = $this->dss->getProductIDByReference((string)$order_product->reference, $this->context->shop->id);
                        $id_product = (int)$data['id_product'];
                        $id_product_attribute = (int)$data['id_product_attribute'];
                        $quantity = (int)$order_product->quantity;

                        if (StockAvailable::getQuantityAvailableByProduct($id_product, $id_product_attribute) < $quantity && in_array(StockAvailable::outOfStock($id_product), $check_out_of_stock)) {
                            if ($allowOrdersZeroQty) {
                                if (!is_null($id_product_attribute)) {
                                    Db::getInstance()->execute(
                                        'UPDATE `'._DB_PREFIX_.'stock_available`'."\n".
                                        'SET `quantity` = `quantity` + '.(int)$quantity."\n".
                                        'WHERE `id_product` = '.(int)$id_product.
                                        ' AND `id_product_attribute` = '.(int)$id_product_attribute.
                                        ' AND `id_shop` = '.(int)$id_shop
                                    );
                                    Db::getInstance()->execute(
                                        'UPDATE `'._DB_PREFIX_.'stock_available`'."\n".
                                        'SET `quantity` = `quantity` + '.(int)$quantity."\n".
                                        'WHERE `id_product` = '.(int)$id_product.'
                                        AND `id_product_attribute` = 0 AND `id_shop` = '.(int)$id_shop
                                    );
                                } else {
                                    Db::getInstance()->execute(
                                        'UPDATE `'._DB_PREFIX_.'stock_available`'."\n".
                                        'SET `quantity` = `quantity` + '.(int)$quantity."\n".
                                        'WHERE `id_product` = '.(int)$id_product.'
                                        AND `id_product_attribute` = 0 AND `id_shop` = '.(int)$id_shop
                                    );
                                }
                            } else {
                                $this->showError('5004', 'Quantity not available for product: '.(string)$order_product->reference);
                                break;
                            }
                        }

                        $updateQuantity = $cart->updateQty((int)$quantity, (int)$id_product, (int)$id_product_attribute, false, 'up', 0, $shop);
                        if ((int)$updateQuantity < 0) {
                            $this->showError('5005', 'Minimal quantity not reached for '.(string)$order_product->reference);
                            break;
                        }
                    }
                } else {
                    DssEventsClass::setEvent('error', sprintf($this->module->l('Dropshipper id %s cannot add products to cart.', 'dropshipsystem'), $id_dropshipper));
                    $this->showError('5023', 'Error adding product to cart');
                }

                $dss->writeLog('CART ID: '.$cart->id);

                if ((int)$this->dropshippers->feed_type == 1) {
                    if (isset($discounts)) {
                        foreach ($discounts->discount as $discount) {
                            $cart_rule = new CartRule();
                            $cart_rule->name = array($this->id_default_lang => (string)$discount->name);
                            $cart_rule->id_customer = (int)$customer->id;
                            $cart_rule->date_from = date('Y-m-d H:i:s');
                            $cart_rule->date_to = date('Y-m-d H:i:s', strtotime("+1 minute"));
                            $cart_rule->quantity = 1;
                            $cart_rule->quantity_per_user = 1;
                            $cart_rule->partial_use = 0;
                            $cart_rule->code = (string)$discount->code;
                            $cart_rule->minimum_amount_currency = 1;
                            $cart_rule->reduction_amount = (float)$discount->value_tax_excl;
                            $cart_rule->reduction_currency = 1;
                            $cart_rule->active = 1;

                            if ($cart_rule->add()) {
                                $id_cart_rule = (int)$cart_rule->id;
                                $cart->addCartRule($id_cart_rule);
                            } else {
                                DssEventsClass::setEvent('error', $this->module->l('Error adding cart rule.', 'dropshipsystem'));
                                $this->showError('5027', 'Error adding cart rule');
                            }
                            $total_discounts += (float)$discount->value;
                        }
                        $total_tax_incl -= $total_discounts;
                    }
                } else {
                    //$total_products = (float)$cart->getOrderTotal(false, Cart::ONLY_PRODUCTS_WITHOUT_SHIPPING);
                    $total_shipping = (float)$cart->getOrderTotal(false, Cart::ONLY_SHIPPING);
                    //$total = (float)$cart->getOrderTotal(true, Cart::BOTH);
                    //$total_tax_excl = $total_products_tax_excl + $total_shipping;
                    $total_tax_incl = $total_products_tax_incl + (float)$cart->getOrderTotal(true, Cart::ONLY_SHIPPING);
                }

                $dss->writeLog('CARRIER TAX RATE: '.$carrier_tax_rate);
                $dss->writeLog('TOTAL SHIPPING: '.$total_shipping);
                $dss->writeLog('TOTAL SHIPPING EXTRA: '.$total_shipping_extra_fee);
                $dss->writeLog('TOTAL TAX INCL: '.$total_tax_incl);

                $previous_credit = (float)$this->dropshippers->credit;
                $daily_limit = (float)$this->dropshippers->daily_limit;
                $monthly_limit = (float)$this->dropshippers->monthly_limit;

                if ($daily_limit > 0) {
                    $daily_orders_total = DssOrderClass::getOrderTotalByPeriod($id_dropshipper, null, 'daily');

                    if (((float)$daily_orders_total['total'] + (float)$total) > (float)$daily_limit) {
                        DssEventsClass::setEvent('alert', sprintf($this->module->l('Daily order limit exceded for dropshipper id %s', 'dropshipsystem'), $id_dropshipper));
                        $this->showError('5025', 'Daily order limit exceded');
                    }
                }

                if ($monthly_limit > 0) {
                    $monthly_orders_total = DssOrderClass::getOrderTotalByPeriod($id_dropshipper, null, 'monthly');

                    if (((float)$monthly_orders_total['total'] + (float)$total) > (float)$monthly_limit) {
                        DssEventsClass::setEvent('alert', sprintf($this->module->l('Monthly order limit exceded for dropshipper id %s', 'dropshipsystem'), $id_dropshipper));
                        $this->showError('5026', 'Monthly order limit exceded');
                    }
                }

                $payment_desc = $this->module->l('Dropship', 'dropshipsystem');
                if ((string)$this->dropshippers->payment_type == 'none') {
                    if ($payment_status == 'PENDING_PAYMENT') {
                        if ($payment_method == 'BANKWIRE') {
                            $status = (int)Configuration::get('PS_OS_BANKWIRE', null, null, $id_shop);
                        } elseif ($payment_method == 'CHEQUE') {
                            $status = (int)Configuration::get('PS_OS_CHEQUE', null, null, $id_shop);
                        } elseif ($payment_method == 'COD') {
                            $status = (int)Configuration::get('PS_OS_COD_VALIDATION', null, null, $id_shop);
                        } elseif ($payment_method == 'PAYPAL') {
                            $status = (int)Configuration::get('PS_OS_PAYPAL', null, null, $id_shop);
                        } else {
                            $status = (int)Configuration::get('PS_OS_ERROR', null, null, $id_shop);
                        }
                        $status_desc = 'PENDING_PAYMENT';
                    } elseif ($payment_status == 'PAYMENT_SUCCESS') {
                        $status = (int)Configuration::get('PS_OS_PAYMENT', null, null, $id_shop);
                        $status_desc = 'PAYMENT_SUCCESS';
                    } elseif ($payment_status == 'PREPARATION_IN_PROGRESS') {
                        $status = (int)Configuration::get('PS_OS_PREPARATION', null, null, $id_shop);
                        $status_desc = 'PREPARATION_IN_PROGRESS';
                    } elseif ($payment_status == 'SHIPPING_IN_PROGRESS') {
                        $status = (int)Configuration::get('PS_OS_SHIPPING', null, null, $id_shop);
                        $status_desc = 'SHIPPING_IN_PROGRESS';
                    } elseif ($payment_status == 'DELIVERED') {
                        $status = (int)Configuration::get('PS_OS_DELIVERED', null, null, $id_shop);
                        $status_desc = 'DELIVERED';
                    } elseif ($payment_status == 'CANCELLED') {
                        $status = (int)Configuration::get('PS_OS_CANCELED', null, null, $id_shop);
                        $status_desc = 'CANCELLED';
                    } elseif ($payment_status == 'REFUNDED') {
                        $status = (int)Configuration::get('PS_OS_REFUND', null, null, $id_shop);
                        $status_desc = 'REFUNDED';
                    } elseif ($payment_status == 'OUTOFSTOCK_PAID') {
                        $status = (int)Configuration::get('PS_OS_OUTOFSTOCK_PAID', null, null, $id_shop);
                        $status_desc = 'OUTOFSTOCK_PAID';
                    } elseif ($payment_status == 'OUTOFSTOCK_UNPAID') {
                        $status = (int)Configuration::get('PS_OS_OUTOFSTOCK_UNPAID', null, null, $id_shop);
                        $status_desc = 'OUTOFSTOCK_UNPAID';
                    } elseif ($payment_status == 'ERROR') {
                        $status = (int)Configuration::get('PS_OS_ERROR', null, null, $id_shop);
                        $status_desc = 'ERROR';
                    } else {
                        $status = -1;
                        $status_desc = 'UNKNOW_STATUS';
                    }

                    if ($payment_method == 'BANKWIRE') {
                        $payment_desc .= ': '.$this->module->l('Bankwire payment', 'dropshipsystem');
                    } elseif ($payment_method == 'COD') {
                        $payment_desc .= ': '.$this->module->l('Cash on delivery payment', 'dropshipsystem');
                    } elseif ($payment_method == 'CHEQUE') {
                        $payment_desc .= ': '.$this->module->l('Cheque payment', 'dropshipsystem');
                    } elseif ($payment_method == 'PAYPAL') {
                        $payment_desc .= ': '.$this->module->l('Paypal payment', 'dropshipsystem');
                    } elseif ($payment_method == 'POSTEPAY') {
                        $payment_desc .= ': '.$this->module->l('Postepay payment', 'dropshipsystem');
                    } elseif ($payment_method == 'CC') {
                        $payment_desc .= ': '.$this->module->l('Credit Card payment', 'dropshipsystem');
                    } elseif ($payment_method == 'FASTBAY1') {
                        $payment_desc .= ': '.$this->module->l('Fastbay1 payment', 'dropshipsystem');
                    } elseif ($payment_method == 'AMAZON') {
                        $payment_desc .= ': '.$this->module->l('Amazon payment', 'dropshipsystem');
                    } else {
                        $payment_desc .= ': '.$this->module->l('Unknow payment', 'dropshipsystem');
                    }
                } elseif ((string)$this->dropshippers->payment_type == 'prepayed') {
                    if ($total_tax_incl > $previous_credit) {
                        $status_desc = 'INSUFFICIENT_FUNDS';
                        DssEventsClass::setEvent('alert', sprintf($this->module->l('Dropshipper id %s have insufficient funds for pay order.', 'dropshipsystem'), $id_dropshipper));
                        $this->showError('5006', 'Insufficient funds for order');
                    } else {
                        $status = (int)Configuration::get('PS_OS_PAYMENT', null, null, $id_shop);
                        $status_desc = 'PAYMENT_SUCCESS';
                    }
                } elseif ((string)$this->dropshippers->payment_type == 'postpayed') {
                    $status = (int)Configuration::get('PS_OS_DROPSHIP', null, null, $id_shop);
                    $status_desc = 'PENDING_PAYMENT';

                    $payclass = DssPaymentClass::getInstance();
                    $payres = $payclass->getAuth();
                    unset($payclass);

                    if (!$payres) {
                        DssEventsClass::setEvent('error', $this->module->l('Error with payment account. Please check credentials.', 'dropshipsystem'));
                        $this->showError('5010', 'Error with payment authentication');
                    }
                }

                $dss->writeLog('STATUS: '.$status_desc);

                $mail_vars = array();
                /*
                $mail_vars = array(
                    '{dss_owner}' => Configuration::get('DSS_OWNER', null, null, $id_shop),
                    '{dss_details}' => nl2br(Configuration::get('DSS_DETAILS', null, null, $id_shop)),
                    '{dss_address}' => nl2br(Configuration::get('DSS_ADDRESS', null, null, $id_shop))
                );
                */

                $payment = new DssPaymentClass();
                if (!$payment->validateDssOrder($product_list, $total_shipping, $total_shipping_extra_fee, $carrier_tax_rate, false, $cart->id, $status, $total_tax_incl, $order_reference, $payment_desc, null, $mail_vars, (int)$currency->id, false, $customer->secure_key, $this->dropshippers, $id_dss_order, $shop)) {
                    $status_desc = 'ORDER_ERROR';
                    DssEventsClass::setEvent('error', sprintf($this->module->l('Error creating order with dropshipper id %s.', 'dropshipsystem'), $id_dropshipper));
                    $this->showError('5017', 'Error during create order');
                } else {
                    $dss->writeLog('ORDER REFERENCE: '.$order_reference);

                    if (isset($messages)) {
                        foreach ($messages->message as $msg) {
                            $message = new Message();
                            $message->message = (string)$msg->message;
                            $message->id_order = (int)$payment->currentOrder;
                            $message->private = (int)$msg->private;
                            $message->date_add = $msg->date;
                            $message->add();
                        }
                    }

                    if ((string)$this->dropshippers->payment_type == 'prepayed') {
                        if (!$this->dropshippers->addCredit(-$total_tax_incl)) {
                            $history = new OrderHistory();
                            $history->id_order = (int)$payment->currentOrder;
                            $history->changeIdOrderState((int)Configuration::get('PS_OS_ERROR', null, null, $id_shop), $history->id_order);
                            $history->addWithemail();
                            $history->save();

                            $status_desc = 'CREDIT_ERROR';
                            DssEventsClass::setEvent('error', sprintf($this->module->l('Error updating credit for dropshipper id %s. Order %s', 'dropshipsystem'), $id_dropshipper, $order_reference));
                            $this->showError('5007', 'Error during set new credit');
                        } else {
                            if ((float)$this->dropshippers->low_credit_threshold > 0 &&
                                (float)$this->dropshippers->credit < (float)$this->dropshippers->low_credit_threshold) {
                                $dss_payment_history = DssPaymentsHistoryClass::getLastPayment($customer->id);
                                $template_vars = array(
                                    '{threshold}' => Tools::displayPrice($this->dropshippers->low_credit_threshold, $currency),
                                    '{credit}' => Tools::displayPrice($this->dropshippers->credit, $currency),
                                    '{last_charge_credit}' => (isset($dss_payment_history['buyed_credit']) ? Tools::displayPrice($dss_payment_history['buyed_credit'], $dss_payment_history['currency']) : '-'),
                                    '{last_charge_date}' => (isset($dss_payment_history['request_date']) ? $dss_payment_history['request_date'] : '-'),
                                );
                                Mail::Send((int)$customer->id_lang, 'dss_low_credit', Mail::l('Low credit for your dropship account', (int)$customer->id_lang), $template_vars, $customer->email, $customer->firstname.' '.$customer->lastname, null, null, null, null, dirname(__FILE__).'/../../mails/');
                            }
                        }
                    }
                }

                $order = new Order((int)$payment->currentOrder);

                $payment_link = '';
                $payment_gateway_link = '';
                if ((string)$this->dropshippers->payment_type == 'postpayed') {
                    $token = (string)DssPaymentsTokenClass::getToken();

                    $params = array(
                        'is_credit' => false,
                        'token' => (string)$token,
                        'id_order' => (int)$order->id,
                        'name' => (string)$order->reference,
                        'total' => (float)$total_tax_incl,
                        'custom_reference' => (string)$order->reference,
                        'return_url' => $this->context->link->getBaseLink().'ws?action=payment-return&ref='.(string)$order->reference.'&mode=1',
                        'cancel_url' => $this->context->link->getBaseLink().'ws?action=payment-cancel&ref='.(string)$order->reference.'&mode=1',
                    );

                    $payclass = DssPaymentClass::getInstance();
                    $payres = $payclass->getPaymentPage($params);
                    unset($payclass);

                    if ($payres['success']) {
                        $payment_link = 'http'.(Configuration::get('PS_SSL_ENABLED', null, null, $id_shop) ? 's' : '').'://'.
                                    Tools::getShopDomain(false, true).__PS_BASE_URI__.'ws?action=payment&ref='.$order->reference;
                        $payment_gateway_link = (string)$payres['paymentlink'];
                    } else {
                        $order->setCurrentState((int)Configuration::get('PS_OS_ERROR', null, null, $id_shop));

                        DssEventsClass::setEvent('error', sprintf($this->module->l('Error retrive gateway payment link for order %s', 'dropshipsystem'), $order_reference));
                        $this->showError('5009', 'Error retrive payment link');
                    }
                }

                $dss_order = new DssOrderClass((int)$id_dss_order);
                $dss_order->id_order = (int)$order->id;
                $dss_order->id_dropshipper = (int)$id_dropshipper;
                $dss_order->id_shipping_address = (int)$id_address_delivery;
                $dss_order->id_billing_address = (int)$id_address_invoice;
                if ((int)$this->dropshippers->feed_type == 1) {
                    $dss_order->order_reference = (string)$order_reference;
                }
                $dss_order->shipping_method = (int)$shipping_method;
                $dss_order->payment_type = (string)$this->dropshippers->payment_type;
                $dss_order->total = (float)$total_tax_incl;
                $dss_order->previous_credit = (float)$previous_credit;
                $dss_order->current_credit = (float)$previous_credit - (float)$total_tax_incl;
                $dss_order->payment_link = (string)$payment_link;
                $dss_order->payment_gateway_link = (string)$payment_gateway_link;

                if ($dss_order->update()) {
                    $this->dropshippers->increaseOrder();
                    $this->dropshippers->setLastOrderDate();
                }

                if (is_callable(array('Tools', 'changeFileMTime'))) {
                    Tools::changeFileMTime($this->module->push_filename);
                }

                $dss->writeLog('ORDER ID: '.$order->id);
                $dss->writeLog('ORDER DSS ID: '.$id_dss_order);

                $this->_html .= "<order>";
                $this->_html .= "<id>".(int)$order->id."</id>";
                $this->_html .= "<reference>".(string)$order->reference."</reference>";
                $this->_html .= "<date>".(string)$order->date_add."</date>";
                $this->_html .= "<shipping_method>".(int)$shipping_method."</shipping_method>";
                $this->_html .= "<total_products>".(string)$order->total_products."</total_products>";
                $this->_html .= "<total_shipping>".(string)$order->total_shipping_tax_excl."</total_shipping>";
                $this->_html .= "<total_discounts>".(string)$order->total_discounts_tax_excl."</total_discounts>";
                $this->_html .= "<total>".(string)$order->total_paid_tax_excl."</total>";
                $this->_html .= "<currency>".(string)$currency->iso_code."</currency>";
                //$this->_html .= "<carrier>".(string)$order_carrier->name."</carrier>";
                $this->_html .= "<current_state>".(string)$status_desc."</current_state>";
                //$this->_html .= "<current_state>".(string)$order_state->name[(int)Context::getContext()->language->id]."</current_state>";
                $this->_html .= "<payment_link><![CDATA[".(string)$payment_link."]]></payment_link>";
                $this->_html .= "<tracking_link><![CDATA[]]></tracking_link>";
                $this->_html .= "<products>";
                foreach ($order->getProducts() as $order_product) {
                    $this->_html .= "<product>";
                    $this->_html .= "<reference><![CDATA[".(string)$order_product['product_reference']."]]></reference>";
                    $this->_html .= "<name><![CDATA[".(string)$order_product['product_name']."]]></name>";
                    $this->_html .= "<quantity>".(int)$order_product['product_quantity']."</quantity>";
                    $this->_html .= "<price>".(float)$order_product['total_price_tax_excl']."</price>";
                    $this->_html .= "</product>";
                }
                $this->_html .= "</products>";
                $this->_html .= "</order>";
            } catch (Exception $e) {
                $this->showError('1001', 'Error during call webservice', null, $e);
            }

            $dss->writeLog('-------------------------------------');
        } else {
            $this->showError('1000', 'Invalid action');
        }

        if (isset($context->dropshippers)) {
            unset($context->dropshippers);
        }

        echo $this->_html;
        die();
    }

    private function getCategoriesFeed($categories, $langs, $home_level, $with_children = true, $version = 0)
    {
        foreach ($categories as $category) {
            if (!(int)DssCategoriesClass::isCategoryActive((int)$category['id_category'])) {
                continue;
            }
            $_category = new Category((int)$category['id_category']);
            $_category = (array)$_category;

            $id_dss_category = (int)DssCategoriesClass::getDssCategoryID((int)$_category['id_category']);
            $dss_categories = new DssCategoriesClass((int)$id_dss_category);

            //if ($this->dropshippers->feed_type == 1) {
            //    $level_depth = (int)$category['level_depth'];
            //} else {
                $level_depth = (int)$_category['level_depth'] - (int)$home_level - 1;
            //}
            $this->_html .= "<category".($version ? " version='".(int)$version."'" : "").">";
            //if ($this->dropshippers->feed_type == 1) {
            //    $this->_html .= "<parent_id>".(int)$category['id_parent']."</parent_id>";
            //}
            $this->_html .= "<parent><![CDATA[".(string)$dss_categories->dss_category_code_parent."]]></parent>";
            //if ($this->dropshippers->feed_type == 1) {
            //    $this->_html .= "<reference_id>".(int)$category['id_category']."</reference_id>";
            //}
            $this->_html .= "<reference><![CDATA[".(string)$dss_categories->dss_category_code."]]></reference>";
            if (!$this->dropshippers->simple_feed) {
                $this->_html .= "<level>".$level_depth."</level>";
            }
            foreach ($langs as $lang) {
                $this->_html .= "<name lang=\"".(string)$lang['iso_code']."\"><![CDATA[".(string)$_category['name'][$lang['id_lang']]."]]></name>";
                if (!$this->dropshippers->simple_feed) {
                    $this->_html .= "<description lang=\"".(string)$lang['iso_code']."\"><![CDATA[".(string)$_category['description'][$lang['id_lang']]."]]></description>";
                    $this->_html .= "<link_rewrite lang=\"".(string)$lang['iso_code']."\"><![CDATA[".(string)$_category['link_rewrite'][$lang['id_lang']]."]]></link_rewrite>";
                    $this->_html .= "<meta_title lang=\"".(string)$lang['iso_code']."\"><![CDATA[".(string)$_category['meta_title'][$lang['id_lang']]."]]></meta_title>";
                    $this->_html .= "<meta_description lang=\"".(string)$lang['iso_code']."\"><![CDATA[".(string)$_category['meta_description'][$lang['id_lang']]."]]></meta_description>";
                    $this->_html .= "<meta_keywords lang=\"".(string)$lang['iso_code']."\"><![CDATA[".(string)$_category['meta_keywords'][$lang['id_lang']]."]]></meta_keywords>";
                }
            }
            $this->_html .= "</category>";
            if ($with_children) {
                if (isset($category['children']) && $category['children'] != '') {
                    $this->_html .= $this->getCategoriesFeed($category['children'], $langs, $home_level);
                }
            }
        }
    }

    private function getQuantitiesFeed($products, $version = 0, $id_shop = 0)
    {
        $mask_qt_value = (int)Configuration::get('DSS_MASK_REAL_QUANTITY_VALUE', null, null, $id_shop);

        foreach ($products as $child) {
            if (isset($child) && is_array($child)) {
                $id_product = (int)$child['id_product'];
            } else {
                $id_product = (int)$child;
            }
            if ($id_product > 0) {
                $product = new Product((int)$id_product, true);
                $product_attributes = $product->getAttributeCombinations((int)$this->context->language->id);
                if ($this->dropshippers->mask_quantity && (int)$product->quantity > (int)$mask_qt_value) {
                    $quantity = (int)$mask_qt_value;
                } else {
                    $quantity = (int)$product->quantity;
                }
                if (!$this->dropshippers->simple_feed) {
                    $this->_html .= '<quantity'.($version ? ' version=\''.(int)$version.'\'' : '').'>';
                    $this->_html .= '<reference><![CDATA['.trim((string)$product->reference).']]></reference>';
                    $this->_html .= '<active>'.(int)$product->active.'</active>';
                    $this->_html .= '<quantity>'.(int)$quantity.'</quantity>';
                    //$this->_html .= '<out_of_stock>'.(int)$product->out_of_stock.'</out_of_stock>';
                    $this->_html .= '<available_for_order>'.(int)$product->available_for_order.'</available_for_order>';
                    $this->_html .= '<available_date>'.(string)$product->available_date.'</available_date>';
                    if (isset($product_attributes) && $product_attributes) {
                        $this->_html .= '<attributes>';
                        foreach ($product_attributes as $product_attribute) {
                            if ($this->dropshippers->mask_quantity && (int)$product_attribute['quantity'] > (int)$mask_qt_value) {
                                $attribute_quantity = (int)$mask_qt_value;
                            } else {
                                $attribute_quantity = (int)$product_attribute['quantity'];
                            }
                            $this->_html .= '<attribute>';
                            $this->_html .= '<reference><![CDATA['.trim((string)$product_attribute['reference']).']]></reference>';
                            $this->_html .= '<quantity>'.(int)$attribute_quantity.'</quantity>';
                            $this->_html .= '<available_date>'.(string)$product_attribute['available_date'].'</available_date>';
                            $this->_html .= '</attribute>';
                        }
                        $this->_html .= '</attributes>';
                    }
                    $this->_html .= '</quantity>';
                } else {
                    if (isset($product_attributes) && $product_attributes) {
                        foreach ($product_attributes as $product_attribute) {
                            if ($this->dropshippers->mask_quantity && (int)$product_attribute['quantity'] > (int)$mask_qt_value) {
                                $attribute_quantity = (int)$mask_qt_value;
                            } else {
                                $attribute_quantity = (int)$product_attribute['quantity'];
                            }
                            $this->_html .= '<quantity'.($version ? ' version=\''.(int)$version.'\'' : '').'>';
                            $this->_html .= '<reference><![CDATA['.trim((string)$product_attribute['reference']).']]></reference>';
                            $this->_html .= '<active>'.(int)$product->active.'</active>';
                            $this->_html .= '<quantity>'.(int)$attribute_quantity.'</quantity>';
                            //$this->_html .= '<out_of_stock>'.(int)$product_attribute->out_of_stock.'</out_of_stock>';
                            $this->_html .= '<available_for_order>'.(int)$product->available_for_order.'</available_for_order>';
                            $this->_html .= '<available_date>'.(string)$product_attribute['available_date'].'</available_date>';
                            $this->_html .= '</quantity>';
                        }
                    } else {
                        $this->_html .= '<quantity'.($version ? ' version=\''.(int)$version.'\'' : '').'>';
                        $this->_html .= '<reference><![CDATA['.trim((string)$product->reference).']]></reference>';
                        $this->_html .= '<active>'.(int)$product->active.'</active>';
                        $this->_html .= '<quantity>'.(int)$quantity.'</quantity>';
                        //$this->_html .= '<out_of_stock>'.(int)$product->out_of_stock.'</out_of_stock>';
                        $this->_html .= '<available_for_order>'.(int)$product->available_for_order.'</available_for_order>';
                        $this->_html .= '<available_date>'.(string)$product->available_date.'</available_date>';
                        $this->_html .= '</quantity>';
                    }
                }
                unset($product);
            }
        }
    }

    private function getProductsFeed($products, $langs, $version, $group, $id_shop)
    {
        $mask_qt_value = (int)Configuration::get('DSS_MASK_REAL_QUANTITY_VALUE', null, null, $id_shop);

        foreach ($products as $child) {
            if (isset($child) && is_array($child)) {
                $id_product = (int)$child['id_product'];
            } else {
                $id_product = (int)$child;
            }
            $product = new Product((int)$id_product, true);

            $this->prices_vat = $this->ps_tax ? 0 : (float)$this->prices_vat;

            $product->wholesale_price = (float)$this->dss->vatExtraction((float)$product->wholesale_price, $this->prices_vat);
            $product->base_price = (float)$this->dss->vatExtraction((float)$product->base_price, $this->prices_vat);
            $product->price = (float)$this->dss->vatExtraction((float)$product->price, $this->prices_vat);

            $this->_html .= "<product".($version ? " version='".(int)$version."'" : "").">";
            $this->_html .= "<reference><![CDATA[".trim((string)$product->reference)."]]></reference>";
            $this->_html .= "<category>".(string)$this->dss->getCategoryUniqueCodeByID($product->id_category_default)."</category>";
            if (!$this->dropshippers->simple_feed) {
                $this->_html .= "<additional_categories>".(string)$this->dss->getAdditionalCategoriesUniqueCodeByIDProduct($id_product, $id_shop)."</additional_categories>";
            }
            foreach ($langs as $lang) {
                $this->_html .= "<name lang=\"".(string)$lang['iso_code']."\"><![CDATA[".$this->dss->purify((string)$product->name[$lang['id_lang']], true)."]]></name>";
            }
            $this->_html .= "<ean13><![CDATA[".(string)$product->ean13."]]></ean13>";
            $this->_html .= "<upc><![CDATA[".(string)$product->upc."]]></upc>";
            $extra_description = array();
            if (!$this->dropshippers->simple_feed) {
                $extra_description = $this->dss->getExtraDescription($langs, $group, $id_product, -1, $id_shop);
            } else {
                foreach ($langs as $lang) {
                    $extra_description[$lang['id_lang']] = '';
                }
            }
            foreach ($langs as $lang) {
                $this->_html .= "<description lang=\"".(string)$lang['iso_code']."\"><![CDATA[".$this->dss->purify((string)$product->description[$lang['id_lang']].(string)$extra_description[$lang['id_lang']])."]]></description>";
            }
            if (!$this->dropshippers->simple_feed) {
                foreach ($langs as $lang) {
                    $this->_html .= "<description_short lang=\"".(string)$lang['iso_code']."\"><![CDATA[".$this->dss->purify((string)Tools::substr($product->description_short[$lang['id_lang']], 0, 255))."]]></description_short>";
                }
                foreach ($langs as $lang) {
                    $this->_html .= "<meta_title lang=\"".(string)$lang['iso_code']."\"><![CDATA[".(string)Tools::substr($product->meta_title[$lang['id_lang']], 0, 65)."]]></meta_title>";
                }
                foreach ($langs as $lang) {
                    $this->_html .= "<meta_description lang=\"".(string)$lang['iso_code']."\"><![CDATA[".(string)Tools::substr($product->meta_description[$lang['id_lang']], 0, 155)."]]></meta_description>";
                }
                foreach ($langs as $lang) {
                    $this->_html .= "<meta_keywords lang=\"".(string)$lang['iso_code']."\"><![CDATA[".(string)$product->meta_keywords[$lang['id_lang']]."]]></meta_keywords>";
                }
            }
            $this->_html .= "<images>";
            $images = $product->getImages($this->id_default_lang);
            if (is_array($images) && sizeof($images)) {
                foreach ($images as $image) {
                    $this->_html .= "<image>";
                    if (!$this->dropshippers->simple_feed) {
                        $this->_html .= "<cover>".(int)$image['cover']."</cover>";
                    }
                    if (!$this->dropshippers->simple_feed) {
                        foreach ($langs as $lang) {
                            $this->_html .= "<legend lang=\"".(string)$lang['iso_code']."\"><![CDATA[".(string)$image['legend']."]]></legend>";
                        }
                    }
                    $this->_html .= "<url>".$this->context->link->getImageLink('image'.(int)$image['id_image'], (int)$image['id_image'])."</url>";
                    $this->_html .= "</image>";
                }
            }
            $this->_html .= "</images>";

            $this->_html .= "<attributes>";
//            $_grouparr = array();
//            foreach ($product->getAttributeCombinations($this->id_default_lang) as $val) {
//                $_grouparr[$val['id_product_attribute']][] = $val;
//            }
//            $grouparr = array();
//            foreach ($_grouparr as $id_attrib => $arr) {
//                foreach ($arr as $key => $val) {
//                    if ($key == 0) {
//                        $grouparr[$id_attrib] = $val;
//                        $grouparr[$id_attrib]['group_name'] = null;
//                        $grouparr[$id_attrib]['attribute_name'] = null;
//                    }
//                    $grouparr[$id_attrib]['group_name'] .= $val['group_name'].',';
//                    $grouparr[$id_attrib]['attribute_name'] .= $val['attribute_name'].',';
//                }
//                $grouparr[$id_attrib]['group_name'] = rtrim($grouparr[$id_attrib]['group_name'], ',');
//                $grouparr[$id_attrib]['attribute_name'] = rtrim($grouparr[$id_attrib]['attribute_name'], ',');
//            }
            $product_attributes_ids = Product::getProductAttributesIds($product->id);
            foreach ($product_attributes_ids as $attrib) {
                $id_product_attribute = (int)$attrib['id_product_attribute'];
                $this->_html .= "<attribute>";
                $this->_html .= "<attribute_values>";
                foreach ($product->getAttributeCombinationsById($id_product_attribute, $this->id_default_lang) as $comb) {
                    $this->_html .= "<attribute_value>";
                    foreach ($langs as $lang) {
                        $this->_html .= "<group_name lang=\"".(string)$lang['iso_code']."\"><![CDATA[".(string)$comb['group_name']."]]></group_name>";
                    }
                    foreach ($langs as $lang) {
                        $this->_html .= "<attribute_name lang=\"".(string)$lang['iso_code']."\"><![CDATA[".(string)$comb['attribute_name']."]]></attribute_name>";
                    }
                    $this->_html .= "<is_color_group>".(int)$comb['is_color_group']."</is_color_group>";
                    $this->_html .= "</attribute_value>";
                }
                $this->_html .= "</attribute_values>";
                $this->_html .= "<reference><![CDATA[".(string)$comb['reference']."]]></reference>";
                if (!$this->dropshippers->simple_feed) {
                    $attribute_wholesale_price = (float)$comb['wholesale_price'];
                    $attribute_price = (float)$comb['price'];
                    $attribute_unit_price_impact = (float)$comb['unit_price_impact'];

                    if ((int)$this->dropshippers->feed_type == 0) {
                        if ($attribute_wholesale_price != 0) {
                            $specific_attribute_wholesale_price = DssSpecificWholesalePriceClass::getSpecificWholesalePrice(
                                (int)$product->id,
                                (int)$this->context->customer->id_shop,
                                (int)$this->context->currency->id,
                                (int)$this->dropshippers->id_country,
                                (int)$group,
                                (int)$id_product_attribute
                            );
                            if ($this->wholesale_base_price == 0) {
                                if (isset($specific_attribute_wholesale_price) && $specific_attribute_wholesale_price) {
                                    $attribute_wholesale_price = (float)$product->wholesale_price * ((100 + (float)$specific_attribute_wholesale_price['value']) / 100);
                                } else {
                                    $attribute_wholesale_price = (float)$product->wholesale_price * ((100 + (float)$this->dropshippers->wholesale_reduction) / 100);
                                }
                            } else if ($this->wholesale_base_price == 1) {
                                if (isset($specific_attribute_wholesale_price) && $specific_attribute_wholesale_price) {
                                    $attribute_wholesale_price = (float)$product->base_price * ((100 + (float)$specific_attribute_wholesale_price['value']) / 100);
                                } else {
                                    $attribute_wholesale_price = (float)$product->base_price * ((100 + (float)$this->dropshippers->wholesale_reduction) / 100);
                                }
                            }
                        }
                        if ($attribute_price != 0) {
                            $attribute_price = (float)$attribute_price * ((100 + $this->dropshippers->reduction) / 100);
                        }
                        if ($attribute_unit_price_impact != 0) {
                            $attribute_unit_price_impact = (float)$attribute_unit_price_impact * ((100 + $this->dropshippers->reduction) / 100);
                        }
                    }

                    $this->_html .= "<supplier_reference><![CDATA[".(string)$comb['supplier_reference']."]]></supplier_reference>";
                    $this->_html .= "<location>".(string)$comb['location']."</location>";
                    $this->_html .= "<wholesale_price>".(float)$attribute_wholesale_price."</wholesale_price>";
                    $this->_html .= "<price>".(float)$attribute_price."</price>";
                    $this->_html .= "<ecotax>".(float)$comb['ecotax']."</ecotax>";
                    $this->_html .= "<unit_price_impact>".(float)$attribute_unit_price_impact."</unit_price_impact>";
                    $this->_html .= "<minimal_quantity>".(int)$comb['minimal_quantity']."</minimal_quantity>";
                }
                if ($this->dropshippers->mask_quantity && (int)$comb['quantity'] > (int)$mask_qt_value) {
                    $attribute_quantity = (int)$mask_qt_value;
                } else {
                    $attribute_quantity = (int)$comb['quantity'];
                }
                $this->_html .= "<ean13><![CDATA[".(string)$comb['ean13']."]]></ean13>";
                $this->_html .= "<upc><![CDATA[".(string)$comb['upc']."]]></upc>";
                $this->_html .= "<quantity>".(int)$attribute_quantity."</quantity>";
                $this->_html .= "<weight>".(float)$comb['weight']."</weight>";
                if (!$this->dropshippers->simple_feed) {
                    $this->_html .= "<default_on>".(int)$comb['default_on']."</default_on>";
                }
                $this->_html .= "<available_date>".$comb['available_date']."</available_date>";
                $this->_html .= "</attribute>";
            }
            $this->_html .= "</attributes>";
            $accessories = $product->getAccessories($this->id_default_lang);
            $this->_html .= "<accessories>";
            if (isset($accessories) && $accessories) {
                $_accessories = array();
                foreach ($accessories as $accessory) {
                    $_accessories[] = $accessory['reference'];
                }
                $this->_html .= "<references>".implode(',', $_accessories)."</references>";
            }
            $this->_html .= "</accessories>";
            $this->_html .= "<features>";
            foreach ($this->dss->getFeatures($id_product) as $feature) {
                $feature_group = new Feature((int)$feature['id_feature']);
                //$feature_value = new FeatureValue((int)$feature['id_feature_value']);
                $multi_features = $this->dss->getMultiFeatures($langs, $id_product, (int)$feature['id_feature']);
                $this->_html .= "<feature>";
                foreach ($langs as $lang) {
                    $this->_html .= "<name lang=\"".(string)$lang['iso_code']."\"><![CDATA[".(string)$feature_group->name[$lang['id_lang']]."]]></name>";
                }
                if (isset($multi_features) && count($multi_features) > 0) {
                    if (is_array(reset($multi_features))) {
                        foreach (reset($multi_features) as $key => $multi_feature) {
                            $this->_html .= "<values>";
                            foreach ($langs as $lang) {
                                $this->_html .= "<value lang=\"".(string)$lang['iso_code']."\"><![CDATA[".$multi_features[$lang['id_lang']][$key]."]]></value>";
                            }
                            $this->_html .= "</values>";
                        }
                    } else {
                        foreach ($langs as $lang) {
                            $this->_html .= "<value lang=\"".(string)$lang['iso_code']."\"><![CDATA[".(string)$multi_features[$lang['id_lang']]."]]></value>";
                        }
                    }
                }
                $this->_html .= "</feature>";
            }
            $this->_html .= "</features>";

            if ($this->dropshippers->mask_quantity && (int)$product->quantity > (int)$mask_qt_value) {
                $quantity = (int)$mask_qt_value;
            } else {
                $quantity = (int)$product->quantity;
            }
            $this->_html .= "<quantity>".(int)$quantity."</quantity>";
            if (!$this->dropshippers->simple_feed) {
                $this->_html .= "<minimal_quantity>".(int)$product->minimal_quantity."</minimal_quantity>";
            }

            if ((int)$this->dropshippers->feed_type == 0) {
                $specific_wholesale_price = DssSpecificWholesalePriceClass::getSpecificWholesalePrice(
                    (int)$product->id,
                    (int)$this->context->customer->id_shop,
                    (int)$this->context->currency->id,
                    (int)$this->dropshippers->id_country,
                    (int)$group,
                    0
                );

                if ($this->wholesale_base_price == 0) {
                    if (isset($specific_wholesale_price) && $specific_wholesale_price) {
                        $wholesale_price = (float)$product->wholesale_price * ((100 + (float)$specific_wholesale_price['value']) / 100);
                    } else {
                        $wholesale_price = (float)$product->wholesale_price * ((100 + (float)$this->dropshippers->wholesale_reduction) / 100);
                    }
                } else if ($this->wholesale_base_price == 1) {
                    if (isset($specific_wholesale_price) && $specific_wholesale_price) {
                        $wholesale_price = (float)$product->base_price * ((100 + (float)$specific_wholesale_price['value']) / 100);
                    } else {
                        $wholesale_price = (float)$product->base_price * ((100 + (float)$this->dropshippers->wholesale_reduction) / 100);
                    }
                }

                if ($this->base_price == 0) {
                    $base_price = (float)$product->base_price;
                    $price = (float)$product->price * ((100 + $this->dropshippers->reduction) / 100);
                } elseif ($this->base_price == 1) {
                    $base_price = (float)$wholesale_price;
                    $price = (float)$wholesale_price * ((100 + $this->dropshippers->reduction) / 100);
                }
            } else {
                $wholesale_price = (float)$product->wholesale_price;
                $base_price = (float)$product->base_price;
                $price = (float)$product->price;
            }

            $this->_html .= "<wholesale_price>".(float)$wholesale_price."</wholesale_price>";
            $this->_html .= "<base_price>".(float)$base_price."</base_price>";
            $this->_html .= "<price>".(float)$price."</price>";

            if (!$this->dropshippers->simple_feed) {
                $this->_html .= "<tax_rate>".(float)$product->tax_rate."</tax_rate>";
                $this->_html .= "<unity>".$product->unity."</unity>";
                $this->_html .= "<unit_price_ratio>".(float)$product->unit_price_ratio."</unit_price_ratio>";
                $this->_html .= "<additional_shipping_cost>".(float)$product->additional_shipping_cost."</additional_shipping_cost>";
                $this->_html .= "<redirect_type>".(int)$product->redirect_type."</redirect_type>";
            }
            $this->_html .= "<width>".(float)$product->width."</width>";
            $this->_html .= "<height>".(float)$product->height."</height>";
            $this->_html .= "<depth>".(float)$product->depth."</depth>";
            $this->_html .= "<weight>".(float)$product->weight."</weight>";
            $this->_html .= "<out_of_stock>".(int)$product->out_of_stock."</out_of_stock>";
            if (!$this->dropshippers->simple_feed) {
                $this->_html .= "<on_sale>".(int)$product->on_sale."</on_sale>";
                $this->_html .= "<quantity_discount>".(int)$product->quantity_discount."</quantity_discount>";
                $this->_html .= "<customizable>".$product->customizable."</customizable>";
                $this->_html .= "<uploadable_files>".$product->uploadable_files."</uploadable_files>";
                $this->_html .= "<text_fields>".$product->text_fields."</text_fields>";
                $this->_html .= "<visibility>".(string)$product->visibility."</visibility>";
                $this->_html .= "<online_only>".(int)$product->online_only."</online_only>";
                $this->_html .= "<is_virtual>".(int)$product->is_virtual."</is_virtual>";
                $this->_html .= "<condition>".(string)$product->condition."</condition>";
            }
            $this->_html .= "<active>".(int)$product->active."</active>";
            $this->_html .= "<available_for_order>".(int)$product->available_for_order."</available_for_order>";
            $this->_html .= "<available_date>".$product->available_date."</available_date>";
            $this->_html .= "<manufacturer_name><![CDATA[".(string)$product->manufacturer_name."]]></manufacturer_name>";
            if ($this->dropshippers->feed_type == 1) {
                $this->_html .= "<supplier_name><![CDATA[".(string)$product->supplier_name."]]></supplier_name>";
            }
            $this->_html .= "<last_update>".$product->date_upd."</last_update>";
            $this->_html .= "</product>";
        }
    }

    private function getProductsActionFeed($version, $action, $reference)
    {
        $this->_html .= "<product".($version ? " version='".(int)$version."'" : "").">";
        $this->_html .= "<reference><![CDATA[".trim((string)$reference)."]]></reference>";
        $this->_html .= "<action>".(string)$action."</action>";
        $this->_html .= "</product>";
    }

    private function showError($number, $description, $extras = null, $e = null)
    {
        if (!$this->context) {
            $this->context = Context::getContext();
        }

        $number = (int)$number;

        $this->_html = "";
        if (!(int)Tools::getValue('mode') && $number < 9000) {
            ob_clean();
            header("Content-Type:text/xml; charset=utf-8; Connection: close");
            $this->_html = "<?xml version='1.0' encoding='UTF-8'?>\n";
        }

        $dss = new DropShipSystem();
        if (isset($extras) && $extras) {
            $dss->writeLog('('.$number.') '.$description.((isset($e) && $e) ? ' - '.$e->getMessage() : ''));

            if (is_array($extras) && count($extras) > 0) {
                foreach ($extras as $key => $extra) {
                    $dss->writeLog(($this->debug ? '[DEBUG]' : '[INFO]').': ['.$key.'] '.$extra);
                }
            } else {
                $dss->writeLog(($this->debug ? '[DEBUG]' : '[INFO]').': '.$extras);
            }
        } else {
            $dss->writeLog('('.$number.') '.$description.((isset($e) && $e) ? ' - '.$e->getMessage() : ''));
        }

        if ($number < 9000) {
            $this->_html .= '<error>';
            $this->_html .= '<error_time>'.date('Y-m-d H:i:s').'</error_time>';
            $this->_html .= '<error_number>'.$number.'</error_number>';
            $this->_html .= '<error_description>'.$description;
            if (isset($e) && $e) {
                $this->_html .= ' - '.$e->getMessage();
            }
            $this->_html .= '</error_description>';
            $this->_html .= '</error>';

            if (isset($this->context->dropshippers)) {
                unset($this->context->dropshippers);
            }

            echo $this->_html;
            die();
        }
    }
}
