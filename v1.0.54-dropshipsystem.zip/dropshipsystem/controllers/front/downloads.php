<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class DropShipSystemDownloadsModuleFrontController extends ModuleFrontController
{
    public function __construct()
    {
        parent::__construct();
        $this->context = Context::getContext();
        $id_shop = $this->context->shop->id;

        if (!$this->context->customer->isLogged()) {
            $u = Tools::getValue('u');
            $p = Tools::getValue('p');
            $s = Tools::getValue('s');
            $customer = new Customer();
            $customer->getByEmail(trim($u), trim($p));
            $dss_auth = (object)DssDropshippersClass::getUser((int)$customer->id, $s);
            if ((int)$dss_auth->id_dss_dropshipper) {
                if ($dss_auth->active == 1) {
                    $context = Context::getContext();
                    $context->cookie->id_compare = isset($context->cookie->id_compare) ? $context->cookie->id_compare: CompareProduct::getIdCompareByIdCustomer($customer->id);
                    $context->cookie->id_customer = (int)$customer->id;
                    $context->cookie->customer_lastname = $customer->lastname;
                    $context->cookie->customer_firstname = $customer->firstname;
                    $context->cookie->logged = 1;
                    $customer->logged = 1;
                    $context->cookie->is_guest = $customer->isGuest();
                    $context->cookie->passwd = $customer->passwd;
                    $context->cookie->email = $customer->email;
                    $context->customer = $customer;
                }
            }
        }

        if ($this->context->customer->isLogged()) {
            $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);

            $file = trim(Tools::getValue('file'));
            $fullpath = null;

            $action = Tools::getValue('action');

            $client = 0;
            if ($id_dropshipper) {
                if (Tools::getValue('client')) {
                    $file = trim(Tools::getValue('client'));
                    $client = 1;
                }
                $ext = Tools::strtolower(pathinfo($file, PATHINFO_EXTENSION));

                if ($client) {
                    $fullpath = $this->module->getLocalPath().'downloads/clients/'.$file ;
                } else {
                    $file = str_replace('.'.$ext, '', $file);
                    if ($file == 'categories') {
                        $file .= '_'.$this->context->customer->id_default_group;
                    } elseif ($file == 'products') {
                        $file .= '_'.$this->context->customer->id_default_group;
                    } elseif ($file == 'pricelist') {
                        $file .= '_'.$id_dropshipper;
                    } elseif ($file == 'all') {
                        $file .= '_'.$id_dropshipper;
                    }
                    $fullpath = $this->module->getLocalPath().'downloads/'.(int)$id_shop.'/'.$file.'.'.$ext;
                }
            } elseif (!$id_dropshipper && $action == 'signup') {
                $ext = 'pdf';
                $fullpath = $this->module->getLocalPath().'downloads/'.(int)$id_shop.'/'.$file;
            } else {
                die('unauthorized');
            }

            if ($file && file_exists($fullpath)) {
                $fsize = filesize($fullpath);
                $filename = $file.'.'.$ext;
                header("Cache-Control: public");
                header("Content-Description: File Transfer");
                header("Content-Disposition: attachment; filename={$filename}");
                header("Content-length: $fsize");
                if ($ext == 'pdf') {
                    header('Content-Type: application/pdf');
                    header('Content-Transfer-Encoding: binary');
                } elseif ($ext == 'csv') {
                    header('Content-Type: text/csv');
                } elseif ($ext == 'xml') {
                    header('Content-Type: text/xml');
                } elseif ($ext == 'zip') {
                    header('Content-Type: application/zip');
                }
                readfile($fullpath);
                exit;
            } else {
                DssEventsClass::setEvent('error', $this->module->l('File not present:').' '.$fullpath);
                die('File not present');
            }
        } else {
            die('unauthorized');
        }
    }
}
