<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

include_once(_PS_MODULE_DIR_.'dropshipsystem/classes/DssClass.php');
include_once(_PS_MODULE_DIR_.'dropshipsystem/classes/DssCartClass.php');
include_once(_PS_MODULE_DIR_.'dropshipsystem/classes/DssDropshippersClass.php');
include_once(_PS_MODULE_DIR_.'dropshipsystem/classes/DssPaymentsHistoryClass.php');

class DropShipSystemMyDropshipAccountModuleFrontController extends ModuleFrontController
{
    public $auth = true;
    public $display_column_left = true;
    public $ssl = true;

    public $display_column_right = true;

    public $pagename = null;
    public $credits = array();

    public function __construct()
    {
        parent::__construct();
        $this->context = Context::getContext();

        $id_shop = (int)$this->context->shop->id;
        $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID((int)$this->context->customer->id);
        $dropshipper = new DssDropshippersClass($id_dropshipper);
//        if (!$dropshipper->id) {
//            //Tools::redirect($this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount', array('action' => 'signup'), true));
//            if (Tools::getValue('action') != 'signup') {
//                $this->{'displaySignup'}();
//            }
//        } else
        if ($dropshipper->id && !$dropshipper->active == 1) {
            Tools::redirect($this->context->link->getPageLink('my-account'));
        }

        $product_credits = unserialize(Configuration::get('DSS_CREDIT_PRODUCTS', null, null, $id_shop));

        $dss = new DssClass();
        foreach ($product_credits as $product_credit) {
            $_product = $dss->getProductIDByReference((string)$product_credit['reference']);
            $product = new Product((int)$_product['id_product']);
            if (isset($product) && $product->active && $product->online_only && $product->visibility == 'none') {
                $this->credits[] = array('price' => $product->price, 'reference' => $product_credit['reference']);
            }
        }
        $prices = array();
        if (isset($this->credits) && count($this->credits) > 0) {
            foreach ($this->credits as $credit) {
                $prices[] = $credit['price'];
            }
            array_multisort($prices, SORT_ASC, $this->credits);
        }
    }

    public function initContent()
    {
        parent::initContent();

        $action = Tools::getValue('action');

        Media::addJsDef(array(
            'token' => Tools::getToken(false),
            'dss_ajaxurl' => $this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount', array(), true),
            'dss_pluginurl' => $this->context->link->getModuleLink('dropshipsystem', 'downloads', array(), true),
        ));

        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            $this->context->controller->addJquery();
            $this->context->controller->addJqueryPlugin('fancybox');
            $this->context->controller->addJS($this->module->getLocalPath().'views/js/mydropshipaccount.js');
        } else {
            $this->context->controller->addJquery();
            Media::addJsDefL('msg_check_agreement', $this->l('Please accept agreement to continue'));
            Media::addJsDefL('err_nocredit', $this->l('No credit value has been selected'));
            Media::addJsDefL('err_invalid_payment', $this->l('Invalid payment selected'));

            $this->context->controller->addJS($this->module->getLocalPath().'views/js/mydropshipaccount17.js');
        }

        if (!empty($action) && method_exists($this, 'display'.Tools::toCamelCase($action))) {
            $this->{'display'.Tools::toCamelCase($action)}();
        } elseif (!empty($action) && method_exists($this, 'process'.Tools::toCamelCase($action))) {
            $this->{'process'.Tools::toCamelCase($action)}();
        } elseif (!empty($action) && Tools::getValue('ajax') && method_exists($this, 'ajaxProcess'.Tools::toCamelCase($action))) {
            $this->{'ajaxProcess'.Tools::toCamelCase($action)}();
        } elseif (!empty($action) && $action == 'orderdetails') {
            $id_order = (int)Tools::getValue('id_order');
            $this->displayForm($id_order);
        } else {
            $this->displayForm();
        }
    }

    public function displayPaymentPage()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;
        $id_lang = (int)$this->context->language->id;

        $token = (string)Tools::getValue('payment_token');
        $payment_token = new DssPaymentsTokenClass($token);

        $amount = (float)$payment_token->amount;
        $currency = (string)$payment_token->currency;
        $address_invoice = new Address($this->context->cart->id_address_invoice);
        $state_invoice = State::getNameById($address_invoice->id_state);

        $customer_name = array(
            'firstname' => $this->context->customer->firstname,
            'lastname' => $this->context->customer->lastname,
        );

        $billing_address = array(
            'line1' => $address_invoice->address1,
            'line2' => $address_invoice->address2,
            'city' => $address_invoice->city,
            'zip_code' => $address_invoice->postcode,
            'country' => $address_invoice->country,
            'state' => $state_invoice,
            'phone' => $address_invoice->phone_mobile ? $address_invoice->phone_mobile : $address_invoice->phone,
            'email' => $this->context->customer->email,
        );

        $payclass = DssPaymentClass::getInstance(false, true);

        $base_dir = $this->context->link->getBaseLink($this->context->shop->id, true);
        $tos_page_id = (int)Configuration::get('DSS_PAGE_TOS', null, null, $id_shop);
        $privacy_page_id = (int)Configuration::get('DSS_PAGE_PRIVACY', null, null, $id_shop);

        $this->context->smarty->assign(array(
            'iscredit' => (bool)$payment_token->is_credit,
            'ssl' => (int)Configuration::get('PS_SSL_ENABLED'),
            'module_dir' => $base_dir.'modules/'.$this->module->name.'/',
            'baseDir' => $base_dir,
            'currency' => $this->context->currency,
            'payment_token' => (string)$payment_token->token,
            'payment_description' => (string)$payment_token->name,
            'payment_currency' => (string)$currency,
            'payment_amount' => (float)$amount,
            'payment_customer_name' => $customer_name,
            'payment_billing_address' => Tools::jsonEncode($billing_address),
            'tos_url' => $this->context->link->getCMSLink((int)$tos_page_id, null, true),
            'privacy_url' => $this->context->link->getCMSLink((int)$privacy_page_id, null, true),
            'tpldata' => $payclass->tpldata,
            'tplfile' => (string)$payclass->tplfile,
        ));

        if (isset($payclass->register_js) && $payclass->register_js) {
            if (version_compare(_PS_VERSION_, '1.7', '<')) {
                if (is_array($payclass->register_js)) {
                    foreach ($payclass->register_js as $register_js) {
                        $this->context->controller->addJS($register_js['url']);
                    }
                } else {
                    $this->context->controller->addJS($payclass->register_js['url']);
                }
            } else {
                if (is_array($payclass->register_js)) {
                    foreach ($payclass->register_js as $register_js) {
                        $this->context->controller->registerJavascript($register_js['name'], $register_js['url'], $register_js['array']);
                    }
                } else {
                    $this->context->controller->registerJavascript($payclass->register_js['name'], $payclass->register_js['url'], $payclass->register_js['array']);
                }
            }
        }
        if (isset($payclass->has_js) && $payclass->has_js) {
            if (is_array($payclass->has_js)) {
                foreach ($payclass->has_js as $has_js) {
                    $base = '';
                    if (Tools::substr($has_js, 0, 4) !== "http") {
                        $base = _PS_MODULE_DIR_.'dropshipsystem/libs/';
                    }
                    $this->context->controller->addJS($base.$has_js);
                }
            } else {
                $base = '';
                if (Tools::substr($payclass->has_js, 0, 4) !== "http") {
                    $base = _PS_MODULE_DIR_.'dropshipsystem/libs/';
                }
                $this->context->controller->addJS($base.$payclass->has_js);
            }
        }
        if (isset($payclass->has_css) && $payclass->has_css) {
            if (is_array($payclass->has_css)) {
                foreach ($payclass->has_css as $has_css) {
                    $base = '';
                    if (Tools::substr($payclass->has_css, 0, 4) !== "http") {
                        $base = _PS_MODULE_DIR_.'dropshipsystem/libs/';
                    }
                    $this->context->controller->addCSS($base.$has_css);
                }
            } else {
                $base = '';
                if (Tools::substr($payclass->has_css, 0, 4) !== "http") {
                    $base = _PS_MODULE_DIR_.'dropshipsystem/libs/';
                }
                $this->context->controller->addCSS($base.$payclass->has_css);
            }
        }
        unset($payclass);

        Tools::clearSmartyCache('payment.tpl');

        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            $this->setTemplate('payment.tpl');
        } else {
            $this->setTemplate('module:dropshipsystem/views/templates/front/1.7/payment.tpl');
        }
    }

    public function displayForm($id_order = 0)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $errors = array();
        $id_dropshipper = 0;
        //$address = (object)array();

        if ($this->context->customer->isLogged()) {
            $add = Tools::getIsset('add');
            $add = (empty($add) === false ? 1 : 0);
            $delete = Tools::getIsset('deleted');
            $delete = (empty($delete) === false ? 1 : 0);
            $default = Tools::getIsset('default');
            $default = (empty($default) === false ? 1 : 0);

            $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);

            if ($id_dropshipper) {
                $dropshipper = new DssDropshippersClass($id_dropshipper);
                //$operator = new Employee((int)$dss_dropshippers->id_operator);
                $operator = $dropshipper->getOperator();
                $invoice_address = new Address((int)$dropshipper->id_address_invoice);
                $invoice_country = new Country((int)$invoice_address->id_country, $this->context->customer->id_lang);
                $invoice_state = new State((int)$invoice_address->id_state);
                $delivery_address = new Address((int)$dropshipper->id_address_delivery);
                $delivery_country = new Country((int)$delivery_address->id_country);
                $delivery_state = new State((int)$delivery_address->id_state);

                $dropshipper = (object)array_merge(
                    (array)$dropshipper,
                    array(
                        'invoice' => $invoice_address,
                        'invoice_country' => $invoice_country,
                        'invoice_state' => $invoice_state,
                        'delivery' => $delivery_address,
                        'delivery_country' => $delivery_country,
                        'delivery_state' => $delivery_state
                    )
                );

                if (!$id_order) {
                    $orders = array();
                    $dropship_orders = DssOrderClass::getOrdersIDByDropshipperID((int)$dropshipper->id);

                    if (isset($dropship_orders) && $dropship_orders) {
                        $customer_orders = Order::getCustomerOrders((int)$this->context->customer->id);
                        foreach ($customer_orders as $customer_order) {
                            if (in_array((int)$customer_order['id_order'], $dropship_orders)) {
                                $order = array();
                                foreach ($customer_order as $key => $value) {
                                    $order[$key] = $value;
                                }
                                $orders[] = $order;
                            }
                        }
                    }
                }
            } else {
                Tools::redirect($this->context->link->getPageLink('my-account'));
            }
        } else {
            Tools::redirect('index.php?controller=authentication&back='.urlencode($this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount')));
        }

        if (!$id_order) {
            $this->context->smarty->assign(array(
                'operator' => $operator,
                'dss_customer' => $this->context->customer,
                'dropshipper' => $dropshipper,
                'orders' => $orders,
                'errors' => $errors,
                'form_link' => $errors,
                'invoiceAllowed' => (int)Configuration::get('PS_INVOICE', null, null, $id_shop),
                //'reorderingAllowed' => !(bool)Configuration::get('PS_DISALLOW_HISTORY_REORDERING'),
            ));

            if (version_compare(_PS_VERSION_, '1.7', '<')) {
                $this->setTemplate('mydropshipaccount.tpl');
            } else {
                $this->setTemplate('module:dropshipsystem/views/templates/front/1.7/mydropshipaccount.tpl');
            }
        } else {
            $order = new Order($id_order);
            $id_order_state = (int)$order->getCurrentState();
            $carrier = new Carrier((int)$order->id_carrier, (int)$order->id_lang);
            $addressInvoice = new Address((int)$order->id_address_invoice);
            $addressDelivery = new Address((int)$order->id_address_delivery);

            $inv_adr_fields = AddressFormat::getOrderedAddressFields($addressInvoice->id_country);
            $dlv_adr_fields = AddressFormat::getOrderedAddressFields($addressDelivery->id_country);

            $invoiceAddressFormatedValues = AddressFormat::getFormattedAddressFieldsValues($addressInvoice, $inv_adr_fields);
            $deliveryAddressFormatedValues = AddressFormat::getFormattedAddressFieldsValues($addressDelivery, $dlv_adr_fields);

            $products = $order->getProducts();

            $id_dss_order = DssOrderClass::getDssOrderIDByOrderID((int)$order->id);
            $dss_order = new DssOrderClass((int)$id_dss_order);
            $payment_link = (string)$dss_order->payment_link;
            unset($dss_order);

            $customer = new Customer($order->id_customer);
            $this->context->smarty->assign(array(
                'operator' => $operator,
                'dss_customer' => $customer,
                'dropshipper' => $dropshipper,
                //'return_allowed' => (int)$order->isReturnable(),
                'currency' => new Currency($order->id_currency),
                'order' => $order,
                'order_state' => (int)$id_order_state,
                'order_history' => $order->getHistory($this->context->language->id, false, true),
                'paid' => $order->hasBeenPaid(),
                'payment_link' => (string)$payment_link,
                'carrier' => $carrier,
                'products' => $products,
                'invoice' => $order->invoice_number,
                'invoiceAllowed' => (int)Configuration::get('PS_INVOICE', null, null, $id_shop),
                'address_invoice' => $addressInvoice,
                'invoiceState' => (Validate::isLoadedObject($addressInvoice) && $addressInvoice->id_state) ? new State($addressInvoice->id_state) : false,
                'address_delivery' => $addressDelivery,
                'inv_adr_fields' => $inv_adr_fields,
                'dlv_adr_fields' => $dlv_adr_fields,
                'deliveryState' => (Validate::isLoadedObject($addressDelivery) && $addressDelivery->id_state) ? new State($addressDelivery->id_state) : false,
                'invoiceAddressFormatedValues' => $invoiceAddressFormatedValues,
                'deliveryAddressFormatedValues' => $deliveryAddressFormatedValues,
                //'is_guest' => false,
                'messages' => CustomerMessage::getMessagesByOrderId((int)$order->id, false),
                'use_tax' => Configuration::get('PS_TAX', null, null, $id_shop),
                'group_use_tax' => (Group::getPriceDisplayMethod($customer->id_default_group) == PS_TAX_INC),
                'errors' => $errors,
                'form_link' => $errors,
                'token' => Tools::getToken(false),
            ));

            if ($carrier->url && $order->shipping_number) {
                $this->context->smarty->assign('followup', str_replace('@', $order->shipping_number, $carrier->url));
            }
            unset($carrier, $addressInvoice, $addressDelivery);

            if (version_compare(_PS_VERSION_, '1.7', '<')) {
                $this->setTemplate('dropshiporder-details.tpl');
            } else {
                $this->setTemplate('module:dropshipsystem/views/templates/front/1.7/dropshiporder-details.tpl');
            }
        }
    }

    public function displayAddCredit()
    {
        $this->context->smarty->assign(array(
            'token' => Tools::getToken(false),
            'credits' => $this->credits
        ));

        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            $this->setTemplate('addcredit.tpl');
        } else {
            $this->setTemplate('module:dropshipsystem/views/templates/front/1.7/addcredit.tpl');
        }
    }

    public function displayCreditHistory()
    {
        if ($this->context->customer->isLogged()) {
            $id_shop = (int)$this->context->shop->id;
            $id_lang = (int)$this->context->language->id;
            $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);

            if ($id_dropshipper) {
                $dropshipper = new DssDropshippersClass($id_dropshipper);
                $paymentshistory = new DssPaymentsHistoryClass();

                $this->context->smarty->assign(array(
                    'dss_customer' => $this->context->customer,
                    'dropshipper' => $dropshipper,
                    'paymentshistory' => $paymentshistory->getAllPayments($id_lang, $this->context->customer->id),
                    'invoiceAllowed' => (int)Configuration::get('PS_INVOICE', null, null, $id_shop),
                    'token' => Tools::getToken(false),
                ));

                if (version_compare(_PS_VERSION_, '1.7', '<')) {
                    $this->setTemplate('credithistory.tpl');
                } else {
                    $this->setTemplate('module:dropshipsystem/views/templates/front/1.7/credithistory.tpl');
                }
            }
        } else {
            Tools::redirect('index.php?controller=authentication&back='.urlencode($this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount')));
        }
    }

    public function displayCreditDetails()
    {
        if ($this->context->customer->isLogged()) {
            $id_lang = (int)$this->context->language->id;

            $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
            if ($id_dropshipper) {
                $dropshipper = new DssDropshippersClass($id_dropshipper);
                $id_payment = (int)Tools::getValue('id_payment');
                $dssph = new DssPaymentsHistoryClass($id_payment);

                $this->context->smarty->assign(array(
                    'dss_customer' => $this->context->customer,
                    'dropshipper' => $dropshipper,
                    'creditdetails' => $dssph->getPaymentDetails($id_lang),
                ));

                if (version_compare(_PS_VERSION_, '1.7', '<')) {
                    $this->setTemplate('creditdetails.tpl');
                } else {
                    $this->setTemplate('module:dropshipsystem/views/templates/front/1.7/creditdetails.tpl');
                }
            } else {
                Tools::redirect($this->context->link->getPageLink('my-account'));
            }
        } else {
            Tools::redirect('index.php?controller=authentication&back='.urlencode($this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount')));
        }
    }

    public function displayPreferences()
    {
        if ($this->context->customer->isLogged()) {
            $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);

            if ($id_dropshipper) {
                $dropshipper = new DssDropshippersClass($id_dropshipper);

                $this->context->smarty->assign(array(
                    'preference_validation' => DssDropshippersClass::$definition['fields'],
                    'dss_customer' => $this->context->customer,
                    'dropshipper' => $dropshipper,
                    'token' => Tools::getToken(false),
                    'errors' => $this->errors
                ));

                if (version_compare(_PS_VERSION_, '1.7', '<')) {
                    $this->setTemplate('preferences.tpl');
                } else {
                    $this->setTemplate('module:dropshipsystem/views/templates/front/1.7/preferences.tpl');
                }
            } else {
                Tools::redirect($this->context->link->getPageLink('my-account'));
            }
        } else {
            Tools::redirect('index.php?controller=authentication&back='.urlencode($this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount')));
        }
    }

    public function displayChangeContact()
    {
        if ($this->context->customer->isLogged()) {
            $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
    
            if ($id_dropshipper) {
                $dropshipper = new DssDropshippersClass($id_dropshipper);

                $this->context->smarty->assign(array(
                    'contact_validation' => DssDropshippersClass::$definition['fields'],
                    'dss_customer' => $this->context->customer,
                    'dropshipper' => $dropshipper,
                    'token' => Tools::getToken(false),
                    'errors' => $this->errors
                ));

                if (version_compare(_PS_VERSION_, '1.7', '<')) {
                    $this->setTemplate('changecontact.tpl');
                } else {
                    $this->setTemplate('module:dropshipsystem/views/templates/front/1.7/changecontact.tpl');
                }
            } else {
                Tools::redirect($this->context->link->getPageLink('my-account'));
            }
        } else {
            Tools::redirect('index.php?controller=authentication&back='.urlencode($this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount')));
        }
    }

    public function displaySignup()
    {
        $id_shop = (int)$this->context->shop->id;
        if ((int)Configuration::get('DSS_DROPSHIPPERS_REGISTRATION', null, null, $id_shop) && $this->context->customer->isLogged()) {
            $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);

            if (!$id_dropshipper) {
                $payment_type = array(
                    array('id_payment_type' => 'none', 'name' => $this->module->l('None')),
                    array('id_payment_type' => 'prepayed', 'name' => $this->module->l('Prepayed credit')),
                    array('id_payment_type' => 'postpayed', 'name' => $this->module->l('Billed')),
                );

                $this->context->smarty->assign(array(
                    'signup_validation' => DssDropshippersClass::$definition['fields'],
                    'dss_customer' => $this->context->customer,
                    'payment_type' => $payment_type,
                    'agreement' => Configuration::get('DSS_CHECKAGREEMENT_TEXT', (int)$this->context->language->id, null, $id_shop),
                    'module_dir' => _MODULE_DIR_,
                    'token' => Tools::getToken(false),
                    'id_module' => $this->module->id
                ));

                if (version_compare(_PS_VERSION_, '1.7', '<')) {
                    $this->setTemplate('signup.tpl');
                } else {
                    $this->setTemplate('module:dropshipsystem/views/templates/front/1.7/signup.tpl');
                }
            } else {
                Tools::redirect($this->context->link->getPageLink('my-account'));
            }
        } else {
            Tools::redirect('index.php?controller=authentication&back='.urlencode($this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount')));
        }
    }

    public function getLayout()
    {
        if (Tools::getValue('action') == 'neworder' && version_compare(_PS_VERSION_, '1.7', '>=')) {
            return 'layouts/layout-full-width.tpl';
        } else {
            return parent::getLayout();
        }
    }

    public function displayNeworder()
    {
        $this->display_column_right = false;

        if ($this->context->customer->isLogged()) {
            $id_shop = (int)$this->context->shop->id;
            $id_lang = (int)$this->context->language->id;
            //$id_def_lang = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);

            $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
            if ($id_dropshipper) {
                $dropshipper = new DssDropshippersClass($id_dropshipper);

                if ($dropshipper->direct_order == 1) {
                    if (Tools::getValue('page') == 'confirm') {
                        $id_order = (int)Tools::getValue('id_order');

                        $order = new Order((int)$id_order);
                        $dss_order = new DssOrderClass();
                        $dss_order->getDssOrderByOrderID((int)$id_order);

                        $dss_order->formatted_previous_credit = Tools::displayPrice($dss_order->previous_credit, new Currency($order->id_currency));
                        $dss_order->formatted_current_credit = Tools::displayPrice($dss_order->current_credit, new Currency($order->id_currency));

                        $status = 1;
                        $payment_method = (string)Configuration::get('DSS_DEFAULT_PAYMENT_GATEWAY', null, null, $id_shop);
                        if ((string)$dropshipper->payment_method != '') {
                            $payment_method = (string)$dropshipper->payment_method;
                        }

                        if (isset($dss_order) && $dss_order->id) {
                            $this->context->smarty->assign(array(
                                'dropshipper' => $dropshipper,
                                'token' => Tools::getToken(false),
                                'dss_order' => $dss_order,
                                'status' => $status,
                                'shop_name' => (string)$this->context->shop->name,
                                'reference' => (string)$order->reference,
                                'total' => Tools::displayPrice(
                                    $order->getOrdersTotalPaid(),
                                    new Currency($order->id_currency),
                                    false
                                ),
                                'payment_method' => $payment_method,
                                'payment_link' => (string)$dss_order->payment_link,
                                'bankwire' => (int)Configuration::get('DSS_BANKWIRE', null, null, $id_shop),
                                'bankwire_owner' => (string)Configuration::get('DSS_BANKWIRE_OWNER', null, null, $id_shop),
                                'bankwire_name' => (string)Configuration::get('DSS_BANKWIRE_NAME', null, null, $id_shop),
                                'bankwire_iban' => (string)Configuration::get('DSS_BANKWIRE_IBAN', null, null, $id_shop),
                                'bankwire_swift' => (string)Configuration::get('DSS_BANKWIRE_SWIFT', null, null, $id_shop),
                                'contact_url' => $this->context->link->getPageLink('contact', true)
                            ));
                        } else {
                            $this->context->smarty->assign(array(
                                'status' => 0,
                                'shop_name' => (string)$this->context->shop->name,
                                'contact_url' => $this->context->link->getPageLink('contact', true)
                            ));
                        }

                        if (version_compare(_PS_VERSION_, '1.7', '<')) {
                            $this->setTemplate('order-confirm.tpl');
                        } else {
                            $this->setTemplate('module:dropshipsystem/views/templates/front/1.7/order-confirm.tpl');
                        }
                    } else {
                        $dss_cart = new DssCartClass();
                        $cart = $dss_cart->getCart($id_dropshipper);
                        unset($dss_cart);

                        $countries = array();
                        foreach (Country::getCountries($id_lang, true) as $country) {
                            $countries[(int)$country['id_country']] = array(
                                'name' => (string)$country['name'],
                            );
                        }

                        $states = array();
                        if (Country::containsStates($cart['delivery_address']->id_country)) {
                            foreach (State::getStates($id_lang, true) as $state) {
                                $states[(int)$state['id_state']] = (string)$state['name'];
                            }
                        }

                        $shipping_methods = array();
                        for ($i = 1; $i <= 3; $i++) {
                            $id_carrier = (int)Configuration::get('DSS_SHIPPING_METHOD_'.(int)$i, null, null, $id_shop);
                            $carrier = new Carrier($id_carrier);
                            $shipping_methods[(int)$carrier->id] = (string)$carrier->name;
                            unset($carrier);
                        }

                        $this->context->smarty->assign(array(
                            'order_validation' => DssDropshippersClass::$definition['fields'],
                            'dss_customer' => $this->context->customer,
                            'dropshipper' => $dropshipper,
                            'token' => Tools::getToken(false),
                            'dss_cart' => $cart,
                            'countries' => $countries,
                            'states' => $states,
                            'shipping_methods' => $shipping_methods,
                            'errors' => $this->errors,
                        ));

                        if (version_compare(_PS_VERSION_, '1.7', '<')) {
                            $this->setTemplate('order.tpl');
                        } else {
                            $this->setTemplate('module:dropshipsystem/views/templates/front/1.7/order.tpl');
                        }
                    }
                } else {
                    Tools::redirect($this->context->link->getPageLink('my-account'));
                }
            } else {
                Tools::redirect($this->context->link->getPageLink('my-account'));
            }
        } else {
            Tools::redirect('index.php?controller=authentication&back='.urlencode($this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount')));
        }
    }

    public function processPayment()
    {
        $errors = array();
        $total = 0;
        $status = 'error';
        $iscredit = 0;
        $payment_link = null;

        $id_shop = (int)$this->context->shop->id;

        if ($this->context->customer->isLogged()) {
            $shop_name = (string)$this->context->shop->name;

            $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
            $dropshippers = new DssDropshippersClass($id_dropshipper);

            if ($id_dropshipper && isset($dropshippers) && $dropshippers->id > 0) {
                $response = (string)Tools::getValue('response');
                $params = array(
                    'token' => (string)Tools::getValue('token'),
                );
                if ($response == 'return') {
                    $dss_payment_token = new DssPaymentsTokenClass((string)$params['token']);
                    if (isset($dss_payment_token) && $dss_payment_token->id) {
                        $iscredit = (int)$dss_payment_token->is_credit;
                        if ($dss_payment_token->status == 'valid' || $dss_payment_token->status == 'cbok') {
                            $payclass = DssPaymentClass::getInstance();
                            $payres = $payclass->processPayment($params);
                            unset($payclass);

                            if ($payres['success']) {
                                $id_currency = (int)Currency::getIdByIsoCode($payres['currency']);
                                $currency = new Currency($id_currency);

                                $payment_amount = (float)$payres['amount'];
                                $payment_date = $payres['payment_date'];
                                $payment_transaction = (string)$payres['transaction_id'];
                                $payment_token = (string)$payres['token'];

                                if ($iscredit) {
                                    $id_payment_history = (int)DssPaymentsHistoryClass::getPaymentHistoryID($this->context->customer->id, $payment_token);
                                    if ($id_payment_history) {
                                        $status = 'success';
                                    } else {
                                        $errors[] = $this->module->l('Payment history has not be found', 'dropshipsystem');
                                    }
                                } else {
                                    $status = 'success';
                                }
                            } else {
                                if ($payres['error'] == 'pending') {
                                    // TO DO
                                    $errors[] = $this->module->l('PENDING PAYMENT', 'dropshipsystem');
                                } else {
                                    $errors[] = sprintf($this->module->l('PAYMENT ERROR: %s', 'dropshipsystem'), (string)$payres['error']);
                                }
                            }
                        } else {
                            $errors[] = $this->module->l('Payment already executed', 'dropshipsystem');
                        }
                    } else {
                        $errors[] = $this->module->l('Invalid or missing token', 'dropshipsystem');
                    }
                } elseif ($response == 'cancel') {
                    $dss_payment_token = new DssPaymentsTokenClass((string)$params['token']);
                    $id_dss_order = DssOrderClass::getDssOrderIDByOrderID((int)$dss_payment_token->id_order);
                    $dss_order = new DssOrderClass((int)$id_dss_order);
                    $payment_link = (string)$dss_order->payment_link;
                    unset($dss_order);

                    $errors[] = $this->module->l('Payment has been cancel by the user', 'dropshipsystem');
                    $status = 'cancel';
                } else {
                    Tools::redirect($this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount'));
                }
            } else {
                $errors[] = $this->module->l('Unknow dropshipper customer', 'dropshipsystem');
            }

            if (!count($errors)) {
                if ($iscredit) {
                    $dssph = new DssPaymentsHistoryClass($id_payment_history);

                    $id_address_invoice = (int)Address::getFirstCustomerAddressId($this->context->customer->id);

                    /* Make new cart */
                    $cart = new Cart();
                    $cart->id_customer = (int)$this->context->customer->id;
                    $cart->id_address_invoice = (int)$id_address_invoice;
                    $cart->id_address_delivery = 0;
                    $cart->id_lang = (int)$this->context->customer->id_lang;
                    $cart->id_currency = (int)$currency->id;
                    $cart->is_guest = (int)$this->context->customer->is_guest;
                    $cart->id_carrier = 0;
                    $cart->secure_key = $this->context->customer->secure_key;
                    $cart->recyclable = 0;
                    $cart->gift = 0;
                    if ($cart->add()) {
                        $cart->updateQty(1, (int)$dssph->id_product, 0, null, 'up', 0, null, false);
                        $cart->update();
                    }

                    //$total_product = (float)$cart->getOrderTotal(false, Cart::ONLY_PRODUCTS_WITHOUT_SHIPPING);
                    //$total_shipping = (float)$cart->getOrderTotal(false, Cart::ONLY_SHIPPING);
                    $total = (float)$cart->getOrderTotal(true, Cart::BOTH);

                    $mail_vars = array(
                        '{date}' => Tools::displayDate(date('Y-m-d H:i:s'), null, 1),
                        '{previous_credit}' => Tools::displayPrice($dropshippers->credit, $currency),
                        '{buyed_credit}' => Tools::displayPrice($total, $currency),
                        '{credit}' => Tools::displayPrice($total + $dropshippers->credit, $currency),
                        '{dropship_account_url}' => $this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount', array(), true)
                    );

                    $payment = new DssPaymentClass();
                    if (!$payment->validateOrder($cart->id, (int)Configuration::get('PS_OS_DROPSHIP_CREDIT_SUCCESS', null, null, $id_shop), $total, $this->module->displayName, null, $mail_vars, (int)$currency->id, false, $this->context->customer->secure_key)) {
                        $errors[] = $this->module->l('Error during create credit order', 'dropshipsystem');
                        $dssph->status = 'error';
                    } else {
                        $dss_payment_token->setStatus('used');

                        $dssph->status = 'accepted';
                        $dssph->currency = (string)$currency->iso_code;
                        $dssph->previous_credit = (float)$dropshippers->credit;
                        $dssph->buyed_credit = (float)$payment_amount;
                        $dssph->current_credit = (float)$dropshippers->credit + (float)$payment_amount;
                        $dssph->id_invoice = 0;
                        $dssph->id_order = (int)$payment->currentOrder;
                        $dssph->transaction_id = (string)$payment_transaction;
                        $dssph->payment_date = (string)date('Y-m-d H:i:s', $payment_date);
                    }

                    if ($dssph->update()) {
                        if (!count($errors) && $payres['success'] && $dropshippers->addCredit($payment_amount)) {
                            $total = $payment_amount;
                        } else {
                            $errors[] = $this->module->l('Error adding credit', 'dropshipsystem');
                        }
                    } else {
                        $errors[] = $this->module->l('Error registering credit payment', 'dropshipsystem');
                    }
                } else {
                    $total = (float)$dss_payment_token->amount;
                    if ($dss_payment_token->status == 'valid' || $dss_payment_token->status == 'cbok') {
                        $history = new OrderHistory();
                        $history->id_order = (int)$dss_payment_token->id_order;
                        $history->changeIdOrderState((int)Configuration::get('PS_OS_PAYMENT', null, null, $id_shop), $history->id_order);
                        $history->addWithemail();
                        $history->save();

                        $dss_payment_token->setStatus('used');
                    }
                }
            }

            Tools::clearSmartyCache('payment-result.tpl');

            $this->context->smarty->assign(array(
                'iscredit' => (int)$iscredit,
                'payment_link' => (string)$payment_link,
                'shop_name' => (string)$shop_name,
                'credit' => (float)$dropshippers->getCredit(),
                'total' => (float)$total,
                'status' => (string)$status,
                'contact_url' => $this->context->link->getPageLink('contact', true),
                'errors' => $errors
            ));

            if (version_compare(_PS_VERSION_, '1.7', '<')) {
                $this->setTemplate('payment-result.tpl');
            } else {
                $this->setTemplate('module:dropshipsystem/views/templates/front/1.7/payment-result.tpl');
            }
        } else {
            Tools::redirect('index.php?controller=authentication&back='.urlencode($this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount')));
        }
    }

    public function getBreadcrumbLinks()
    {
        $breadcrumb = parent::getBreadcrumbLinks();

        $breadcrumb['links'][] = $this->addMyAccountToBreadcrumb();

        if (Tools::getValue('action')) {
            $breadcrumb['links'][] = array(
                'title' => $this->l('My Dropship Account', 'dropshipsystem'),
                'url' => $this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount')
            );
        }

        return $breadcrumb;
    }

    public function ajaxProcessSetAddress()
    {
        //$errors = array();
        parse_str(Tools::getValue('form_data'), $data);

        if (isset($data) && $data) {
            $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
            if ($id_dropshipper) {
                $dropshippers = new DssDropshippersClass($id_dropshipper);
                $dss_cart = new DssCartClass();
                $dss_cart->getCartByDropshipperId($id_dropshipper);

                $shipping_firstname = isset($data['dss_address_firstname']) ? (string)$data['dss_address_firstname'] : null;
                $shipping_lastname = isset($data['dss_address_lastname']) ? (string)$data['dss_address_lastname'] : null;
                $shipping_company = isset($data['dss_address_company']) ? (string)$data['dss_address_company'] : null;
                $shipping_address1 = isset($data['dss_address_address1']) ? (string)$data['dss_address_address1'] : null;
                $shipping_address2 = isset($data['dss_address_address2']) ? (string)$data['dss_address_address2'] : null;
                $shipping_postcode = isset($data['dss_address_postcode']) ? (string)$data['dss_address_postcode'] : null;
                $shipping_city = isset($data['dss_address_city']) ? (string)$data['dss_address_city'] : null;
                $shipping_id_country = isset($data['dss_address_country']) ? (int)$data['dss_address_country'] : 0;
                $shipping_id_state = isset($data['dss_address_state']) ? (int)$data['dss_address_state'] : 0;
                $shipping_phone = isset($data['dss_address_phone']) ? (string)$data['dss_address_phone'] : null;
                $shipping_method = isset($data['dss_order_shipping_method']) ? (int)$data['dss_order_shipping_method'] : 0;

                $delivery_alias = md5(serialize(array(
                    'DRP '.(int)$id_dropshipper,
                    $shipping_company,
                    $shipping_lastname,
                    $shipping_firstname,
                    $shipping_address1,
                    $shipping_address2,
                    $shipping_postcode,
                    $shipping_city,
                    $shipping_id_country,
                    $shipping_id_state,
                    $shipping_phone)));

                $address = new Address();
                if (isset($dss_cart) && (int)$dss_cart->id_address_delivery > 0) {
                    $address = new $address((int)$dss_cart->id_address_delivery);
                }
                $address->alias = empty($address->alias) ? $delivery_alias : $address->alias;
                $address->firstname = (string)$shipping_firstname;
                $address->lastname = (string)$shipping_lastname;
                $address->company = (string)$shipping_company;
                $address->address1 = (string)$shipping_address1;
                $address->address2 = (string)$shipping_address2;
                $address->postcode = (string)$shipping_postcode;
                $address->city = (string)$shipping_city;
                $address->id_country = (int)$shipping_id_country;
                $address->id_state = (int)$shipping_id_state;
                $address->phone = (string)$shipping_phone;
                $address->active = 1;
                $address->deleted = 1;
                $address->id_customer = $this->context->customer->id;

                try {
                    if (!$address->id) {
                        if ($address->add(true, true)) {
                            $dss_cart->id_address_delivery = (int)$address->id;
                        }
                    } else {
                        $address->update(true);
                    }
                    $dss_cart->id_carrier = (int)$shipping_method;
                    $dss_cart->id_address_invoice = (int)$dropshippers->id_address_invoice;
                    $dss_cart->update();
                } catch (Exception $e) {
                    die(Tools::jsonEncode(array(
                        'success' => false,
                        'error' => $e->getMessage()
                    )));
                }

                $states = array();
                if (Country::containsStates((int)$shipping_id_country)) {
                    foreach (State::getStatesByIdCountry($shipping_id_country, true) as $state) {
                        $states[(int)$state['id_state']] = (string)$state['name'];
                    }
                }

                $cart = array();
                $cart['delivery_address'] = $address;

                if (version_compare(_PS_VERSION_, '1.7', '<')) {
                    $tpl = $this->context->smarty->createTemplate(
                        dirname(__FILE__).'/../../views/templates/front/states.tpl'
                    );
                    $tpl->assign(array(
                        'link' => $this->context->link,
                        'dss_cart' => $cart,
                        'states' => $states,
                        'static_token' => Tools::getToken(false),
                    ));
                    $res = array(
                        'success' => true,
                        'preview' => $tpl->fetch(),
                    );
                } else {
                    $res = array(
                        'success' => true,
                        'preview' => $this->render('../../../modules/dropshipsystem/views/templates/front/1.7/_partials/states', array(
                            'dss_cart' => $cart,
                            'states' => $states,
                            'static_token' => Tools::getToken(false),
                        ))
                    );
                }
            } else {
                $res = array(
                    'success' => false,
                    'error' => $this->module->l('No Dropshipper profile', 'dropshipsystem')
                );
            }

            die(Tools::jsonEncode($res));
        }
    }

//    public function ajaxProcessGetStates()
//    {
//        $id_country = (int)Tools::getValue('id_country');
//
//        $states = array();
//        foreach (State::getStatesByIdCountry($id_country, true) as $state) {
//            $states[(int)$state['id_state']] = (string)$state['name'];
//        }
//
//        die(Tools::jsonEncode(array(
//            'preview' => $this->render('../../../modules/dropshipsystem/views/templates/front/1.7/_partials/states', array(
//                'states' => $states,
//                'static_token' => Tools::getToken(false),
//            ))
//        )));
//    }

    public function ajaxProcessGetPaymentPage()
    {
        $this->context = Context::getContext();

//        $payclass = DssPaymentClass::getInstance();
//        $payres = $payclass->getAuth();
//        unset($payclass);
//
//        die(Tools::jsonEncode(array(
//            'success' => false,
//            'error' => serialize($payres)
//        )));

        if (!$this->context->customer->isLogged()) {
            die(Tools::jsonEncode(array(
                'success' => false,
                'error' => $this->module->l('You aren\'t logged in', 'dropshipsystem')
            )));
        }

        $token = (string)DssPaymentsTokenClass::getToken();

        $ref_credit = (string)Tools::getValue('ref_credit');

        $id_product = 0;
        $products = array();
        foreach ($this->credits as $credit) {
            if ((string)$credit['reference'] == $ref_credit) {
                $dss = new DssClass();
                $_product = $dss->getProductIDByReference((string)$credit['reference']);
                $id_product = (int)$_product['id_product'];
                $product = new Product((int)$id_product, false, (int)$this->context->language->id);
                $product_name = (string)$product->name;
                unset($product);

                $params = array(
                    'is_credit' => true,
                    'token' => (string)$token,
                    'id_order' => 0,
                    'name' => (string)$product_name,
                    'total' => (float)$credit['price'],
                    'custom_reference' => (string)$credit['reference'],
                    'return_url' => $this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount', array('action' => 'payment', 'response' => 'return'), true),
                    'cancel_url' => $this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount', array('action' => 'payment', 'response' => 'cancel'), true),
                );
                break;
            }
        }

        $payclass = DssPaymentClass::getInstance();
        $payres = $payclass->getPaymentPage($params);
        unset($payclass);

        if ($payres['success']) {
            $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
            $dropshippers = new DssDropshippersClass($id_dropshipper);

            $dssph = new DssPaymentsHistoryClass();
            $dssph->id_customer = (int)$this->context->customer->id;
            $dssph->request_date = date('Y-m-d H:i:s');
            $dssph->status = 'pending';
            $dssph->currency = (string)$payres['currency'];
            $dssph->previous_credit = (float)$dropshippers->credit;
            $dssph->id_product = (int)$id_product;
            $dssph->buyed_credit = 0;
            $dssph->current_credit = (float)$dropshippers->credit;
            $dssph->token = (string)$payres['token'];
            $dssph->payment_link = (string)$payres['paymentlink'];

            if ($dssph->add()) {
                $res = array(
                    'success' => true,
                    'paymentlink' => (string)$payres['paymentlink'],
                );
            } else {
                $res = array(
                    'success' => false,
                    'error' => $this->module->l('Error during creating payment', 'dropshipsystem')
                );
            }
        } else {
            if ($payres['error'] == 'NO_LOGGED') {
                $res = array(
                    'success' => false,
                    'error' => $this->module->l('You aren\'t logged in', 'dropshipsystem')
                );
            } elseif ($payres['error'] == 'INVALID_PRODUCT') {
                $res = array(
                    'success' => false,
                    'error' => $this->module->l('Product has not valid', 'dropshipsystem')
                );
            }
        }

        die(Tools::jsonEncode($res));
    }

    /**
     * Start forms process
     * @see FrontController::postProcess()
     */
    public function postProcess()
    {
        $id_shop = (int)$this->context->shop->id;
        $id_lang = (int)$this->context->language->id;
        $id_default_lang = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);

        $wholesale_base_price = (int)Configuration::get('DSS_WHOLESALE_BASE_PRICE', null, null, $id_shop);

        if (Tools::isSubmit('submitSignup')) {
            $dropshippers = new DssDropshippersClass();
            $dropshippers->id_shop = (int)$this->context->shop->id;
            $dropshippers->active = 2;
            $dropshippers->id_operator = 0;
            $dropshippers->payment_method = (string)Configuration::get('DSS_DEFAULT_PAYMENT_GATEWAY', null, null, $id_shop);
            $dropshippers->secret = (string)$this->makeSecret();
            $this->errors = $dropshippers->validateController();

            $customer = $this->context->customer;
            if ($customer->isLogged() && !$this->isTokenValid()) {
                $this->errors[] = $this->module->l('Invalid token.', 'dropshipsystem');
            }
            if ($this->errors) {
                return;
            }
            if ($dropshippers->add()) {
                $admin_mail = Configuration::get('PS_SHOP_EMAIL', null, null, $id_shop);
                if (isset($admin_mail) && $admin_mail) {
                    $template_vars = array(
                        '{firstname}' => $customer->firstname,
                        '{lastname}' => $customer->lastname,
                        '{contact_name}' => $dropshippers->contact_name,
                        '{contact_email}' => $dropshippers->contact_email,
                        '{contact_phone}' => $dropshippers->contact_phone,
                        '{contact_mobile}' => $dropshippers->contact_mobile,
                        '{website}' => $dropshippers->website,
                        '{payment_type}' => $dropshippers->payment_type,
                    );
                    Mail::Send((int)$customer->id_lang, 'dss_new_customer', Mail::l('New Dropship customer request', (int)$customer->id_lang), $template_vars, $admin_mail, $customer->firstname.' '.$customer->lastname, null, null, null, null, dirname(__FILE__).'/../../mails/');
                }
                Tools::redirect($this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount'));
            }
            $this->errors[] = $this->module->l('An error occurred during update.', 'dropshipsystem');
        }

        if (Tools::isSubmit('submitContact') || Tools::isSubmit('submitPreferences')) {
            $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);

            if ($id_dropshipper) {
                $dropshippers = new DssDropshippersClass($id_dropshipper);
                $this->errors = $dropshippers->validateController();

                if ($this->context->customer->isLogged() && !$this->isTokenValid()) {
                    $this->errors[] = $this->module->l('Invalid token.', 'dropshipsystem');
                }
                if ($this->errors) {
                    return;
                }
                if ($dropshippers->update()) {
                    Tools::redirect($this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount'));
                }
            }
            $this->errors[] = $this->module->l('An error occurred during update.', 'dropshipsystem');
        }

        if (Tools::isSubmit('submitOrder')) {
            $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);

            if ($id_dropshipper) {
                $total_products_tax_excl = 0;
                $total_products_tax_incl = 0;
                $total_shipping = 0;
                $total_shipping_extra_fee = 0;
                $carrier_tax_rate = 0;
                $order_reference = null;

                $group = $this->context->customer->id_default_group;

                $dropshippers = new DssDropshippersClass($id_dropshipper);
                $dss_cart = new DssCartClass();
                $dss_cart->getCartByDropshipperId((int)$id_dropshipper);

                if ($this->context->customer->isLogged() && !$this->isTokenValid()) {
                    $this->errors[] = $this->module->l('Invalid token.', 'dropshipsystem');
                }

                $shipping_firstname = (string)Tools::getValue('dss_address_firstname');
                $shipping_lastname = (string)Tools::getValue('dss_address_lastname');
                $shipping_company = (string)Tools::getValue('dss_address_company');
                $shipping_address1 = (string)Tools::getValue('dss_address_address1');
                $shipping_address2 = (string)Tools::getValue('dss_address_address2');
                $shipping_postcode = (string)Tools::getValue('dss_address_postcode');
                $shipping_city = (string)Tools::getValue('dss_address_city');
                $shipping_id_country = (int)Tools::getValue('dss_address_country');
                $shipping_id_state = (int)Tools::getValue('dss_address_state');
                $shipping_phone = (string)Tools::getValue('dss_address_phone');

                if (empty($shipping_firstname)) {
                    $this->errors[] = $this->module->l('Missing data: Shipping First Name', 'dropshipsystem');
                }
                if (empty($shipping_lastname)) {
                    $this->errors[] = $this->module->l('Missing data: Shipping Last Name', 'dropshipsystem');
                }
                if (empty($shipping_address1)) {
                    $this->errors[] = $this->module->l('Missing data: Shipping Address', 'dropshipsystem');
                }
                if (empty($shipping_postcode)) {
                    $this->errors[] = $this->module->l('Missing data: Shipping Zip/Cap', 'dropshipsystem');
                }
                if (empty($shipping_city)) {
                    $this->errors[] = $this->module->l('Missing data: Shipping City', 'dropshipsystem');
                }
                if (empty($shipping_id_country)) {
                    $this->errors[] = $this->module->l('Missing data: Shipping Country', 'dropshipsystem');
                }

                if ($shipping_id_country && Country::containsStates($shipping_id_country)) {
                    if (empty($shipping_id_state)) {
                        $this->errors[] = $this->module->l('Missing data: Shipping State', 'dropshipsystem');
                    }
                }

                $delivery_alias = md5(serialize(array(
                    'DRP '.(int)$id_dropshipper,
                    $shipping_company,
                    $shipping_lastname,
                    $shipping_firstname,
                    $shipping_address1,
                    $shipping_address2,
                    $shipping_postcode,
                    $shipping_city,
                    $shipping_id_country,
                    $shipping_id_state,
                    $shipping_phone)));

                $address = new Address();
                if (isset($dss_cart) && (int)$dss_cart->id_address_delivery > 0) {
                    $address = new $address((int)$dss_cart->id_address_delivery);
                }
                $address->alias = (string)$delivery_alias;
                $address->firstname = (string)$shipping_firstname;
                $address->lastname = (string)$shipping_lastname;
                $address->company = (string)$shipping_company;
                $address->address1 = (string)$shipping_address1;
                $address->address2 = (string)$shipping_address2;
                $address->postcode = (string)$shipping_postcode;
                $address->city = (string)$shipping_city;
                $address->id_country = (int)$shipping_id_country;
                $address->id_state = (int)$shipping_id_state;
                $address->phone = (string)$shipping_phone;
                $address->active = 1;
                $address->deleted = 1;
                $address->id_customer = $this->context->customer->id;

                try {
                    if (!$address->id) {
                        if ($address->add()) {
                            $dss_cart->id_address_delivery = (int)$address->id;
                        }
                    } else {
                        $address->update();
                    }
                    $dss_cart->id_carrier = (int)Tools::getValue('dss_order_shipping_method');
                    $dss_cart->id_address_invoice = (int)$dropshippers->id_address_invoice;
                    $dss_cart->update();
                } catch (Exception $e) {
                    $this->errors[] = $e->getMessage();
                    return;
                }

                if (!$dropshippers->id_address_invoice) {
                    DssEventsClass::setEvent('error', sprintf($this->module->l('Dropshipper id %s without billing profile.', 'dropshipsystem'), $id_dropshipper));
                    $this->errors[] = $this->module->l('Dropshipper without billing profile', 'dropshipsystem');
                    return;
                } else {
                    $_country = new Address($dropshippers->id_address_invoice);
                    $dropshippers->id_country = (int)$_country->id_country;
                    unset($_country);
                }

                $check_out_of_stock = array(0);
                if (Configuration::get('PS_ORDER_OUT_OF_STOCK') == 0) {
                    $check_out_of_stock[] = 2;
                }

                if (empty($dss_cart->cart['products'])) {
                    $this->errors[] = $this->module->l('Products not specified', 'dropshipsystem');
                } else {
                    $product_list = array();
                    $unavailable_products = array();
                    foreach ($dss_cart->cart['products'] as $cart_product) {
                        $id_product = (int)$cart_product['id_product'];
                        $id_product_attribute = (int)$cart_product['id_product_attribute'];
                        $quantity = (int)$cart_product['quantity'];

                        /* Check if customer quantity is valid */
                        if (!$quantity) {
                            $this->errors[] = sprintf($this->module->l('Quantity value for product %s is not valid', 'dropshipsystem'), (string)$cart_product['reference']);
                            break;
                        }

                        $id_stock_available = (int)StockAvailable::getStockAvailableIdByProductId($id_product, $id_product_attribute, $id_shop);
                        if ($id_stock_available) {
                            $stock_available = new StockAvailable($id_stock_available);
                            if ($stock_available->quantity <= 0 && !in_array(2, $check_out_of_stock)) {
                                $stock_available->quantity = 999999;
                            }
                            if ($quantity > $stock_available->quantity) {
                                $unavailable_products[] = (string)$cart_product['reference'];
                            } else {
                                $product_to_add = new Product((int)$id_product, true, $id_default_lang);

                                /* Check if product is valid */
                                if (!$product_to_add->id || !$product_to_add->active) {
                                    $this->errors[] = sprintf($this->module->l('Invalid product %s'), (string)$cart_product['reference']);
                                    break;
                                }

                                /* Check if product is available for order */
                                if (!$product_to_add->available_for_order) {
                                    $this->errors[] = sprintf($this->module->l('Product %s is not available for order'), (string)$cart_product['reference']);
                                    break;
                                }

                                $key = $id_product.'-'.$id_product_attribute;

                                if (isset($product_list[$key])) {
                                    $product_list[$key]['quantity'] += (int)$quantity;
                                } else {
                                    $specific_wholesale_price = 0;
                                    $prd = new Product($id_product);
                                    $product_tax_rate = (float)$prd->getTaxesRate(new Address($dropshippers->id_address_invoice));

                                    $specific_wholesale_price = DssSpecificWholesalePriceClass::getSpecificWholesalePrice(
                                        (int)$id_product,
                                        (int)$id_shop,
                                        (int)$this->context->currency->id,
                                        (int)$dropshippers->id_country,
                                        (int)$group,
                                        (int)$id_product_attribute
                                    );

                                    if ($wholesale_base_price == 0) {
                                        $base_price = $prd->wholesale_price;
                                    } else if ($wholesale_base_price == 1) {
                                        $base_price = $prd->getPriceWithoutReduct(true, (int)$id_product_attribute);
                                    }

                                    if ($specific_wholesale_price) {
                                        $product_price = (float)$base_price * ((100 + (float)$specific_wholesale_price['value']) / 100);
                                    } else {
                                        $product_price = (float)$base_price * ((100 + (float)$dropshippers->wholesale_reduction) / 100);
                                    }

                                    $product_list[$key] = array(
                                        'quantity' => (int)$quantity,
                                        'price' => (float)$product_price,
                                        'tax_rate' => (float)$product_tax_rate
                                    );
                                    $total_products_tax_excl += ($product_price * $quantity);
                                    $total_products_tax_incl += ($product_price * $quantity) + ((($product_price * $quantity) / 100) * (float)$product_tax_rate);
                                    unset($prd);
                                }
                            }
                        }
                    }
                    if (count($unavailable_products) > 0) {
                        $this->errors[] = sprintf($this->module->l('Some products are not available: %s'), implode(', ', $unavailable_products));
                    }
                    $total_tax_excl = $total_products_tax_excl + $total_shipping + $total_shipping_extra_fee;
                    $total_tax_incl = $total_products_tax_incl + ($total_shipping + (($total_shipping / 100) * (float)$carrier_tax_rate)) + $total_shipping_extra_fee;
                }

                if ($this->errors) {
                    return;
                }

                $currency = new Currency((int)Configuration::get('PS_CURRENCY_DEFAULT', null, null, $id_shop));

                $allowOrdersZeroQty = (int)Configuration::get('DSS_ALLOW_ORDERS_ZERO_QTY');

                $_state = new State((int)Configuration::get('PS_SHOP_STATE_ID', null, null, $id_shop));

                $shop_name = (string)$this->context->shop->name;
                $shop_address = (string)Configuration::get('PS_SHOP_ADDR1', null, null, $id_shop);
                $shop_city = (string)Configuration::get('PS_SHOP_CITY', null, null, $id_shop);
                $shop_cap = (string)Configuration::get('PS_SHOP_CODE', null, null, $id_shop);
                $shop_coutry = (string)Country::getIsoById((int)Configuration::get('PS_SHOP_COUNTRY_ID', null, null, $id_shop));
                $shop_state = (string)$_state->iso_code;
                $shop_phone = (string)Configuration::get('PS_SHOP_PHONE', null, null, $id_shop);
                $shop_logo = 'http'.(Configuration::get('PS_SSL_ENABLED', null, null, $id_shop) ? 's' : '').'://'.
                                    Tools::getShopDomain(false, true).__PS_BASE_URI__.'img/'.(string)Configuration::get('PS_LOGO', null, null, $id_shop);
                unset($_state);

                /* Make new cart */
                $cart = new Cart();
                $cart->id_customer = (int)$this->context->customer->id;
                $cart->id_address_invoice = (int)$dss_cart->id_address_invoice;
                $cart->id_address_delivery = (int)$dss_cart->id_address_delivery;
                $cart->id_lang = (int)$id_lang;
                $cart->id_currency = (int)$currency->id;
                $cart->is_guest = (int)$this->context->customer->is_guest;
                $cart->id_carrier = (int)$dss_cart->id_carrier;
                if (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=')) {
                    $cart->delivery_option = json_encode(array($dss_cart->id_address_delivery => $dss_cart->id_carrier .','));
                } else {
                    $cart->delivery_option = serialize(array($dss_cart->id_address_delivery => $dss_cart->id_carrier .','));
                }
                $cart->secure_key = $this->context->customer->secure_key;

                if ($cart->add()) {
                    /* add product to cart */
                    foreach ($dss_cart->cart['products'] as $cart_product) {
                        $id_product = (int)$cart_product['id_product'];
                        $id_product_attribute = (int)$cart_product['id_product_attribute'];
                        $quantity = (int)$cart_product['quantity'];

                        if (StockAvailable::getQuantityAvailableByProduct((int)$id_product, (int)$id_product_attribute) < (int)$quantity && in_array(StockAvailable::outOfStock($id_product), $check_out_of_stock)) {
                            if ($allowOrdersZeroQty) {
                                if (!is_null($cart_product['id_product_attribute'])) {
                                    Db::getInstance()->execute(
                                        'UPDATE `'._DB_PREFIX_.'stock_available`'."\n".
                                        'SET `quantity` = `quantity` + '.(int)$quantity."\n".
                                        'WHERE `id_product` = '.(int)$id_product.
                                        ' AND `id_product_attribute` = '.(int)$id_product_attribute.
                                        ' AND `id_shop` = '.(int)$id_shop
                                    );
                                    Db::getInstance()->execute(
                                        'UPDATE `'._DB_PREFIX_.'stock_available`'."\n".
                                        'SET `quantity` = `quantity` + '.(int)$quantity."\n".
                                        'WHERE `id_product` = '.(int)$id_product.'
                                        AND `id_product_attribute` = 0 AND `id_shop` = '.(int)$id_shop
                                    );
                                } else {
                                    Db::getInstance()->execute(
                                        'UPDATE `'._DB_PREFIX_.'stock_available`'."\n".
                                        'SET `quantity` = `quantity` + '.(int)$quantity."\n".
                                        'WHERE `id_product` = '.(int)$id_product.'
                                        AND `id_product_attribute` = 0 AND `id_shop` = '.(int)$id_shop
                                    );
                                }
                            } else {
                                $this->errors[] = sprintf($this->module->l('Quantity not available for product: %s', 'dropshipsystem'), (string)$cart_product['reference']);
                                break;
                            }
                        }

                        $updateQuantity = $cart->updateQty((int)$quantity, (int)$id_product, (int)$id_product_attribute);
                        if ((int)$updateQuantity < 0) {
                            $this->errors[] = sprintf($this->module->l('Minimal quantity not reached for %s', 'dropshipsystem'), (string)$cart_product['reference']);
                            break;
                        }
                    }
                } else {
                    DssEventsClass::setEvent('error', sprintf($this->module->l('Dropshipper id %s cannot add products to cart.', 'dropshipsystem'), $id_dropshipper));
                    $this->errors[] = $this->module->l('Error adding product to cart');
                }

                $total_shipping = (float)$cart->getOrderTotal(false, Cart::ONLY_SHIPPING);
                $total_tax_excl = $total_products_tax_excl + $total_shipping;
                $total_tax_incl = $total_products_tax_incl + (float)$cart->getOrderTotal(true, Cart::ONLY_SHIPPING);

                $previous_credit = (float)$dropshippers->credit;
                $daily_limit = (float)$dropshippers->daily_limit;
                $monthly_limit = (float)$dropshippers->monthly_limit;

                if ($daily_limit > 0) {
                    $daily_orders_total = DssOrderClass::getOrderTotalByPeriod($id_dropshipper, null, 'daily');

                    if (((float)$daily_orders_total['total'] + (float)$total_tax_excl) > (float)$daily_limit) {
                        DssEventsClass::setEvent('alert', sprintf($this->module->l('Daily order limit exceded for dropshipper id %s', 'dropshipsystem'), $id_dropshipper));
                        $this->errors[] = $this->module->l('Daily order limit exceded', 'dropshipsystem');
                    }
                }

                if ($monthly_limit > 0) {
                    $monthly_orders_total = DssOrderClass::getOrderTotalByPeriod($id_dropshipper, null, 'monthly');

                    if (((float)$monthly_orders_total['total'] + (float)$total_tax_excl) > (float)$monthly_limit) {
                        DssEventsClass::setEvent('alert', sprintf($this->module->l('Monthly order limit exceded for dropshipper id %s', 'dropshipsystem'), $id_dropshipper));
                        $this->errors[] = $this->module->l('Monthly order limit exceded', 'dropshipsystem');
                    }
                }

                $payment_desc = $this->module->l('Dropship');
                if ((string)$dropshippers->payment_type == 'none') {
                    $status = (int)Configuration::get('PS_OS_PAYMENT', null, null, $id_shop);
                } elseif ((string)$dropshippers->payment_type == 'prepayed') {
                    if ($total_tax_incl > $previous_credit) {
                        DssEventsClass::setEvent('alert', sprintf($this->module->l('Dropshipper id %s have insufficient funds for pay order.', 'dropshipsystem'), $id_dropshipper));
                        $this->errors[] = $this->module->l('Insufficient funds for order', 'dropshipsystem');
                    } else {
                        $status = (int)Configuration::get('PS_OS_PAYMENT', null, null, $id_shop);
                    }
                } elseif ((string)$dropshippers->payment_type == 'postpayed') {
                    $status = (int)Configuration::get('PS_OS_DROPSHIP', null, null, $id_shop);

                    $payclass = DssPaymentClass::getInstance();
                    $payres = $payclass->getAuth();
                    unset($payclass);

                    if (!$payres) {
                        DssEventsClass::setEvent('error', $this->module->l('Error with Payment Gateway account. Please check credentials.', 'dropshipsystem'));
                        $this->errors[] = $this->module->l('Error with Payment Gateway authentication', 'dropshipsystem');
                    }
                }

                if ($this->errors) {
                    return;
                }

                $mail_vars = array();

                $id_dss_order = 0;
                $payment = new DssPaymentClass();
                if (!$payment->validateDssOrder($product_list, $total_shipping, $total_shipping_extra_fee, $carrier_tax_rate, false, $cart->id, $status, $total_tax_incl, $order_reference, $payment_desc, null, $mail_vars, (int)$currency->id, false, $this->context->customer->secure_key, $dropshippers, $id_dss_order)) {
                    DssEventsClass::setEvent('error', sprintf($this->module->l('Error creating order with dropshipper id %s.', 'dropshipsystem'), $id_dropshipper));
                    $this->errors[] = $this->module->l('Error during create order', 'dropshipsystem');
                    return;
                } else {
                    if ((string)$dropshippers->payment_type == 'prepayed') {
                        if (!$dropshippers->addCredit(-$total_tax_incl)) {
                            $history = new OrderHistory();
                            $history->id_order = (int)$payment->currentOrder;
                            $history->changeIdOrderState((int)Configuration::get('PS_OS_ERROR', null, null, $id_shop), $history->id_order);
                            $history->addWithemail();
                            $history->save();

                            DssEventsClass::setEvent('error', sprintf($this->module->l('Error updating credit for dropshipper id %s. Order %s', 'dropshipsystem'), $id_dropshipper, $payment->reference));
                            $this->errors[] = $this->module->l('Error during set new credit', 'dropshipsystem');
                            return;
                        } else {
                            if ((float)$dropshippers->low_credit_threshold > 0 &&
                                (float)$dropshippers->credit < (float)$dropshippers->low_credit_threshold) {
                                $dss_payment_history = DssPaymentsHistoryClass::getLastPayment($this->context->customer->id);
                                $template_vars = array(
                                    '{threshold}' => Tools::displayPrice($dropshippers->low_credit_threshold, $currency),
                                    '{credit}' => Tools::displayPrice($dropshippers->credit, $currency),
                                    '{last_charge_credit}' => (isset($dss_payment_history['buyed_credit']) ? Tools::displayPrice($dss_payment_history['buyed_credit'], $dss_payment_history['currency']) : '-'),
                                    '{last_charge_date}' => (isset($dss_payment_history['request_date']) ? $dss_payment_history['request_date'] : '-'),
                                );
                                Mail::Send((int)$this->context->customer->id_lang, 'dss_low_credit', Mail::l('Low credit for your dropship account', (int)$this->context->customer->id_lang), $template_vars, $this->context->customer->email, $this->context->customer->firstname.' '.$this->context->customer->lastname, null, null, null, null, dirname(__FILE__).'/../../mails/');
                            }
                        }
                    }
                }

                if ($this->errors) {
                    return;
                }

                $order = new Order((int)$payment->currentOrder);

                $payment_link = '';
                $payment_gateway_link = '';
                if ((string)$dropshippers->payment_type == 'postpayed') {
                    $token = (string)DssPaymentsTokenClass::getToken();

                    $params = array(
                        'is_credit' => false,
                        'token' => (string)$token,
                        'id_order' => (int)$order->id,
                        'name' => (string)$order->reference,
                        'total' => (float)$total_tax_incl,
                        'custom_reference' => (string)$order->reference,
                        'return_url' => $this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount', array('action' => 'payment', 'response' => 'return'), true),
                        'cancel_url' => $this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount', array('action' => 'payment', 'response' => 'cancel'), true),
                    );

                    $payclass = DssPaymentClass::getInstance();
                    $payres = $payclass->getPaymentPage($params);
                    unset($payclass);

                    if ($payres['success']) {
                        $payment_link = 'http'.(Configuration::get('PS_SSL_ENABLED', null, null, $id_shop) ? 's' : '').'://'.
                                    Tools::getShopDomain(false, true).__PS_BASE_URI__.'ws?action=payment&ref='.$order->reference;
                        $payment_gateway_link = (string)$payres['paymentlink'];
                    } else {
                        if (is_array($payres['error'])) {
                            $this->errors = $payres['error'];
                        }

                        $order->setCurrentState((int)Configuration::get('PS_OS_ERROR', null, null, $id_shop));

                        DssEventsClass::setEvent('error', $this->module->l('Error retrive payment link for order', 'dropshipsystem'));
                        $this->errors[] = $this->module->l('Error retrive payment link', 'dropshipsystem');
                    }
                }

                if ($this->errors) {
                    return;
                }

                $dss_order = new DssOrderClass((int)$id_dss_order);
                $dss_order->id_order = (int)$order->id;
                $dss_order->id_dropshipper = (int)$id_dropshipper;
                $dss_order->id_shipping_address = (int)$dropshippers->id_address_delivery;
                $dss_order->id_billing_address = (int)$dropshippers->id_address_invoice;
                $dss_order->shipping_method = (int)$dss_cart->id_carrier;
                $dss_order->payment_type = (string)$dropshippers->payment_type;
                $dss_order->total = (float)$total_tax_incl;
                $dss_order->previous_credit = (float)$previous_credit;
                $dss_order->current_credit = (float)$previous_credit - (float)$total_tax_incl;
                $dss_order->payment_link = (string)$payment_link;
                $dss_order->payment_gateway_link = (string)$payment_gateway_link;

                if ($dss_order->update()) {
                    $dropshippers->increaseOrder();
                    $dropshippers->setLastOrderDate();
                }

                $dss_cart->deleteCart($id_dropshipper);

                Tools::redirect($this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount', array('action' => 'neworder', 'page' => 'confirm', 'id_order' => (int)$order->id)));
            } else {
                Tools::redirect($this->context->link->getPageLink('my-account'));
            }
        }
    }

    private function makeSecret()
    {
        $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
        $pass = array();
        $charslen = Tools::strlen($chars) - 1;
        for ($i = 0; $i < 32; $i++) {
            $n = rand(0, $charslen);
            $pass[] = $chars[$n];
        }
        return implode($pass);
    }

    public function ajaxProcessGetCart()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
        if ($id_dropshipper) {
            //$dropshipper = new DssDropshippersClass($id_dropshipper);

            $dss_cart = new DssCartClass();
            $cart = $dss_cart->getCart($id_dropshipper);
            unset($dss_cart);

            if (version_compare(_PS_VERSION_, '1.7', '<')) {
                $tpl = $this->context->smarty->createTemplate(
                    dirname(__FILE__).'/../../views/templates/front/order-form.tpl'
                );
                $tpl->assign(array(
                    'link' => $this->context->link,
                    'dss_cart' => $cart,
                    'static_token' => Tools::getToken(false),
                ));
                $res = array(
                    'success' => true,
                    'preview' => $tpl->fetch(),
                );
            } else {
                $res = array(
                    'success' => true,
                    'preview' => $this->render('../../../modules/dropshipsystem/views/templates/front/1.7/order-form', array(
                        'dss_cart' => $cart,
                        'static_token' => Tools::getToken(false),
                    ))
                );
            }
        } else {
            $res = array(
                'success' => false,
                'error' => $this->module->l('No Dropshipper profile', 'dropshipsystem')
            );
        }

        die(Tools::jsonEncode($res));
    }

    public function ajaxProcessSearchProduct()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
        if ($id_dropshipper) {
            $query = trim((string)Tools::getValue('query'));

            $dss_cart = new DssCartClass();
            $results = $dss_cart->searchProduct($id_dropshipper, $query);
            unset($dss_cart);

            if (version_compare(_PS_VERSION_, '1.7', '<')) {
                $tpl = $this->context->smarty->createTemplate(
                    dirname(__FILE__).'/../../views/templates/front/search-result.tpl'
                );
                $tpl->assign(array(
                    'results' => $results,
                    'link' => $this->context->link,
                    'static_token' => Tools::getToken(false),
                ));
                $res = array(
                    'success' => true,
                    'preview' => $tpl->fetch(),
                );
            } else {
                $res = array(
                    'success' => true,
                    'preview' => $this->render('../../../modules/dropshipsystem/views/templates/front/1.7/search-result', array(
                        'results' => $results,
                        'static_token' => Tools::getToken(false),
                    ))
                );
            }
        } else {
            $res = array(
                'success' => false,
                'error' => $this->module->l('No Dropshipper profile', 'dropshipsystem')
            );
        }

        die(Tools::jsonEncode($res));
    }

    public function ajaxProcessGetVariants()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_lang = $this->context->language->id;
        $id_product = (int)Tools::getValue('id_product');
        $product = new Product($id_product, true, $id_lang);

        $groups = array();
        $attributes_groups = $product->getAttributesGroups($id_lang);
        if (is_array($attributes_groups) && $attributes_groups) {
            foreach ($attributes_groups as $k => $row) {
                if (!isset($groups[$row['id_attribute_group']])) {
                    $groups[$row['id_attribute_group']] = array(
                        'name' => (string)$row['public_group_name'],
                        'group_name' => (string)$row['group_name'],
                        'group_type' => (string)$row['group_type'],
                        'is_color_group' => (int)$row['is_color_group'],
                        'default' => -1,
                    );
                }
                $groups[$row['id_attribute_group']]['attributes'][$row['id_attribute']] = array(
                    'name' => (string)$row['attribute_name'],
                    'html_color_code' => $row['attribute_color'],
                    'texture' => null,
                    'selected' => ((int)$row['default_on'] == 1 ? true : false)
                );
                if ($row['default_on'] && $groups[$row['id_attribute_group']]['default'] == -1) {
                    $groups[$row['id_attribute_group']]['default'] = (int)$row['id_attribute'];
                }
                if (!isset($groups[$row['id_attribute_group']]['attributes_quantity'][$row['id_attribute']])) {
                    $groups[$row['id_attribute_group']]['attributes_quantity'][$row['id_attribute']] = 0;
                }
                $groups[$row['id_attribute_group']]['attributes_quantity'][$row['id_attribute']] += (int)$row['quantity'];
            }
        }

        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            $tpl = $this->context->smarty->createTemplate(
                dirname(__FILE__).'/../../views/templates/front/variants.tpl'
            );
            $tpl->assign(array(
                'groups' => $groups,
                'img_col_dir' => _PS_COL_IMG_DIR_,
                'img_col_uri' => _PS_IMG_.'co/',
                'link' => $this->context->link,
                'static_token' => Tools::getToken(false),
            ));
            $res = array(
                'success' => true,
                'preview' => $tpl->fetch(),
            );
        } else {
            $res = array(
                'success' => true,
                'preview' => $this->render('../../../modules/dropshipsystem/views/templates/front/1.7/variants', array(
                    'groups' => $groups,
                    'static_token' => Tools::getToken(false),
                ))
            );
        }

        die(Tools::jsonEncode($res));
    }

    public function ajaxProcessGetProductAttribute()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        //$id_shop = (int)$this->context->shop->id;
        $id_lang = (int)$this->context->language->id;

        $id_product = (int)Tools::getValue('id_product');
        $product_quantity = (int)Tools::getValue('product_quantity');
        $query = Tools::getValue('query');

        parse_str($query, $get);
        $group = $get['group'];

        $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
        if ($id_dropshipper) {
            $dropshipper = new DssDropshippersClass($id_dropshipper);
            $address = new Address($dropshipper->id_address_invoice);
            $dropshipper->id_country = (int)$address->id_country;
            unset($address);

            $id_product_attribute = (int)DssClass::getIdProductAttributesByIdAttributes(
                $id_product,
                $group
            );

            $product = array(
                'id_product' => (int)$id_product,
                'id_product_attribute' => (int)$id_product_attribute,
                'quantity' => (int)$product_quantity
            );

            $dss_cart = new DssCartClass();
            $res = $dss_cart->getProduct($product, $dropshipper, $id_lang, $this->context->customer->id_default_group);
            $product_price = (float)$res['price'];

            $res = array(
                'success' => true,
                'id_product_attribute' => $id_product_attribute,
                'price' => (float)$product_price,
                'formatted_price' => Tools::displayPrice($product_price),
                'total' => (float)($product_price * $product_quantity),
                'formatted_total' => Tools::displayPrice($product_price * $product_quantity)
            );
        } else {
            $res = array(
                'success' => false,
                'error' => $this->module->l('No Dropshipper profile', 'dropshipsystem')
            );
        }

        die(Tools::jsonEncode($res));
    }

    public function ajaxProcessGetPrices()
    {
        $product_price = (float)Tools::getValue('product_price');
        $product_quantity = (int)Tools::getValue('product_quantity');
        $update = (bool)Tools::getValue('update');

        if ($update) {
            $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
            if ($id_dropshipper) {
                $id_product = (int)Tools::getValue('id_product');
                $id_product_attribute = (int)Tools::getValue('id_product_attribute');
                if ($product_quantity > 0) {
                    $dss_cart = new DssCartClass();
                    $ret = $dss_cart->updateCart('update', $id_dropshipper, array(
                        'id_product' => $id_product,
                        'id_product_attribute' => $id_product_attribute,
                        'product_price' => $product_price,
                        'product_quantity' => $product_quantity));
                    unset($dss_cart);
                    if (!$ret) {
                        die(Tools::jsonEncode(array(
                            'success' => false,
                            'error' => $this->module->l('Error updating cart', 'dropshipsystem')
                        )));
                    }
                } else {
                    die(Tools::jsonEncode(array(
                        'success' => false,
                        'error' => $this->module->l('Invalid quantity', 'dropshipsystem')
                    )));
                }
            } else {
                die(Tools::jsonEncode(array(
                    'success' => false,
                    'error' => $this->module->l('No Dropshipper profile', 'dropshipsystem')
                )));
            }
        }

        $res = array(
            'success' => true,
            'price' => (float)$product_price,
            'formatted_price' => Tools::displayPrice($product_price),
            'total' => (float)($product_price * $product_quantity),
            'formatted_total' => Tools::displayPrice($product_price * $product_quantity)
        );

        die(Tools::jsonEncode($res));
    }

    public function ajaxProcessSetCarrier()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
        if ($id_dropshipper) {
            $id_carrier = (int)Tools::getValue('id_carrier');

            $dss_cart = new DssCartClass();
            $ret = $dss_cart->updateCart('set_carrier', $id_dropshipper, array('id_carrier' => (int)$id_carrier));
            unset($dss_cart);

            if (!$ret) {
                $res = array(
                    'success' => false,
                    'error' => $this->module->l('Error updating carrier', 'dropshipsystem')
                );
            } else {
                $res = array(
                    'success' => true,
                );
            }
        } else {
            $res = array(
                'success' => false,
                'error' => $this->module->l('No Dropshipper profile', 'dropshipsystem')
            );
        }

        die(Tools::jsonEncode($res));
    }

    public function ajaxProcessGetTotals()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
        if ($id_dropshipper) {
            $dss_cart = new DssCartClass();
            $cart = $dss_cart->getCart($id_dropshipper);
            unset($dss_cart);

            $res = array(
                'success' => true,
                'dss_cart' => $cart
            );
        } else {
            $res = array(
                'success' => false,
                'error' => $this->module->l('No Dropshipper profile', 'dropshipsystem')
            );
        }

        die(Tools::jsonEncode($res));
    }

    public function ajaxProcessAddProductToCart()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_lang = $this->context->language->id;

        $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
        if ($id_dropshipper) {
            $group = null;
            $query = null;
            $id_product_attribute = 0;
            //$dropshipper = new DssDropshippersClass($id_dropshipper);
            if (Tools::getIsset('query')) {
                $query = (string)Tools::getValue('query');
                parse_str($query, $get);
                $id_product = (int)$get['id_product'];
                $group = isset($get['group']) ? $get['group'] : null;
            } else {
                $id_product = (int)Tools::getValue('id_product');
            }
            if (Tools::getIsset('id_product_attribute')) {
                $id_product_attribute = (int)Tools::getValue('id_product_attribute');
            } elseif (isset($group)) {
                $id_product_attribute = (int)Product::getIdProductAttributesByIdAttributes(
                    $id_product,
                    $group
                );
            }
            $product_price = (float)Tools::getValue('product_price');
            $product_quantity = (int)Tools::getValue('product_quantity');

            if ($id_product == 0) {
                die(Tools::jsonEncode(array(
                    'success' => false,
                    'error' => $this->module->l('Invalid product', 'dropshipsystem')
                )));
            }

            if ($product_quantity < 1) {
                die(Tools::jsonEncode(array(
                    'success' => false,
                    'error' => $this->module->l('Invalid quantity', 'dropshipsystem')
                )));
            }

            $product = new Product((int)$id_product, true, $id_lang);
            $image = Product::getCover((int)$id_product);
            if (version_compare(_PS_VERSION_, '1.7', '<')) {
                $image_url = $this->context->link->getImageLink((string)$product->link_rewrite[$id_lang], (int)$image['id_image'], ImageType::getFormatedName('large'));
            } else {
                $image_url = $this->context->link->getImageLink((string)$product->link_rewrite[$id_lang], (int)$image['id_image'], ImageType::getFormattedName('large'));
            }

            if (!$id_product_attribute && $product->hasAttributes()) {
                $minimum_quantity = $product->out_of_stock == 2 ? !Configuration::get('PS_ORDER_OUT_OF_STOCK') : !$product->out_of_stock;
                $id_product_attribute = (int)Product::getDefaultAttribute($product->id, $minimum_quantity);
            }

            $dss_cart = new DssCartClass();
            $ret = $dss_cart->updateCart('add', $id_dropshipper, array(
                'id_product' => $id_product,
                'id_product_attribute' => $id_product_attribute,
                'product_price' => $product_price,
                'product_quantity' => $product_quantity));
            $cart = $dss_cart->getCart($id_dropshipper);
            unset($dss_cart);

            $combinations = $product->getAttributeCombinationsById((int)$id_product_attribute, $id_lang);

            if ($ret) {
                $res = array(
                    'success' => true,
                    'dss_cart' => array(
                        'count' => sprintf($this->module->l('There are %d items in your dropship cart.', 'dropshipsystem'), 1),
                        'formatted_total' => (string)Tools::displayPrice((float)$cart['totals']['formatted_subtotal']),
                    ),
                    'product' => array(
                        'name' => $product->name,
                        'image_url' => (string)$image_url,
                        'price' => (string)Tools::displayPrice((float)$product_price),
                        'combinations' => $combinations
                    )
                );
            } else {
                $res = array(
                    'success' => false,
                    'error' => $this->module->l('Error adding product', 'dropshipsystem')
                );
            }
        } else {
            $res = array(
                'success' => false,
                'error' => $this->module->l('No Dropshipper profile', 'dropshipsystem')
            );
        }

        die(Tools::jsonEncode($res));
    }

    public function ajaxProcessRemoveProductFromCart()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
        if ($id_dropshipper) {
            $id_product = Tools::getValue('id_product');
            $id_product_attribute = (int)Tools::getValue('id_product_attribute');

            $dss_cart = new DssCartClass();
            $ret = $dss_cart->updateCart('remove', $id_dropshipper, array(
                'id_product' => $id_product,
                'id_product_attribute' => $id_product_attribute));
            unset($dss_cart);

            if ($ret) {
                $res = array(
                    'success' => true,
                );
            } else {
                $res = array(
                    'success' => false,
                    'error' => $this->module->l('Error removing product', 'dropshipsystem')
                );
            }
        } else {
            $res = array(
                'success' => false,
                'error' => $this->module->l('No Dropshipper profile', 'dropshipsystem')
            );
        }

        die(Tools::jsonEncode($res));
    }
}
