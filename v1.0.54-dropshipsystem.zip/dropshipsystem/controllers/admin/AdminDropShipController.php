<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminDropShipController extends ModuleAdminController
{
    //public $asso_type = 'shop';
    public $instant_search;
    public $ajax_search;

    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'dss_dropshipper';
        $this->className = 'DssDropshippersClass';
        $this->lang = false;
        $this->explicitSelect = true;
        $this->allow_export = true;
        //$this->multishop_context = Shop::CONTEXT_ALL;

        parent::__construct();

        $this->context = Context::getContext();

        $this->default_form_language = $this->context->language->id;
        $id_shop = (int)$this->context->shop->id;

        $this->_select = 'COALESCE(c.company, CONCAT(c.lastname, \' \', c.firstname)) AS dropshipper';
        $this->_join = 'LEFT JOIN '._DB_PREFIX_.'customer c ON a.id_customer = c.id_customer';
        if (Shop::isFeatureActive()) {
            $this->_where = 'AND a.id_shop = '.(int)$id_shop;
        }
        $this->_defaultOrderBy = 'a.id_dss_dropshipper';
        $this->_defaultOrderWay = 'DESC';
        $this->_use_found_rows = false;

        $this->fields_list = array(
            'id_dss_dropshipper' => array(
                'title' => $this->l('Id'),
                'type' => 'text',
                'class' => 'fixed-width-sm',
                'orderby' => true,
                'havingFilter' => true,
            ),
            'dropshipper' => array(
                'title' => $this->l('Dropshipper'),
                'type' => 'text',
                'orderby' => true,
                'havingFilter' => true,
            ),
            'feed_type' => array(
                'title' => $this->l('Secondary site'),
                'type' => 'bool',
                'align' => 'center',
                'class' => 'fixed-width-xs',
                'active' => 'feed',
                'ajax' => true,
                'orderby' => true,
                'havingFilter' => true,
                'filter_key' => 'a!feed_type'
            ),
            'active' => array(
                'title' => $this->l('Active'),
                'type' => 'bool',
                'align' => 'text-center',
                'class' => 'fixed-width-xs',
                'active' => 'active',
                'ajax' => true,
                'orderby' => true,
                'havingFilter' => true,
                'filter_key' => 'a!active'
            ),
            'credit' => array(
                'title' => $this->l('Credit'),
                'type' => 'text',
                'align' => 'text-center',
                'class' => 'fixed-width-xs',
                'orderby' => true,
                'havingFilter' => false,
            ),
            'wholesale_reduction' => array(
                'title' => $this->l('Wholesale %'),
                'type' => 'text',
                'align' => 'text-center',
                'class' => 'fixed-width-xs',
                'orderby' => true,
                'havingFilter' => false,
            ),
            'reduction' => array(
                'title' => $this->l('Sell %'),
                'type' => 'text',
                'align' => 'text-center',
                'class' => 'fixed-width-xs',
                'orderby' => true,
                'havingFilter' => false,
            ),
            'orders' => array(
                'title' => $this->l('Orders'),
                'type' => 'text',
                'align' => 'text-center',
                'class' => 'fixed-width-xs',
                'orderby' => true,
                'havingFilter' => false,
            ),
            'last_order' => array(
                'title' => $this->l('Last Order'),
                'type' => 'datetime',
                'align' => 'text-right',
            ),
            'last_connection' => array(
                'title' => $this->l('Last Connection'),
                'type' => 'datetime',
                'align' => 'text-right',
            )
        );

        $this->bulk_actions = array(
            'delete' => array(
                'text' => $this->l('Delete selected'),
                'confirm' => $this->l('Delete selected items?'),
                'icon' => 'icon-trash'
            )
        );
        //$this->specificConfirmDelete = false;
    }

    public function initPageHeaderToolbar()
    {
        if (empty($this->display)) {
            $this->page_header_toolbar_btn['new'] = array(
                'href' => self::$currentIndex.'&adddss_dropshipper&token='.$this->token,
                'desc' => $this->l('Add New Dropshipper', null, null, false),
                'icon' => 'process-icon-new'
            );
        } elseif ($this->display == 'edit') {
            $this->page_header_toolbar_btn['credit_history'] = array(
                'href' => $this->context->link->getAdminLink('AdminDropShipCreditHistory').'&id_dss_dropshipper='.Tools::getValue('id_dss_dropshipper'),
                'desc' => $this->l('Show Credit History', null, null, false),
                'icon' => 'process-icon-stats'
            );
        }

        parent::initPageHeaderToolbar();
    }

    public function init()
    {
        parent::init();

        $this->ajax_search = Tools::getValue('ajaxSearch');

        $action = Tools::getValue('action');

        if (Tools::getValue('ajax') && method_exists($this, 'ajaxProcess'.Tools::toCamelCase($action))) {
            $this->{'ajaxProcess'.Tools::toCamelCase($action)}();
        } else {
            $original_query = Tools::getValue('q');
            if ($original_query) {
                $query = Tools::replaceAccentedChars(urldecode($original_query));
                if ($this->ajax_search) {
                    $searchResults = $this->getCustomers($query);
                    $this->ajaxDie(Tools::jsonEncode($searchResults));
                }
            }
        }
    }

    public function setMedia($isNewTheme = false)
    {
        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            parent::setMedia();
        } else {
            parent::setMedia($isNewTheme);
        }
        $this->context->controller->addJqueryPlugin('autocomplete');
        $this->addJS(_MODULE_DIR_.$this->module->name.'/views/js/jquery-confirm.js');
        $this->addJS(_MODULE_DIR_.$this->module->name.'/views/js/customer.js');
        $this->addCSS(_MODULE_DIR_.$this->module->name.'/views/css/jquery-confirm.css');
    }

    public function renderList()
    {
        $this->initToolbar();
        //$this->addRowAction('view');
        $this->addRowAction('edit');
        $this->addRowAction('credithistory');
        $this->addRowAction('delete');
        return parent::renderList();
    }

    public function displayCreditHistoryLink($token, $id, $name = null)
    {
        $tpl = $this->createTemplate('helpers/list/list_action_credithistory.tpl');
        if (!array_key_exists('credithistory', self::$cache_lang)) {
            self::$cache_lang['credithistory'] = $this->l('Credit History', 'Helper');
        }

        $tpl->assign(array(
            'href' => $this->context->link->getAdminLink('AdminDropShipCreditHistory').'&'.$this->identifier.'='.$id.'&back='.$this->context->link->getAdminLink('AdminDropShip', false),
            'action' => self::$cache_lang['credithistory'],
            'id' => $id,
            'token' => $token,
            'name' => $name
        ));

        return $tpl->fetch();
    }

    public function postProcess()
    {
        $dss = new DssDropshippersClass();
        $id_shop = (int)$this->context->shop->id;
        if (Tools::isSubmit('deletedss_dropshipper') && Tools::getValue('id_'.$this->table) != '') {
            $dss = new $dss((int)Tools::getValue('id_'.$this->table));

            if (!$dss->delete()) {
                $this->errors[] = Tools::displayError('An error occurred while deleting the object.')
                    .' <b>'.$this->table.' ('.Db::getInstance()->getMsgError().')</b>';
            } else {
                //Hook::exec('actionsbdeletepost', array('DropShip' => $dss));
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminDropShip'));
            }
        } elseif (Tools::isSubmit('status'.$this->table)) {
            $id_dss_dropshipper = (int)Tools::getValue('id_'.$this->table);
            if ($this->tabAccess['edit'] === '1') {
                $dss = new $dss($id_dss_dropshipper);
                if (!Validate::isLoadedObject($dss)) {
                    $this->errors[] = Tools::displayError('An error occurred while updating dropshipper information.');
                }
                $dss->active = $dss->active ? 0 : 1;
                if (!$dss->update()) {
                    $this->errors[] = Tools::displayError('An error occurred while updating dropshipper information.');
                }
                Tools::redirectAdmin(self::$currentIndex.'&conf=6&token='.$this->token);
            } else {
                $this->errors[] = Tools::displayError('You do not have permission to edit this.');
            }
        } elseif (Tools::isSubmit('submitAdd'.$this->table)) {
            $this->validateRules();
            $dss = $this->loadObject(true);
            if (!Validate::isLoadedObject($dss)) {
                $dss = new $dss();
                //$this->errors[] = Tools::displayError('An error occurred while updating the status for an object.').' <b>'.$this->table.'</b> '.Tools::displayError('(cannot load object)');
                //return;
            }

            if (!count($this->errors)) {
                if ((float)$dss->credit != (float)Tools::getValue('credit')) {
                    $currency = new Currency(Configuration::get('PS_CURRENCY_DEFAULT', null, null, $id_shop));
                    $custom_token = Tools::strtoupper(Tools::substr(sha1(uniqid(rand(), true)._COOKIE_KEY_.$dss->id_customer), 0, 32));

                    $dssph = new DssPaymentsHistoryClass();
                    $dssph->id_customer = (int)$dss->id_customer;
                    $dssph->id_operator = (int)$this->context->employee->id;
                    $dssph->request_date = date('Y-m-d H:i:s');
                    $dssph->status = 'accepted';
                    $dssph->currency = (string)$currency->iso_code;
                    $dssph->previous_credit = (float)$dss->credit;
                    $dssph->id_product = 0;
                    $dssph->buyed_credit = 0;
                    $dssph->current_credit = (float)Tools::getValue('credit');
                    $dssph->id_invoice = 0;
                    $dssph->id_order = 0;
                    $dssph->token = $custom_token;

                    if (!$dssph->add()) {
                        $this->errors[] = Tools::displayError('An error occurred adding Payment history information.');
                    }
                }

                if (!count($this->errors)) {
                    $this->copyFromPost($dss, $this->table);

                    if ($dss->feed_type && ($dss->simple_feed || $dss->payment_type != 'none')) {
                        $dss->simple_feed = 0;
                        $dss->direct_order = 0;
                        $dss->payment_type = 'none';
                    }

                    if (Tools::strlen(trim($dss->allowed_domains)) > 0) {
                        $dss->allowed_domains = serialize(explode("\r\n", trim($dss->allowed_domains)));
                    } else {
                        $dss->allowed_domains = '';
                    }

                    if (Tools::getValue('allowed_time_from') != '-1' && Tools::getValue('allowed_time_to') != '-1') {
                        $dss->allowed_time = serialize(
                            array(
                                Tools::getValue('allowed_time_from'),
                                Tools::getValue('allowed_time_to')
                            )
                        );
                    } else {
                        $dss->allowed_time = '';
                    }

                    if (!Validate::isDate($dss->date_end)) {
                        $dss->date_end = null;
                    }

                    if (is_callable(array('Tools', 'changeFileMTime'))) {
                        Tools::changeFileMTime($this->module->push_filename);
                    }

                    if ($dss->id) {
                        if (!$dss->update()) {
                            $this->errors[] = Tools::displayError('An error occurred while updating an object.').' <b>'.$this->table.' ('.Db::getInstance()->getMsgError().')</b>';
                        } else {
                            Tools::redirectAdmin($this->context->link->getAdminLink('AdminDropShip').'&conf=4&id_'.$this->table.'='.$dss->id.'&update'.$this->table.'&token='.$this->token);
                        }
                    } else {
                        if (!$dss->save()) {
                            $this->errors[] = Tools::displayError('An error occurred while save an object.').' <b>'.$this->table.' ('.Db::getInstance()->getMsgError().')</b>';
                        }
                    }
                }
            }
        } elseif (Tools::isSubmit($this->table.'Orderby')&& Tools::isSubmit($this->table.'Orderway')) {
            $this->_defaultOrderBy = Tools::getValue($this->table.'Orderby');
            $this->_defaultOrderWay = Tools::getValue($this->table.'Orderway');
        }
        //parent::postProcess();
    }

    public function renderForm()
    {
        if (!($dss = $this->loadObject(true))) {
            return;
        }

        $id_shop = (int)$this->context->shop->id;

        if (!$dss->id_customer && Tools::getIsset('id_customer') && Tools::getIsset('add'.$this->table)) {
            $id_customer = Tools::getValue('id_customer');
            if ($id_customer > 0) {
                $dss->id_customer = (int)$id_customer;
            }
        }

        $customers = array();
        $pscustomer = $this->getCustomers(null, $dss->id_customer);
        foreach ($pscustomer as $pscustomer) {
            $customers[] = array('id' => $pscustomer['id_customer'], 'name' => $pscustomer['name']);
        }

        $taxes = array();
        $pstaxes = Tax::getTaxes((int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop));
        foreach ($pstaxes as $tax) {
            $taxes[] = array('id' => $tax['rate'], 'name' => $tax['name']);
        }

        $operators = array();
        $psoperators = Employee::getEmployees(false);
        foreach ($psoperators as $operator) {
            $operators[] = array('id' => $operator['id_employee'], 'name' => $operator['firstname'].' '.$operator['lastname']);
        }

        $addresses = array();
        $customer = new Customer($dss->id_customer);
        $psaddress = $customer->getAddresses($this->context->language->id);
        foreach ($psaddress as $address) {
            if ($address['active'] && !$address['deleted']) {
                $addresses[] = array('id' => $address['id_address'], 'name' => $address['alias']);
            }
        }

        $payment_gateways = array();
        $dsspayment_gateways = unserialize(Configuration::get('DSS_PAYMENT_GATEWAYS', null, null, $id_shop));
        $payment_gateways[] = array('id' => '', 'name' => $this->l('-- Default --'));
        foreach ($dsspayment_gateways as $paymentgateway) {
            $payment_gateways[] = array('id' => $paymentgateway['id'], 'name' => $paymentgateway['name']);
        }

        if ($dss->id_customer) {
            if ($dss->allowed_domains) {
                $dss->allowed_domains = implode("\r\n", unserialize($dss->allowed_domains));
            }
            if ($dss->allowed_time) {
                $dss->allowed_time = unserialize($dss->allowed_time);
            }
        }

        $timerange = array();
        for ($i = 0; $i < 24; $i++) {
            $time = $i * 3600;
            $dt = new DateTime('now', new DateTimeZone('UTC'));
            $dt->setTimestamp($time);
            $timerange[] = array('id' => $time, 'name' => $dt->format('H:i'));
        }
        $timerange[] = array('id' => '86400', 'name' => '24:00');

        $this->fields_form = array(
            'legend' => array(
                'title' => $this->l('Dropshipper'),
            ),
            'input' => array(
                array(
                    'type' => 'hidden',
                    'name' => 'post_type',
                    'default_value' => 0,
                ),
                array(
                    'type' => 'hidden',
                    'name' => 'id_shop',
                    'default_value' => $id_shop,
                ),
                /*
                array(
                    'type' => 'hidden',
                    'name' => 'id_customer',
                    'default_value' => 0,
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Customer'),
                    'name' => 'customer',
                    'suffix' => '<i class="icon-search"></i>',
                    'class' => 'fixed-width-xxl ajax-customer-search',
                    'required' => true,
                    'desc' => $this->l('Customer'),
                ),
                */
                array(
                    'type' => 'select',
                    'label' => $this->l('Customer'),
                    'name' => 'id_customer',
                    'hint' => $this->l('Select the customer for dropshipper account.'),
                    'class' => 'chosen fixed-width-xxl',
                    'required' => true,
                    'options' => array(
                        'query' => $customers,
                        'id' => 'id',
                        'name' => 'name',
                        'default' => array(
                            'value' => 0,
                            'label' => '-- '.$this->l('Select one').' --'
                        )
                    ),
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Status'),
                    'name' => 'active',
                    'hint' => $this->l('Dropshipper status'),
                    'options' => array(
                        'query' => array(
                            array('id' => 2, 'name' => $this->l('New Profile')),
                            array('id' => 1, 'name' => $this->l('Enabled')),
                            array('id' => 0, 'name' => $this->l('Disabled')),
                        ),
                        'id' => 'id',
                        'name' => 'name'
                    )
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Commercial referrer'),
                    'name' => 'id_operator',
                    'hint' => $this->l('Select the commercial referrer for this customer.'),
                    'options' => array(
                        'query' => $operators,
                        'id' => 'id',
                        'name' => 'name',
                        'default' => array(
                            'value' => 0,
                            'label' => $this->l('Nobody')
                        )
                    ),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Secret key'),
                    'name' => 'secret',
                    'maxlength' => 32,
                    'prefix' => '<i class="icon-key"></i>',
                    'class' => 'fixed-width-xxl',
                    'required' => true,
                    'hint' => $this->l('This is the secret key used for client webservice connection'),
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Invoice address'),
                    'name' => 'id_address_invoice',
                    'hint' => $this->l('Invoice address.'),
                    'required' => true,
                    'options' => array(
                        'query' => $addresses,
                        'id' => 'id',
                        'name' => 'name',
                        'default' => array(
                            'value' => 0,
                            'label' => ''
                        )
                    ),
                ),
                /*array(
                    'type' => 'select',
                    'label' => $this->l('Delivery address'),
                    'name' => 'id_address_delivery',
                    'hint' => $this->l('Delivery address.'),
                    'options' => array(
                        'query' => $addresses,
                        'id' => 'id',
                        'name' => 'name',
                        'default' => array(
                            'value' => 0,
                            'label' => ''
                        )
                    ),
                ),*/
                array(
                    'type' => 'text',
                    'label' => $this->l('Contact name'),
                    'name' => 'contact_name',
                    'maxlength' => 255,
                    'class' => 'fixed-width-xxl',
                    'required' => true,
                    'hint' => $this->l('Contact name'),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Contact email'),
                    'name' => 'contact_email',
                    'maxlength' => 255,
                    'class' => 'fixed-width-xxl',
                    'required' => true,
                    'hint' => $this->l('Contact email'),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Contact phone'),
                    'name' => 'contact_phone',
                    'maxlength' => 64,
                    'class' => 'fixed-width-xl',
                    'hint' => $this->l('Contact phone'),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Contact mobile'),
                    'name' => 'contact_mobile',
                    'maxlength' => 64,
                    'class' => 'fixed-width-xl',
                    'hint' => $this->l('Contact mobile'),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Web site'),
                    'name' => 'website',
                    'maxlength' => 255,
                    'class' => 'fixed-width-xxl',
                    'required' => true,
                    'hint' => $this->l('Web site'),
                ),
                array(
                    'type' => 'date',
                    'label' => $this->l('Expiration date'),
                    'name' => 'date_end',
                    'hint' => $this->l('Expiration date'),
                    'size' => 10,
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Feed Type'),
                    'name' => 'feed_type',
                    'hint' => $this->l('Feed Type'),
                    'options' => array(
                        'query' => array(
                            array('id' => 0, 'name' => $this->l('Reseller (Dropshipper)')),
                            array('id' => 1, 'name' => $this->l('Secondary site')),
                        ),
                        'id' => 'id',
                        'name' => 'name'
                    )
                ),
                array(
                    'type' => 'switch',
                    'label' => $this->l('Mask product quantity'),
                    'name' => 'mask_quantity',
                    'class' => 't',
                    'is_bool' => true,
                    'hint' => $this->l('Available product quantities will be mask with quantity set in \'Mask real quantity\' field in global setting'),
                    'values' => array(
                        array(
                            'id' => 'mask_quantity_on',
                            'value' => 1,
                            'label' => $this->l('Enabled')
                        ),
                        array(
                            'id' => 'mask_quantity_off',
                            'value' => 0,
                            'label' => $this->l('Disabled')
                        )
                    ),
                ),
                array(
                    'type' => 'switch',
                    'label' => $this->l('Simple Feed'),
                    'name' => 'simple_feed',
                    'class' => 't',
                    'is_bool' => true,
                    'values' => array(
                        array(
                            'id' => 'simple_on',
                            'value' => 1,
                            'label' => $this->l('Enabled')
                        ),
                        array(
                            'id' => 'simple_off',
                            'value' => 0,
                            'label' => $this->l('Disabled')
                        )
                    ),
                ),
                array(
                    'type' => 'switch',
                    'label' => $this->l('Allow direct order'),
                    'name' => 'direct_order',
                    'class' => 't',
                    'is_bool' => true,
                    'values' => array(
                        array(
                            'id' => 'direct_order_on',
                            'value' => 1,
                            'label' => $this->l('Enabled')
                        ),
                        array(
                            'id' => 'direct_order_off',
                            'value' => 0,
                            'label' => $this->l('Disabled')
                        )
                    ),
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Payment type'),
                    'name' => 'payment_type',
                    'hint' => $this->l('Payment type'),
                    'options' => array(
                        'query' => array(
                            array('id' => 'none', 'name' => $this->l('None')),
                            array('id' => 'prepayed', 'name' => $this->l('Prepayed credit')),
                            array('id' => 'postpayed', 'name' => $this->l('Billed')),
                        ),
                        'id' => 'id',
                        'name' => 'name'
                    )
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Payment Method'),
                    'name' => 'payment_method',
                    'hint' => $this->l('Select the payment method'),
                    'options' => array(
                        'query' => $payment_gateways,
                        'id' => 'id',
                        'name' => 'name',
                    ),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Current credit'),
                    'name' => 'credit',
                    'prefix' => '€',
                    'class' => 'fixed-width-sm',
                    'hint' => $this->l('Current credit'),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Low credit threshold'),
                    'name' => 'low_credit_threshold',
                    'prefix' => '€',
                    'class' => 'fixed-width-sm',
                    'hint' => $this->l('Below this threshold, an email will be sent to the dropshipper. (0 is disabled)'),
                    'desc' => $this->l('Zero is disabled'),
                ),
                /*
                array(
                    'type' => 'select',
                    'label' => $this->l('Customer Tax'),
                    'name' => 'customer_tax_value',
                    'hint' => $this->l('Select the value of TAX of dropshipper customer.'),
                    'options' => array(
                        'query' => $taxes,
                        'id' => 'id',
                        'name' => 'name',
                        'default' => array(
                            'value' => -1,
                            'label' => $this->l('No Tax')
                        )
                    ),
                ),
                */
                array(
                    'type' => 'text',
                    'label' => $this->l('Wholesale Reduction / Charge'),
                    'name' => 'wholesale_reduction',
                    'prefix' => '%',
                    'class' => 'fixed-width-sm',
                    'hint' => $this->l('Wholesale Reduction / Charge'),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Reduction / Charge'),
                    'name' => 'reduction',
                    'prefix' => '%',
                    'class' => 'fixed-width-sm',
                    'hint' => $this->l('Reduction / Charge'),
                ),

                array(
                    'type' => 'text',
                    'label' => $this->l('Orders daily limit'),
                    'name' => 'daily_limit',
                    'prefix' => '€',
                    'class' => 'fixed-width-sm',
                    'hint' => $this->l('Orders daily limit. Set 0 to disable.'),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Orders monthly limit'),
                    'name' => 'monthly_limit',
                    'prefix' => '€',
                    'class' => 'fixed-width-sm',
                    'hint' => $this->l('Orders monthly limit. Set 0 to disable.'),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Min products prices order'),
                    'name' => 'min_product_price_order',
                    'prefix' => '€',
                    'class' => 'fixed-width-sm',
                    'hint' => $this->l('Set the minimum order products price value. Set 0 to disable.'),
                ),
                array(
                    'type' => 'timerange',
                    'label' => $this->l('Time table connection (API only)'),
                    'name' => 'allowed_time',
                    'hint' => $this->l('Write the allowed hours time range connection. Es: 8-16 to allow connections from 8 AM to 16 PM. Left blank to authorize connection at any time.'),
                    'options' => array(
                        'from' => array(
                            'query' => $timerange,
                            'id' => 'id',
                            'name' => 'name',
                            'default' => array(
                                'value' => '-1',
                                'label' => $this->l('Any')
                            )
                        ),
                        'to' => array(
                            'query' => $timerange,
                            'id' => 'id',
                            'name' => 'name',
                            'default' => array(
                                'value' => '-1',
                                'label' => $this->l('Any')
                            )
                        ),
                    )
                ),
                array(
                    'type' => 'textarea',
                    'label' => $this->l('Allowed domains (API only)'),
                    'name' => 'allowed_domains',
                    'class' => 'fixed-width-xl',
                    'rows' => 4,
                    'hint' => $this->l('Write the FQDN (Fully Qualified Domain Name) of the host authorized to connect with this account, one per line. Left blank to authorize all.'),
                ),
                array(
                    'type' => 'textarea',
                    'label' => $this->l('Notes'),
                    'name' => 'notes',
                    'rows' => 5,
                    'desc' => $this->l('Notes'),
                ),
            ),
            'submit' => array(
                'title' => $this->l('Save'),
                'class' => 'button btn btn-default pull-right'
            )
        );

        if ($dss->active == 2) {
            $fields_form = array_slice($this->fields_form, 0, 1, true) +
                array('warning' => $this->l('New profile! Please complete all mandatory fields and enable the account.')) +
                array_slice($this->fields_form, 1, count($this->fields_form) - 1, true);
            $this->fields_form = $fields_form;
        }

//        if (Shop::isFeatureActive()) {
//            $this->fields_form['input'][] = array(
//                'type' => 'shop',
//                'label' => $this->l('Shop association:'),
//                'name' => 'checkBoxShopAsso',
//            );
//        }

        //$dss->customer = $this->getCustomerNameById((int)$dss->id_customer);
        $this->fields_value = array(
            'id_dss_dropshipper' => $dss->id,
            'allowed_time_from' => $dss->allowed_time ? $dss->allowed_time[0] : '-1',
            'allowed_time_to' => $dss->allowed_time ? $dss->allowed_time[1] : '-1',
            //'customer' => $dss->customer,
        );

        $this->context->smarty->assign(array(
            'dss_ajaxurl' => $this->context->link->getAdminLink('AdminDropShip'),
            'dss_token' => Tools::getAdminTokenLite('AdminCustomers'),
        ));
        $js = $this->context->smarty->fetch(dirname(__FILE__).'/../../views/templates/admin/drop_ship/vars.tpl');

        return parent::renderForm().$js;
    }

    private function getCustomers($query = null, $id_customer = null)
    {
        $sql = 'SELECT `c`.`id_customer`, CONCAT(\'(ID: \', `c`.`id_customer`, \') \', COALESCE(`c`.`company`, CONCAT(`c`.`lastname`, \' \', `c`.`firstname`))) AS `name`
                FROM `'._DB_PREFIX_.'customer` `c`
                WHERE `c`.`id_customer` NOT IN (SELECT `dssd`.`id_customer` FROM `'._DB_PREFIX_.'dss_dropshipper` `dssd` ';
        if (isset($id_customer)) {
            $sql .= 'WHERE `dssd`.`id_customer` <> '.(int)$id_customer.Shop::addSqlRestrictionOnLang('dssd').') ';
        } else {
            $sql .= 'WHERE 1'.Shop::addSqlRestrictionOnLang('dssd').') ';
        }
        $sql .= Shop::addSqlRestrictionOnLang('c');
        if (isset($query)) {
            $sql .= ' AND (`c`.`company` LIKE \'%'.pSQL($query).'%\'
                    OR `c`.`firstname` LIKE \'%'.pSQL($query).'%\'
                    OR `c`.`lastname` LIKE \'%'.pSQL($query).'%\')';
        }
        $sql .= ' ORDER BY `name`';

        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql, true, false);
    }

    private function getCustomerNameById($id_customer)
    {
        $res = Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow('
                SELECT COALESCE(`c`.`company`, CONCAT(`c`.`lastname`, \' \', `c`.`firstname`)) AS name
                FROM `'._DB_PREFIX_.'customer` `c` 
                WHERE `c`.`id_customer` = '.(int)$id_customer);

        return $res ? $res['name'] : '';
    }

    public function ajaxProcessFeedDssDropshipper()
    {
        if (!$id_dss_dropshipper = (int)Tools::getValue('id_dss_dropshipper')) {
            die(Tools::jsonEncode(array('success' => false, 'error' => true, 'text' => $this->l('Failed to update the dropshipper feed type'))));
        } else {
            $dss = new DssDropshippersClass((int)$id_dss_dropshipper);
            if (Validate::isLoadedObject($dss)) {
                if ($dss->feed_type) {
                    $dss->feed_type = 0;
                    $dss->simple_feed = 0;
                    $dss->direct_order = 0;
                    $dss->payment_type = 'none';
                } else {
                    $dss->feed_type = 1;
                }
                $dss->save() ?
                die(Tools::jsonEncode(array('success' => true, 'text' => $this->l('The dropshipper feed type has been updated successfully')))) :
                die(Tools::jsonEncode(array('success' => false, 'error' => true, 'text' => $this->l('Failed to update the dropshipper feed type'))));
            }
        }
    }

    public function ajaxProcessActiveDssDropshipper()
    {
        if (!$id_dss_dropshipper = (int)Tools::getValue('id_dss_dropshipper')) {
            die(Tools::jsonEncode(array('success' => false, 'error' => true, 'text' => $this->l('Failed to update the dropshipper status'))));
        } else {
            $dss = new DssDropshippersClass((int)$id_dss_dropshipper);
            if (Validate::isLoadedObject($dss)) {
                $dss->active = $dss->active == 1 ? 0 : 1;
                $dss->save() ?
                die(Tools::jsonEncode(array('success' => true, 'text' => $this->l('The dropshipper status has been updated successfully')))) :
                die(Tools::jsonEncode(array('success' => false, 'error' => true, 'text' => $this->l('Failed to update the dropshipper status'))));
            }
        }
    }

    public function ajaxProcessGetCustomerLink()
    {
        if (!$id_customer = (int)Tools::getValue('id_customer')) {
            die(Tools::jsonEncode(array('success' => false, 'error' => true, 'text' => $this->l('Failed to load the customer profile'))));
        } else {
            $id_dss_dropshipper = (int)Tools::getValue('id_customer');
            $url = $this->context->link->getAdminLink('AdminCustomers').'&id_customer='.(int)$id_customer.'&updatecustomer&back='.urlencode($this->context->link->getAdminLink('AdminDropShip').'&id_dss_dropshipper='.(int)$id_dss_dropshipper.'&updatedss_dropshipper');
            die(Tools::jsonEncode(array('success' => true, 'href' => $url)));
        }
    }
}
