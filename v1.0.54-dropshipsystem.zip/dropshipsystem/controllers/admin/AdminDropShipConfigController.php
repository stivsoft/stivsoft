<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminDropShipConfigController extends ModuleAdminController
{
    protected $html = '';
    public $errors = array();
    public $thumb_logo;
    public $extra_modules;

    protected $payment_gateways = array();

    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();

        $this->thumb_logo = Tools::getMediaServer($this->module->name).
            '/img/wsm_logo_'.(int)$this->context->shop->id.'.jpg';

        $this->conf_keys = array(
            'DSS_MAX_DAILY_CONNECTIONS',
            'DSS_CUSTOMER_MAILS',
            'DSS_ALLOW_ORDERS_ZERO_QTY',
            'DSS_REMOVE_DISABLED_PRODUCTS_FROM_FEED',
            'DSS_PRICES_VAT',
            'DSS_WHOLESALE_BASE_PRICE',
            'DSS_BASE_PRICE',
            'DSS_SHIPPING_METHOD_1',
            'DSS_SHIPPING_METHOD_2',
            'DSS_SHIPPING_METHOD_3',
            'DSS_MASK_REAL_QUANTITY_VALUE',
            'DSS_ENABLE_FASTSYNC',
            'DSS_DROPSHIPPERS_REGISTRATION',
            'DSS_NOTIFY_DROPSHIPPERS',
            'DSS_PAGE_TOS',
            'DSS_PAGE_PRIVACY',
            'DSS_DEFAULT_PAYMENT_GATEWAY',
            'DSS_BANKWIRE',
            'DSS_BANKWIRE_OWNER',
            'DSS_BANKWIRE_NAME',
            'DSS_BANKWIRE_IBAN',
            'DSS_BANKWIRE_SWIFT',
            'DSS_DOWNLOAD_BLOCK_ENABLE',
            'DSS_FILE_CATEGORIES_ENABLE',
            'DSS_FILE_PRODUCTS_ENABLE',
            'DSS_FILE_PRICELIST_ENABLE',
            'DSS_FILE_ALL_ENABLE',
            'DSS_AGREEMENT_FILE',
            'DSS_WSM_LOGO',
        );

        $this->payment_gateways = glob(_PS_MODULE_DIR_.'dropshipsystem/libs/payment_*');

        $payment_gateways = array();
        foreach ($this->payment_gateways as $payment_gateway) {
            $path_parts = pathinfo($payment_gateway);
            $class_name = $path_parts['filename'];

            require_once($payment_gateway);
            if (class_exists($class_name)) {
                $gateway = new $class_name();
                $this->conf_keys = array_merge($this->conf_keys, $gateway->getFieldsKeys());

                //if (isset($gateway->gateway_active) && $gateway->gateway_active) {
                    $payment_gateways[] = array('id' => (string)$class_name, 'name' => $gateway->gateway_name);
                //}
            }
        }
        Configuration::updateValue('DSS_PAYMENT_GATEWAYS', serialize($payment_gateways), false, null, $this->context->shop->id);

        $this->extra_modules = array('productextratabs', 'multifeatures');
    }

    public function initContent()
    {
        $action = Tools::getValue('action');

        if (Tools::getValue('ajax') && method_exists($this, 'ajaxProcess'.Tools::toCamelCase($action))) {
            $this->{'ajaxProcess'.Tools::toCamelCase($action)}();
        } else {
            if (!$this->module->active) {
                $this->content .= $this->module->displayError('This module is not active');
            } else {
                $this->initTabModuleList();
                $this->initToolbar();
                $this->initPageHeaderToolbar();
                $this->display = '';
                $this->content .= $this->renderForm();
            }
        }

        parent::initContent();
    }

    public function initPageHeaderToolbar()
    {
        parent::initPageHeaderToolbar();

        //$this->page_header_toolbar_btn['clear_cache'] = array(
        //    'href' => self::$currentIndex.'&token='.$this->token.'&empty_smarty_cache=1',
        //    'desc' => $this->l('Clear cache'),
        //    'icon' => 'process-icon-eraser'
        //);
    }

    public function setMedia($isNewTheme = false)
    {
        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            parent::setMedia();
        } else {
            parent::setMedia($isNewTheme);
        }
        //$this->addJquery();
        //$this->addJqueryPlugin('tagify');
        $this->addJS(_MODULE_DIR_.$this->module->name.'/views/js/jquery-confirm.js');
        $this->addJS(_MODULE_DIR_.$this->module->name.'/views/js/config.js');
        $this->addCSS(_MODULE_DIR_.$this->module->name.'/views/css/jquery-confirm.css');
        $this->addCSS(_MODULE_DIR_.$this->module->name.'/views/css/dss_admin.css');
    }

    public function postProcess()
    {
        if (_PS_MODE_DEMO_) {
            $this->errors[] = Tools::displayError('This functionality has been disabled.');
            return;
        }

        $id_shop = $this->context->shop->id;
        $id_lang = $this->context->language->id;

        if (Tools::isSubmit('submitRegistration')) {
            $reg_order = (string)Tools::getValue('DSS_REGISTRATION_ORDER');
            $reg_key = (string)Tools::getValue('DSS_REGISTRATION_KEY');

            if ($reg_order && $reg_key) {
                $reg = DssClass::checkRegistration($reg_order, $reg_key);
                $lic = (string)$reg['lic'];
                $exp = (string)$reg['exp'];

                if ($lic == 'valid') {
                    Configuration::updateValue('DSS_REGISTRATION_ORDER', (string)$reg_order);
                    Configuration::updateValue('DSS_REGISTRATION_KEY', (string)$reg_key);
                    Configuration::updateValue('DSS_REGISTRATION', 1);

                    $this->content .= $this->module->displayConfirmation($this->l('License installed successfully'));
                } elseif ($lic == 'invalid_domain') {
                    Configuration::updateValue('DSS_REGISTRATION', 0);
                    $this->errors[] = $this->l('Invalid domain for this license');
                } elseif ($lic == 'license_expired') {
                    Configuration::updateValue('DSS_REGISTRATION', 0);
                    $this->errors[] = sprintf($this->l('License expired on %s'), Tools::displayDate($exp, $id_lang));
                } elseif (!isset($lic) || $lic == 'invalid_license') {
                    Configuration::updateValue('DSS_REGISTRATION', 0);
                    $this->errors[] = $this->l('Invalid license');
                }
            } else {
                Configuration::updateValue('DSS_REGISTRATION', 0);
                $this->errors[] = $this->l('Invalid registration references');
            }

            return parent::postProcess();
        }

        if (Tools::isSubmit('submitRegistrationRetry')) {
            Configuration::updateValue('DSS_REGISTRATION', 0);
            return parent::postProcess();
        }

        if (Tools::isSubmit('submitDss') || Tools::isSubmit('submitDssAndMake')) {
            $ok = true;
            foreach ($this->conf_keys as $c) {
                if (Tools::getValue($c) !== false) {
                    if (is_array(Tools::getValue($c))) {
                        $ok &= Configuration::updateValue($c, implode(',', Tools::getValue($c)), false, null, $id_shop);
                    } else {
                        $ok &= Configuration::updateValue($c, Tools::getValue($c), false, null, $id_shop);
                    }
                }
            }

            $checkbox_options = array();
            foreach ($this->extra_modules as $mod) {
                $module = Module::getInstanceByName((string)$mod);
                if (Validate::isLoadedObject($module) && $module->active) {
                    if (Tools::getValue('DSS_ENABLE_THIRD_MODULES_'.(int)$module->id)) {
                        $checkbox_options[] = (int)$module->id;
                    }
                }
            }
            Configuration::updateValue('DSS_ENABLE_THIRD_MODULES', implode(',', $checkbox_options), false, null, $id_shop);

            /* upload payment plugins */
            if (isset($_FILES['DSS_UPLOAD_PLUGIN']) && isset($_FILES['DSS_UPLOAD_PLUGIN']['tmp_name']) && !empty($_FILES['DSS_UPLOAD_PLUGIN']['tmp_name'])) {
                $tmp_folder = _PS_MODULE_DIR_.'dropshipsystem/libs/tmp/';
                $file_ext = pathinfo($_FILES['DSS_UPLOAD_PLUGIN']['name'], PATHINFO_EXTENSION);
                if ($file_ext && Tools::strtolower($file_ext) == 'zip') {
                    $uploaded = false;

                    $this->recursiveDeleteOnDisk($tmp_folder);

                    if (!($tmpName = tempnam(_PS_MODULE_DIR_.'dropshipsystem/libs/', 'PLUGIN_')) || !move_uploaded_file($_FILES['DSS_UPLOAD_PLUGIN']['tmp_name'], $tmpName)) {
                        $ok = false;
                    }
                    if (file_exists($tmpName)) {
                        if (Tools::ZipExtract($tmpName, $tmp_folder)) {
                            $file = glob($tmp_folder.'payment_*');
                            $path_parts = pathinfo($file[0]);
                            $class_name = $path_parts['filename'];

                            if (class_exists($class_name)) {
                                $this->errors[] = $this->l('This plugin already exist');
                            } else {
                                if (Tools::ZipExtract($tmpName, _PS_MODULE_DIR_.'dropshipsystem/libs/')) {
                                    $uploaded = true;
                                }
                            }
                            $this->recursiveDeleteOnDisk($tmp_folder);
                        }
                    }
                    if (isset($tmpName)) {
                        @unlink($tmpName);
                    }
                    if ($uploaded) {
                        Tools::redirectAdmin($this->context->link->getAdminLink('AdminDropShipConfig'));
                    }
                } else {
                    $this->errors[] = sprintf($this->l('File not allowed (%s)'), $file_ext);
                }
            }

            /* upload the image */
            if (isset($_FILES['DSS_WSM_LOGO']) && isset($_FILES['DSS_WSM_LOGO']['tmp_name']) && !empty($_FILES['DSS_WSM_LOGO']['tmp_name'])) {
                $allowed_ext = array('png', 'jpg', 'jpeg', 'gif', 'tiff');
                $file_ext = pathinfo($_FILES['DSS_WSM_LOGO']['name'], PATHINFO_EXTENSION);
                if ($file_ext && in_array(Tools::strtolower($file_ext), $allowed_ext)) {
                    Configuration::set('PS_IMAGE_GENERATION_METHOD', 1, null, null, $id_shop);
                    if (file_exists(_PS_IMG_DIR_.'wsm_logo_'.(int)$id_shop.'.jpg')) {
                        unlink(_PS_IMG_DIR_.'wsm_logo_'.(int)$id_shop.'.jpg');
                    }
                    if ($error = ImageManager::validateUpload($_FILES['DSS_WSM_LOGO'])) {
                        $this->errors[] = $error;
                        $ok = false;
                    } elseif (!($tmpName = tempnam(_PS_TMP_IMG_DIR_, 'PS')) || !move_uploaded_file($_FILES['DSS_WSM_LOGO']['tmp_name'], $tmpName)) {
                        $ok = false;
                    } elseif (!ImageManager::resize($tmpName, _PS_IMG_DIR_.'wsm_logo_'.(int)$id_shop.'.jpg')) {
                        $this->errors[] = $this->displayError($this->l('An error occurred while attempting to upload the image.'));
                        $ok = false;
                    } else {
                        Configuration::updateValue('DSS_WSM_LOGO', 'wsm_logo_'.(int)$id_shop.'.jpg', false, null, $id_shop);
                    }
                    if (isset($tmpName)) {
                        unlink($tmpName);
                    }
                } else {
                    $this->errors[] = sprintf($this->l('File not allowed (%s)'), $file_ext);
                }
            }

            /* upload the agreement */
            if (isset($_FILES['DSS_AGREEMENT_FILE']) && isset($_FILES['DSS_AGREEMENT_FILE']['tmp_name']) && !empty($_FILES['DSS_AGREEMENT_FILE']['tmp_name'])) {
                $allowed_ext = array('pdf');
                $file_ext = pathinfo($_FILES['DSS_AGREEMENT_FILE']['name'], PATHINFO_EXTENSION);
                if ($file_ext && in_array(Tools::strtolower($file_ext), $allowed_ext)) {
                    if (file_exists(_PS_MODULE_DIR_.'dropshipsystem/downloads/'.(int)$id_shop.'/dropship_agreement.pdf')) {
                        unlink(_PS_MODULE_DIR_.'dropshipsystem/downloads/'.(int)$id_shop.'/dropship_agreement.pdf');
                    }
                    if (!move_uploaded_file($_FILES['DSS_AGREEMENT_FILE']['tmp_name'], _PS_MODULE_DIR_.'dropshipsystem/downloads/'.(int)$id_shop.'/dropship_agreement.pdf')) {
                        $ok = false;
                    } else {
                        Configuration::updateValue('DSS_AGREEMENT_FILE', 'dropship_agreement.pdf', false, null, $id_shop);
                    }
                    if (isset($tmpName)) {
                        unlink($tmpName);
                    }
                } else {
                    $this->errors[] = sprintf($this->l('File not allowed (%s)'), $file_ext);
                }
            }

            $checkagreement_text = array();
            foreach (Language::getLanguages(false) as $lang) {
                $checkagreement_text[(int)$lang['id_lang']] = Tools::getValue('DSS_CHECKAGREEMENT_TEXT_'.(int)$lang['id_lang']);
            }
            if (!Configuration::updateValue('DSS_CHECKAGREEMENT_TEXT', $checkagreement_text, true, null, $id_shop)) {
                $this->errors[] = $this->l('Error occurred during settings update');
            }

            if (Tools::isSubmit('submitDssAndMake')) {
                $first_page_text = array();
                $footer_text = array();
                foreach (Language::getLanguages(false) as $lang) {
                    $first_page_text[(int)$lang['id_lang']] = Tools::getValue('DSS_WSM_FIRST_PAGE_TEXT_'.(int)$lang['id_lang']);
                    $footer_text[(int)$lang['id_lang']] = Tools::getValue('DSS_WSM_FOOTER_TEXT_'.(int)$lang['id_lang']);
                }
                if (!Configuration::updateValue('DSS_WSM_FIRST_PAGE_TEXT', $first_page_text, true, null, $id_shop) ||
                    !Configuration::updateValue('DSS_WSM_FOOTER_TEXT', $footer_text, true, null, $id_shop)) {
                    $ok = false;
                }

                if ($ok) {
                    $dss = new DssClass();
                    if (!$dss->generatePDF('webservice_manual')) {
                        $this->errors[] = $this->l('Setting updated succesfully, but an error occurred during manual creation');
                    }
                } else {
                    $this->errors[] = $this->l('Error occurred during settings update');
                }
            }

            if (count($this->errors)) {
                return false;
            } elseif ($ok && !count($this->errors)) {
                $this->content .= $this->module->displayConfirmation($this->l('Settings updated succesfully'));
            }

            return parent::postProcess();
            //Tools::redirectAdmin($this->context->link->getAdminLink('AdminDropShipConfig'));
        }
    }

    protected function recursiveDeleteOnDisk($dir)
    {
        if (strpos(realpath($dir), realpath(_PS_MODULE_DIR_)) === false) {
            return;
        }
        if (is_dir($dir)) {
            $objects = scandir($dir);
            foreach ($objects as $object) {
                if ($object != '.' && $object != '..') {
                    if (filetype($dir.'/'.$object) == 'dir') {
                        $this->recursiveDeleteOnDisk($dir.'/'.$object);
                    } else {
                        unlink($dir.'/'.$object);
                    }
                }
            }
            reset($objects);
            rmdir($dir);
        }
    }

    public function renderForm()
    {
        $this->context->smarty->assign(array(
            'tab' => array(
                'info' => $this->tabInfo(),
                'settings' => $this->tabSettings(),
                'categories_group' => $this->tabCategoriesGroup(),
                'manufacturers' => $this->tabManufacturers(),
                'suppliers' => $this->tabSuppliers(),
                'shipping' => $this->tabShipping(),
                'payments' => $this->tabPayments(),
                'documents' => $this->tabDocuments()
            ),
            'module_dir' => _MODULE_DIR_,
            'errors' => $this->errors,
            'registered' => (int)Configuration::get('DSS_REGISTRATION'),
            'dss_version' => $this->module->version,
            'dss_ajaxurl' => AdminController::$currentIndex."&token=".Tools::getAdminTokenLite('AdminDropShipConfig'),
            'dss_token' => Tools::getAdminTokenLite('AdminDropShipConfig'),
        ));

        return $this->context->smarty->fetch(dirname(__FILE__).'/../../views/templates/admin/config_main.tpl');
    }

    private function tabInfo()
    {
        $id_shop = $this->context->shop->id;
        $registered = (int)Configuration::get('DSS_REGISTRATION');
        $dss_new_version = Configuration::get('DSS_NEW_VERSION');
        $suffix = ($this->context->language->iso_code == 'it') ? 'it' : 'en';
        $xmlrss = $this->module->getXmlRss();

        $this->context->smarty->assign(array(
            'registration_order' => (string)Tools::getValue('DSS_REGISTRATION_ORDER', Configuration::get('DSS_REGISTRATION_ORDER', null, null, $id_shop)),
            'registration_key' => (string)Tools::getValue('DSS_REGISTRATION_KEY', Configuration::get('DSS_REGISTRATION_KEY', null, null, $id_shop)),
            'registered' => $registered,
            'module_dir' => _MODULE_DIR_,
            'dss_version' => $this->module->version,
            //'file_exist' => file_exists(dirname(__FILE__).'/../../readme_'.$suffix.'.pdf'),
            'suffix' => $suffix,
            'xmlrss' => isset($xmlrss) ? $xmlrss : '',
            'exist_new_version' => version_compare($dss_new_version, $this->module->version, '>'),
            'dss_new_version' => $dss_new_version,
            'cron_string' => $this->context->shop->getBaseURL(true).'module/'.$this->module->name.'/cron?secure_key='.
                Configuration::get('DSS_SECURE_KEY', null, null, $id_shop).
                (Shop::isFeatureActive() ? '&id_shop='.(int)$id_shop : ''),
        ));

        return $this->context->smarty->fetch(dirname(__FILE__).'/../../views/templates/admin/tab_info.tpl');
    }

    private function tabSettings()
    {
        $id_shop = (int)$this->context->shop->id;
        $id_def_lang = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);

        $languages = Language::getLanguages(false);
        foreach ($languages as $k => $language) {
            $languages[$k]['is_default'] = (int)$language['id_lang'] == $id_def_lang;
        }

        $pstax_active = (int)Configuration::get('PS_TAX', null, null, $id_shop);
        $taxes = array();
        $pstaxes = Tax::getTaxes($id_def_lang);
        foreach ($pstaxes as $tax) {
            $taxes[] = array('id' => $tax['rate'], 'name' => $tax['name']);
        }

        $shipping_methods = array();
        $psshipping = Carrier::getCarriers($id_def_lang);
        foreach ($psshipping as $carrier) {
            if ((int)$carrier['active'] == 1 && (int)$carrier['deleted'] == 0) {
                $shipping_methods[] = array('id' => $carrier['id_carrier'], 'name' => $carrier['name']);
            }
        }

        $module_list = array();
        foreach ($this->extra_modules as $mod) {
            $module = Module::getInstanceByName((string)$mod);
            if (Validate::isLoadedObject($module) && $module->active) {
                $module_list[] = array(
                    'id' => $module->id,
                    'name' => $module->displayName,
                    'val' => '1',
                );
            }
        }

        $cms = array();
        foreach (CMS::getCMSPages($id_def_lang) as $page) {
            $cms[] = array('id' => $page['id_cms'], 'name' => $page['meta_title']);
        }

        $fields_form = array(
            'form' => array(
                'tinymce' => true,
                'legend' => array(
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs',
                ),
                //'description' => $this->l(''),
                'input' => array(
                    /*array(
                        'type' => 'text',
                        'label' => $this->l('Max daily connections per user'),
                        'name' => 'DSS_MAX_DAILY_CONNECTIONS',
                        //'prefix' => '%',
                        'class' => 'fixed-width-sm',
                        'hint' => $this->l('Max daily connections per user'),
                    ),*/
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Enable mails to the customers / dropshippers'),
                        'name' => 'DSS_CUSTOMER_MAILS',
                        'class' => 't',
                        'is_bool' => true,
                        'hint' => $this->l('Enable mails to the customers / dropshippers. (only for \'secondary site\')'),
                        'values' => array(
                            array(
                                'id' => 'on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Allow orders with zero quantity'),
                        'name' => 'DSS_ALLOW_ORDERS_ZERO_QTY',
                        'class' => 't',
                        'is_bool' => true,
                        'hint' => $this->l('Allow orders when quantity is zero.'),
                        'values' => array(
                            array(
                                'id' => 'on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Remove disabled products from xml feed'),
                        'name' => 'DSS_REMOVE_DISABLED_PRODUCTS_FROM_FEED',
                        'class' => 't',
                        'is_bool' => true,
                        'hint' => $this->l('Disabled product will be removed from xml feed'),
                        'values' => array(
                            array(
                                'id' => 'on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Remove VAT Price'),
                        'name' => 'DSS_PRICES_VAT',
                        'hint' => $this->l('Select the value of VAT to remove from price.'),
                        'disabled' => $pstax_active ? true : false,
                        'options' => array(
                            'query' => $taxes,
                            'id' => 'id',
                            'name' => 'name',
                            'default' => array(
                                'value' => 0,
                                'label' => $this->l('No Tax')
                            )
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Wholesale base price'),
                        'name' => 'DSS_WHOLESALE_BASE_PRICE',
                        'hint' => $this->l('Select the base price for calculate the wholesale price for dropshippers.'),
                        'options' => array(
                            'query' => array(
                                array('id' => '0', 'name' => $this->l('Wholesale price')),
                                array('id' => '1', 'name' => $this->l('Final price without discount'))
                            ),
                            'id' => 'id',
                            'name' => 'name',
                        ),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Final price as wholesale price'),
                        'name' => 'DSS_BASE_PRICE',
                        'class' => 't',
                        'is_bool' => true,
                        'hint' => $this->l('Enable to make the final price the same as wholesale price.'),
                        'values' => array(
                            array(
                                'id' => 'on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    count($module_list) > 0 ? array(
                        'type' => 'checkbox',
                        'label' => $this->l('Enable detected third modules'),
                        'name' => 'DSS_ENABLE_THIRD_MODULES',
                        'values' => array(
                            'query' => $module_list,
                            'id' => 'id',
                            'name' => 'name',
                            'value' => '1',
                        ),
                        'hint' => $this->l('Mark all third modules detected on your store to enable compatibility.')
                    ) : null,
                    array(
                        'type' => 'text',
                        'label' => $this->l('Mask real quantity value'),
                        'name' => 'DSS_MASK_REAL_QUANTITY_VALUE',
                        'class' => 'fixed-width-sm',
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Enable FastSync for dropshippers'),
                        'name' => 'DSS_ENABLE_FASTSYNC',
                        'class' => 't',
                        'is_bool' => true,
                        'hint' => $this->l('Enable FastSync for dropshippers.'),
                        'values' => array(
                            array(
                                'id' => 'on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Dropshippers registration form'),
                        'name' => 'DSS_DROPSHIPPERS_REGISTRATION',
                        'class' => 't',
                        'is_bool' => true,
                        'hint' => $this->l('Enable the registration form for the new dropshipper customers.'),
                        'values' => array(
                            array(
                                'id' => 'on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Show notify for new dropshippers'),
                        'name' => 'DSS_NOTIFY_DROPSHIPPERS',
                        'class' => 't',
                        'is_bool' => true,
                        'hint' => $this->l('Show a notify for new dropshippers in backoffice'),
                        'values' => array(
                            array(
                                'id' => 'on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Select the TOS page'),
                        'name' => 'DSS_PAGE_TOS',
                        'options' => array(
                            'query' => $cms,
                            'id' => 'id',
                            'name' => 'name',
                            'default' => array(
                                'value' => 0,
                                'label' => ''
                            )
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Select the Privacy page'),
                        'name' => 'DSS_PAGE_PRIVACY',
                        'options' => array(
                            'query' => $cms,
                            'id' => 'id',
                            'name' => 'name',
                            'default' => array(
                                'value' => 0,
                                'label' => ''
                            )
                        ),
                    ),
                    array(
                        'type' => 'file',
                        'label' => $this->l('Dropshipper agreement file'),
                        'name' => 'DSS_AGREEMENT_FILE',
                        'desc' => $this->l('(Only PDF file format)'),
                        'hint' => $this->l('Agreement file for new dropshipper customer registration. (Only PDF file format)')
                    ),
                    array(
                        'type' => 'textarea',
                        'label' => $this->l('Dropshipper agreement text'),
                        'name' => 'DSS_CHECKAGREEMENT_TEXT',
                        'lang' => true,
                        'autoload_rte' => false,
                        'cols' => 60,
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Debug mode'),
                        'name' => 'DSS_DEBUG',
                        'class' => 't',
                        'is_bool' => true,
                        'hint' => $this->l('Debug mode'),
                        'values' => array(
                            array(
                                'id' => 'on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                ),
                'submit' => array(
                    'name' => 'submitDss',
                    'title' => $this->l('Save'),
                    'class' => 'button btn btn-default pull-right'
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = true;
        $helper->module = $this->module;
        $helper->name_controller = $this->module->name;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminDropShipConfig');
        $helper->languages = $languages;
        $helper->currentIndex = $this->context->link->getAdminLink('AdminDropShipConfig', false);
        $helper->default_form_language = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', null, null, $id_shop) ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', null, null, $id_shop) : 0;
        $helper->title = $this->module->displayName;
        $helper->submit_action = 'submitDss';
        $helper->tpl_vars = array(
            'currencies' => Currency::getCurrencies(),
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );
        $helper->override_folder = 'drop_ship_config/';

        return $helper->generateForm(array(
            $fields_form,
        ));
    }

    private function tabCategoriesGroup()
    {
        $dss = new DssClass();
        $id_shop = (int)$this->context->shop->id;
        $id_def_lang = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);

        $languages = Language::getLanguages(false);
        foreach ($languages as $key => $language) {
            $languages[$key]['is_default'] = (int)$language['id_lang'] == $id_def_lang;
        }

        $id_group = 0;
        $groups = array();
        $psgroups = Group::getGroups($id_def_lang, $id_shop);
        $groupdef = array(Configuration::get('PS_UNIDENTIFIED_GROUP', null, null, $id_shop), Configuration::get('PS_GUEST_GROUP', null, null, $id_shop), Configuration::get('PS_CUSTOMER_GROUP', null, null, $id_shop));
        foreach ($psgroups as $group) {
            if (!in_array($group['id_group'], $groupdef)) {
                if (!$id_group) {
                    $id_group = $group['id_group'];
                }
                $groups[] = array('id' => $group['id_group'], 'name' => $group['name']);
            }
        }
        $id_group = Tools::getValue('DSS_GROUP', $id_group);

        $root = Category::getRootCategory();
        $categories = $dss->getNestedCategories($root->id, $id_def_lang);
        $categories_selected = $dss->getGroupCategories($id_group);
        //$categories_disabled = $dss->getDisabledCategories($id_def_lang);

        $tree = new HelperTreeCategories('categories_treeview');
        $tree->setUseCheckBox(true)
            ->setUseSearch(true)
            ->setData($categories)
            //->setAttribute('is_category_filter', $root->id)
            //->setRootCategory($root->id)
            ->setSelectedCategories($categories_selected)
            //->setDisabledCategories($disabled_cat)
            ->setInputName('DSS_CATEGORY_GROUP');
        $category_tree = $tree->render();

        $fields_form = array(
            'form' => array(
                'tinymce' => true,
                'legend' => array(
                    'title' => $this->l('Categories Group'),
                    'icon' => 'icon-folder-open',
                ),
                'input' => array(
                    array(
                        'type' => 'select',
                        'label' => $this->l('Dropshipper Group'),
                        'name' => 'DSS_GROUP',
                        'hint' => $this->l('Select the dropshipper group'),
                        'options' => array(
                            'query' => $groups,
                            'id' => 'id',
                            'name' => 'name',
                        ),
                    ),
                    array(
                        'type'  => 'categories_select',
                        'label' => $this->l('Categories'),
                        'name'  => 'DSS_CATEGORY_GROUP',
                        'category_tree'  => $category_tree,
                    ),
                    array(
                        'type'  => 'generateuniquecodes',
                        'label' => $this->l('Generate unique codes'),
                        'name'  => 'generateuniquecodes',
                    ),
                ),
                'submit' => array(
                    'name' => 'submitDss',
                    'title' => $this->l('Save'),
                    'class' => 'button btn btn-default pull-right'
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = true;
        $helper->module = $this->module;
        $helper->name_controller = $this->module->name;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminDropShipConfig');
        $helper->languages = $languages;
        $helper->currentIndex = $this->context->link->getAdminLink('AdminDropShipConfig', false);
        $helper->default_form_language = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', null, null, $id_shop) ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', null, null, $id_shop) : 0;
        $helper->title = $this->module->displayName;
        $helper->submit_action = 'submitDss';
        $helper->tpl_vars = array(
            'currencies' => Currency::getCurrencies(),
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );
        $helper->override_folder = 'drop_ship_config/';

        return $helper->generateForm(array(
            $fields_form,
        ));
    }

    private function tabManufacturers()
    {
        $id_shop = (int)$this->context->shop->id;
        $id_def_lang = Configuration::get('PS_LANG_DEFAULT');

        $groups = array();
        $dss_manufacturers = array();
        $psgroups = Group::getGroups($id_def_lang, $id_shop);
        $groupdef = array(Configuration::get('PS_UNIDENTIFIED_GROUP', null, null, $id_shop), Configuration::get('PS_GUEST_GROUP', null, null, $id_shop), Configuration::get('PS_CUSTOMER_GROUP', null, null, $id_shop));
        foreach ($psgroups as $group) {
            if (!in_array($group['id_group'], $groupdef)) {
                $manufacturers = DssManufacturersClass::getManufacturersByGroups((int)$group['id_group']);
                if (isset($manufacturers) && $manufacturers) {
                    $groups[(int)$group['id_group']] = (string)$group['name'];
                    foreach ($manufacturers as $manufacturer) {
                        $dss_manufacturers[(int)$manufacturer['id_manufacturer']][(int)$group['id_group']] = (int)$manufacturer['active'];
                    }
                }
            }
        }

        $this->context->smarty->assign(array(
            'groups' => $groups,
            'manufacturers' => Manufacturer::getManufacturers(),
            'dss_manufacturers' => $dss_manufacturers
        ));

        return $this->context->smarty->fetch(dirname(__FILE__).'/../../views/templates/admin/tab_manufacturers.tpl');
    }

    private function tabSuppliers()
    {
        $id_shop = (int)$this->context->shop->id;
        $id_def_lang = Configuration::get('PS_LANG_DEFAULT');

        $groups = array();
        $dss_suppliers = array();
        $psgroups = Group::getGroups($id_def_lang, $id_shop);
        $groupdef = array(Configuration::get('PS_UNIDENTIFIED_GROUP', null, null, $id_shop), Configuration::get('PS_GUEST_GROUP', null, null, $id_shop), Configuration::get('PS_CUSTOMER_GROUP', null, null, $id_shop));
        foreach ($psgroups as $group) {
            if (!in_array($group['id_group'], $groupdef)) {
                $suppliers = DssSuppliersClass::getSuppliersByGroups((int)$group['id_group']);
                if (isset($suppliers) && $suppliers) {
                    $groups[(int)$group['id_group']] = (string)$group['name'];
                    foreach ($suppliers as $supplier) {
                        $dss_suppliers[(int)$supplier['id_supplier']][(int)$group['id_group']] = (int)$supplier['active'];
                    }
                }
            }
        }

        $this->context->smarty->assign(array(
            'groups' => $groups,
            'suppliers' => Supplier::getSuppliers(),
            'dss_suppliers' => $dss_suppliers
        ));

        return $this->context->smarty->fetch(dirname(__FILE__).'/../../views/templates/admin/tab_suppliers.tpl');
    }

    private function tabShipping()
    {
        $id_shop = (int)$this->context->shop->id;
        $id_def_lang = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);

        $languages = Language::getLanguages(false);
        foreach ($languages as $k => $language) {
            $languages[$k]['is_default'] = (int)$language['id_lang'] == $id_def_lang;
        }

        $shipping_methods = array();
        $psshipping = Carrier::getCarriers($id_def_lang, true, false, false, false, null);
        foreach ($psshipping as $carrier) {
            if ((int)$carrier['active'] == 1 && (int)$carrier['deleted'] == 0) {
                $shipping_methods[] = array('id' => $carrier['id_carrier'], 'name' => $carrier['name']);
            }
        }

        $fields_form = array(
            'form' => array(
                'tinymce' => true,
                'legend' => array(
                    'title' => $this->l('Shipping'),
                    'icon' => 'icon-truck',
                ),
                //'description' => $this->l(''),
                'input' => array(
                    array(
                        'type' => 'select',
                        'label' => $this->l('Shipping method 1'),
                        'name' => 'DSS_SHIPPING_METHOD_1',
                        'hint' => $this->l('Select the shipping method 1'),
                        'options' => array(
                            'query' => $shipping_methods,
                            'id' => 'id',
                            'name' => 'name',
                            'default' => array(
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Shipping method 2'),
                        'name' => 'DSS_SHIPPING_METHOD_2',
                        'hint' => $this->l('Select the shipping method 2'),
                        'options' => array(
                            'query' => $shipping_methods,
                            'id' => 'id',
                            'name' => 'name',
                            'default' => array(
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Shipping method 3'),
                        'name' => 'DSS_SHIPPING_METHOD_3',
                        'hint' => $this->l('Select the shipping method 3'),
                        'options' => array(
                            'query' => $shipping_methods,
                            'id' => 'id',
                            'name' => 'name',
                            'default' => array(
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                ),
                'submit' => array(
                    'name' => 'submitDss',
                    'title' => $this->l('Save'),
                    'class' => 'button btn btn-default pull-right'
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = true;
        $helper->module = $this->module;
        $helper->name_controller = $this->module->name;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminDropShipConfig');
        $helper->languages = $languages;
        $helper->currentIndex = $this->context->link->getAdminLink('AdminDropShipConfig', false);
        $helper->default_form_language = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', null, null, $id_shop) ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', null, null, $id_shop) : 0;
        $helper->title = $this->module->displayName;
        $helper->submit_action = 'submitDss';
        $helper->tpl_vars = array(
            'currencies' => Currency::getCurrencies(),
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );
        $helper->override_folder = 'drop_ship_config/';

        return $helper->generateForm(array(
            $fields_form,
        ));
    }

    private function tabPayments()
    {
        $id_shop = (int)$this->context->shop->id;
        $id_def_lang = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);

        $languages = Language::getLanguages(false);
        foreach ($languages as $k => $language) {
            $languages[$k]['is_default'] = (int)$language['id_lang'] == $id_def_lang;
        }

        $payment_gateways = array();
        $dsspayment_gateways = unserialize(Configuration::get('DSS_PAYMENT_GATEWAYS', null, null, $id_shop));
        foreach ($dsspayment_gateways as $paymentgateway) {
            $payment_gateways[] = array('id' => $paymentgateway['id'], 'name' => $paymentgateway['name']);
        }

        $fields_values = $this->getConfigFieldsValues();
        $fields_options = array(
            'general' => array(
                'title' => $this->l('Payments'),
                'icon' => 'icon-money',
                'fields' => array(
                    'DSS_DEFAULT_PAYMENT_GATEWAY' => array(
                        'type' => 'select',
                        'title' => $this->l('Default Payment Gateway'),
                        'hint' => $this->l('Select the default payment gateway'),
                        'identifier' => 'id',
                        'value' => 1,
                        'list' => $payment_gateways
                    ),
                    'DSS_UPLOAD_PLUGIN' => array(
                        'type' => 'file',
                        'title' => $this->l('Upload payment plugin'),
                        'name' => 'DSS_UPLOAD_PLUGIN',
                        'lang'  =>  false,
                        'display_image' => false,
                    ),
                    'DSS_BANKWIRE' => array(
                        'type' => 'bool',
                        'title' => $this->l('Enable bank wire transfer'),
                        'name' => 'DSS_BANKWIRE',
                    ),
                    'DSS_BANKWIRE_OWNER' => array(
                        'type' => 'text',
                        'title' => $this->l('Bank owner'),
                        'name' => 'DSS_BANKWIRE_OWNER',
                        'class' => 'fixed-width-xl',
                    ),
                    'DSS_BANKWIRE_NAME' => array(
                        'type' => 'text',
                        'title' => $this->l('Bank name'),
                        'name' => 'DSS_BANKWIRE_NAME',
                        'class' => 'fixed-width-xl',
                    ),
                    'DSS_BANKWIRE_IBAN' => array(
                        'type' => 'text',
                        'title' => $this->l('Bank IBAN'),
                        'name' => 'DSS_BANKWIRE_IBAN',
                        'class' => 'fixed-width-xl',
                    ),
                    'DSS_BANKWIRE_SWIFT' => array(
                        'type' => 'text',
                        'title' => $this->l('Bank SWIFT'),
                        'name' => 'DSS_BANKWIRE_SWIFT',
                        'class' => 'fixed-width-xl',
                    ),
                ),
                'submit' => array(
                    'name' => 'submitDss',
                    'title' => $this->l('Save'),
                    'class' => 'button btn btn-default pull-right'
                )
            ),
            'appearance' => array(
                'title' => $this->l('Payments gateways'),
                'icon' => 'icon-money',
                'tabs' => array(),
                'fields' => array(),
                'submit' => array(
                    'name' => 'submitDss',
                    'title' => $this->l('Save'),
                    'class' => 'button btn btn-default pull-right'
                )
            )
        );

        foreach ($this->payment_gateways as $payment_gateway) {
            $path_parts = pathinfo($payment_gateway);
            $class_name = $path_parts['filename'];

            require_once($payment_gateway);
            if (class_exists($class_name)) {
                $gateway = new $class_name();

                $fields_options['appearance']['tabs'] = array_merge($fields_options['appearance']['tabs'], array($class_name => $gateway->gateway_name));
                $fields_options['appearance']['fields'] = array_merge($fields_options['appearance']['fields'], $gateway->getFieldsForm());
                $fields_options['appearance']['fields'] = array_merge(
                    $fields_options['appearance']['fields'],
                    array(
                        'DSS_REMOVE_'.Tools::strtoupper($class_name) => array(
                            'type' => 'html',
                            'html_content' => "<div class='col-sm-12 text-right'>
                                <a href='#' class='remove_plugin' id='DSS_REMOVE_".Tools::strtoupper($class_name)."' data-plugin='".(string)$gateway->gateway_name."'><i class='icon-trash'></i> ".$this->l('Remove this plugin', 'dropshipsystem')."</a></div>",
                            'tab' => $class_name,
                        )
                    )
                );

                $fields_values = array_merge($fields_values, $gateway->getFieldsValues());
            }
        }

        $helper = new HelperOptions();
        $helper->show_toolbar = true;
        $helper->module = $this->module;
        $helper->name_controller = $this->module->name;
        $helper->id = $this->id;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminDropShipConfig');
        $helper->languages = $languages;
        $helper->currentIndex = $this->context->link->getAdminLink('AdminDropShipConfig', false);
        $helper->default_form_language = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', null, null, $id_shop) ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', null, null, $id_shop) : 0;
        $helper->title = $this->module->displayName;
        $helper->submit_action = 'submitDss';
        $helper->tpl_vars = array(
            'currencies' => Currency::getCurrencies(),
            'fields_value' => $fields_values,
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );
        $helper->override_folder = 'drop_ship_config/';

        return $helper->generateOptions($fields_options);
    }

    private function tabDocuments()
    {
        $id_shop = (int)$this->context->shop->id;
        $id_def_lang = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);

        $languages = Language::getLanguages(false);
        foreach ($languages as $k => $language) {
            $languages[$k]['is_default'] = (int)$language['id_lang'] == $id_def_lang;
        }

        $fields_form = array(
            'form' => array(
                'tinymce' => true,
                'legend' => array(
                    'title' => $this->l('Documents'),
                    'icon' => 'icon-AdminCatalog',
                ),
                //'description' => $this->l(''),
                'input' => array(
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Enable download client block'),
                        'name' => 'DSS_DOWNLOAD_BLOCK_ENABLE',
                        'class' => 't',
                        'is_bool' => true,
                        'hint' => $this->l('Enable download client block'),
                        'values' => array(
                            array(
                                'id' => 'on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Enable categories feed download'),
                        'name' => 'DSS_FILE_CATEGORIES_ENABLE',
                        'class' => 't',
                        'is_bool' => true,
                        'hint' => $this->l('Enable categories feed download'),
                        'values' => array(
                            array(
                                'id' => 'on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Enable products feed download'),
                        'name' => 'DSS_FILE_PRODUCTS_ENABLE',
                        'class' => 't',
                        'is_bool' => true,
                        'hint' => $this->l('Enable products feed download'),
                        'values' => array(
                            array(
                                'id' => 'on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Enable pricelist feed download'),
                        'name' => 'DSS_FILE_PRICELIST_ENABLE',
                        'class' => 't',
                        'is_bool' => true,
                        'hint' => $this->l('Enable pricelist feed download'),
                        'values' => array(
                            array(
                                'id' => 'on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Enable complete feed download'),
                        'name' => 'DSS_FILE_ALL_ENABLE',
                        'class' => 't',
                        'is_bool' => true,
                        'hint' => $this->l('Enable complete feed download'),
                        'values' => array(
                            array(
                                'id' => 'on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'file',
                        'label' => $this->l('Manual header logo'),
                        'name' => 'DSS_WSM_LOGO',
                        'lang'  =>  false,
                        'display_image' => true,
                        'thumb' => $this->context->link->protocol_content.$this->thumb_logo,
                        'hint' => $this->l('Logo in the header of every page of PDF manual.')
                    ),
                    array(
                        'type' => 'textarea',
                        'label' => $this->l('Manual first page text'),
                        'name' => 'DSS_WSM_FIRST_PAGE_TEXT',
                        'lang' => true,
                        'autoload_rte' => true,
                        'cols' => 60,
                        'desc' => $this->l('Message in the first page of PDF manual.')
                    ),
                    array(
                        'type' => 'textarea',
                        'label' => $this->l('Manual footer text'),
                        'name' => 'DSS_WSM_FOOTER_TEXT',
                        'lang' => true,
                        'autoload_rte' => true,
                        'cols' => 60,
                        'desc' => $this->l('Message at the footer of every page of the PDF manual')
                    ),
                ),
                'submit' => array(
                    'name' => 'submitDssAndMake',
                    'title' => $this->l('Save & Make'),
                    'class' => 'button btn btn-default pull-right'
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = true;
        $helper->module = $this->module;
        $helper->name_controller = $this->module->name;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminDropShipConfig');
        $helper->languages = $languages;
        $helper->currentIndex = $this->context->link->getAdminLink('AdminDropShipConfig', false);
        $helper->default_form_language = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', null, null, $id_shop) ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', null, null, $id_shop) : 0;
        $helper->title = $this->module->displayName;
        $helper->submit_action = 'submitDssAndMake';
        $helper->tpl_vars = array(
            'currencies' => Currency::getCurrencies(),
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );
        $helper->override_folder = 'drop_ship_config/';

        return $helper->generateForm(array(
            $fields_form,
        ));
    }

    public function getConfigFieldsValues()
    {
        $languages = Language::getLanguages(false);
        $id_shop = (int)$this->context->shop->id;
        $pstax_active = (int)Configuration::get('PS_TAX', null, null, $id_shop);

        $fields_values = array(
            'DSS_MAX_DAILY_CONNECTIONS' => (int)Tools::getValue('DSS_MAX_DAILY_CONNECTIONS', Configuration::get('DSS_MAX_DAILY_CONNECTIONS', null, null, $id_shop)),
            'DSS_CUSTOMER_MAILS' => Tools::getValue('DSS_CUSTOMER_MAILS', Configuration::get('DSS_CUSTOMER_MAILS', null, null, $id_shop)),
            'DSS_ALLOW_ORDERS_ZERO_QTY' => Tools::getValue('DSS_ALLOW_ORDERS_ZERO_QTY', Configuration::get('DSS_ALLOW_ORDERS_ZERO_QTY', null, null, $id_shop)),
            'DSS_REMOVE_DISABLED_PRODUCTS_FROM_FEED' => Tools::getValue('DSS_REMOVE_DISABLED_PRODUCTS_FROM_FEED', Configuration::get('DSS_REMOVE_DISABLED_PRODUCTS_FROM_FEED', null, null, $id_shop)),
            'DSS_PRICES_VAT' => $pstax_active ? 0 : Tools::getValue('DSS_PRICES_VAT', Configuration::get('DSS_PRICES_VAT', null, null, $id_shop)),
            'DSS_WHOLESALE_BASE_PRICE' => Tools::getValue('DSS_WHOLESALE_BASE_PRICE', Configuration::get('DSS_WHOLESALE_BASE_PRICE', null, null, $id_shop)),
            'DSS_BASE_PRICE' => Tools::getValue('DSS_BASE_PRICE', Configuration::get('DSS_BASE_PRICE', null, null, $id_shop)),
            'DSS_SHIPPING_METHOD_1' => Tools::getValue('DSS_SHIPPING_METHOD_1', Configuration::get('DSS_SHIPPING_METHOD_1', null, null, $id_shop)),
            'DSS_SHIPPING_METHOD_2' => Tools::getValue('DSS_SHIPPING_METHOD_2', Configuration::get('DSS_SHIPPING_METHOD_2', null, null, $id_shop)),
            'DSS_SHIPPING_METHOD_3' => Tools::getValue('DSS_SHIPPING_METHOD_3', Configuration::get('DSS_SHIPPING_METHOD_3', null, null, $id_shop)),
            'DSS_MASK_REAL_QUANTITY_VALUE' => Tools::getValue('DSS_MASK_REAL_QUANTITY_VALUE', Configuration::get('DSS_MASK_REAL_QUANTITY_VALUE', null, null, $id_shop)),
            'DSS_ENABLE_FASTSYNC' => Tools::getValue('DSS_ENABLE_FASTSYNC', Configuration::get('DSS_ENABLE_FASTSYNC', null, null, $id_shop)),
            'DSS_DROPSHIPPERS_REGISTRATION' => Tools::getValue('DSS_DROPSHIPPERS_REGISTRATION', Configuration::get('DSS_DROPSHIPPERS_REGISTRATION', null, null, $id_shop)),
            'DSS_NOTIFY_DROPSHIPPERS' => Tools::getValue('DSS_NOTIFY_DROPSHIPPERS', Configuration::get('DSS_NOTIFY_DROPSHIPPERS', null, null, $id_shop)),
            'DSS_PAGE_TOS' => Tools::getValue('DSS_PAGE_TOS', Configuration::get('DSS_PAGE_TOS', null, null, $id_shop)),
            'DSS_PAGE_PRIVACY' => Tools::getValue('DSS_PAGE_PRIVACY', Configuration::get('DSS_PAGE_PRIVACY', null, null, $id_shop)),
            'DSS_DEFAULT_PAYMENT_GATEWAY' => Tools::getValue('DSS_DEFAULT_PAYMENT_GATEWAY', Configuration::get('DSS_DEFAULT_PAYMENT_GATEWAY', null, null, $id_shop)),
            'DSS_BANKWIRE' => Tools::getValue('DSS_BANKWIRE', Configuration::get('DSS_BANKWIRE', null, null, $id_shop)),
            'DSS_BANKWIRE_OWNER' => Tools::getValue('DSS_BANKWIRE_OWNER', Configuration::get('DSS_BANKWIRE_OWNER', null, null, $id_shop)),
            'DSS_BANKWIRE_NAME' => Tools::getValue('DSS_BANKWIRE_NAME', Configuration::get('DSS_BANKWIRE_NAME', null, null, $id_shop)),
            'DSS_BANKWIRE_IBAN' => Tools::getValue('DSS_BANKWIRE_IBAN', Configuration::get('DSS_BANKWIRE_IBAN', null, null, $id_shop)),
            'DSS_BANKWIRE_SWIFT' => Tools::getValue('DSS_BANKWIRE_SWIFT', Configuration::get('DSS_BANKWIRE_SWIFT', null, null, $id_shop)),
            'DSS_DOWNLOAD_BLOCK_ENABLE' => Tools::getValue('DSS_DOWNLOAD_BLOCK_ENABLE', Configuration::get('DSS_DOWNLOAD_BLOCK_ENABLE', null, null, $id_shop)),
            'DSS_FILE_CATEGORIES_ENABLE' => Tools::getValue('DSS_FILE_CATEGORIES_ENABLE', Configuration::get('DSS_FILE_CATEGORIES_ENABLE', null, null, $id_shop)),
            'DSS_FILE_PRODUCTS_ENABLE' => Tools::getValue('DSS_FILE_PRODUCTS_ENABLE', Configuration::get('DSS_FILE_PRODUCTS_ENABLE', null, null, $id_shop)),
            'DSS_FILE_PRICELIST_ENABLE' => Tools::getValue('DSS_FILE_PRICELIST_ENABLE', Configuration::get('DSS_FILE_PRICELIST_ENABLE', null, null, $id_shop)),
            'DSS_FILE_ALL_ENABLE' => Tools::getValue('DSS_FILE_ALL_ENABLE', Configuration::get('DSS_FILE_ALL_ENABLE', null, null, $id_shop)),
            'DSS_WSM_LOGO' => Tools::getValue('DSS_WSM_LOGO', Configuration::get('DSS_WSM_LOGO', null, null, $id_shop)),
            'DSS_AGREEMENT_FILE' => Tools::getValue('DSS_AGREEMENT_FILE', Configuration::get('DSS_AGREEMENT_FILE', null, null, $id_shop)),
            'DSS_DEBUG' => Tools::getValue('DSS_DEBUG', Configuration::get('DSS_DEBUG', null, null, $id_shop)),
            'DSS_GROUP' => Tools::getValue('DSS_GROUP'),
        );

        $module_list = array();
        foreach ($this->extra_modules as $mod) {
            $module = Module::getInstanceByName((string)$mod);
            if (Validate::isLoadedObject($module) && $module->active) {
                $module_list[] = $module->id;
            }
        }
        if ($confs = Configuration::get('DSS_ENABLE_THIRD_MODULES', null, null, $id_shop)) {
            $confs = explode(',', Configuration::get('DSS_ENABLE_THIRD_MODULES', null, null, $id_shop));
        } else {
            $confs = array();
        }
        if (count($confs) > 0) {
            foreach ($confs as $conf) {
                $fields_values['DSS_ENABLE_THIRD_MODULES_'.(int)$conf] = Tools::getValue('DSS_ENABLE_THIRD_MODULES_'.(int)$conf, true);
            }
        }

        foreach ($languages as $lang) {
            $fields_values['DSS_WSM_FIRST_PAGE_TEXT'][$lang['id_lang']] = Tools::getValue('DSS_WSM_FIRST_PAGE_TEXT_'.(int)$lang['id_lang'], Configuration::get('DSS_WSM_FIRST_PAGE_TEXT', (int)$lang['id_lang'], null, $id_shop));
            $fields_values['DSS_WSM_FOOTER_TEXT'][$lang['id_lang']] = Tools::getValue('DSS_WSM_FOOTER_TEXT_'.(int)$lang['id_lang'], Configuration::get('DSS_WSM_FOOTER_TEXT', (int)$lang['id_lang'], null, $id_shop));
            $fields_values['DSS_CHECKAGREEMENT_TEXT'][$lang['id_lang']] = Tools::getValue('DSS_CHECKAGREEMENT_TEXT_'.(int)$lang['id_lang'], Configuration::get('DSS_CHECKAGREEMENT_TEXT', (int)$lang['id_lang'], null, $id_shop));
        }
        return $fields_values;
    }

    public function ajaxProcessGenerateUniqueCodes()
    {
        $overwrite = (int)Tools::getValue('overwrite');

        $root = Category::getRootCategory();
        $categories = Category::getNestedCategories((int)$root->id);

        $ucodes = array();
        if (isset($categories) && $categories) {
            foreach ($categories as $id_category => $category) {
                //$ucodes[(int)$id_category] = DssClass::makeUniqueCode($category, $ucodes);
                if (isset($category['children'])) {
                    $ucodes = self::subcategories($category['children'], $ucodes);
                }
            }
        }

        $res = DssCategoriesClass::setCategoryUniqueCodes($ucodes, $overwrite);

        if ($res) {
            die(Tools::jsonEncode(array('success' => true, 'text' => $this->l('Unique codes generated successfully'))));
        } else {
            die(Tools::jsonEncode(array('success' => false, 'text' => $this->l('Error generating unique codes'))));
        }
    }

    private static function subcategories($categories, $ucodes)
    {
        if (isset($categories) && $categories) {
            foreach ($categories as $id_category => $category) {
                $ucodes[(int)$id_category] = DssClass::makeUniqueCode($category, $ucodes);
                if (isset($category['children'])) {
                    $ucodes = self::subcategories($category['children'], $ucodes);
                }
            }
        }
        return $ucodes;
    }

    public function ajaxProcessRenderCategories()
    {
        $dss = new DssClass();
        $id_shop = (int)$this->context->shop->id;
        $id_def_lang = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);
        $id_group = (int)Tools::getValue('id_group');

        $root = Category::getRootCategory();
        $categories = $dss->getNestedCategories($root->id, $id_def_lang);
        $categories_selected = $dss->getGroupCategories($id_group);
        //$categories_disabled = $dss->getDisabledCategories($id_def_lang);

        $tree = new HelperTreeCategories('categories_treeview');
        $tree->setUseCheckBox(true)
            ->setUseSearch(true)
            ->setData($categories)
            //->setAttribute('is_category_filter', $root->id)
            //->setRootCategory($root->id)
            ->setSelectedCategories($categories_selected)
            //->setDisabledCategories($disabled_cat)
            ->setInputName('DSS_CATEGORY_GROUP');
        $category_tree = $tree->render();

        die(Tools::jsonEncode(array('success' => true, 'html' => $category_tree)));
    }

    public function ajaxProcessSetCategoryGroup()
    {
        $id_group = (int)Tools::getValue('id_group');
        $id_categories = (string)Tools::getValue('id_categories');
        $is_checked = (string)Tools::getValue('is_checked') == 'true' ? 1 : 0;

        $categories = explode(',', urldecode($id_categories));

        foreach ($categories as $id_category) {
            $category = new Category((int)$id_category);
            if (isset($category) && $category) {
                if (DssCategoriesClass::isCategoryActive((int)$id_category)) {
                    if ($is_checked) {
                        $category->addGroupsIfNoExist($id_group);
                        if (count($categories) == 1) {
                            die(Tools::jsonEncode(array('success' => true, 'error' => false, 'text' => $this->l('Group added successfully'))));
                        }
                    } else {
                        if (Db::getInstance()->delete('category_group', 'id_category = '.(int)$id_category.' AND id_group = '.(int)$id_group)) {
                            if (count($categories) == 1) {
                                die(Tools::jsonEncode(array('success' => true, 'error' => false, 'text' => $this->l('Group removed successfully'))));
                            }
                        } else {
                            if (count($categories) == 1) {
                                die(Tools::jsonEncode(array('success' => false, 'error' => true, 'text' => $this->l('Error during delete group'))));
                            }
                        }
                    }
                } else {
                    if (count($categories) == 1) {
                        die(Tools::jsonEncode(array('success' => false, 'error' => true, 'text' => $this->l('This category is not active for dropship'))));
                    }
                }
            } else {
                if (count($categories) == 1) {
                    die(Tools::jsonEncode(array('success' => false, 'error' => true, 'text' => $this->l('Error during update category'))));
                }
            }
        }

        if (count($categories) > 1) {
            die(Tools::jsonEncode(array('success' => true, 'error' => false, 'text' => $this->l('Groups updated successfully'))));
        }
    }

    public function ajaxProcessSetManufacturerGroup()
    {
        if (!$this->context) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;
        $id_group = (int)Tools::getValue('id_group');

        if (is_numeric(Tools::getValue('id'))) {
            $id_manufacturer = (int)Tools::getValue('id');

            $dss_groups = new DssManufacturersClass();
            $dss_groups->id_manufacturer = (int)$id_manufacturer;
            $dss_groups->id_shop = (int)$id_shop;
            $dss_groups->group = (int)$id_group;

            $dss_group_exist = (int)$dss_groups->existsManufacturerGroup((int)$id_manufacturer, (int)$id_group);
            if ($dss_group_exist) {
                if ($dss_groups->delete()) {
                    die(Tools::jsonEncode(array('success' => true, 'single' => true, 'enabled' => false, 'text' => $this->l('Group disabled'))));
                } else {
                    die(Tools::jsonEncode(array('success' => false, 'error' => true, 'text' => $this->l('Error during update'))));
                }
            }
            if ($dss_groups->add()) {
                die(Tools::jsonEncode(array('success' => true, 'single' => true, 'enabled' => true, 'text' => $this->l('Group enabled'))));
            } else {
                die(Tools::jsonEncode(array('success' => false, 'error' => true, 'text' => $this->l('Error during update'))));
            }
        } elseif (is_string(Tools::getValue('id'))) {
            if ((string)Tools::getValue('id') == 'check') {
                DssManufacturersClass::setManufacturerGroups($id_group, true);
                die(Tools::jsonEncode(array('success' => true, 'single' => false, 'enabled' => true, 'text' => $this->l('Group enabled'))));
            } elseif ((string)Tools::getValue('id') == 'remove') {
                DssManufacturersClass::setManufacturerGroups($id_group, false);
                die(Tools::jsonEncode(array('success' => true, 'single' => false, 'enabled' => false, 'text' => $this->l('Group disabled'))));
            }
        }
    }

    public function ajaxProcessSetSupplierGroup()
    {
        if (!$this->context) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;
        $id_group = (int)Tools::getValue('id_group');

        if (is_numeric(Tools::getValue('id'))) {
            $id_supplier = (int)Tools::getValue('id');

            $dss_groups = new DssSuppliersClass();
            $dss_groups->id_supplier = (int)$id_supplier;
            $dss_groups->id_shop = (int)$id_shop;
            $dss_groups->group = (int)$id_group;

            $dss_group_exist = (int)$dss_groups->existsSupplierGroup((int)$id_supplier, (int)$id_group);
            if ($dss_group_exist) {
                if ($dss_groups->delete()) {
                    die(Tools::jsonEncode(array('success' => true, 'single' => true, 'enabled' => false, 'text' => $this->l('Group disabled'))));
                } else {
                    die(Tools::jsonEncode(array('success' => false, 'single' => true, 'error' => true, 'text' => $this->l('Error during update'))));
                }
            }
            if ($dss_groups->add()) {
                die(Tools::jsonEncode(array('success' => true, 'single' => true, 'enabled' => true, 'text' => $this->l('Group enabled'))));
            } else {
                die(Tools::jsonEncode(array('success' => false, 'single' => true, 'error' => true, 'text' => $this->l('Error during update'))));
            }
        } elseif (is_string(Tools::getValue('id'))) {
            if ((string)Tools::getValue('id') == 'check') {
                DssSuppliersClass::setSupplierGroups($id_group, true);
                die(Tools::jsonEncode(array('success' => true, 'single' => false, 'enabled' => true, 'text' => $this->l('Group enabled'))));
            } elseif ((string)Tools::getValue('id') == 'remove') {
                DssSuppliersClass::setSupplierGroups($id_group, false);
                die(Tools::jsonEncode(array('success' => true, 'single' => false, 'enabled' => false, 'text' => $this->l('Group disabled'))));
            }
        }
    }

    public function ajaxProcessRemovePlugin()
    {
        $plugin = (string)Tools::getValue('plugin');
        $folder = _PS_MODULE_DIR_.'dropshipsystem/libs/';
        $plugin_file = $folder.'payment_'.(string)Tools::strtolower($plugin).'.php';
        $level = $this->authorizationLevel();

        if ($level == 4) {
            if (file_exists($plugin_file)) {
                $path_parts = pathinfo($plugin_file);
                $class_name = $path_parts['filename'];

                if (class_exists($class_name)) {
                    $gateway = new $class_name;
                    $active = $gateway->gateway_active;
                    if (!$active) {
                        @unlink($plugin_file);
                        $this->recursiveDeleteOnDisk($folder.$plugin);
                        $redirect = $this->context->link->getAdminLink('AdminDropShipConfig');
                        die(Tools::jsonEncode(array('success' => true, 'redirect' => $redirect, 'text' => $this->l('Plugin removed successfully'))));
                    } else {
                        die(Tools::jsonEncode(array('success' => false, 'text' => $this->l('Cannot remove active plugin'))));
                    }
                } else {
                    die(Tools::jsonEncode(array('success' => false, 'text' => $this->l('Error loading plugin'))));
                }
            } else {
                die(Tools::jsonEncode(array('success' => false, 'text' => $this->l('This plugin not exist'))));
            }
        } else {
            die(Tools::jsonEncode(array('success' => false, 'text' => $this->l('Unauthorized action'))));
        }
    }

    public function ajaxProcessSetDashboardFilter()
    {
        $id_shop = (int)$this->context->shop->id;
        $filter = (string)Tools::getValue('id');
        Configuration::updateValue($filter, (int)Configuration::get($filter) ? 0 : 1, false, null, $id_shop);
        die(1);
    }

    public function ajaxProcessGetNotifications()
    {
        $id_employee = (int)$this->context->cookie->id_employee;

        $dss_employee = new DssEmployeeClass((int)$id_employee);
        $dss_employee->id_employee = (int)$id_employee;
        $dss_employee->save();

        $notifications = array();
        $employee_infos = Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow('
            SELECT id_last_dropshipper
            FROM `'._DB_PREFIX_.'dss_employee`
            WHERE `id_employee` = '.(int)$id_employee);

        $notifications = $this->getLastElementsIdsByType($employee_infos['id_last_dropshipper']);

        die(Tools::jsonEncode($notifications));
    }

    public function ajaxProcessSetNotifications()
    {
        $id_employee = (int)$this->context->cookie->id_employee;

        $ret = Db::getInstance()->execute('
            UPDATE `'._DB_PREFIX_.'dss_employee`
            SET `id_last_dropshipper` = (
                SELECT IFNULL(MAX(`id_dss_dropshipper`), 0)
                FROM `'._DB_PREFIX_.'dss_dropshipper`
            )
            WHERE `id_employee` = '.(int)$id_employee);

        die($ret);
    }
    
    public function getLastElementsIdsByType($id_last_element)
    {
        $sql = 'SELECT SQL_CALC_FOUND_ROWS t.*
            FROM `'._DB_PREFIX_.'dss_dropshipper` t
            WHERE t.`active` > 0 AND t.`id_dss_dropshipper` > '.(int)$id_last_element.'
            ORDER BY t.`date_add` DESC
            LIMIT 5';

        $json = array('total' => 0, 'results' => array());
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql, true, false);
        if (isset($result) && $result) {
            $total = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('SELECT FOUND_ROWS()', false);
            $json['total'] = $total;
            foreach ($result as $value) {
                $dropshipper_name = '';
                if (isset($value['contact_name']) && isset($value['contact_name'])) {
                    $dropshipper_name = Tools::safeOutput($value['contact_name']);
                }

                $json['results'][] = array(
                    'id_dss_dropshipper' => ((!empty($value['id_dss_dropshipper'])) ? (int)$value['id_dss_dropshipper'] : 0),
                    'dropshipper_name' => $dropshipper_name,
                    'add_date' => isset($value['date_add']) ? (int)strtotime($value['date_add']) * 1000 : 0,
                );
            }
        }

        return $json;
    }
}
