<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminDropShipSpecificWholesalePriceRuleController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'dss_specific_wholesale_price_rule';
        $this->className = 'DssSpecificWholesalePriceRuleClass';
        $this->lang = false;
        $this->multishop_context = Shop::CONTEXT_ALL;

        /* if $_GET['id_shop'] is transmitted, virtual url can be loaded in config.php, so we wether transmit shop_id in herfs */
        if ($this->id_shop = (int)Tools::getValue('shop_id')) {
            $_GET['id_shop'] = $this->id_shop;
            $_POST['id_shop'] = $this->id_shop;
        }

        parent::__construct();

        $this->context = Context::getContext();

        $this->_select = 's.name shop_name, cu.name currency_name, cl.name country_name, gl.name group_name';
        $this->_join = 'LEFT JOIN '._DB_PREFIX_.'shop s ON (s.id_shop = a.id_shop)
		LEFT JOIN '._DB_PREFIX_.'currency cu ON (cu.id_currency = a.id_currency)
		LEFT JOIN '._DB_PREFIX_.'country_lang cl ON (cl.id_country = a.id_country AND cl.id_lang='.(int)$this->context->language->id.')
		LEFT JOIN '._DB_PREFIX_.'group_lang gl ON (gl.id_group = a.id_group AND gl.id_lang='.(int)$this->context->language->id.')';
        $this->_use_found_rows = false;

        $this->bulk_actions = array(
            'delete' => array(
                'text' => $this->l('Delete selected'),
                'confirm' => $this->l('Delete selected items?'),
                'icon' => 'icon-trash'
            )
        );

        $this->fields_list = array(
            'id_dss_specific_wholesale_price_rule' => array(
                'title' => $this->l('Id'),
                'align' => 'center',
                'class' => 'fixed-width-xs'
            ),
            'name' => array(
                'title' => $this->l('Name'),
                'filter_key' => 'a!name',
                'width' => 'auto'
            ),
            'shop_name' => array(
                'title' => $this->l('Shop'),
                'filter_key' => 's!name'
            ),
            'currency_name' => array(
                'title' => $this->l('Currency'),
                'align' => 'center',
                'filter_key' => 'cu!name'
            ),
            'country_name' => array(
                'title' => $this->l('Country'),
                'align' => 'center',
                'filter_key' => 'cl!name'
            ),
            'group_name' => array(
                'title' => $this->l('Group'),
                'align' => 'center',
                'filter_key' => 'gl!name'
            ),
            'value' => array(
                'title' => $this->l('Reduction / Charge'),
                'align' => 'center',
                'class' => 'fixed-width-xs'
            ),
            'from' => array(
                'title' => $this->l('Beginning'),
                'align' => 'right',
                'type' => 'datetime',
            ),
            'to' => array(
                'title' => $this->l('End'),
                'align' => 'right',
                'type' => 'datetime'
            ),
        );
    }

    public function initContent()
    {
        $action = Tools::getValue('action');

        if (Tools::getValue('ajax') && method_exists($this, 'ajaxProcess'.Tools::toCamelCase($action))) {
            $this->{'ajaxProcess'.Tools::toCamelCase($action)}();
        } else {
            if (!$this->module->active) {
                $this->content .= $this->module->displayError('This module is not active');
            }
        }

        parent::initContent();
    }

    public function initPageHeaderToolbar()
    {
        if (empty($this->display)) {
            $this->page_header_toolbar_btn['new_specific_wholesale_price_rule'] = array(
                'href' => self::$currentIndex.'&adddss_specific_wholesale_price_rule&token='.$this->token,
                'desc' => $this->l('Add new catalog wholesale price rule', null, null, false),
                'icon' => 'process-icon-new'
            );
        }

        parent::initPageHeaderToolbar();
    }

    public function getList($id_lang, $order_by = null, $order_way = null, $start = 0, $limit = null, $id_lang_shop = false)
    {
        parent::getList($id_lang, $order_by, $order_way, $start, $limit, $id_lang_shop);

        foreach ($this->_list as $k => $list) {
            if ($list['value'] == 0) {
                $this->_list[$k]['value'] = '-';
            } else {
                $this->_list[$k]['value'] = number_format($list['value'], 2, '.', ' ').' %';
            }
        }
    }

    public function renderList()
    {
        $this->addRowAction('edit');
        $this->addRowAction('delete');
        return parent::renderList();
    }

    public function renderForm()
    {
        $id_shop = (int)$this->context->shop->id;

        $groups = array();
        $psgroups = Group::getGroups($this->context->language->id, $id_shop);
        $groupdef = array(Configuration::get('PS_UNIDENTIFIED_GROUP', null, null, $id_shop), Configuration::get('PS_GUEST_GROUP', null, null, $id_shop), Configuration::get('PS_CUSTOMER_GROUP', null, null, $id_shop));
        foreach ($psgroups as $group) {
            if (!in_array($group['id_group'], $groupdef)) {
                //if (!$id_group) {
                //    $id_group = $group['id_group'];
                //}
                $groups[] = array('id_group' => $group['id_group'], 'name' => $group['name']);
            }
        }

        $this->fields_form = array(
            'legend' => array(
                'title' => $this->l('Catalog wholesale price rules (Only for resellers)'),
                'icon' => 'icon-dollar'
            ),
            'input' => array(
                array(
                    'type' => 'text',
                    'label' => $this->l('Name'),
                    'name' => 'name',
                    'maxlength' => 32,
                    'required' => true,
                    'hint' => $this->l('Forbidden characters').' <>;=#{}'
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Shop'),
                    'name' => 'shop_id',
                    'options' => array(
                        'query' => Shop::getShops(),
                        'id' => 'id_shop',
                        'name' => 'name'
                    ),
                    'condition' => Shop::isFeatureActive(),
                    'default_value' => Shop::getContextShopID()
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Currency'),
                    'name' => 'id_currency',
                    'options' => array(
                        'query' => array_merge(array(0 => array('id_currency' => 0, 'name' => $this->l('All currencies'))), Currency::getCurrencies(false, true, true)),
                        'id' => 'id_currency',
                        'name' => 'name'
                    ),
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Country'),
                    'name' => 'id_country',
                    'options' => array(
                        'query' => array_merge(array(0 => array('id_country' => 0, 'name' => $this->l('All countries'))), Country::getCountries((int)$this->context->language->id)),
                        'id' => 'id_country',
                        'name' => 'name'
                    ),
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Group'),
                    'name' => 'id_group',
                    'options' => array(
                        'query' => array_merge(array(0 => array('id_group' => 0, 'name' => $this->l('All groups'))), $groups),
                        'id' => 'id_group',
                        'name' => 'name'
                    ),
                ),
                array(
                    'type' => 'datetime',
                    'label' => $this->l('From'),
                    'name' => 'from'
                ),
                array(
                    'type' => 'datetime',
                    'label' => $this->l('To'),
                    'name' => 'to'
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Reduction / Charge'),
                    'name' => 'value',
                    'prefix' => '%',
                    'class' => 'fixed-width-sm',
                    'required' => true,
                ),
            ),
            'submit' => array(
                'title' => $this->l('Save')
            ),
        );

        $this->fields_value = array(
            'value' => number_format((($value = $this->getFieldValue($this->object, 'value')) ? $value : 0), 2),
            'shop_id' => (($value = $this->getFieldValue($this->object, 'id_shop')) ? $value : 1)
        );

        $attribute_groups = array();
        $attributes = Attribute::getAttributes((int)$this->context->language->id);
        foreach ($attributes as $attribute) {
            if (!isset($attribute_groups[$attribute['id_attribute_group']])) {
                $attribute_groups[$attribute['id_attribute_group']] = array(
                    'id_attribute_group' => $attribute['id_attribute_group'],
                    'name' => $attribute['attribute_group']
                );
            }
            $attribute_groups[$attribute['id_attribute_group']]['attributes'][] = array(
                'id_attribute' => $attribute['id_attribute'],
                'name' => $attribute['name']
            );
        }
        $features = Feature::getFeatures((int)$this->context->language->id);
        foreach ($features as &$feature) {
            $feature['values'] = FeatureValue::getFeatureValuesWithLang((int)$this->context->language->id, $feature['id_feature'], true);
        }

        $this->tpl_form_vars = array(
            'manufacturers' => Manufacturer::getManufacturers(),
            'suppliers' => Supplier::getSuppliers(),
            'attributes_group' => $attribute_groups,
            'features' => $features,
            'categories' => Category::getSimpleCategories((int)$this->context->language->id),
            'conditions' => $this->object->getConditions(),
            'is_multishop' => Shop::isFeatureActive()
            );
        return parent::renderForm();
    }

    public function processSave()
    {
        if (Validate::isLoadedObject(($object = parent::processSave()))) {
            $object->deleteConditions();
            foreach ($_POST as $key => $values) {
                if (preg_match('/^condition_group_([0-9]+)$/Ui', $key, $condition_group)) {
                    $conditions = array();
                    foreach ($values as $value) {
                        $condition = explode('_', $value);
                        $conditions[] = array('type' => $condition[0], 'value' => $condition[1]);
                    }
                    $object->addConditions($conditions);
                }
            }
            $object->apply();
            return $object;
        }
    }

    public function postProcess()
    {
        Tools::clearSmartyCache();
        return parent::postProcess();
    }

    public function getSpecificWholesalePriceList($product, $defaultCurrency, $shops, $currencies, $countries, $groups)
    {
        $content = array();
        $specific_prices = DssSpecificWholesalePriceClass::getByProductId((int)$product->id);

        $tmp = array();
        foreach ($shops as $shop) {
            $tmp[$shop['id_shop']] = $shop;
        }
        $shops = $tmp;
        $tmp = array();
        foreach ($currencies as $currency) {
            $tmp[$currency['id_currency']] = $currency;
        }
        $currencies = $tmp;

        $tmp = array();
        foreach ($countries as $country) {
            $tmp[$country['id_country']] = $country;
        }
        $countries = $tmp;

        $tmp = array();
        foreach ($groups as $group) {
            $tmp[$group['id_group']] = $group;
        }
        $groups = $tmp;

        if (is_array($specific_prices) && count($specific_prices)) {
            foreach ($specific_prices as $specific_price) {
                $id_currency = $specific_price['id_currency'] ? $specific_price['id_currency'] : $defaultCurrency->id;
                if (!isset($currencies[$id_currency])) {
                    continue;
                }

                if ($specific_price['value'] <> 0) {
                    $value = $specific_price['value'].' %';
                } else {
                    $value = '--';
                }

                if ($specific_price['from'] == '0000-00-00 00:00:00' && $specific_price['to'] == '0000-00-00 00:00:00') {
                    $period = $this->l('Unlimited');
                } else {
                    $period = $this->l('From').' '.($specific_price['from'] != '0000-00-00 00:00:00' ? $specific_price['from'] : '0000-00-00 00:00:00').'<br />'.$this->l('To').' '.($specific_price['to'] != '0000-00-00 00:00:00' ? $specific_price['to'] : '0000-00-00 00:00:00');
                }
                if ($specific_price['id_product_attribute']) {
                    $combination = new Combination((int)$specific_price['id_product_attribute']);
                    $attributes = $combination->getAttributesName((int)$this->context->language->id);
                    $attributes_name = '';
                    foreach ($attributes as $attribute) {
                        $attributes_name .= $attribute['name'].' - ';
                    }
                    $attributes_name = rtrim($attributes_name, ' - ');
                } else {
                    $attributes_name = $this->l('All combinations');
                }

                $rule = new DssSpecificWholesalePriceRuleClass((int)$specific_price['id_dss_specific_wholesale_price_rule']);
                $rule_name = ($rule->id ? $rule->name : '--');

                if (!$specific_price['id_shop'] || in_array($specific_price['id_shop'], Shop::getContextListShopID())) {
                    $can_delete_specific_prices = true;
                    if (Shop::isFeatureActive()) {
                        $can_delete_specific_prices = (count($this->context->employee->getAssociatedShops()) > 1 && !$specific_price['id_shop']) || $specific_price['id_shop'];
                    }

                    $value = Tools::ps_round($value, 2);

                    $content[] = array(
                        'id_specific_wholesale_price' => $specific_price['id_dss_specific_wholesale_price'],
                        'id_product' => $product->id,
                        'rule_name' => $rule_name,
                        'attributes_name' => $attributes_name,
                        'shop' => ($specific_price['id_shop'] ? $shops[$specific_price['id_shop']]['name'] : $this->l('All shops')),
                        'currency' => ($specific_price['id_currency'] ? $currencies[$specific_price['id_currency']]['name'] : $this->l('All currencies')),
                        'country' => ($specific_price['id_country'] ? $countries[$specific_price['id_country']]['name'] : $this->l('All countries')),
                        'group' => ($specific_price['id_group'] ? $groups[$specific_price['id_group']]['name'] : $this->l('All groups')),
                        'value' => $value,
                        'period' => $period,
                        'can_delete' => (!$rule->id && $can_delete_specific_prices) ? true : false
                    );
                }
            }
        }

        return $content;
    }

    public function ajaxProcessGetSpecificWholesalePriceList()
    {
        $id_product = (int)Tools::getValue('id_product');

        $content = '';
        $product = new Product((int)$id_product);

        if ($product->id) {
            $id_shop = (int)$this->context->shop->id;
            $shops = Shop::getShops();
            $countries = Country::getCountries($this->context->language->id);
            $currencies = Currency::getCurrencies();
            //$attributes = $product->getAttributesGroups((int)$this->context->language->id);

            $groups = array();
            $psgroups = Group::getGroups($this->context->language->id, $id_shop);
            $groupdef = array(Configuration::get('PS_UNIDENTIFIED_GROUP', null, null, $id_shop), Configuration::get('PS_GUEST_GROUP', null, null, $id_shop), Configuration::get('PS_CUSTOMER_GROUP', null, null, $id_shop));
            foreach ($psgroups as $group) {
                if (!in_array($group['id_group'], $groupdef)) {
                    $groups[] = array('id_group' => $group['id_group'], 'name' => $group['name']);
                }
            }

            $content = $this->getSpecificWholesalePriceList(
                $product,
                $this->context->currency,
                $shops,
                $currencies,
                $countries,
                $groups
            );
        }

        die(Tools::jsonEncode($content));
    }

    public function ajaxProcessAddSpecificWholesalePrice()
    {
        $data = array();
        parse_str(Tools::getValue('data'), $data);

        $id_product = (int)$data['form']['id_product'];

        $dssswp = new DssSpecificWholesalePriceClass();
        $errors = $dssswp->setSpecificWholesalePrice($id_product, $data);
        unset($dssswp);

        if (count($errors) > 0) {
            die(Tools::jsonEncode(array('success' => false, 'errors' => $errors)));
        } else {
            die(Tools::jsonEncode(array('success' => true)));
        }
    }
}
