<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminDropShipCreditHistoryController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'dss_payments_history';
        $this->className = 'DssPaymentsHistoryClass';
        $this->lang = false;
        $this->explicitSelect = false;
        $this->allow_export = true;

        parent::__construct();
        
        $this->context = Context::getContext();
        $this->default_form_language = $this->context->language->id;
        $id_shop = (int)$this->context->shop->id;

        $id_customer = (int)DssPaymentsHistoryClass::getCustomerIDByDropshipperID((int)Tools::getValue('id_dss_dropshipper'));

        $this->_select = 'id_payment_history AS id_dss_payments_history, IF(a.id_operator > 0, CONCAT(e.lastname, \' \', e.firstname), \'System\') AS operator ';
        $this->_join = 'LEFT JOIN '._DB_PREFIX_.'orders o ON o.id_order = a.id_order 
            LEFT JOIN '._DB_PREFIX_.'order_detail od ON od.id_order = o.id_order AND od.product_id = a.id_product ';
        if (Shop::isFeatureActive()) {
            $this->_join .= ' AND od.id_shop = '.(int)$id_shop.' ';
        }
        $this->_join .= 'LEFT JOIN '._DB_PREFIX_.'employee e ON e.id_employee = a.id_operator ';
        $this->_having = 'a.id_customer = '.(int)$id_customer;

        $this->_defaultOrderBy = 'a.request_date';
        $this->_defaultOrderWay = 'DESC';
        //if (Shop::isFeatureActive() && Shop::getContext() != Shop::CONTEXT_SHOP) {
        //    $this->_group = 'GROUP BY a.id_customer';
        //}

        $this->fields_list = array(
            'request_date' => array(
                'title' => $this->l('Request date'),
                'type' => 'datetime',
                'class' => 'fixed-width-xl',
                'orderby' => true,
                'havingFilter' => true,
            ),
            'reference' => array(
                'title' => $this->l('Order'),
                'type' => 'text',
                'orderby' => true,
                'havingFilter' => false,
                'filter_key' => 'o!reference'
            ),
            'product_name' => array(
                'title' => $this->l('Product'),
                'type' => 'text',
                'orderby' => true,
                'havingFilter' => false,
            ),
            'current_credit' => array(
                'title' => $this->l('Current credit'),
                'type' => 'text',
                'align' => 'text-center',
                'orderby' => true,
                'havingFilter' => false,
            ),
            'previous_credit' => array(
                'title' => $this->l('Previous credit'),
                'type' => 'text',
                'align' => 'text-center',
                'orderby' => true,
                'havingFilter' => false,
            ),
            'status' => array(
                'title' => $this->l('Status'),
                'type' => 'text',
                'align' => 'text-center',
                'orderby' => true,
                'havingFilter' => false,
            ),
            'operator' => array(
                'title' => $this->l('Operator'),
                'type' => 'text',
                'align' => 'text-center',
                'orderby' => true,
                'havingFilter' => false,
            ),
        );
    }

    public function initContent()
    {
        if ($this->display == 'view') {
            $this->renderView();
        }
        parent::initContent();
    }

    public function setMedia($isNewTheme = false)
    {
        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            parent::setMedia();
        } else {
            parent::setMedia($isNewTheme);
        }
        $this->context->controller->addJqueryPlugin('autocomplete');
        $this->addJS(_MODULE_DIR_.$this->module->name.'/views/js/customer.js');
    }

    public function renderList()
    {
        $this->addRowAction('view');
        //$this->addRowAction('view_order');
        return parent::renderList();
    }

    public function initPageHeaderToolbar()
    {
        parent::initPageHeaderToolbar();

        switch ($this->display) {
            case 'view':
                $this->page_header_toolbar_btn['back_to_list'] = array(
                    'href' => self::$currentIndex.'&token='.$this->token,
                    'desc' => $this->l('Back to list', null, null, false),
                    'icon' => 'process-icon-back'
                );
                break;
            default:
                $back = Tools::safeOutput(Tools::getValue('back', ''));
                if (empty($back)) {
                    $back = $this->context->link->getAdminLink('AdminDropShip', true).'&id_dss_dropshipper='.Tools::getValue('id_dss_dropshipper').'&updatedss_dropshipper';
                }
                $this->page_header_toolbar_btn['back_to_list'] = array(
                    'href' => $back,
                    'desc' => $this->l('Back', null, null, false),
                    'icon' => 'process-icon-back'
                );
        }
    }

    public function initToolbar()
    {
        switch ($this->display) {
            case 'view':
                $this->toolbar_btn['back'] = array(
                    'href' => self::$currentIndex.'&token='.$this->token,
                    'desc' => $this->l('Back to list', null, null, false)
                );
                break;
            default:
                $back = Tools::safeOutput(Tools::getValue('back', ''));
                if (empty($back)) {
                    $back = $this->context->link->getAdminLink('AdminDropShip', true).'&id_dss_dropshipper='.Tools::getValue('id_dss_dropshipper').'&updatedss_dropshipper';
                }
                $this->toolbar_btn['back'] = array(
                    'href' => $back,
                    'desc' => $this->l('Back', null, null, false)
                );
        }
    }
    
    public function renderView()
    {
        $this->display = 'view';
        $this->toolbar_title = sprintf($this->l('Payment #%06d'), Tools::getValue('id_dss_payments_history'));

        $dssph = new DssPaymentsHistoryClass(Tools::getValue('id_dss_payments_history'));
        if (!Validate::isLoadedObject($dssph)) {
            $this->errors[] = Tools::displayError('The payment cannot be found within your database.');
        }

        $this->tpl_view_vars = array(
            'creditdetails' => $dssph->getPaymentDetails($this->context->language->id),
            'back_url' => $this->context->link->getAdminLink('AdminDropShipCreditHistory', true).'&id_dss_dropshipper='.$dssph->getDropshipperIDByPaymentHistoryID($dssph->id),
        );

        $this->base_tpl_view = 'creditdetails_view.tpl';

        return parent::renderView();
    }
}
