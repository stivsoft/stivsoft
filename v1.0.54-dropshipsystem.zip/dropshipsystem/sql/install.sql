CREATE TABLE IF NOT EXISTS `PREFIX_dss_action_log` (
   `id_dss_action` BIGINT(16) UNSIGNED NOT NULL,
   `type` ENUM('categories', 'products', 'quantities') NOT NULL,
   `id_reference` INT NOT NULL,
   `reference` VARCHAR(45) NULL,
   `action` VARCHAR(45) NULL,
   `date_add` DATETIME NOT NULL,
  PRIMARY KEY (`id_dss_action`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_address` (
  `id_dss_address` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_dss_dropshipper` INT(10) UNSIGNED NOT NULL,
  `alias` VARCHAR(32) NOT NULL,
  `id_address` INT(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_dss_address`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_cart` (
  `id_dss_cart` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_shop` INT(11) UNSIGNED NOT NULL DEFAULT '1',
  `id_dropshipper` INT(10) UNSIGNED NOT NULL,
  `id_customer` INT(10) UNSIGNED NOT NULL,
  `id_address_delivery` INT(10) UNSIGNED NOT NULL,
  `id_address_invoice` INT(10) UNSIGNED NOT NULL,
  `id_carrier` INT(10) UNSIGNED NOT NULL,
  `id_currency` INT(10) UNSIGNED NOT NULL,
  `date_add` DATETIME NOT NULL,
  `date_upd` DATETIME NOT NULL,
  PRIMARY KEY (`id_dss_cart`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_cart_product` (
  `id_dss_cart` INT(10) UNSIGNED NOT NULL,
  `id_product` INT(10) UNSIGNED NOT NULL,
  `id_product_attribute` INT(10) UNSIGNED NOT NULL DEFAULT '0',
  `id_shop` INT(10) UNSIGNED NOT NULL DEFAULT '1',
  `quantity` INT(10) UNSIGNED NOT NULL DEFAULT '0',
  `date_add` DATETIME NOT NULL,
  PRIMARY KEY (`id_dss_cart`, `id_product`, `id_product_attribute`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_categories` (
  `id_dss_category` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_shop` INT UNSIGNED NOT NULL,
  `id_category` INT UNSIGNED NOT NULL,
  `dss_category_active` TINYINT(1) UNSIGNED NULL DEFAULT '0',
  `dss_category_code` VARCHAR(16) NULL DEFAULT NULL,
  `dss_category_code_parent` VARCHAR(16) NULL,
  PRIMARY KEY (`id_dss_category`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_dropshipper` (
  `id_dss_dropshipper` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_shop` int(10) UNSIGNED NOT NULL,
  `id_customer` int(10) unsigned NOT NULL,
  `id_operator` int(11) unsigned NOT NULL DEFAULT '0',
  `id_address_delivery` int(10) unsigned NOT NULL,
  `id_address_invoice` int(10) unsigned NOT NULL,
  `secret` varchar(32) DEFAULT NULL,
  `contact_name` varchar(255) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `contact_phone` varchar(64) DEFAULT NULL,
  `contact_mobile` varchar(64) DEFAULT NULL,
  `website` varchar(256) DEFAULT NULL,
  `feed_type` int(11) NOT NULL DEFAULT '1',
  `simple_feed` int(11) NOT NULL DEFAULT '0',
  `mask_quantity` int(11) NOT NULL DEFAULT '0',
  `direct_order` int(11) NOT NULL DEFAULT '1',
  `payment_type` enum('none','prepayed','postpayed') NOT NULL DEFAULT 'prepayed',
  `payment_method` VARCHAR(64) NOT NULL DEFAULT '',
  `credit` decimal(17,2) NOT NULL DEFAULT '0.00',
  `customer_tax_value` decimal(17,2) NOT NULL DEFAULT '0.00',
  `wholesale_reduction` decimal(17,2) NOT NULL,
  `reduction` decimal(17,2) NOT NULL DEFAULT '0.00',
  `daily_limit` decimal(17,2) NOT NULL DEFAULT '0.00',
  `monthly_limit` decimal(17,2) NOT NULL DEFAULT '0.00',
  `orders` int(11) NOT NULL DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '0',
  `low_credit_threshold` DECIMAL(17,2) NOT NULL DEFAULT '0',
  `hidden_product_prices` INT(1) NOT NULL DEFAULT '1',
  `notes` TEXT NULL,
  `last_order` datetime DEFAULT NULL,
  `last_connection` datetime DEFAULT NULL,
  `allowed_time` varchar(128) NULL DEFAULT NULL,
  `allowed_domains` TEXT NULL DEFAULT NULL,
  `date_end` date NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  PRIMARY KEY (`id_dss_dropshipper`),
  INDEX `index1` (`id_customer` ASC, `id_shop` ASC)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_employee` (
  `id_employee` INT UNSIGNED NOT NULL,
  `id_last_dropshipper` INT(10) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_employee`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_events` (
  `id_dss_event` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_shop` INT(11) UNSIGNED NOT NULL,
  `date` datetime NOT NULL,
  `type` enum('info','alert','error') NOT NULL,
  `handled_date` datetime DEFAULT NULL,
  `handled_by` INT(11) DEFAULT NULL,
  `message` text NOT NULL,
  `link` text,
  PRIMARY KEY (`id_dss_event`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_order` (
  `id_dss_order` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_order` int(10) unsigned NOT NULL,
  `id_dropshipper` int(11) NOT NULL,
  `id_shipping_address` int(11) NOT NULL,
  `id_billing_address` int(11) NOT NULL,
  `order_reference` varchar(128) NOT NULL,
  `shipping_method` int(1) NOT NULL,
  `payment_type` enum('none','prepayed','postpayed') NOT NULL DEFAULT 'prepayed',
  `total` decimal(17,2) NOT NULL DEFAULT '0.00',
  `previous_credit` decimal(17,2) DEFAULT '0.00',
  `current_credit` decimal(17,2) DEFAULT '0.00',
  `payment_link` text,
  `payment_gateway_link` text,
  PRIMARY KEY (`id_dss_order`),
  KEY `index1` (`id_order`,`id_dropshipper`,`order_reference`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_payments_history` (
  `id_payment_history` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_customer` int(10) unsigned NOT NULL,
  `id_operator` int(10) unsigned NOT NULL DEFAULT '0',
  `request_date` datetime NOT NULL,
  `status` enum('accepted','pending','rejected','error') NOT NULL DEFAULT 'pending',
  `currency` varchar(5) DEFAULT NULL,
  `previous_credit` decimal(17,2) NOT NULL DEFAULT '0.00',
  `id_product` int(11) NOT NULL,
  `buyed_credit` decimal(17,2) NOT NULL DEFAULT '0.00',
  `current_credit` decimal(17,2) NOT NULL DEFAULT '0.00',
  `id_order` int(11) DEFAULT NULL,
  `id_invoice` int(11) DEFAULT NULL,
  `token` varchar(64) NOT NULL,
  `payment_link` text,
  `transaction_id` varchar(64) DEFAULT NULL,
  `payment_status` varchar(64) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_payment_history`),
  UNIQUE KEY `token_UNIQUE` (`token`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_payments_token` (
  `id_dss_payment_token` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(64) NOT NULL,
  `status` ENUM('valid', 'cbok', 'cbko', 'used') NOT NULL DEFAULT 'valid',
  `payment_gateway` varchar(64) DEFAULT NULL,
  `id_order` int(11) unsigned NOT NULL DEFAULT '0',
  `is_credit` int(1) unsigned NOT NULL DEFAULT '0',
  `name` text NOT NULL,
  `custom_reference` text NOT NULL,
  `currency` varchar(10) NOT NULL,
  `amount` decimal(17,2) NOT NULL,
  `params` text NULL DEFAULT NULL,
  `return_url` text,
  `cancel_url` text,
  `date_add` datetime NOT NULL,
  PRIMARY KEY (`id_dss_payment_token`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_product_groups` (
  `id_product` INT UNSIGNED NOT NULL,
  `id_shop` INT(11) UNSIGNED NOT NULL,
  `group` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id_product`, `group`, `id_shop`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_specific_wholesale_price` (
  `id_dss_specific_wholesale_price` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_dss_specific_wholesale_price_rule` INT(11) UNSIGNED NOT NULL,
  `id_shop` INT(11) UNSIGNED NOT NULL DEFAULT '1',
  `id_product` INT(10) UNSIGNED NOT NULL,
  `id_product_attribute` INT(10) UNSIGNED NOT NULL,
  `id_currency` INT(10) UNSIGNED NOT NULL,
  `id_country` INT(10) UNSIGNED NOT NULL,
  `id_group` INT(10) UNSIGNED NOT NULL,
  `value` DECIMAL(20,6) NOT NULL,
  `from` DATETIME NOT NULL,
  `to` DATETIME NOT NULL,
  PRIMARY KEY (`id_dss_specific_wholesale_price`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_specific_wholesale_price_rule` (
  `id_dss_specific_wholesale_price_rule` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `id_shop` int(11) unsigned NOT NULL DEFAULT '1',
  `id_currency` int(10) unsigned NOT NULL,
  `id_country` int(10) unsigned NOT NULL,
  `id_group` int(10) unsigned NOT NULL,
  `value` decimal(20,6) NOT NULL,
  `from` datetime NOT NULL,
  `to` datetime NOT NULL,
  PRIMARY KEY (`id_dss_specific_wholesale_price_rule`),
  KEY `id_product` (`id_shop`,`id_currency`,`id_country`,`id_group`,`from`,`to`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_specific_wholesale_price_rule_condition` (
  `id_dss_specific_wholesale_price_rule_condition` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_dss_specific_wholesale_price_rule_condition_group` INT(11) UNSIGNED NOT NULL,
  `type` VARCHAR(255) NOT NULL,
  `value` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id_dss_specific_wholesale_price_rule_condition`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_specific_wholesale_price_rule_condition_group` (
  `id_dss_specific_wholesale_price_rule_condition_group` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_dss_specific_wholesale_price_rule` INT(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_dss_specific_wholesale_price_rule_condition_group`, `id_dss_specific_wholesale_price_rule`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_suppliers` (
  `id_supplier` INT(10) UNSIGNED NOT NULL,
  `id_shop` INT(11) UNSIGNED NOT NULL,
  `group` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_supplier`, `group`, `id_shop`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `PREFIX_dss_manufacturers` (
  `id_manufacturer` INT(10) UNSIGNED NOT NULL,
  `id_shop` INT(11) UNSIGNED NOT NULL,
  `group` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_manufacturer`, `group`, `id_shop`)
) ENGINE=ENGINE_TYPE DEFAULT CHARSET=utf8;
