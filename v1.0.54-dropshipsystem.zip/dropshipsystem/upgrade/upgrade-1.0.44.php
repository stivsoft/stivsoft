<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_44($object)
{
    $object->uninstallOverrides();
    $object->installOverrides();

    Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'dss_suppliers` (
        `id_supplier` INT(10) UNSIGNED NOT NULL,
        `id_shop` INT(11) UNSIGNED NOT NULL,
        `group` INT UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY (`id_supplier`, `group`, `id_shop`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8');

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_suppliers`
        CHANGE COLUMN `group` `group` INT(10) UNSIGNED NOT NULL DEFAULT 0,
        DROP PRIMARY KEY,
        ADD PRIMARY KEY (`id_supplier`, `id_shop`, `group`)');

    Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'dss_manufacturers` (
        `id_manufacturer` INT(10) UNSIGNED NOT NULL,
        `id_shop` INT(11) UNSIGNED NOT NULL,
        `group` INT UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY (`id_manufacturer`, `group`, `id_shop`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8');

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_manufacturers`
        CHANGE COLUMN `group` `group` INT(10) UNSIGNED NOT NULL DEFAULT 0,
        DROP PRIMARY KEY,
        ADD PRIMARY KEY (`id_manufacturer`, `id_shop`, `group`)');

    Configuration::updateValue('DSS_VERSION', '1.0.44');
    return true;
}
