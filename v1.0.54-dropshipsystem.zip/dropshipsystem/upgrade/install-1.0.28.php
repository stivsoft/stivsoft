<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_28($object)
{
    $context = Context::getContext();
    $id_shop = (int)$context->shop->id;
    $id_def_lang = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);

    $object->uninstallOverrides();
    $object->installOverrides();

    $object->registerHook('actionAdminControllerSetMedia');
    $object->registerHook('AdminStatsModules');

    if (version_compare(_PS_VERSION_, '1.7', '<')) {
        $admin_parent_cart_rule = (int)Tab::getIdFromClassName('AdminPriceRule');
    } else {
        $admin_parent_cart_rule = (int)Tab::getIdFromClassName('AdminParentCartRules');
    }

    $object->installModuleTab('AdminDropShipSpecificWholesalePriceRule', array($id_def_lang => 'Catalog Wholesale Price Rules'), $admin_parent_cart_rule, 2);

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_dropshipper` 
        ADD COLUMN `allowed_time` VARCHAR(128) NULL AFTER `last_connection`');

    Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'dss_specific_wholesale_price` (
        `id_dss_specific_wholesale_price` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
        `id_dss_specific_wholesale_price_rule` INT(11) UNSIGNED NOT NULL,
        `id_shop` INT(11) UNSIGNED NOT NULL DEFAULT \'1\',
        `id_product` INT(10) UNSIGNED NOT NULL,
        `id_product_attribute` INT(10) UNSIGNED NOT NULL,
        `id_currency` INT(10) UNSIGNED NOT NULL,
        `id_country` INT(10) UNSIGNED NOT NULL,
        `id_group` INT(10) UNSIGNED NOT NULL,
        `value` DECIMAL(20,6) NOT NULL,
        `from` DATETIME NOT NULL,
        `to` DATETIME NOT NULL,
        PRIMARY KEY (`id_dss_specific_wholesale_price`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8');

    Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'dss_specific_wholesale_price_rule` (
        `id_dss_specific_wholesale_price_rule` int(10) unsigned NOT NULL AUTO_INCREMENT,
        `name` varchar(255) NOT NULL,
        `id_shop` int(11) unsigned NOT NULL DEFAULT \'1\',
        `id_currency` int(10) unsigned NOT NULL,
        `id_country` int(10) unsigned NOT NULL,
        `id_group` int(10) unsigned NOT NULL,
        `value` decimal(20,6) NOT NULL,
        `from` datetime NOT NULL,
        `to` datetime NOT NULL,
        PRIMARY KEY (`id_dss_specific_wholesale_price_rule`),
        KEY `id_product` (`id_shop`,`id_currency`,`id_country`,`id_group`,`from`,`to`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8');

    Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'dss_specific_wholesale_price_rule_condition` (
        `id_dss_specific_wholesale_price_rule_condition` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `id_dss_specific_wholesale_price_rule_condition_group` INT(11) UNSIGNED NOT NULL,
        `type` VARCHAR(255) NOT NULL,
        `value` VARCHAR(255) NOT NULL,
        PRIMARY KEY (`id_dss_specific_wholesale_price_rule_condition`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8');

    Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'dss_specific_wholesale_price_rule_condition_group` (
        `id_dss_specific_wholesale_price_rule_condition_group` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `id_dss_specific_wholesale_price_rule` INT(11) UNSIGNED NOT NULL,
        PRIMARY KEY (`id_dss_specific_wholesale_price_rule_condition_group`, `id_dss_specific_wholesale_price_rule`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8');

    Configuration::updateValue('DSS_VERSION', '1.0.28');
    return true;
}
