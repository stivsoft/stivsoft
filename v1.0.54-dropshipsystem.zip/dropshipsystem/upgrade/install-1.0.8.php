<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_8($object)
{
    $object->uninstallOverrides();
    $object->installOverrides();

    $id_shop_default = (int)Configuration::get('PS_SHOP_DEFAULT');

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_dropshipper` 
        ADD COLUMN `id_shop` INT(11) UNSIGNED NOT NULL AFTER `id_dss_dropshipper`');

    Db::getInstance()->Execute('UPDATE `'._DB_PREFIX_.'dss_dropshipper` 
        SET `id_shop` = '.(int)$id_shop_default);

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_categories` 
        ADD COLUMN `id_shop` INT(11) UNSIGNED NOT NULL AFTER `id_dss_category`');

    Db::getInstance()->Execute('UPDATE `'._DB_PREFIX_.'dss_categories` 
        SET `id_shop` = '.(int)$id_shop_default);

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_events` 
        ADD COLUMN `id_shop` INT(11) UNSIGNED NOT NULL AFTER `id_dss_event`');

    Db::getInstance()->Execute('UPDATE `'._DB_PREFIX_.'dss_events` 
        SET `id_shop` = '.(int)$id_shop_default);

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_suppliers` 
        ADD COLUMN `id_shop` INT(11) UNSIGNED NOT NULL AFTER `id_supplier`');

    Db::getInstance()->Execute('UPDATE `'._DB_PREFIX_.'dss_suppliers` 
        SET `id_shop` = '.(int)$id_shop_default);

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_manufacturers` 
        ADD COLUMN `id_shop` INT(11) UNSIGNED NOT NULL AFTER `id_manufacturer`');

    Db::getInstance()->Execute('UPDATE `'._DB_PREFIX_.'dss_manufacturers` 
        SET `id_shop` = '.(int)$id_shop_default);

    $clients = array(
        array(
            'name' => 'dropshipclient_presta16',
            'version' => '1.0.5',
            'date' => '20170408'
        ),
    );

    Configuration::updateValue('DSS_CLIENTS', serialize($clients));

    Configuration::updateValue('DSS_VERSION', '1.0.8');
    return true;
}
