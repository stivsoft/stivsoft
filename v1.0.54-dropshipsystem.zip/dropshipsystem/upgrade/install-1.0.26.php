<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_26($object)
{
    $object->uninstallOverrides();
    $object->installOverrides();

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_dropshipper` 
        CHANGE COLUMN `payment_type` `payment_type` ENUM(\'none\',\'prepayed\',\'postpayed\') NOT NULL DEFAULT \'prepayed\'');

    Configuration::updateValue('DSS_VERSION', '1.0.26');
    return true;
}
