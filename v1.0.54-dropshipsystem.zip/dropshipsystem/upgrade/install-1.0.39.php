<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_39($object)
{
    $object->registerHook('actionEmailSendBefore');

    if (version_compare(_PS_VERSION_, '1.7', '<')) {
        $object->registerHook('displayProductButtons');
        $object->updateHookPosition('displayProductButtons', 0, 0);
    } else {
        $object->registerHook('displayProductAdditionalInfo');
        $object->updateHookPosition('displayProductAdditionalInfo', 0, 0);
    }

    Configuration::updateValue('DSS_CUSTOMER_MAILS', 0);

    $exist = (int)Db::getInstance()->Execute('SELECT `order_reference` FROM `'._DB_PREFIX_.'dss_order`');
    if (!$exist) {
        Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_order` 
            ADD COLUMN `order_reference` VARCHAR(128) NULL AFTER `id_billing_address`');
    }

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_dropshipper` 
        CHANGE COLUMN `payment_type` `payment_type` ENUM(\'none\',\'prepayed\',\'postpayed\') NOT NULL DEFAULT \'prepayed\'');

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_dropshipper` 
        ADD COLUMN `direct_order` INT NOT NULL DEFAULT 1 AFTER `simple_feed`');

    Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'dss_cart` (
      `id_dss_cart` INT UNSIGNED NOT NULL AUTO_INCREMENT,
      `id_shop` INT(11) UNSIGNED NOT NULL DEFAULT \'1\',
      `id_dropshipper` INT(10) UNSIGNED NOT NULL,
      `id_customer` INT(10) UNSIGNED NOT NULL,
      `id_address_delivery` INT(10) UNSIGNED NOT NULL,
      `id_address_invoice` INT(10) UNSIGNED NOT NULL,
      `id_carrier` INT(10) UNSIGNED NOT NULL,
      `id_currency` INT(10) UNSIGNED NOT NULL,
      `date_add` DATETIME NOT NULL,
      `date_upd` DATETIME NOT NULL,
      PRIMARY KEY (`id_dss_cart`)
    ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8');

    Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'dss_cart_product` (
      `id_dss_cart` INT(10) UNSIGNED NOT NULL,
      `id_product` INT(10) UNSIGNED NOT NULL,
      `id_product_attribute` INT(10) UNSIGNED NOT NULL DEFAULT \'0\',
      `id_shop` INT(10) UNSIGNED NOT NULL DEFAULT \'1\',
      `quantity` INT(10) UNSIGNED NOT NULL DEFAULT \'0\',
      `date_add` DATETIME NOT NULL,
      PRIMARY KEY (`id_dss_cart`, `id_product`, `id_product_attribute`)
    ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8');

    $clients = array(
        array(
            'name' => 'dropshipclient_presta',
            'version' => '1.0.33',
            'date' => '20180420'
        ),
    );

    Configuration::updateValue('DSS_CLIENTS', serialize($clients));

    Configuration::updateValue('DSS_VERSION', '1.0.39');
    return true;
}
