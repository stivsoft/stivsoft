<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_17($object)
{
    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_dropshipper` 
        ADD COLUMN `id_shop` INT UNSIGNED NOT NULL AFTER `id_dss_dropshipper`');

    $clients = array(
        array(
            'name' => 'dropshipclient_presta16',
            'version' => '1.0.15',
            'date' => '20170713'
        ),
    );

    Configuration::updateValue('DSS_CLIENTS', serialize($clients));

    Configuration::updateValue('DSS_VERSION', '1.0.17');
    return true;
}
