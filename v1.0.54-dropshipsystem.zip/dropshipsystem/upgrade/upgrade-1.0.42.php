<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_42($object)
{
    $object->uninstallOverrides();
    $object->installOverrides();

    Db::getInstance()->Execute('UPDATE `'._DB_PREFIX_.'order_state` 
        SET `logable` = 1 WHERE `module_name` = \'dropship\'');

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_dropshipper` 
        ADD COLUMN `hidden_product_prices` INT(1) NOT NULL DEFAULT 1 AFTER `low_credit_threshold`');

    Configuration::updateValue('DSS_VERSION', '1.0.42');
    return true;
}
