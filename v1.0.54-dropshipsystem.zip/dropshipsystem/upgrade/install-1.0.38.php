<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_38($object)
{
    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_order` 
        CHANGE COLUMN `order_reference` `order_reference` VARCHAR(128) NOT NULL,
        ADD INDEX `index1` (`id_order` ASC, `id_dropshipper` ASC, `order_reference` ASC)');

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_dropshipper` 
        ADD INDEX `index1` (`id_customer` ASC, `id_shop` ASC)');

    Configuration::updateValue('DSS_VERSION', '1.0.38');
    return true;
}
