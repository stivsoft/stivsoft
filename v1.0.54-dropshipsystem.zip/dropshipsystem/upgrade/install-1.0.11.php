<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_11($object)
{
    Db::getInstance()->Execute('TRUNCATE TABLE `'._DB_PREFIX_.'dss_action_log`');

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_action_log` 
        CHANGE COLUMN `id_dss_action` `id_dss_action` INT(10) UNSIGNED NOT NULL');

    $clients = array(
        array(
            'name' => 'dropshipclient_presta16',
            'version' => '1.0.9',
            'date' => '20170520'
        ),
    );

    Configuration::updateValue('DSS_CLIENTS', serialize($clients));

    Configuration::updateValue('DSS_VERSION', '1.0.11');
    return true;
}
