<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_4($object)
{
    /* Update hooks */
    $object->registerHook('actionAdminSuppliersListingFieldsModifier');
    $object->registerHook('actionAdminSuppliersFormModifier');
    $object->registerHook('actionAdminSuppliersControllerSaveAfter');
    $object->registerHook('actionAdminManufacturersListingFieldsModifier');
    $object->registerHook('actionAdminManufacturersFormModifier');
    $object->registerHook('actionAdminManufacturersControllerSaveAfter');

    Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'dss_product_groups` (
      `id_product` INT UNSIGNED NOT NULL,
      `group` INT UNSIGNED NOT NULL,
      PRIMARY KEY (`id_product`, `group`)
      ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8');

    Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'dss_suppliers` (
      `id_dss_supplier` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
      `id_supplier` INT(10) UNSIGNED NOT NULL,
      `dss_supplier_active` TINYINT(1) UNSIGNED NULL DEFAULT \'0\',
      `dss_supplier_group` INT UNSIGNED NULL,
      PRIMARY KEY (`id_dss_supplier`)
      ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8');

    Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'dss_manufacturers` (
      `id_dss_manufacturer` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
      `id_manufacturer` INT(10) UNSIGNED NOT NULL,
      `dss_manufacturer_active` TINYINT(1) UNSIGNED NULL DEFAULT \'0\',
      `dss_manufacturer_group` INT UNSIGNED NULL,
      PRIMARY KEY (`id_dss_manufacturer`)
      ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8');

    Configuration::updateValue('DSS_VERSION', '1.0.4');
    return true;
}
