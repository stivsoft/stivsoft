<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_27($object)
{
    $object->registerHook('displayAdminProductsExtra');

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_suppliers`
        CHANGE COLUMN `id_supplier` `id_supplier` INT(10) UNSIGNED NOT NULL,
        DROP PRIMARY KEY,
        ADD PRIMARY KEY (`id_supplier`, `group`, `id_shop`)');

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_manufacturers`
        CHANGE COLUMN `id_manufacturer` `id_manufacturer` INT(10) UNSIGNED NOT NULL,
        DROP PRIMARY KEY,
        ADD PRIMARY KEY (`id_manufacturer`, `group`, `id_shop`)');

    try {
        Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_product_groups`
            ADD COLUMN `id_shop` INT(11) UNSIGNED NOT NULL AFTER `id_product`,
            DROP PRIMARY KEY,
            ADD PRIMARY KEY (`id_product`, `group`, `id_shop`)');
    } catch (Exception $e) {
        echo 'ok';
    }

    Db::getInstance()->Execute('UPDATE `'._DB_PREFIX_.'dss_product_groups` SET `id_shop` = 1');

    Configuration::updateValue('DSS_VERSION', '1.0.27');
    return true;
}
