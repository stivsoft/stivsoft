<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_45($object)
{
    Configuration::updateValue('DSS_MASK_REAL_QUANTITY_VALUE', 10);

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_dropshipper` 
        ADD COLUMN `mask_quantity` INT(11) NOT NULL DEFAULT 0 AFTER `simple_feed`');

    Configuration::updateValue('DSS_VERSION', '1.0.45');
    return true;
}
