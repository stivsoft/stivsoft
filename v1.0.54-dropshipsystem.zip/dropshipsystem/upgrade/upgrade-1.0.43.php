<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_43($object)
{
    $object->registerHook('registerGDPRConsent');
    $object->registerHook('actionDeleteGDPRCustomer');
    $object->registerHook('actionExportGDPRData');

    Configuration::updateValue('DSS_PAYPAL_ACTIVE', 1);
    Configuration::updateValue('DSS_DEFAULT_PAYMENT_GATEWAY', 'payment_paypal');

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_dropshipper` 
        ADD COLUMN `payment_method` VARCHAR(64) NOT NULL DEFAULT \'\' AFTER `payment_type`');

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_order` 
        CHANGE COLUMN `paypal_link` `payment_gateway_link` TEXT NULL DEFAULT NULL');

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_paypal_order` 
        DROP COLUMN `payment_status`,
        DROP COLUMN `capture`,
        DROP COLUMN `shipping`,
        DROP COLUMN `id_invoice`,
        DROP COLUMN `id_transaction`,
        CHANGE COLUMN `payment_date` `token` VARCHAR(64) NOT NULL AFTER `id_dss_payment_token`,
        CHANGE COLUMN `id_order` `id_dss_payment_token` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
        CHANGE COLUMN `total_paid` `amount` DECIMAL(17,2) NOT NULL,
        CHANGE COLUMN `payment_method` `return_url` TEXT NULL,
        ADD COLUMN `status` ENUM(\'valid\', \'cbok\', \'cbko\', \'used\') NOT NULL DEFAULT \'valid\' AFTER `token`,
        ADD COLUMN `payment_gateway` VARCHAR(64) NULL DEFAULT NULL AFTER `status`,
        ADD COLUMN `id_order` INT(11) UNSIGNED NOT NULL DEFAULT 0 AFTER `payment_gateway`,
        ADD COLUMN `is_credit` INT(1) UNSIGNED NOT NULL DEFAULT 0 AFTER `id_order`,
        ADD COLUMN `name` TEXT NOT NULL AFTER `is_credit`,
        ADD COLUMN `custom_reference` TEXT NOT NULL AFTER `name`,
        ADD COLUMN `params` TEXT NULL DEFAULT NULL AFTER `amount`,
        ADD COLUMN `cancel_url` TEXT NULL AFTER `return_url`,
        ADD COLUMN `date_add` DATETIME NOT NULL AFTER `cancel_url`, 
        RENAME TO `'._DB_PREFIX_.'dss_payments_token`');

    Configuration::updateValue('DSS_VERSION', '1.0.43');
    return true;
}
