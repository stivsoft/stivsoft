<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_12($object)
{
    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_dropshipper` 
        ADD COLUMN `daily_limit` DECIMAL(17,2) NOT NULL DEFAULT 0 AFTER `reduction`,
        ADD COLUMN `monthly_limit` DECIMAL(17,2) NOT NULL DEFAULT 0 AFTER `daily_limit`');

    $clients = array(
        array(
            'name' => 'dropshipclient_presta16',
            'version' => '1.0.10',
            'date' => '20170605'
        ),
    );

    Configuration::updateValue('DSS_CLIENTS', serialize($clients));

    Configuration::updateValue('DSS_VERSION', '1.0.12');
    return true;
}
