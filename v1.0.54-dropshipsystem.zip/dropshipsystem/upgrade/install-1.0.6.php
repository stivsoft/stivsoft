<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_6($object)
{
    $object->uninstallOverrides();
    $object->installOverrides();

    /* Update hooks */
    $object->registerHook('displayAdminAfterHeader');

    Configuration::updateValue('DSS_DROPSHIPPERS_REGISTRATION', 1);
    Configuration::updateValue('DSS_NOTIFY_DROPSHIPPERS', 1);

    Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'dss_employee` (
          `id_employee` INT UNSIGNED NOT NULL,
          `id_last_dropshipper` INT(10) UNSIGNED NOT NULL DEFAULT \'0\',
          PRIMARY KEY (`id_employee`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8');

    $clients = array(
        array(
            'name' => 'dropshipclient_presta16',
            'version' => '1.0.4',
            'date' => '20170321'
        ),
    );

    Configuration::updateValue('DSS_CLIENTS', serialize($clients));

    Configuration::updateValue('DSS_VERSION', '1.0.6');
    return true;
}
