<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_1($object)
{
    $id_def_lang = (int)Configuration::get('PS_LANG_DEFAULT');

    /* Update hooks */
    $object->registerHook('actionCarrierUpdate');
    $object->registerHook('adminCustomers');

    if (version_compare(_PS_VERSION_, '1.6', '>=')) {
        $object->registerHook('dashboardData');
        $object->registerHook('dashboardZoneTwo');

        $id_hook = Hook::get('dashboardZoneTwo');
        for ($i = 0; $i < 50; $i++) {
            $object->updatePosition($id_hook, 0, 0);
        }
    }

    $object->installModuleTab('AdminDropShipCreditHistory', array($id_def_lang => 'Dropshippers Credit History'), -1, 0, 0);

    Configuration::updateValue('DSS_NBR_SHOW_LAST_ORDER', 10);
    Configuration::updateValue('DSS_NBR_SHOW_BEST_DROPSHIPPERS', 10);

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_dropshipper` 
        ADD COLUMN `id_operator` INT(11) UNSIGNED NOT NULL DEFAULT \'0\' AFTER `id_customer`,
        ADD COLUMN `id_address_delivery` INT(10) UNSIGNED NOT NULL AFTER `id_operator`,
        ADD COLUMN `id_address_invoice` INT(10) UNSIGNED NOT NULL AFTER `id_address_delivery`,
        ADD COLUMN `contact_name` VARCHAR(255) NULL AFTER `secret`,
        ADD COLUMN `contact_email` VARCHAR(255) NULL DEFAULT NULL AFTER `contact_name`,
        ADD COLUMN `contact_phone` VARCHAR(64) NULL DEFAULT NULL AFTER `contact_email`,
        ADD COLUMN `contact_mobile` VARCHAR(64) NULL AFTER `contact_phone`,
        ADD COLUMN `website` VARCHAR(256) NULL DEFAULT NULL AFTER `contact_mobile`,
        ADD COLUMN `payment_type` ENUM(\'none\',\'prepayed\',\'postpayed\') NOT NULL DEFAULT \'prepayed\' AFTER `simple_feed`,
        ADD COLUMN `credit` DECIMAL(17,2) NOT NULL DEFAULT \'0.00\' AFTER `payment_type`,
        ADD COLUMN `low_credit_threshold` DECIMAL(17,2) NOT NULL DEFAULT \'0.00\' AFTER `active`,
        ADD COLUMN `notes` TEXT NULL AFTER `low_credit_threshold`,
        ADD COLUMN `date_end` DATE NULL AFTER `last_connection`');

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_order` 
        ADD COLUMN `shipping_method` INT(1) NOT NULL AFTER `id_billing_address`,
        ADD COLUMN `payment_type` ENUM(\'prepayed\',\'postpayed\') NOT NULL DEFAULT \'prepayed\' AFTER `shipping_method`,
        ADD COLUMN `total` DECIMAL(17,2) NOT NULL DEFAULT \'0.00\' AFTER `payment_type`,
        ADD COLUMN `previous_credit` DECIMAL(17,2) NULL DEFAULT \'0.00\' AFTER `total`,
        ADD COLUMN `current_credit` DECIMAL(17,2) NULL DEFAULT \'0.00\' AFTER `previous_credit`,
        ADD COLUMN `payment_link` TEXT NULL DEFAULT NULL AFTER `current_credit`,
        ADD COLUMN `paypal_link` TEXT NULL DEFAULT NULL AFTER `payment_link`');

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_payments_history` 
        CHANGE COLUMN `id_dropshipper` `id_customer` INT(10) UNSIGNED NOT NULL,
        CHANGE COLUMN `date_payment` `request_date` DATETIME NOT NULL,
        ADD COLUMN `id_operator` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `id_customer`,
        ADD COLUMN `id_product` INT NOT NULL AFTER `previous_credit`,
        ADD COLUMN `id_order` INT NULL AFTER `current_credit`,
        ADD COLUMN `payment_date` DATETIME NULL AFTER `payment_status`');

    Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'dss_events` (
        `id_dss_event` int(10) unsigned NOT NULL AUTO_INCREMENT,
        `date` datetime NOT NULL,
        `type` enum(\'info\',\'alert\',\'error\') NOT NULL,
        `handled_date` datetime DEFAULT NULL,
        `handled_by` int(11) DEFAULT NULL,
        `message` text NOT NULL,
        `link` text,
        PRIMARY KEY (`id_dss_event`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8');

    Configuration::updateValue('DSS_VERSION', '1.0.1');
    return true;
}
