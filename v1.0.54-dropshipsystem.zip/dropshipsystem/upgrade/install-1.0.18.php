<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_18($object)
{
    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_action_log` 
        CHANGE COLUMN `id_dss_action` `id_dss_action` BIGINT(16) UNSIGNED NOT NULL ,
        DROP PRIMARY KEY,
        ADD PRIMARY KEY (`id_dss_action`)');

    $clients = array(
        array(
            'name' => 'dropshipclient_presta16',
            'version' => '1.0.16',
            'date' => '20170911'
        ),
    );

    Configuration::updateValue('DSS_CLIENTS', serialize($clients));

    Configuration::updateValue('DSS_VERSION', '1.0.18');
    return true;
}
