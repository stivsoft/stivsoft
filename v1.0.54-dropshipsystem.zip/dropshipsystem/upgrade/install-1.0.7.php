<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_7($object)
{
    Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'dss_address` (
          `id_dss_address` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
          `id_dss_dropshipper` INT(10) UNSIGNED NOT NULL,
          `alias` VARCHAR(32) NOT NULL,
          `id_address` INT(10) UNSIGNED NOT NULL,
          PRIMARY KEY (`id_dss_address`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8');

    Configuration::updateValue('DSS_VERSION', '1.0.7');
    return true;
}
