<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_36($object)
{
    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_order` 
        ADD COLUMN `order_reference` VARCHAR(128) NULL AFTER `id_billing_address`');

    Configuration::updateValue('DSS_VERSION', '1.0.36');
    return true;
}
