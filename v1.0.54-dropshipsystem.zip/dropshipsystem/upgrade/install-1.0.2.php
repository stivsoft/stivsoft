<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_2($object)
{
    $id_def_lang = (int)Configuration::get('PS_LANG_DEFAULT');

    /* Update hooks */
    $object->registerHook('actionCategoryAdd');
    $object->registerHook('actionCategoryUpdate');
    $object->registerHook('actionCategoryDelete');
    $object->registerHook('actionProductAdd');
    $object->registerHook('actionProductUpdate');
    $object->registerHook('actionProductDelete');
    $object->registerHook('actionProductOutOfStock');
    $object->registerHook('actionUpdateQuantity');
    $object->registerHook('displayAdminProductsExtra');

    Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'dss_action_log` (
      `id_dss_action` INT UNSIGNED NOT NULL AUTO_INCREMENT,
      `type` ENUM(\'categories\', \'products\', \'quantities\') NOT NULL,
      `id_reference` INT NOT NULL,
      `date_add` DATETIME NOT NULL,
      PRIMARY KEY (`id_dss_action`)
      ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8');

    Configuration::updateValue('DSS_VERSION', '1.0.2');
    return true;
}
