<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_5($object)
{
    $object->uninstallOverrides();
    $object->installOverrides();

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_suppliers` 
        DROP COLUMN `dss_supplier_active`,
        DROP COLUMN `id_dss_supplier`,
        CHANGE COLUMN `dss_supplier_group` `group` INT(10) UNSIGNED NOT NULL ,
        DROP PRIMARY KEY,
        ADD PRIMARY KEY (`id_supplier`, `group`)');

    Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'dss_manufacturers` 
        DROP COLUMN `dss_manufacturer_active`,
        DROP COLUMN `id_dss_manufacturer`,
        CHANGE COLUMN `dss_manufacturer_group` `group` INT(10) UNSIGNED NOT NULL ,
        DROP PRIMARY KEY,
        ADD PRIMARY KEY (`id_manufacturer`, `group`)');

    $clients = array(
        array(
            'name' => 'dropshipclient_presta16',
            'version' => '1.0.3',
            'date' => '20170216'
        ),
    );

    Configuration::updateValue('DSS_CLIENTS', serialize($clients));

    Configuration::updateValue('DSS_VERSION', '1.0.5');
    return true;
}
