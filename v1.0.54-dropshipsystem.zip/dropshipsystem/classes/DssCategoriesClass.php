<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class DssCategoriesClass extends ObjectModel
{
    public $id;

    /** @var int ID Shop */
    public $id_shop;

    /** @var int ID Category */
    public $id_category;

    /** @var bool dss_category_active */
    public $dss_category_active = 1;

    /** @var string dss_category_code */
    public $dss_category_code;

    /** @var string dss_category_code_parent */
    public $dss_category_code_parent;

    public static $definition = array(
        'table' => 'dss_categories',
        'primary' => 'id_dss_category',
        'fields' => array(
            'id_shop'                   => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true),
            'id_category'               => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true),
            'dss_category_active'       => array('type' => self::TYPE_BOOL, 'validate' => 'isBool', 'required' => true),
            'dss_category_code'         => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 16),
            'dss_category_code_parent'  => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 16),
        ),
    );

    public static function getDssCategoryID($id_category)
    {
        return (int)Db::getInstance()->getValue('
            SELECT `id_dss_category`
            FROM  `'._DB_PREFIX_.'dss_categories`
            WHERE `id_category` = '.(int)$id_category.Shop::addSqlRestrictionOnLang());
    }

    public static function getDSSParentCode($parent = false, $id_parent = null, $id_category = null)
    {
        if (!isset($id_parent)) {
            $id_parent = (int)Tools::getValue('id_parent');
        }
        if (!isset($id_category)) {
            $id_category = (int)Tools::getValue('id_category');
        }

        $sql = 'SELECT `dssc`.`dss_category_code`
            FROM `'._DB_PREFIX_.'category` `c`
            '.Shop::addSqlAssociation('category', 'c').'
            INNER JOIN `'._DB_PREFIX_.'dss_categories` `dssc`
            ON `dssc`.`id_category` = `c`.`id_category`'.Shop::addSqlRestrictionOnLang('dssc').'
            WHERE `c`.`id_category` = ';
        if ($parent) {
            $sql .= (int)$id_parent;
        } else {
            $sql .= '(SELECT DISTINCT `c2`.`id_parent`
                FROM `'._DB_PREFIX_.'category` `c2`
                '.Shop::addSqlAssociation('category', 'c2').'
                WHERE `c2`.`id_category` = '.(int)$id_category.')';
        }
        $code = Db::getInstance()->getValue($sql);
        return isset($code) ? $code : '';
    }

    public static function isCategoryActive($id_category)
    {
        return (int)Db::getInstance()->getValue('
            SELECT `dss_category_active`
            FROM  `'._DB_PREFIX_.'dss_categories`
            WHERE `id_category` = '.(int)$id_category.Shop::addSqlRestrictionOnLang());
    }

    public static function setCategoryUniqueCodes($ucodes, $overwrite = false)
    {
        $id_shop = (int)Context::getContext()->shop->id;

        $res = true;

        if (isset($ucodes) && $ucodes) {
            foreach ($ucodes as $id_category => $ucode) {
                $id_dss_category = (int)Db::getInstance()->getValue('
                    SELECT `id_dss_category`
                    FROM  `'._DB_PREFIX_.'dss_categories`
                    WHERE `id_category` = '.(int)$id_category.'
                    AND `id_shop` = '.(int)$id_shop);

                if ($id_dss_category) {
                    if ($overwrite) {
                        if (!Db::getInstance()->execute('
                            UPDATE `'._DB_PREFIX_.'dss_categories`
                            SET `dss_category_code` = \''.(string)$ucode['code'].'\',
                            `dss_category_code_parent` = \''.(string)$ucode['parent'].'\'
                            WHERE `id_dss_category` = '.(int)$id_dss_category)) {
                            $res = false;
                            break;
                        }
                    }
                } else {
                    if (!Db::getInstance()->execute('
                        INSERT INTO `'._DB_PREFIX_.'dss_categories`
                        (`id_shop`, `id_category`, `dss_category_active`, `dss_category_code`, `dss_category_code_parent`) VALUES
                        ('.(int)$id_shop.', '.(int)$id_category.', 1, \''.(string)$ucode['code'].'\', \''.(string)$ucode['parent'].'\')')) {
                        $res = false;
                        break;
                    }
                }
            }
        }
        return $res;
    }

    public function clearOrphans()
    {
        return Db::getInstance()->execute('
            DELETE FROM `'._DB_PREFIX_.'dss_categories`
            WHERE `id_category` NOT IN (SELECT `id_category` FROM `'._DB_PREFIX_.'category`)
            '.Shop::addSqlRestrictionOnLang());
    }
}
