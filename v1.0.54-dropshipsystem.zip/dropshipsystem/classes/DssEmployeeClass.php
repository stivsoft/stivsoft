<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class DssEmployeeClass extends ObjectModel
{
    public $id;
    public $id_last_dropshipper;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'dss_employee',
        'primary' => 'id_employee',
        'fields' => array(
            'id_employee' =>            array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            'id_last_dropshipper' =>    array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
        ),
    );

    public static function existsEmployee($id_employee)
    {
        $ret = (int)Db::getInstance()->getValue('
            SELECT COUNT(*) AS count 
            FROM `'._DB_PREFIX_.'dss_employee` 
            WHERE `id_employee` = '.(int)$id_employee);

        return $ret ? true : false;
    }
}
