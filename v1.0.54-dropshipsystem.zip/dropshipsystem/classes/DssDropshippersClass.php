<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

include_once(_PS_MODULE_DIR_.'dropshipsystem/dropshipsystem.php');

class DssDropshippersClass extends ObjectModel
{
    public $id;

    /** @var int ID Shop */
    public $id_shop;

    /** @var int ID Customer */
    public $id_customer;

    /** @var int ID Operator */
    public $id_operator;

    /** @var int ID address delivery */
    public $id_address_delivery;

    /** @var int ID address invoice */
    public $id_address_invoice;

    /** @var string Secret */
    public $secret;

    /** @var string contact_name */
    public $contact_name;

    /** @var string contact_email */
    public $contact_email;

    /** @var string contact_phone */
    public $contact_phone;

    /** @var string contact_mobile */
    public $contact_mobile;

    /** @var string website */
    public $website;

    /** @var int Feed Type */
    public $feed_type;

    /** @var int Simple Feed */
    public $simple_feed;

    /** @var int Mask Quantity */
    public $mask_quantity;

    /** @var int Direct Order */
    public $direct_order;

    /** @var enum Payment Type  */
    public $payment_type;

    /** @var enum Payment Method  */
    public $payment_method;

    /** @var float Credit */
    public $credit;

    /** @var float Customer Tax Value */
    public $customer_tax_value;

    /** @var float Daily Limit Value */
    public $daily_limit;

    /** @var float Monthly Limit Value */
    public $monthly_limit;

    /** @var float Min product price_order */
    public $min_product_price_order;

    /** @var float Wholesale Reduction */
    public $wholesale_reduction;
    
    /** @var float Reduction */
    public $reduction;

    /** @var int Total Orders */
    public $orders;

    /** @var int Active */
    public $active;

    /** @var float low_credit_threshold */
    public $low_credit_threshold;

    /** @var bool hidden_product_prices */
    public $hidden_product_prices;

    /** @var string Notes */
    public $notes;

    /** @var string Object last order date */
    public $last_order;

    /** @var string Object last connection date */
    public $last_connection;

    /** @var string Allowed Time */
    public $allowed_time;

    /** @var string Allowed Domains */
    public $allowed_domains;

    /** @var string Object expiration date */
    public $date_end = '0000-00-00';

    /** @var string Object creation date */
    public $date_add;

    /** @var string Object last modification date */
    public $date_upd;

    public static $definition = array(
        'table' => 'dss_dropshipper',
        'primary' => 'id_dss_dropshipper',
        'fields' => array(
            'id_shop'                   => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt', 'required' => true),
            'id_customer'               => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt', 'required' => true),
            'id_operator'               => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt'),
            'id_address_delivery'       => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt'),
            'id_address_invoice'        => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt'),
            'secret'                    => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true, 'size' => 32),
            'contact_name'              => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true, 'size' => 255),
            'contact_email'             => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true, 'size' => 255),
            'contact_phone'             => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 64),
            'contact_mobile'            => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'size' => 64),
            'website'                   => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true, 'size' => 255),
            'feed_type'                 => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt'),
            'simple_feed'               => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt'),
            'mask_quantity'             => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt'),
            'direct_order'              => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt'),
            'payment_type'              => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true),
            'payment_method'            => array('type' => self::TYPE_STRING, 'allow_null' => true, 'validate' => 'isString'),
            'credit'                    => array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat'),
            'customer_tax_value'        => array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat'),
            'wholesale_reduction'       => array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat'),
            'reduction'                 => array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat'),
            'daily_limit'               => array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat'),
            'monthly_limit'             => array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat'),
            'min_product_price_order'   => array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat'),
            'orders'                    => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt'),
            'active'                    => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt'),
            'low_credit_threshold'      => array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat'),
            'hidden_product_prices'     => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt'),
            'notes'                     => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'last_order'                => array('type' => self::TYPE_DATE),
            'last_connection'           => array('type' => self::TYPE_DATE),
            'allowed_time'              => array('type' => self::TYPE_STRING),
            'allowed_domains'           => array('type' => self::TYPE_STRING),
            'date_end'                  => array('type' => self::TYPE_DATE, 'allow_null' => true, 'validate' => 'isDateFormat'),
            'date_add'                  => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
            'date_upd'                  => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
        ),
    );

    public function validateController($htmlentities = true)
    {
        $errors = parent::validateController($htmlentities);

        if (Tools::getValue('hidden_product_prices')) {
            $this->hidden_product_prices = 1;
        } else {
            $this->hidden_product_prices = 0;
        }

        return $errors;
    }

    public static function getUser($id_customer, $secret)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow('
                SELECT *
                FROM `'._DB_PREFIX_.'dss_dropshipper`
                WHERE `id_customer` = '.(int)$id_customer.'
                AND `secret` = \''.pSQL($secret).'\'');
    }

    public function getOperator()
    {
        return (object)Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow('
                SELECT e.*
                FROM `'._DB_PREFIX_.'dss_dropshipper` d
                LEFT JOIN `'._DB_PREFIX_.'employee` e
                ON e.`id_employee` = d.`id_operator`
                WHERE `id_dss_dropshipper` = '.(int)$this->id);
    }

    public static function getDrophippers($active = 1)
    {
        $sql = 'SELECT c.`id_customer`, c.`id_default_group`, c.`siret`, c.`company`,  
            c.`firstname`, c.`lastname`, c.`email`, c.`website`, d.*
            FROM `'._DB_PREFIX_.'customer` c
            INNER JOIN `'._DB_PREFIX_.'dss_dropshipper` d
            ON c.`id_customer` = d.`id_customer` 
            WHERE c.`is_guest` = 0 AND c.`deleted` = 0 ';
        if ($active) {
            $sql .= 'AND c.`active` = 1 AND d.`active` = 1';
        }

        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
    }

    public static function getDrophipperIDByCustomerID($id_customer)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
            SELECT `id_dss_dropshipper` 
            FROM `'._DB_PREFIX_.'dss_dropshipper` 
            WHERE `id_customer` = '.(int)$id_customer);
    }

    public static function isCloneDropshipperCustomerByEmail($email)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
            SELECT COUNT(o.`id_customer`) AS cnt
            FROM `'._DB_PREFIX_.'orders` o
            INNER JOIN `'._DB_PREFIX_.'dss_order` dsso ON dsso.`id_order` = o.`id_order`
            INNER JOIN `'._DB_PREFIX_.'dss_dropshipper` dssd ON dssd.`id_dss_dropshipper` = dsso.`id_dropshipper`
            INNER JOIN `'._DB_PREFIX_.'customer` c ON c.`id_customer` = o.`id_customer`
            WHERE dssd.`active` > 0 AND dssd.`feed_type` = 1 AND c.`email` = \''.pSQL($email).'\'');
    }

    public function increaseOrder()
    {
        return Db::getInstance()->execute('
            UPDATE `'._DB_PREFIX_.'dss_dropshipper`
            SET `orders` = `orders` + 1
            WHERE `id_dss_dropshipper` = '.(int)$this->id.'
        ');
    }

    public function setLastOrderDate()
    {
        return Db::getInstance()->execute('
            UPDATE `'._DB_PREFIX_.'dss_dropshipper`
            SET `last_order` = NOW()
            WHERE `id_dss_dropshipper` = '.(int)$this->id.' AND `last_order` < NOW()
        ');
    }

    public function getCredit()
    {
        return Db::getInstance()->getValue('
            SELECT `credit`
            FROM  `'._DB_PREFIX_.'dss_dropshipper`
            WHERE `id_dss_dropshipper` = '.(int)$this->id.'
        ');
    }
 
    public function addCredit($value)
    {
        return Db::getInstance()->execute('
            UPDATE `'._DB_PREFIX_.'dss_dropshipper`
            SET `credit` = `credit` + '.(float)$value.'
            WHERE `id_dss_dropshipper` = '.(int)$this->id.'
        ');
    }
 
    public function setLastConnectionDate()
    {
        return Db::getInstance()->execute('
            UPDATE `'._DB_PREFIX_.'dss_dropshipper`
            SET `last_connection` = NOW()
            WHERE `id_dss_dropshipper` = '.(int)$this->id.' AND `last_connection` < NOW()
        ');
    }

    public function deleteDropshipperByEmail($email)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        return Db::getInstance()->execute('
            DELETE FROM `'._DB_PREFIX_.'dss_dropshipper`
            WHERE `id_shop` = '.(int)$id_shop.' AND `email` = \''.pSQL($email).'\'');
    }

    public function export($email)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $res = Db::getInstance()->executeS('
            SELECT * FROM `'._DB_PREFIX_.'dss_dropshipper`
            WHERE `id_shop` = '.(int)$id_shop.' AND `email` = \''.pSQL($email).'\'');

        $ret = array();
        if (isset($res) && $res) {
            foreach ($res as $data) {
                $ret[] = array(
                    'contact_name' => (string)$data['contact_name'],
                    'contact_email' => (string)$data['contact_email'],
                    'contact_phone' => (string)$data['contact_phone'],
                    'contact_mobile' => (string)$data['contact_mobile'],
                    'website' => (string)$data['website'],
                    'date_add' => (string)$data['date_add'],
                );
            }
            return $ret;
        } else {
            return false;
        }
    }
}
