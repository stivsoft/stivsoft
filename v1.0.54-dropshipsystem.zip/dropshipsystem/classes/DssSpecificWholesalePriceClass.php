<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class DssSpecificWholesalePriceClass extends ObjectModel
{
    /** @var int id_shop */
    public $id_dss_specific_wholesale_price_rule = 0;

    /** @var int id_shop */
    public $id_shop;

    /** @var int id_category */
    public $id_category;

    /** @var int id_product */
    public $id_product;

    /** @var int id_product_attribute */
    public $id_product_attribute;

    /** @var int id_currency */
    public $id_currency;

    /** @var int id_country */
    public $id_country;

    /** @var int id_group */
    public $id_group;

    /** @var float value */
    public $value;

    /** @var date from */
    public $from;

    /** @var date to */
    public $to;

    private $errors = array();

    public static $definition = array(
        'table' => 'dss_specific_wholesale_price',
        'primary' => 'id_dss_specific_wholesale_price',
        'fields' => array(
            'id_dss_specific_wholesale_price_rule'  => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId'),
            'id_shop'                               => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
            'id_product'                            => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId'),
            'id_product_attribute'                  => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId'),
            'id_currency'                           => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
            'id_country'                            => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
            'id_group'                              => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
            'value'                                 => array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat', 'required' => true),
            'from'                                  => array('type' => self::TYPE_DATE, 'validate' => 'isDateFormat', 'required' => true),
            'to'                                    => array('type' => self::TYPE_DATE, 'validate' => 'isDateFormat', 'required' => true),
        ),
    );

    protected static $_specificPriceCache = array();
    protected static $_filterOutCache = array();
    protected static $_no_specific_values = array();
    
    protected function flushCache()
    {
        DssSpecificWholesalePriceClass::$_specificPriceCache = array();
        DssSpecificWholesalePriceClass::$_filterOutCache = array();
        DssSpecificWholesalePriceClass::$_no_specific_values = array();
        Product::flushPriceCache();
    }

    public function add($autodate = true, $nullValues = false)
    {
        if (parent::add($autodate, $nullValues)) {
            $this->flushCache();
            return true;
        }
        return false;
    }

    public function update($null_values = false)
    {
        if (parent::update($null_values)) {
            $this->flushCache();
            return true;
        }
        return false;
    }

    public function delete()
    {
        if (parent::delete()) {
            $this->flushCache();
            return true;
        }
        return false;
    }

    public static function getByProductId($id_product, $id_product_attribute = false)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
			SELECT *
			FROM `'._DB_PREFIX_.'dss_specific_wholesale_price`
			WHERE `id_product` = '.(int)$id_product.
            ($id_product_attribute ? ' AND id_product_attribute = '.(int)$id_product_attribute : ''));
    }

//    public static function getIdsByProductId($id_product, $id_product_attribute = false, $id_cart = 0)
//    {
//        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
//            SELECT `id_dss_specific_wholesale_price`
//            FROM `'._DB_PREFIX_.'dss_specific_wholesale_price`
//            WHERE `id_product` = '.(int)$id_product.'
//            AND id_product_attribute='.(int)$id_product_attribute);
//    }
    
    protected static function filterOutField($field_name, $field_value, $threshold = 1000)
    {
        $query_extra = 'AND `'.$field_name.'` = 0 ';
        if ($field_value == 0 || array_key_exists($field_name, self::$_no_specific_values)) {
            return $query_extra;
        }
        $key_cache = __FUNCTION__.'-'.$field_name.'-'.$threshold;
        $specific_list = array();
        if (!array_key_exists($key_cache, DssSpecificWholesalePriceClass::$_filterOutCache)) {
            $query_count = 'SELECT COUNT(DISTINCT `'.$field_name.'`) FROM `'._DB_PREFIX_.'dss_specific_wholesale_price` WHERE `'.$field_name.'` != 0';
            $specific_count = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue($query_count);
            if ($specific_count == 0) {
                self::$_no_specific_values[$field_name] = true;
                return $query_extra;
            }
            if ($specific_count < $threshold) {
                $query = 'SELECT DISTINCT `'.$field_name.'` FROM `'._DB_PREFIX_.'dss_specific_wholesale_price` WHERE `'.$field_name.'` != 0';
                $tmp_specific_list = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($query);
                foreach ($tmp_specific_list as $key => $value) {
                    $specific_list[] = $value[$field_name];
                }
            }
            DssSpecificWholesalePriceClass::$_filterOutCache[$key_cache] = $specific_list;
        } else {
            $specific_list = DssSpecificWholesalePriceClass::$_filterOutCache[$key_cache];
        }

        // $specific_list is empty if the threshold is reached
        if (empty($specific_list) || in_array($field_value, $specific_list)) {
            $query_extra = 'AND `'.$field_name.'` '.self::formatIntInQuery(0, $field_value).' ';
        }

        return $query_extra;
    }

    protected static function computeExtraConditions($id_product, $id_product_attribute, $beginning = null, $ending = null)
    {
        $first_date = date('Y-m-d 00:00:00');
        $last_date = date('Y-m-d 23:59:59');
        $now = date('Y-m-d H:i:00');
        if ($beginning === null) {
            $beginning = $now;
        }
        if ($ending === null) {
            $ending = $now;
        }

        $query_extra = '';

        if ($id_product !== null) {
            $query_extra .= self::filterOutField('id_product', $id_product);
        }

        if ($id_product_attribute !== null) {
            $query_extra .= self::filterOutField('id_product_attribute', $id_product_attribute);
        }

        if ($ending == $now && $beginning == $now) {
            $key = __FUNCTION__.'-'.$first_date.'-'.$last_date;
            if (!array_key_exists($key, DssSpecificWholesalePriceClass::$_filterOutCache)) {
                $query_from_count    = 'SELECT 1 FROM `'._DB_PREFIX_.'dss_specific_wholesale_price` WHERE `from` BETWEEN \''.$first_date.'\' AND \''.$last_date.'\'';
                $from_specific_count = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue($query_from_count);

                $query_to_count = 'SELECT 1 FROM `'._DB_PREFIX_.'dss_specific_wholesale_price` WHERE `to` BETWEEN \''.$first_date.'\' AND \''.$last_date.'\'';

                $to_specific_count = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue($query_to_count);
                DssSpecificWholesalePriceClass::$_filterOutCache[$key] = array($from_specific_count, $to_specific_count);
            } else {
                list($from_specific_count, $to_specific_count) = DssSpecificWholesalePriceClass::$_filterOutCache[$key];
            }
        } else {
            $from_specific_count = $to_specific_count = 1;
        }

        if (!$from_specific_count && !$to_specific_count) {
            $ending = $beginning = $first_date;
        }

        $query_extra .= ' AND (`from` = \'0000-00-00 00:00:00\' OR \''.$beginning.'\' >= `from`)'.
            ' AND (`to` = \'0000-00-00 00:00:00\' OR \''.$ending.'\' <= `to`)';

        return $query_extra;
    }

    public static function formatIntInQuery($first_value, $second_value)
    {
        $first_value = (int)$first_value;
        $second_value = (int)$second_value;
        if ($first_value != $second_value) {
            return 'IN ('.$first_value.', '.$second_value.')';
        } else {
            return ' = '.$first_value;
        }
    }

    public static function getSpecificWholesalePrice($id_product, $id_shop, $id_currency, $id_country, $id_group, $id_product_attribute = null)
    {
        $key = ((int)$id_product.'-'.(int)$id_shop.'-'.(int)$id_currency.'-'.(int)$id_country.'-'.(int)$id_group.'-'.(int)$id_product_attribute);
        if (!array_key_exists($key, DssSpecificWholesalePriceClass::$_specificPriceCache)) {
            $query_extra = self::computeExtraConditions($id_product, $id_product_attribute);
            $query = 'SELECT *
            FROM `'._DB_PREFIX_.'dss_specific_wholesale_price`
            WHERE `id_shop` '.self::formatIntInQuery(0, $id_shop).' 
            AND `id_currency` '.self::formatIntInQuery(0, $id_currency).' 
            AND `id_country` '.self::formatIntInQuery(0, $id_country).' 
            AND `id_group` '.self::formatIntInQuery(0, $id_group).' '.$query_extra;

            $query .= ' ORDER BY `id_product_attribute` DESC, `id_dss_specific_wholesale_price_rule` ASC, `to` DESC, `from` DESC';

            DssSpecificWholesalePriceClass::$_specificPriceCache[$key] = Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow($query);
        }
        return DssSpecificWholesalePriceClass::$_specificPriceCache[$key];
    }

    public function setSpecificWholesalePrice($id_product, $data = null)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        $id_product_attribute = isset($data) ? $data['swp_id_product_attribute'] : Tools::getValue('swp_id_product_attribute');
        $id_shop = isset($data) ? $data['swp_id_shop'] : Tools::getValue('swp_id_shop');
        $id_currency = isset($data) ? $data['swp_id_currency'] : Tools::getValue('swp_id_currency');
        $id_country = isset($data) ? $data['swp_id_country'] : Tools::getValue('swp_id_country');
        $id_group = isset($data) ? $data['swp_id_group'] : Tools::getValue('swp_id_group');
        $value = isset($data) ? (float)$data['swp_value'] : (float)Tools::getValue('swp_value');
        $from = isset($data) ? $data['swp_from'] : Tools::getValue('swp_from');
        if (!$from) {
            $from = '0000-00-00 00:00:00';
        }
        $to = isset($data) ? $data['swp_to'] : Tools::getValue('swp_to');
        if (!$to) {
            $to = '0000-00-00 00:00:00';
        }

        $dss = new DropShipSystem();

        if ((float)$value == '0') {
            $this->errors[] = $dss->l('No reduction/charge value has been submitted');
        } elseif ($to != '0000-00-00 00:00:00' && strtotime($to) < strtotime($from)) {
            $this->errors[] = $dss->l('Invalid date range');
        } elseif ((float)$value < -100 || (float)$value > 100) {
            $this->errors[] = $dss->l('Submitted reduction/charge value (-100 / 100) is out-of-range');
        } elseif ($this->validateSpecificWholesalePrice($dss, $id_product, $id_shop, $id_currency, $id_country, $id_group, $value, $from, $to, $id_product_attribute)) {
            $specificPrice = new DssSpecificWholesalePriceClass();
            $specificPrice->id_product = (int)$id_product;
            $specificPrice->id_product_attribute = (int)$id_product_attribute;
            $specificPrice->id_shop = (int)$id_shop;
            $specificPrice->id_currency = (int)$id_currency;
            $specificPrice->id_country = (int)$id_country;
            $specificPrice->id_group = (int)$id_group;
            $specificPrice->value = (float)$value;
            $specificPrice->from = $from;
            $specificPrice->to = $to;

            if (!$specificPrice->add()) {
                $this->errors[] = $dss->l('An error occurred while updating the specific wholesale price.');
            }
        }

        return $this->errors;
    }

    protected function validateSpecificWholesalePrice($dss, $id_product, $id_shop, $id_currency, $id_country, $id_group, $value, $from, $to, $id_combination = 0)
    {
        if (!Validate::isUnsignedId($id_shop) || !Validate::isUnsignedId($id_currency) || !Validate::isUnsignedId($id_country) || !Validate::isUnsignedId($id_group)) {
            $this->errors[] = $dss->l('Wrong IDs');
        } elseif (!isset($value) || (isset($value) && !Validate::isFloat($value))) {
            $this->errors[] = $dss->l('Invalid reduction/charge percent');
        } elseif ($from && $to && (!Validate::isDateFormat($from) || !Validate::isDateFormat($to))) {
            $this->errors[] = $dss->l('The from/to date is invalid.');
        } elseif (DssSpecificWholesalePriceClass::exists((int)$id_product, $id_combination, $id_shop, $id_group, $id_country, $id_currency, $from, $to)) {
            $this->errors[] = $dss->l('A specific wholesale price already exists for these parameters.');
        } else {
            return true;
        }
        return false;
    }

    public static function getProductIdByDate($id_shop, $id_currency, $id_country, $id_group, $beginning, $ending, $with_combination_id = false)
    {
        $query_extra = self::computeExtraConditions(null, null, $beginning, $ending);
        $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
			SELECT `id_product`, `id_product_attribute`
			FROM `'._DB_PREFIX_.'dss_specific_wholesale_price`
			WHERE	`id_shop` '.self::formatIntInQuery(0, $id_shop).' AND
					`id_currency` '.self::formatIntInQuery(0, $id_currency).' AND
					`id_country` '.self::formatIntInQuery(0, $id_country).' AND
					`id_group` '.self::formatIntInQuery(0, $id_group).' AND
					`value` <> 0
		'.$query_extra);
        $ids_product = array();
        foreach ($results as $key => $value) {
            $ids_product[] = $with_combination_id ? array('id_product' => (int)$value['id_product'], 'id_product_attribute' => (int)$value['id_product_attribute']) : (int)$value['id_product'];
        }

        return $ids_product;
    }

    public static function deleteByProductId($id_product)
    {
        if (Db::getInstance()->execute('DELETE FROM `'._DB_PREFIX_.'dss_specific_wholesale_price` WHERE `id_product` = '.(int)$id_product)) {
            return true;
        }
        return false;
    }

    public function duplicate($id_product = false)
    {
        if ($id_product) {
            $this->id_product = (int)$id_product;
        }
        unset($this->id);
        return $this->add();
    }

    public static function exists($id_product, $id_product_attribute, $id_shop, $id_group, $id_country, $id_currency, $from, $to, $rule = false)
    {
        $rule = ' AND `id_dss_specific_wholesale_price_rule` '.(!$rule ? '= 0' : '!= 0');
        return (int)Db::getInstance()->getValue('SELECT `id_dss_specific_wholesale_price`
            FROM '._DB_PREFIX_.'dss_specific_wholesale_price
            WHERE `id_product` = '.(int)$id_product.' 
            AND `id_product_attribute` = '.(int)$id_product_attribute.' 
            AND `id_shop` = '.(int)$id_shop.' 
            AND `id_group` = '.(int)$id_group.' 
            AND `id_country` = '.(int)$id_country.' 
            AND `id_currency` = '.(int)$id_currency.' 
            AND `from` >= \''.pSQL($from).'\' 
            AND `to` <= \''.pSQL($to).'\''.$rule);
    }
}
