<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class DssManufacturersClass extends ObjectModel
{
    public $id;

    /** @var int ID Manufacturer */
    public $id_manufacturer;

    /** @var int ID Shop */
    public $id_shop;

    /** @var integer group */
    public $group;

    public static $definition = array(
        'table' => 'dss_manufacturers',
        'primary' => 'id_manufacturer',
        'fields' => array(
            'id_manufacturer'   => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true),
            'id_shop'           => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true),
            'group'             => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true),
        ),
    );

    public static function getManufacturerGroups($id_manufacturer = null)
    {
        $context = Context::getContext();
        $id_shop = (int)$context->shop->id;

        if (!$id_manufacturer) {
            return Db::getInstance()->executeS('
                SELECT `id_manufacturer`, `group`
                FROM `'._DB_PREFIX_.'dss_manufacturers` 
                WHERE `id_shop` = '.(int)$id_shop.'
                ORDER BY `id_manufacturer`');
        } else {
            return Db::getInstance()->executeS('
                SELECT `group`
                FROM `'._DB_PREFIX_.'dss_manufacturers` 
                WHERE `id_manufacturer` = '.(int)$id_manufacturer.' AND `id_shop` = '.(int)$id_shop);
        }
    }

    public static function setManufacturerGroups($id_group, $active)
    {
        $context = Context::getContext();
        $id_shop = (int)$context->shop->id;

        Db::getInstance()->execute('
            DELETE FROM `'._DB_PREFIX_.'dss_manufacturers`
            WHERE `id_shop` = '.(int)$id_shop.'
            AND (`group` = 0 OR `group` = '.(int)$id_group.')');

        if ($active) {
            $manufacturers = Manufacturer::getManufacturers();
            if (isset($manufacturers) && $manufacturers) {
                foreach ($manufacturers as $manufacturer) {
                    Db::getInstance()->execute('
                        INSERT INTO `'._DB_PREFIX_.'dss_manufacturers`
                        (`id_manufacturer`, `id_shop`, `group`) VALUES
                        ('.(int)$manufacturer['id_manufacturer'].', '.(int)$id_shop.', '.(int)$id_group.')');
                }
            }
        }
    }

    public static function getManufacturersByGroups($id_group)
    {
        $sql = 'SELECT m.`id_manufacturer`, m.`name`, IF(ISNULL(dssm.`id_manufacturer`), 0, 1) AS active  
            FROM `'._DB_PREFIX_.'manufacturer` m
            '.Shop::addSqlAssociation('manufacturer', 'm').'
            LEFT JOIN `'._DB_PREFIX_.'dss_manufacturers` dssm ON dssm.id_manufacturer = m.id_manufacturer
            AND dssm.`group` = '.(int)$id_group.'
            WHERE m.`active` = 1
            ORDER BY m.`name`';

        return Db::getInstance()->executeS($sql);
    }

    public function existsManufacturerGroup($id_manufacturer, $group)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        return (int)Db::getInstance()->getValue('
            SELECT COUNT(*) AS count 
            FROM `'._DB_PREFIX_.'dss_manufacturers` 
            WHERE `id_manufacturer` = '.(int)$id_manufacturer.'
            AND `id_shop` = '.(int)$id_shop.'
            AND `group` = '.(int)$group);
    }

    public function delete()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        if (parent::delete()) {
            Db::getInstance()->execute('
                DELETE FROM `'._DB_PREFIX_.'dss_manufacturers`
                WHERE `id_manufacturer` = '.(int)$this->id_manufacturer.'
                AND `id_shop` = '.(int)$id_shop.'
                AND `group` = '.(int)$this->group);
            return true;
        }
        return false;
    }

    public static function clearManufacturerGroups($id_manufacturer, $groups)
    {
        $context = Context::getContext();
        $id_shop = (int)$context->shop->id;
        if (!isset($groups) || !is_array($groups)) {
            $groups = array();
        }
        $_groups = DssManufacturersClass::getManufacturerGroups($id_manufacturer);
        if (isset($_groups) && $_groups) {
            foreach ($_groups as $_group) {
                if (!in_array((int)$_group['group'], $groups)) {
                    Db::getInstance()->execute('
                        DELETE FROM `'._DB_PREFIX_.'dss_manufacturers`
                        WHERE `id_manufacturer` = '.(int)$id_manufacturer.'
                        AND `id_shop` = '.(int)$id_shop.'
                        AND (`group` = 0 OR `group` = '.(int)$_group['group'].')');
                }
            }
        }
    }
}
