<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class DssSuppliersClass extends ObjectModel
{
    public $id;

    /** @var int ID Supplier */
    public $id_supplier;

    /** @var int ID Shop */
    public $id_shop;

    /** @var integer group */
    public $group;

    public static $definition = array(
        'table' => 'dss_suppliers',
        'primary' => 'id_supplier',
        'fields' => array(
            'id_supplier'   => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true),
            'id_shop'       => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true),
            'group'         => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt', 'required' => true),
        ),
    );

    public static function getSupplierGroups($id_supplier = null)
    {
        $context = Context::getContext();
        $id_shop = (int)$context->shop->id;

        if (!$id_supplier) {
            return Db::getInstance()->executeS('
                SELECT `id_supplier`, `group`
                FROM `'._DB_PREFIX_.'dss_suppliers` 
                WHERE `id_shop` = '.(int)$id_shop.'
                ORDER BY `id_supplier`');
        } else {
            return Db::getInstance()->executeS('
                SELECT `group`
                FROM `'._DB_PREFIX_.'dss_suppliers` 
                WHERE `id_supplier` = '.(int)$id_supplier.' AND `id_shop` = '.(int)$id_shop);
        }
    }

    public static function setSupplierGroups($id_group, $active)
    {
        $context = Context::getContext();
        $id_shop = (int)$context->shop->id;

        Db::getInstance()->execute('
            DELETE FROM `'._DB_PREFIX_.'dss_suppliers`
            WHERE `id_shop` = '.(int)$id_shop.'
            AND (`group` = 0 OR `group` = '.(int)$id_group.')');

        if ($active) {
            $suppliers = Supplier::getSuppliers();
            if (isset($suppliers) && $suppliers) {
                foreach ($suppliers as $supplier) {
                    Db::getInstance()->execute('
                        INSERT INTO `'._DB_PREFIX_.'dss_suppliers`
                        (`id_supplier`, `id_shop`, `group`) VALUES
                        ('.(int)$supplier['id_supplier'].', '.(int)$id_shop.', '.(int)$id_group.')');
                }
            }
        }
    }

    public static function getSuppliersByGroups($id_group)
    {
        $sql = 'SELECT s.`id_supplier`, s.`name`, IF(ISNULL(dsss.`id_supplier`), 0, 1) AS active  
            FROM `'._DB_PREFIX_.'supplier` s
            '.Shop::addSqlAssociation('supplier', 's').'
            LEFT JOIN `'._DB_PREFIX_.'dss_suppliers` dsss ON dsss.id_supplier = s.id_supplier
            AND dsss.`group` = '.(int)$id_group.'
            WHERE s.`active` = 1
            ORDER BY s.`name`';
        return Db::getInstance()->executeS($sql);
    }

    public function existsSupplierGroup($id_supplier, $group)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        return (int)Db::getInstance()->getValue('
            SELECT COUNT(*) AS count 
            FROM `'._DB_PREFIX_.'dss_suppliers` 
            WHERE `id_supplier` = '.(int)$id_supplier.'
            AND `id_shop` = '.(int)$id_shop.'
            AND `group` = '.(int)$group);
    }

    public function delete()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        if (parent::delete()) {
            Db::getInstance()->execute('
                DELETE FROM `'._DB_PREFIX_.'dss_suppliers`
                WHERE `id_supplier` = '.(int)$this->id_supplier.'
                AND `id_shop` = '.(int)$id_shop.'
                AND `group` = '.(int)$this->group);
            return true;
        }
        return false;
    }

    public static function clearSupplierGroups($id_supplier, $groups)
    {
        $context = Context::getContext();
        $id_shop = (int)$context->shop->id;
        if (!isset($groups) || !is_array($groups)) {
            $groups = array();
        }
        $_groups = DssSuppliersClass::getSupplierGroups($id_supplier);
        if (isset($_groups) && $_groups) {
            foreach ($_groups as $_group) {
                if (!in_array((int)$_group['group'], $groups)) {
                    Db::getInstance()->execute('
                        DELETE FROM `'._DB_PREFIX_.'dss_suppliers`
                        WHERE `id_supplier` = '.(int)$id_supplier.'
                        AND `id_shop` = '.(int)$id_shop.'
                        AND (`group` = 0 OR `group` = '.(int)$_group['group'].')');
                }
            }
        }
    }
}
