<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class DssActionLogClass extends ObjectModel
{
    public $id;

    /** @var int id action */
    public $id_dss_action;

    /** @var string type */
    public $type;

    /** @var int ID Customer */
    public $id_reference;

    /** @var string reference */
    public $reference;

    /** @var string action */
    public $action;

    /** @var string Object creation date */
    public $date_add;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'dss_action_log',
        'primary' => 'id_dss_action',
        'fields' => array(
            'id_dss_action' => array('type' => self::TYPE_INT),
            'type'          => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'id_reference'  => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            'reference'     => array('type' => self::TYPE_STRING, 'allow_null' => true, 'validate' => 'isString'),
            'action'        => array('type' => self::TYPE_STRING, 'allow_null' => true, 'validate' => 'isString'),
            'date_add'      => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
        ),
    );

    public function getSync($version, $group, $limit = 100)
    {
        if (!isset($version) || !$version) {
            return false;
        }

        $sql = '
            SELECT DISTINCT al1.* FROM (
                SELECT dssal.* 
                FROM `'._DB_PREFIX_.'category` c
                INNER JOIN `'._DB_PREFIX_.'dss_categories` dssc ON c.`id_category` = dssc.`id_category`
                INNER JOIN `'._DB_PREFIX_.'category_group` cg ON cg.`id_category` = c.`id_category` AND cg.`id_group` = '.(int)$group.'
                INNER JOIN `'._DB_PREFIX_.'dss_action_log` dssal ON dssal.`id_reference` = c.`id_category` AND dssal.`type` = \'categories\'
                WHERE dssal.`id_dss_action` > 0 AND c.`active` = 1 AND dssc.`dss_category_active` = 1
                UNION ALL
                SELECT dssal.* 
                FROM `'._DB_PREFIX_.'product` p
                INNER JOIN `'._DB_PREFIX_.'category_product` cp ON cp.`id_product` = p.`id_product`
                INNER JOIN `'._DB_PREFIX_.'category` c ON c.`id_category` = cp.`id_category`
                INNER JOIN `'._DB_PREFIX_.'dss_categories` dssc ON c.`id_category` = dssc.`id_category`
                INNER JOIN `'._DB_PREFIX_.'category_group` cg ON cg.`id_category` = c.`id_category` AND cg.`id_group` = '.(int)$group.'
                INNER JOIN `'._DB_PREFIX_.'dss_action_log` dssal ON dssal.`id_reference` = p.`id_product` AND dssal.`type` <> \'categories\'
                WHERE dssal.`id_dss_action` > 0 AND c.`active` = 1 AND dssc.`dss_category_active` = 1 AND p.`active` = 1
                AND cg.`id_group` NOT IN (
                    SELECT dsspg.`group` 
                    FROM `'._DB_PREFIX_.'dss_product_groups` dsspg 
                    WHERE dsspg.`id_product` = p.`id_product`)
                UNION ALL
                SELECT dssal.*
                FROM `'._DB_PREFIX_.'dss_action_log` dssal
                WHERE dssal.`id_dss_action` > 0 AND dssal.`reference` IS NOT NULL AND dssal.`action` IS NOT NULL
                ) AS al1 
            WHERE al1.`id_reference` > 0 AND al1.`id_dss_action` > '.(int)$version.' 
            ORDER BY al1.`id_dss_action` LIMIT '.(int)$limit;

            return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
    }

    public function clearDuplicates()
    {
        $sql = '';
        if ($this->type == 'products') {
            $sql .= 'DELETE FROM `'._DB_PREFIX_.'dss_action_log`
                WHERE `type` = \'quantities\' AND `id_reference` = '.(int)$this->id_reference.';';
        }
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('
            DELETE FROM `'._DB_PREFIX_.'dss_action_log`
            WHERE `id_dss_action` = '.(int)$this->id_dss_action.'; '.$sql.'
            DELETE FROM `'._DB_PREFIX_.'dss_action_log`
            WHERE `type` = \''.pSQL($this->type).'\' AND `id_reference` = '.(int)$this->id_reference);
    }
}
