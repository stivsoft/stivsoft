<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

include_once(_PS_MODULE_DIR_.'dropshipsystem/dropshipsystem.php');

class DssCartClass extends ObjectModel
{
    public $id;

    /** @var int ID Shop */
    public $id_shop;

    /** @var int ID Dropshipper */
    public $id_dropshipper;

    /** @var int ID Customer */
    public $id_customer;

    /** @var int ID address delivery */
    public $id_address_delivery;

    /** @var int ID address invoice */
    public $id_address_invoice;

    /** @var int ID Carrier */
    public $id_carrier;

    /** @var int ID Currency */
    public $id_currency;

    /** @var string Object creation date */
    public $date_add;

    /** @var string Object last modification date */
    public $date_upd;

    public static $definition = array(
        'table' => 'dss_cart',
        'primary' => 'id_dss_cart',
        'fields' => array(
            'id_shop'               => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt', 'required' => true),
            'id_dropshipper'        => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt', 'required' => true),
            'id_customer'           => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt'),
            'id_address_delivery'   => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt'),
            'id_address_invoice'    => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt'),
            'id_carrier'            => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt'),
            'id_currency'           => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt'),
            'date_add'              => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
            'date_upd'              => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
        ),
    );

    public function getCartByDropshipperId($id_dropshipper)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow('
            SELECT *
            FROM `'._DB_PREFIX_.'dss_cart`
            WHERE `id_dropshipper` = '.(int)$id_dropshipper.'
            AND `id_shop` = '.(int)$this->context->shop->id);

        if (!$result) {
            return false;
        }

        $this->id = $result['id_dss_cart'];
        foreach ($result as $key => $value) {
            if (property_exists($this, $key)) {
                $this->{$key} = $value;
            }
        }
        $this->cart = $this->getCart($id_dropshipper);

        return $this;
    }
    
    public function getCartIdByDropshipperId($id_dropshipper)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        return (int)Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
            SELECT `id_dss_cart`
            FROM `'._DB_PREFIX_.'dss_cart`
            WHERE `id_dropshipper` = '.(int)$id_dropshipper.'
            AND `id_shop` = '.(int)$this->context->shop->id);
    }

    public function getCart($dropshipper)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_lang = $this->context->language->id;

        if (!$dropshipper instanceof DssDropshippersClass) {
            $dropshipper = new DssDropshippersClass($dropshipper);
        }

        $customer = new Customer($dropshipper->id_customer);
        $address = new Address($dropshipper->id_address_invoice);
        $dropshipper->id_country = (int)$address->id_country;
        unset($address);

        $group = $customer->id_default_group;

        $id_dss_cart = (int)$this->getCartIdByDropshipperId((int)$dropshipper->id);

        if (!$id_dss_cart) {
            $obj = new DssCartClass();
            $obj->id_shop = (int)$this->context->shop->id;
            $obj->id_dropshipper = (int)$dropshipper->id;
            if ($obj->add()) {
                $id_dss_cart = $obj->id;
            }
            unset($obj);
        }

        $cart = Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow('
            SELECT *
            FROM `'._DB_PREFIX_.'dss_cart`
            WHERE `id_dss_cart` = '.(int)$id_dss_cart.'
            AND `id_shop` = '.(int)$this->context->shop->id);

        $cart['delivery_address'] = new Address((int)$cart['id_address_delivery']);
        $cart['invoice_address'] = new Address((int)$cart['id_address_invoice']);
        $id_zone = (int)Address::getZoneById((int)$cart['id_address_delivery']);

        $shipping = 0;
        $subtotal = 0;
        $weight = 0;
        $total = 0;
        $cart_products = array();
        if (isset($cart) && $cart) {
            $products = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
                SELECT *
                FROM `'._DB_PREFIX_.'dss_cart_product`
                WHERE `id_dss_cart` = '.(int)$id_dss_cart.'
                AND `id_shop` = '.(int)$this->context->shop->id.'
                ORDER BY `date_add` ASC');

            if (isset($products) && count($products)) {
                foreach ($products as $product) {
                    $_product = $this->getProduct($product, $dropshipper, $id_lang, $group);
                    $subtotal += (float)$_product['price'] * (int)$_product['quantity'];
                    $weight += (float)$_product['weight'] * (int)$_product['quantity'];
                    $cart_products[] = $_product;
                }
            }
        }
        $cart['products'] = $cart_products;

        $carrier = new Carrier((int)$cart['id_carrier']);
        $shipping_method = $carrier->getShippingMethod();
        if ($shipping_method == Carrier::SHIPPING_METHOD_PRICE) {
            $shipping = $carrier->getDeliveryPriceByPrice($total, $id_zone);
        } elseif ($shipping_method == Carrier::SHIPPING_METHOD_WEIGHT) {
            $shipping = $carrier->getDeliveryPriceByWeight($weight, $id_zone);
        } elseif ($shipping_method == Carrier::SHIPPING_METHOD_FREE) {
            $shipping = 0;
        }
        unset($carrier);

        $total = (float)$subtotal + (float)$shipping;
        $remain_credit = (float)$dropshipper->credit - (float)$total;

        $cart['totals'] = array(
            'shipping' => (float)$shipping,
            'formatted_shipping' => (string)Tools::displayPrice((float)$shipping),
            'subtotal' => (float)$subtotal,
            'formatted_subtotal' => (string)Tools::displayPrice((float)$subtotal),
            'total' => (float)$total,
            'formatted_total' => (string)Tools::displayPrice((float)$total),
            'current_credit' => (float)$dropshipper->credit,
            'formatted_current_credit' => (string)Tools::displayPrice((float)$dropshipper->credit),
            'remain_credit' => (float)$remain_credit,
            'formatted_remain_credit' => (string)Tools::displayPrice((float)$remain_credit),
        );

        return $cart;
    }

    public function getProduct($product, $dropshipper, $id_lang, $group)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        $id_shop = (int)$this->context->customer->id_shop;

        $wholesale_base_price = (int)Configuration::get('DSS_WHOLESALE_BASE_PRICE', null, null, $id_shop);

        $prd = new Product((int)$product['id_product'], true, $id_lang);

        if (!isset($product['id_product_attribute'])) {
            $product['id_product_attribute'] = (int)$prd->cache_default_attribute;
        }

        $attributes = array();
        $combinations = $prd->getAttributeCombinationsById((int)$product['id_product_attribute'], $id_lang);
        foreach ($combinations as $combination) {
            $attributes[(string)$combination['group_name']] = (string)$combination['attribute_name'];
        }

        $specific_wholesale_price = DssSpecificWholesalePriceClass::getSpecificWholesalePrice(
            (int)$prd->id,
            (int)$this->context->customer->id_shop,
            (int)$this->context->currency->id,
            (int)$dropshipper->id_country,
            (int)$group,
            (int)$product['id_product_attribute']
        );

        if ($wholesale_base_price == 0) {
            $base_price = $prd->wholesale_price;
        } else if ($wholesale_base_price == 1) {
            $base_price = $prd->getPriceWithoutReduct(true, (int)$product['id_product_attribute']);
        }

        if (isset($specific_wholesale_price) && $specific_wholesale_price) {
            $price = (float)$base_price * ((100 + (float)$specific_wholesale_price['value']) / 100);
        } else {
            $price = (float)$base_price * ((100 + (float)$dropshipper->wholesale_reduction) / 100);
        }

        $total = (float)$price * (int)$product['quantity'];
        $remain_credit = (float)$dropshipper->credit - (float)$total;

        $res = array(
            'id_product' => (int)$product['id_product'],
            'id_product_attribute' => (int)$product['id_product_attribute'],
            'quantity' => (int)$product['quantity'],
            'reference' => (string)$prd->reference,
            'name' => (string)$prd->name,
            'attributes' => $attributes,
            'weight' => isset($prd->weight) ? (float)$prd->weight : 0,
            'price' => (float)$price,
            'formatted_price' => (string)Tools::displayPrice((float)$price),
            'formatted_total' => (string)Tools::displayPrice((float)$total),
            'current_credit' => (float)$dropshipper->credit,
            'formatted_current_credit' => (string)Tools::displayPrice((float)$dropshipper->credit),
            'remain_credit' => (float)$remain_credit,
            'formatted_remain_credit' => (string)Tools::displayPrice((float)$remain_credit),
            'url' => (string)$this->context->link->getProductLink($prd),
        );

        return $res;
    }

    public function updateCart($action, $id_dropshipper, $params = array())
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        $id_dss_cart = (int)$this->getCartIdByDropshipperId((int)$id_dropshipper);

        if (!$id_dss_cart) {
            $obj = new DssCartClass();
            $obj->id_shop = (int)$this->context->shop->id;
            $obj->id_dropshipper = (int)$id_dropshipper;
            if ($obj->add()) {
                $id_dss_cart = $obj->id;
            }
            unset($obj);
        }

        if ($action == 'remove') {
            $res = Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('
                DELETE FROM `'._DB_PREFIX_.'dss_cart_product`
                WHERE `id_dss_cart` = '.(int)$id_dss_cart.'
                AND `id_product` = '.(int)$params['id_product'].'
                AND `id_product_attribute` = '.(int)$params['id_product_attribute']);
        } elseif ($action == 'add') {
            $res = Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('
                DELETE FROM `'._DB_PREFIX_.'dss_cart_product`
                WHERE `id_dss_cart` = '.(int)$id_dss_cart.'
                AND `id_product` = '.(int)$params['id_product'].'
                AND `id_product_attribute` = '.(int)$params['id_product_attribute']);
            $res &= Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('
                INSERT INTO `'._DB_PREFIX_.'dss_cart_product`
                (`id_dss_cart`, `id_product`, `id_product_attribute`, `id_shop`, `quantity`, `date_add`) VALUES
                ('.(int)$id_dss_cart.', '.(int)$params['id_product'].', '.(int)$params['id_product_attribute'].', 
                '.(int)$this->context->shop->id.', '.(int)$params['product_quantity'].', \''.date('Y-m-d H:i:s').'\')');
        } elseif ($action == 'update') {
            $res = Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('
                UPDATE `'._DB_PREFIX_.'dss_cart_product`
                SET `quantity` = '.(int)$params['product_quantity'].'
                WHERE `id_dss_cart` = '.(int)$id_dss_cart.'
                AND `id_product` = '.(int)$params['id_product'].'
                AND `id_product_attribute` = '.(int)$params['id_product_attribute'].'
                AND `id_shop` = '.(int)$this->context->shop->id);
        } elseif ($action == 'set_carrier') {
            $res = Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('
                UPDATE `'._DB_PREFIX_.'dss_cart`
                SET `id_carrier` = '.(int)$params['id_carrier'].'
                WHERE `id_dss_cart` = '.(int)$id_dss_cart);
        }

        return $res;
    }

    public function searchProduct($id_dropshipper, $query)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_lang = $this->context->language->id;
        $id_shop = (int)$this->context->customer->id_shop;

        $wholesale_base_price = (int)Configuration::get('DSS_WHOLESALE_BASE_PRICE', null, null, $id_shop);

        $dropshipper = new DssDropshippersClass($id_dropshipper);
        $customer = new Customer($dropshipper->id_customer);
        $address = new Address($dropshipper->id_address_invoice);
        $dropshipper->id_country = (int)$address->id_country;
        unset($address);

        $group = 0;
        if (isset($customer) && $customer) {
            $group = $customer->id_default_group;
        }
        unset($customer);

        $dss = new DssClass();
        $products = $dss->getProducts($id_lang, 0, 20, 'pl.name', 'asc', false, true, $group, $query);
        unset($dss);

        $res = array();
        if (isset($products) && $products) {
            foreach ($products as $product) {
                $id_product_attribute = 0;
                $prd = new Product((int)$product['id_product'], true, $id_lang);

                if (!$id_product_attribute && $prd->hasAttributes()) {
                    $minimum_quantity = $prd->out_of_stock == 2 ? !Configuration::get('PS_ORDER_OUT_OF_STOCK') : !$prd->out_of_stock;
                    $id_product_attribute = (int)Product::getDefaultAttribute($prd->id, $minimum_quantity);
                }

                $specific_wholesale_price = DssSpecificWholesalePriceClass::getSpecificWholesalePrice(
                    (int)$prd->id,
                    (int)$this->context->customer->id_shop,
                    (int)$this->context->currency->id,
                    (int)$dropshipper->id_country,
                    (int)$group,
                    (int)$id_product_attribute
                );

                if ($wholesale_base_price == 0) {
                    $base_price = $prd->wholesale_price;
                } else if ($wholesale_base_price == 1) {
                    $base_price = $prd->getPriceWithoutReduct(true, (int)$id_product_attribute);
                }

                if (isset($specific_wholesale_price) && $specific_wholesale_price) {
                    $price = (float)$base_price * ((100 + (float)$specific_wholesale_price['value']) / 100);
                } else {
                    $price = (float)$base_price * ((100 + (float)$dropshipper->wholesale_reduction) / 100);
                }

                $image = Product::getCover((int)$product['id_product']);

                $res[] = array(
                    'id_product' => (int)$product['id_product'],
                    'id_product_attribute' => (int)$id_product_attribute,
                    'link_rewrite' => (string)$product['link_rewrite'],
                    'id_image' => isset($image) ? (int)$image['id_image'] : 0,
                    'reference' => (string)$product['reference'],
                    'name' => (string)$product['name'],
                    'price' => (float)$price,
                    'formatted_price' => (string)Tools::displayPrice((float)$price),
                    'currency' => (int)$this->context->currency->id,
                    'has_attributes' => (int)$prd->hasAttributes()
                );
            }
        }

        return $res;
    }

    public function deleteCart($id_dropshipper)
    {
        $id_dss_cart = (int)$this->getCartIdByDropshipperId((int)$id_dropshipper);

        $res = false;
        if ($id_dss_cart) {
            $res = Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('
                DELETE FROM `'._DB_PREFIX_.'dss_cart_product`
                WHERE `id_dss_cart` = '.(int)$id_dss_cart.'
                AND `id_shop` = '.(int)$this->context->shop->id.';
                DELETE FROM `'._DB_PREFIX_.'dss_cart`
                WHERE `id_dropshipper` = '.(int)$id_dropshipper.'
                AND `id_shop` = '.(int)$this->context->shop->id);
        }
        return $res;
    }
}
