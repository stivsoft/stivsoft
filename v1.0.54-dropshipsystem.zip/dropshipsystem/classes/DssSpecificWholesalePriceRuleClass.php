<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class DssSpecificWholesalePriceRuleClass extends ObjectModel
{
    /** @var string name */
    public $name;

    /** @var int id_shop */
    public $id_shop;

    /** @var int id_category */
    public $id_category;

    /** @var int id_currency */
    public $id_currency;

    /** @var int id_country */
    public $id_country;

    /** @var int id_group */
    public $id_group;

    /** @var float value */
    public $value;

    /** @var date from */
    public $from;

    /** @var date to */
    public $to;

    protected static $rules_application_enable = true;

    public static $definition = array(
        'table' => 'dss_specific_wholesale_price_rule',
        'primary' => 'id_dss_specific_wholesale_price_rule',
        'fields' => array(
            'name'                      => array('type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true),
            'id_shop'                   => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
            'id_currency'               => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
            'id_country'                => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
            'id_group'                  => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
            'value'                     => array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat', 'required' => true),
            'from'                      => array('type' => self::TYPE_DATE, 'validate' => 'isDateFormat', 'required' => true),
            'to'                        => array('type' => self::TYPE_DATE, 'validate' => 'isDateFormat', 'required' => true),
        ),
    );

    public function delete()
    {
        $this->deleteConditions();
        Db::getInstance()->execute('DELETE FROM '._DB_PREFIX_.'dss_specific_wholesale_price
            WHERE id_dss_specific_wholesale_price_rule = '.(int)$this->id);
        return parent::delete();
    }

    public function deleteConditions()
    {
        $ids_condition_group = Db::getInstance()->executeS('SELECT id_dss_specific_wholesale_price_rule_condition_group
            FROM '._DB_PREFIX_.'dss_specific_wholesale_price_rule_condition_group
            WHERE id_dss_specific_wholesale_price_rule = '.(int)$this->id);
        if ($ids_condition_group) {
            foreach ($ids_condition_group as $row) {
                Db::getInstance()->delete('dss_specific_wholesale_price_rule_condition_group', 'id_dss_specific_wholesale_price_rule_condition_group = '.(int)$row['id_dss_specific_wholesale_price_rule_condition_group']);
                Db::getInstance()->delete('dss_specific_wholesale_price_rule_condition', 'id_dss_specific_wholesale_price_rule_condition_group = '.(int)$row['id_dss_specific_wholesale_price_rule_condition_group']);
            }
        }
    }

    public static function disableAnyApplication()
    {
        DssSpecificWholesalePriceRuleClass::$rules_application_enable = false;
    }

    public static function enableAnyApplication()
    {
        DssSpecificWholesalePriceRuleClass::$rules_application_enable = true;
    }

    public function addConditions($conditions)
    {
        if (!is_array($conditions)) {
            return;
        }

        $result = Db::getInstance()->insert('dss_specific_wholesale_price_rule_condition_group', array(
            'id_dss_specific_wholesale_price_rule' => (int)$this->id
        ));
        if (!$result) {
            return false;
        }
        $id_dss_specific_wholesale_price_rule_condition_group = (int)Db::getInstance()->Insert_ID();
        foreach ($conditions as $condition) {
            $result = Db::getInstance()->insert('dss_specific_wholesale_price_rule_condition', array(
                'id_dss_specific_wholesale_price_rule_condition_group' => (int)$id_dss_specific_wholesale_price_rule_condition_group,
                'type' => pSQL($condition['type']),
                'value' => (float)$condition['value'],
            ));
            if (!$result) {
                return false;
            }
        }
        return true;
    }

    public function apply($products = false)
    {
        if (!DssSpecificWholesalePriceRuleClass::$rules_application_enable) {
            return;
        }

        $this->resetApplication($products);
        $products = $this->getAffectedProducts($products);
        foreach ($products as $product) {
            DssSpecificWholesalePriceRuleClass::applyRuleToProduct((int)$this->id, (int)$product['id_product'], (int)$product['id_product_attribute']);
        }
    }

    public function resetApplication($products = false)
    {
        $where = '';
        if ($products && count($products)) {
            $where .= ' AND id_product IN ('.implode(', ', array_map('intval', $products)).')';
        }
        return Db::getInstance()->execute('DELETE FROM '._DB_PREFIX_.'dss_specific_wholesale_price WHERE id_dss_specific_wholesale_price_rule = '.(int)$this->id.$where);
    }

    /**
     * @param array|bool $products
     */
    public static function applyAllRules($products = false)
    {
        if (!DssSpecificWholesalePriceRuleClass::$rules_application_enable) {
            return;
        }

        $rules = new PrestaShopCollection('DssSpecificWholesalePriceRule');
        foreach ($rules as $rule) {
            /** @var SpecificPriceRule $rule */
            $rule->apply($products);
        }
    }

    public function getConditions()
    {
        $conditions = Db::getInstance()->executeS('
            SELECT g.*, c.*
			FROM '._DB_PREFIX_.'dss_specific_wholesale_price_rule_condition_group g
			LEFT JOIN '._DB_PREFIX_.'dss_specific_wholesale_price_rule_condition c
				ON (c.id_dss_specific_wholesale_price_rule_condition_group = g.id_dss_specific_wholesale_price_rule_condition_group)
			WHERE g.id_dss_specific_wholesale_price_rule = '.(int)$this->id);

        $conditions_group = array();
        if ($conditions) {
            foreach ($conditions as &$condition) {
                if ($condition['type'] == 'attribute') {
                    $condition['id_attribute_group'] = Db::getInstance()->getValue('SELECT id_attribute_group
                        FROM '._DB_PREFIX_.'attribute
                        WHERE id_attribute='.(int)$condition['value']);
                } elseif ($condition['type'] == 'feature') {
                    $condition['id_feature'] = Db::getInstance()->getValue('SELECT id_feature
                        FROM '._DB_PREFIX_.'feature_value
                        WHERE id_feature_value='.(int)$condition['value']);
                }
                $conditions_group[(int)$condition['id_dss_specific_wholesale_price_rule_condition_group']][] = $condition;
            }
        }
        return $conditions_group;
    }

    public function getAffectedProducts($products = false)
    {
        $conditions_group = $this->getConditions();
        $current_shop_id = Context::getContext()->shop->id;

        $result = array();

        if ($conditions_group) {
            foreach ($conditions_group as $id_condition_group => $condition_group) {
                // Base request
                $query = new DbQuery();
                $query->select('p.`id_product`')
                    ->from('product', 'p')
                    ->leftJoin('product_shop', 'ps', 'p.`id_product` = ps.`id_product`')
                    ->where('ps.id_shop = '.(int)$current_shop_id);

                $attributes_join_added = false;

                // Add the conditions
                foreach ($condition_group as $id_condition => $condition) {
                    if ($condition['type'] == 'attribute') {
                        if (!$attributes_join_added) {
                            $query->select('pa.`id_product_attribute`')
                                ->leftJoin('product_attribute', 'pa', 'p.`id_product` = pa.`id_product`')
                                ->join(Shop::addSqlAssociation('product_attribute', 'pa', false));

                            $attributes_join_added = true;
                        }

                        $query->leftJoin('product_attribute_combination', 'pac'.(int)$id_condition, 'pa.`id_product_attribute` = pac'.(int)$id_condition.'.`id_product_attribute`')
                            ->where('pac'.(int)$id_condition.'.`id_attribute` = '.(int)$condition['value']);
                    } elseif ($condition['type'] == 'manufacturer') {
                        $query->where('p.id_manufacturer = '.(int)$condition['value']);
                    } elseif ($condition['type'] == 'category') {
                        $query->leftJoin('category_product', 'cp'.(int)$id_condition, 'p.`id_product` = cp'.(int)$id_condition.'.`id_product`')
                            ->where('cp'.(int)$id_condition.'.id_category = '.(int)$condition['value']);
                    } elseif ($condition['type'] == 'supplier') {
                        $query->where('EXISTS(
							SELECT
								`ps'.(int)$id_condition.'`.`id_product`
							FROM
								`'._DB_PREFIX_.'product_supplier` `ps'.(int)$id_condition.'`
							WHERE
								`p`.`id_product` = `ps'.(int)$id_condition.'`.`id_product`
								AND `ps'.(int)$id_condition.'`.`id_supplier` = '.(int)$condition['value'].'
						)');
                    } elseif ($condition['type'] == 'feature') {
                        $query->leftJoin('feature_product', 'fp'.(int)$id_condition, 'p.`id_product` = fp'.(int)$id_condition.'.`id_product`')
                            ->where('fp'.(int)$id_condition.'.`id_feature_value` = '.(int)$condition['value']);
                    }
                }

                // Products limitation
                if ($products && count($products)) {
                    $query->where('p.`id_product` IN ('.implode(', ', array_map('intval', $products)).')');
                }

                // Force the column id_product_attribute if not requested
                if (!$attributes_join_added) {
                    $query->select('NULL as `id_product_attribute`');
                }

                $result = array_merge($result, Db::getInstance()->executeS($query));
            }
        } else {
            // All products without conditions
            if ($products && count($products)) {
                $query = new DbQuery();
                $query->select('p.`id_product`')
                    ->select('NULL as `id_product_attribute`')
                    ->from('product', 'p')
                    ->leftJoin('product_shop', 'ps', 'p.`id_product` = ps.`id_product`')
                    ->where('ps.id_shop = '.(int)$current_shop_id);
                $query->where('p.`id_product` IN ('.implode(', ', array_map('intval', $products)).')');
                $result = Db::getInstance()->executeS($query);
            } else {
                $result = array(array('id_product' => 0, 'id_product_attribute' => null));
            }
        }
        return $result;
    }

    public static function applyRuleToProduct($id_rule, $id_product, $id_product_attribute = null)
    {
        $rule = new DssSpecificWholesalePriceRuleClass((int)$id_rule);
        if (!Validate::isLoadedObject($rule) || !Validate::isUnsignedInt($id_product)) {
            return false;
        }

        $specific_price = new DssSpecificWholesalePriceClass();
        $specific_price->id_dss_specific_wholesale_price_rule = (int)$rule->id;
        $specific_price->id_product = (int)$id_product;
        $specific_price->id_product_attribute = (int)$id_product_attribute;
        $specific_price->id_customer = 0;
        $specific_price->id_shop = (int)$rule->id_shop;
        $specific_price->id_country = (int)$rule->id_country;
        $specific_price->id_currency = (int)$rule->id_currency;
        $specific_price->id_group = (int)$rule->id_group;
        $specific_price->value = (float)$rule->value;
        $specific_price->from = $rule->from;
        $specific_price->to = $rule->to;

        return $specific_price->add();
    }
}
