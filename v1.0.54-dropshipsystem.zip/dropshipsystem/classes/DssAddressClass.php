<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class DssAddressClass extends ObjectModel
{
    public $id;

    /** @var int id_dss_dropshipper */
    public $id_dss_dropshipper;

    /** @var string alias */
    public $alias;

    /** @var int id_address */
    public $id_address;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'dss_address',
        'primary' => 'id_dss_address',
        'fields' => array(
            'id_dss_dropshipper'    => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            'alias'                 => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'id_address'            => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
        ),
    );

    public static function getAddressIdByAlias($alias, $id_customer)
    {
        $query = new DbQuery();
        $query->select('id_address');
        $query->from('address');
        $query->where('alias = \''.pSQL($alias).'\'');
        $query->where('id_customer = '.(int)$id_customer);
        $query->where('deleted = 1');
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue($query);
    }
}
