<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class DssStatisticsClass extends ModuleGraph
{
    private $html = '';
    private $option = 0;

    public function __construct()
    {
        $this->name = 'dropshipsystem';
        $this->displayName = $this->l('Dropship System');

        parent::__construct();
    }

    public function getWholesalePriceStatsForm()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        if (Tools::getValue('export_wholesale_pricelist')) {
            $this->csvExport(array(
                'option' => 1,
                'type' => 'line',
            ));
        }

        $id_shop = (int)Tools::getValue('id_shop');
        $id_group = (int)Tools::getValue('id_group');
        $id_currency = (int)Tools::getValue('id_currency');
        $id_country = (int)Tools::getValue('id_country');
        $id_category = (int)Tools::getValue('id_category');

        $shops = Shop::getShops();
        $countries = Country::getCountries($this->context->language->id);
        $currencies = Currency::getCurrencies();
        $categories = Category::getCategories((int)$this->context->language->id, true, false);

        $groups = array();
        $psgroups = Group::getGroups($this->context->language->id);
        $groupdef = array(Configuration::get('PS_UNIDENTIFIED_GROUP', null, null, $id_shop), Configuration::get('PS_GUEST_GROUP', null, null, $id_shop), Configuration::get('PS_CUSTOMER_GROUP', null, null, $id_shop));
        foreach ($psgroups as $group) {
            if (!in_array($group['id_group'], $groupdef)) {
                $groups[] = array('id_group' => $group['id_group'], 'name' => $group['name']);
            }
        }

        $this->html = '<form action="#" method="post" id="dssFilters" class="dss form-horizontal">';
        if (Shop::isFeatureActive() && count($shops) > 1) {
            $this->html .= '
                <div class="row row-margin-bottom">
					<div class="col-lg-3">
                        <label class="control-label">
                            <span data-toggle="tooltip" class="label-tooltip" 
                                data-original-title="'.$this->l('Choose the shop to filter').'">
                                '.$this->l('Choose a shop').'
                            </span>
                            <select name="id_shop" onchange="$(\'#dssFilters\').submit();">
                                <option value="0">'.$this->l('All').'</option>';
            foreach ($shops as $shop) {
                $this->html .= '<option value="'.$shop['id_shop'].'"'.($id_shop == $shop['id_shop'] ? ' selected="selected"' : '').'>'.$shop['name'].'</option>';
            }
            $this->html .= '</select>
                        </label>
					</div>
                </div>';
        }
        $this->html .= '
                <div class="row row-margin-bottom">
					<div class="col-lg-3">
                        <label class="control-label">
                            <span data-toggle="tooltip" class="label-tooltip" 
                                data-original-title="'.$this->l('Choose the category to filter').'">
                                '.$this->l('Choose a category').'
                            </span>
                            <select name="id_category" onchange="$(\'#dssFilters\').submit();">
                                <option value="0">'.$this->l('All').'</option>';
        foreach ($categories as $category) {
            $this->html .= '<option value="'.$category['id_category'].'"'.($id_category == $category['id_category'] ? ' selected="selected"' : '').'>'.$category['name'].'</option>';
        }
        $this->html .= '
                            </select>
                        </label>
					</div>
					<div class="col-lg-3">
                        <label class="control-label">
                            <span data-toggle="tooltip" class="label-tooltip" 
                                data-original-title="'.$this->l('Choose the category to filter').'">
                                '.$this->l('Choose a group').'
                            </span>
                            <select name="id_group" onchange="$(\'#dssFilters\').submit();">
                                <option value="0">'.$this->l('All').'</option>';
        foreach ($groups as $group) {
            $this->html .= '<option value="'.$group['id_group'].'"'.($id_group == $group['id_group'] ? ' selected="selected"' : '').'>'.$group['name'].'</option>';
        }
        $this->html .= '
                            </select>
                        </label>
					</div>
					<div class="col-lg-3">
                        <label class="control-label">
                            <span data-toggle="tooltip" class="label-tooltip" 
                                data-original-title="'.$this->l('Choose the currency to filter').'">
                                '.$this->l('Choose a currency').'
                            </span>
                            <select name="id_currency" onchange="$(\'#dssFilters\').submit();">
                                <option value="0">'.$this->l('All').'</option>';
        foreach ($currencies as $currency) {
            $this->html .= '<option value="'.$currency['id_currency'].'"'.($id_currency == $currency['id_currency'] ? ' selected="selected"' : '').'>'.$currency['name'].'</option>';
        }
        $this->html .= '
                            </select>
                        </label>
					</div>
					<div class="col-lg-3">
                        <label class="control-label">
                            <span data-toggle="tooltip" class="label-tooltip" 
                                data-original-title="'.$this->l('Choose the country to filter').'">
                                '.$this->l('Choose a country').'
                            </span>
                            <select name="id_country" onchange="$(\'#dssFilters\').submit();">
                                <option value="0">'.$this->l('All').'</option>';
        foreach ($countries as $country) {
            $this->html .= '<option value="'.$country['id_country'].'"'.($id_country == $country['id_country'] ? ' selected="selected"' : '').'>'.$country['name'].'</option>';
        }
        $this->html .= '
                            </select>
                        </label>
					</div>
				</div>
			</form>
			<h4>'.$this->l('Products').'</h4>
			<table class="dss table" style="border: 0; cellspacing: 0;">
				<thead>
					<tr>
						<th><span class="title_box">'.$this->l('Reference').'</span></th>
						<th><span class="title_box">'.$this->l('Name').'</span></th>
						<th><span class="title_box">'.$this->l('Wholesale Price').'</span></th>
						<th><span class="title_box">'.$this->l('Price').'</span></th>
						<th><span class="title_box">'.$this->l('Reseller Price').'</span></th>
						<th><span class="title_box">'.$this->l('Percent').'</span></th>
					</tr>
				</thead>
            <tbody>';

        foreach ($this->getWholesalePricelist($this->context->language->id) as $product) {
            $class = (float)$product['wholesale_price'] > (float)$product['reseller_price'] ? 'alert' : '';
            $this->html .= '
                <tr>
                    <td>'.$product['reference'].'</td>
                    <td><a href="'.Tools::safeOutput(AdminController::$currentIndex.'&token='.Tools::getValue('token').'&module='.$this->name.'&id_product='.$product['id_product']).'" target="_blank">'.$product['name'].'</a></td>
                    <td>'.Tools::displayPrice($product['wholesale_price']).'</td>
                    <td>'.Tools::displayPrice($product['price']).'</td>
                    <td class="'.$class.'">'.Tools::displayPrice($product['reseller_price']).'</td>
                    <td class="'.$class.'">'.number_format((float)$product['percent'], 2, '.', '').' %</td>
                </tr>';
        }

            $this->html .= '
                        </tbody>
                    </table>
                    <a class="btn btn-default export-csv" href="'.Tools::safeOutput($_SERVER['REQUEST_URI'].'&export_wholesale_pricelist=1').'">
                        <i class="icon-cloud-upload"></i> '.$this->l('CSV Export').'
                    </a>
                </div>
            </div>';

        return $this->html;
    }

    private function getWholesalePricelist($id_lang)
    {
        //$date_between = $this->getDate();
        //$array_date_between = explode(' AND ', $date_between);

        $sql = 'SELECT DISTINCT p.`id_product`, p.`reference`, pl.`name`, p.`wholesale_price`, p.`price`, 
            (p.`price` + ((p.`price` / 100) * COALESCE(dsswp.`value`, 0))) AS reseller_price, COALESCE(dsswp.`value`, 0) AS percent
            FROM `'._DB_PREFIX_.'product` p
            LEFT JOIN `'._DB_PREFIX_.'dss_specific_wholesale_price` dsswp ON 
                dsswp.`id_product` IN (0, p.`id_product`)
                AND dsswp.`id_group` '.DssSpecificWholesalePriceClass::formatIntInQuery(0, (int)Tools::getValue('id_group')).' ';
        if (Shop::isFeatureActive()) {
            $sql .= 'AND dsswp.`id_shop` '.DssSpecificWholesalePriceClass::formatIntInQuery(0, (int)Tools::getValue('id_shop')).' ';
        }
        $sql .= 'AND dsswp.`id_currency` '.DssSpecificWholesalePriceClass::formatIntInQuery(0, (int)Tools::getValue('id_currency')).'
                AND dsswp.`id_country` '.DssSpecificWholesalePriceClass::formatIntInQuery(0, (int)Tools::getValue('id_country')).'
            LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON p.`id_product` = pl.`id_product` '.Shop::addSqlRestrictionOnLang('pl').'
            '.Shop::addSqlAssociation('product', 'p').'
            '.(Tools::getValue('id_category') ? 'LEFT JOIN `'._DB_PREFIX_.'category_product` cp ON p.`id_product` = cp.`id_product`' : '').'
            WHERE p.`active` = 1 AND pl.`id_lang` = '.(int)$id_lang.' 
            '.(Tools::getValue('id_category') ? 'AND cp.`id_category` = '.(int)Tools::getValue('id_category') : '').'
            ORDER BY pl.`name`';

        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
    }

    public function setOption($option, $layers = 1)
    {
        $options = explode('-', $option);
        if (count($options) === 2) {
            list($this->option, $this->id_product) = $options;
        } else {
            $this->option = $option;
        }
        $date_between = $this->getDate();
        switch ($this->option) {
            case 1:
                $this->_titles['main'][0] = 'id_product';
                $this->_titles['main'][1] = 'reference';
                $this->_titles['main'][2] = 'name';
                $this->_titles['main'][3] = 'wholesale_price';
                $this->_titles['main'][4] = 'price';
                $this->_titles['main'][5] = 'reseller_price';
                $this->_titles['main'][6] = 'percent';
                break;
        }
    }

    protected function getData($layers)
    {
        if ($this->option == 1) {
            $products = $this->getWholesalePricelist($this->context->language->id);
            foreach ($products as $product) {
                $this->_values[0][] = $product['reference'];
                $this->_values[1][] = '"'.$product['name'].'"';
                $this->_values[2][] = number_format((float)$product['wholesale_price'], 2, ',', '.');
                $this->_values[3][] = number_format((float)$product['price'], 2, ',', '.');
                $this->_values[4][] = number_format((float)$product['reseller_price'], 2, ',', '.');
                $this->_values[5][] = number_format((float)$product['percent'], 2, ',', '.');
                $this->_legend[] = $product['id_product'];
            }
        }
    }
}
