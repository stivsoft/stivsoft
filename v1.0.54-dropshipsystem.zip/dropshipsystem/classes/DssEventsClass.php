<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class DssEventsClass extends ObjectModel
{
    public $id;
    public $id_shop;
    public $date;
    public $type;
    public $handled_date;
    public $handled_by;
    public $message;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'dss_events',
        'primary' => 'id_dss_event',
        'fields' => array(
            'id_shop' =>        array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true),
            'date' =>           array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
            'type' =>           array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'handled_date' =>   array('type' => self::TYPE_DATE, 'allow_null' => true, 'validate' => 'isDate'),
            'handled_by' =>     array('type' => self::TYPE_INT, 'allow_null' => true, 'validate' => 'isUnsignedInt'),
            'message' =>        array('type' => self::TYPE_STRING, 'validate' => 'isString'),
        ),
    );

    public static function setEvent($type, $message, $handled = null)
    {
        $id_shop = (int)Context::getContext()->shop->id;

        $event = new DssEventsClass();
        $event->id_shop = $id_shop;
        $event->date = (string)date('Y-m-d H:i:s');
        $event->type = $type;
        $event->message = pSQL($message);
        if (isset($handled)) {
            $event->handled_date = (string)date('Y-m-d H:i:s');
            $event->handled_by = pSQL($handled);
        }
        $event->save();
    }

    public static function handleEvent($id_event, $handled)
    {
        if (isset($id_event) && $id_event > 0) {
            $event = new DssEventsClass((int)$id_event);
            $event->handled_date = (string)date('Y-m-d H:i:s');
            $event->handled_by = pSQL($handled);
            $event->update();
        }
    }
}
