<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

include_once(_PS_MODULE_DIR_.'dropshipsystem/dropshipsystem.php');

class DssOrderClass extends ObjectModel
{
    public $id;
    public $id_order;
    public $id_dropshipper;
    public $id_shipping_address;
    public $id_billing_address;
    public $order_reference;
    public $shipping_method;
    public $payment_type;
    public $total;
    public $previous_credit;
    public $current_credit;
    public $payment_link;
    public $payment_gateway_link;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'dss_order',
        'primary' => 'id_dss_order',
        'fields' => array(
            'id_order' =>               array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
            'id_dropshipper' =>         array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            'id_shipping_address' =>    array('type' => self::TYPE_INT, 'allow_null' => true, 'validate' => 'isUnsignedInt'),
            'id_billing_address' =>     array('type' => self::TYPE_INT, 'allow_null' => true, 'validate' => 'isUnsignedInt'),
            'order_reference' =>        array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'shipping_method' =>        array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            'payment_type' =>           array('type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true),
            'total' =>                  array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat'),
            'previous_credit' =>        array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat'),
            'current_credit' =>         array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat'),
            'payment_link' =>           array('type' => self::TYPE_STRING, 'validate' => 'isUrl', 'required' => false),
            'payment_gateway_link' =>   array('type' => self::TYPE_STRING, 'validate' => 'isUrl'),
        ),
    );

    public function getDssOrderByOrderID($id_order)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow('
            SELECT *
            FROM `'._DB_PREFIX_.'dss_order`
            WHERE `id_order` = '.(int)$id_order);

        if (!$result) {
            return false;
        }

        $this->id = $result['id_dss_order'];
        foreach ($result as $key => $value) {
            if (property_exists($this, $key)) {
                $this->{$key} = $value;
            }
        }

        return $this;
    }

    public static function getDssOrderIDByOrderID($id_order)
    {
        return (int)Db::getInstance()->getValue('
            SELECT `id_dss_order`
            FROM `'._DB_PREFIX_.'dss_order`
            WHERE `id_order` = '.(int)$id_order);
    }

    public static function getOrdersIDByDropshipperID($id_dropshipper)
    {
        $results = Db::getInstance()->executeS('
            SELECT `id_order`
            FROM `'._DB_PREFIX_.'dss_order`
            WHERE `id_dropshipper` = '.(int)$id_dropshipper);

        $res = array();
        foreach ($results as $result) {
             $res[] = (int)$result['id_order'];
        }
        return $res;
    }

    public static function getOrderIDByReference($reference)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
            SELECT o.`id_order`
            FROM `'._DB_PREFIX_.'orders` o
            WHERE o.`reference` = \''.pSql($reference).'\'');
    }

    public static function getOrderStates($id_lang, $current_state = null)
    {
        $cache_id = 'DssOrderClass::getOrderStates_'.(int)$id_lang.'_'.isset($current_state) ? $current_state : '0';
        if (!Cache::isStored($cache_id)) {
            $sql = 'SELECT *
                FROM `'._DB_PREFIX_.'order_state` os
                LEFT JOIN `'._DB_PREFIX_.'order_state_lang` osl ON (os.`id_order_state` = osl.`id_order_state` AND osl.`id_lang` = '.(int)$id_lang.')
                WHERE os.deleted = 0 AND os.unremovable = 0 '.(isset($current_state) ? 'AND os.id_order_state = '.(int)$current_state : '').'
                ORDER BY osl.`name` ASC';

            if (isset($current_state)) {
                $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow($sql);
            } else {
                $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
            }

            Cache::store($cache_id, $result);
            return $result;
        }
        return Cache::retrieve($cache_id);
    }

    public static function verifyOrderOwner($id_dropshipper, $id_order)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
            SELECT o.`id_customer`
            FROM `'._DB_PREFIX_.'orders` o
            INNER JOIN `'._DB_PREFIX_.'dss_order` dsso ON dsso.`id_order` = o.`id_order`
            WHERE dsso.`id_dropshipper` = '.pSql($id_dropshipper).' 
            AND o.`id_order` = '.pSql($id_order));
    }

    public static function getOrderTotalByPeriod($id_dropshipper = null, $period = null, $type = 'daily')
    {
        $context = Context::getContext();
        $id_shop = (int)$context->shop->id;

        if (!$period) {
            $year = date('Y');
            $month = date('m');
            $day = date('d');
        } else {
            $time = date('Y-m-d 00:00:00', strtotime($period));
            $year = date('Y', $time);
            $month = date('m', $time);
            $day = date('d', $time);
        }

        $status = array(
            (int)Configuration::get('PS_OS_PAYMENT', null, null, $id_shop),
            (int)Configuration::get('PS_OS_PREPARATION', null, null, $id_shop),
            (int)Configuration::get('PS_OS_SHIPPING', null, null, $id_shop),
            (int)Configuration::get('PS_OS_DELIVERED', null, null, $id_shop)
        );

        $sql = 'SELECT dsso.`id_dropshipper`, 
            YEAR(o.`date_add`) AS `year`, MONTH(o.`date_add`) AS `month`, ';
        if ($type == 'daily') {
            $sql .= 'DAY(o.`date_add`) AS `day`, ';
        } elseif ($type == 'monthly') {
            $sql .= '0 AS `day`, ';
        }
        $sql .= 'COALESCE(SUM(o.`total_paid`), 0) AS `total`
            FROM `'._DB_PREFIX_.'dss_order` dsso 
            INNER JOIN `'._DB_PREFIX_.'orders` o ON o.`id_order` = dsso.`id_order` 
            WHERE o.`current_state` IN ('.implode(',', $status).') ';
        if ($id_dropshipper) {
            $sql .= 'AND dsso.`id_dropshipper` = '.(int)$id_dropshipper.' ';
        }
        if ($type == 'daily') {
            $sql .= 'AND YEAR(o.`date_add`) = '.(int)$year.' AND MONTH(o.`date_add`) = '.(int)$month.' ';
        } elseif ($type == 'monthly') {
            $sql .= 'AND YEAR(o.`date_add`) = '.(int)$year.' AND MONTH(o.`date_add`) = '.(int)$month.' AND DAY(o.`date_add`) = '.(int)$day.' ';
        }
        $sql .= 'GROUP BY `year`, `month`, `day`
            ORDER BY dsso.`id_dropshipper`, o.`date_add`';

        if ($id_dropshipper) {
            return Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow($sql);
        } else {
            return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
        }
    }

    public static function getPaymentLink($id_order)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
            SELECT dsso.`payment_link`
            FROM `'._DB_PREFIX_.'dss_order` dsso
            WHERE dsso.`id_order` = '.pSql($id_order));
    }

    public static function getPaymentGatewayLinkByOrderReference($order_reference)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
            SELECT dsso.`payment_gateway_link`
            FROM `'._DB_PREFIX_.'dss_order` dsso
            LEFT JOIN `'._DB_PREFIX_.'orders` o ON dsso.`id_order` = o.`id_order`
            WHERE o.`reference` = \''.pSql($order_reference).'\'');
    }

    public static function setOrderPaymentTransaction($order, $transaction)
    {
        $payment_method = Module::getInstanceByName($order->module);

        return Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('
            UPDATE `'._DB_PREFIX_.'order_payment`
            SET `transaction_id` = \''.pSql($transaction).'\'
            WHERE `order_reference` = \''.pSql($order->reference).'\' AND 
            `payment_method` = \''.pSql($payment_method->displayName).'\'');
    }
}
