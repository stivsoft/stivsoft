<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class DssPaymentsTokenClass extends ObjectModel
{
    public $id;

    /** @var string token */
    public $token;

    /** @var string status */
    public $status;

    /** @var string payment_gateway */
    public $payment_gateway;

    /** @var int id_order */
    public $id_order;

    /** @var int is_credit */
    public $is_credit;

    /** @var string name */
    public $name;

    /** @var string custom_reference */
    public $custom_reference;

    /** @var string currency */
    public $currency;

    /** @var float amount */
    public $amount;

    /** @var string params */
    public $params;

    /** @var string return_url */
    public $return_url;

    /** @var string cancel_url */
    public $cancel_url;

    /** @var string Object creation date */
    public $date_add;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'dss_payments_token',
        'primary' => 'id_dss_payment_token',
        'fields' => array(
            'token'                 => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'status'                => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'payment_gateway'       => array('type' => self::TYPE_STRING, 'allow_null' => true, 'validate' => 'isString'),
            'id_order'              => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            'is_credit'             => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'name'                  => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'custom_reference'      => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'currency'              => array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'amount'                => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice'),
            'params'                => array('type' => self::TYPE_STRING, 'allow_null' => true, 'validate' => 'isString'),
            'return_url'            => array('type' => self::TYPE_STRING, 'allow_null' => true, 'validate' => 'isString'),
            'cancel_url'            => array('type' => self::TYPE_STRING, 'allow_null' => true, 'validate' => 'isString'),
            'date_add'              => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
        ),
    );

    public function __construct($id = null)
    {
        if (isset($id) && is_string($id)) {
            $id_token = (int)DssPaymentsTokenClass::getIDPaymentTokenByToken($id);
            $this->id = (int)$id_token;
            $id = (int)$this->id;
        } else {
            $this->status = 'valid';
        }
        parent::__construct($id);
    }

    public static function getToken()
    {
        $context = Context::getContext();

        return Tools::strtoupper(Tools::substr(sha1(uniqid(rand(), true)._COOKIE_KEY_.$context->customer->id), 0, 32));
    }

    public function getIDPaymentTokenByToken($token)
    {
        return (int)Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
            SELECT `id_dss_payment_token`
            FROM `'._DB_PREFIX_.'dss_payments_token`
            WHERE `token` = \''.pSql($token).'\'');
    }

    public static function getPaymentByToken($token)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
            SELECT * 
            FROM `'._DB_PREFIX_.'dss_payments_token` 
            WHERE `token` = \''.pSQL($token).'\'');
    }

    public function setStatus($status)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('
            UPDATE `'._DB_PREFIX_.'dss_payments_token`
            SET `status` = \''.(string)$status.'\'
            WHERE `id_dss_payment_token` = '.(int)$this->id);
    }
}
