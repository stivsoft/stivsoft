<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class DssClass extends ObjectModel
{
    private $context;
    private $csv;
    private $xml;
    private $csvFilename;
    private $csvOutput;
    private $xmlFilename;
    private $xmlOutput;
    private $wholesale_base_price;
    private $base_price;

    public function __construct()
    {
        if ((int)Configuration::get('DSS_REGISTRATION_POOL') < (int)time()) {
            Configuration::updateValue('DSS_REGISTRATION_POOL', (int)strtotime(date('Y-m-d 23:59:59')));
            $reg_order = (string)Configuration::get('DSS_REGISTRATION_ORDER');
            $reg_key = (string)Configuration::get('DSS_REGISTRATION_KEY');

            $reg = DssClass::checkRegistration($reg_order, $reg_key);
            if (isset($reg) && $reg) {
                $lic = (string)$reg['lic'];

                if ($lic != 'valid') {
                    Configuration::updateValue('DSS_REGISTRATION_ORDER', '');
                    Configuration::updateValue('DSS_REGISTRATION_KEY', '');
                    Configuration::updateValue('DSS_REGISTRATION', 0);
                }
            }
        }
    }

    public function getCategoryIDByReference($ref)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $sql = 'SELECT `c`.`id_category`
            FROM `'._DB_PREFIX_.'category` `c`
            '.Shop::addSqlAssociation('category', 'c').'
            INNER JOIN `'._DB_PREFIX_.'dss_categories` `dssc`
            ON `c`.`id_category` = `dssc`.`id_category`
            WHERE `c`.`active` = 1 AND `dssc`.`dss_category_active` = 1
            AND `dssc`.`dss_category_code` = \''.pSQL($ref).'\' ';
        if (Shop::isFeatureActive() && $id_shop) {
            $sql .= 'AND dssc.`id_shop` = '.(int)$id_shop;
        }
        return (int)Db::getInstance()->getValue($sql);
    }

    public static function makeUniqueCode($category, $ucodes)
    {
        $parent = isset($ucodes[(int)$category['id_parent']]['code']) ? (string)$ucodes[(int)$category['id_parent']]['code'] : '';

        $variant = 0;
        do {
            $name = Tools::strtoupper((string)$category['name']);
            $arr = explode(' ', $name);

            if (count($arr) > 1) {
                $part = '';
                foreach ($arr as $key => $value) {
                    if (Tools::strlen($value) < 4) {
                        continue;
                    }
                    $name = preg_replace('/[^\w]/', '', (string)$arr[$key]);
                    $part .= Tools::substr($name, 0, 2);
                }
                $unique = $parent.$part.($variant > 0 ? (string)$variant : '');
            } else {
                $name = preg_replace('/[^\w]/', '', (string)$name);
                $unique = $parent.Tools::substr($name, 0, 2).($variant > 0 ? (string)$variant : '');
            }

            $variant++;

            $duplicate = false;
            foreach ($ucodes as $code) {
                if ((string)$code['code'] == (string)$unique) {
                    $duplicate = true;
                }
            }
        } while ($duplicate);

        return array('parent' => $parent, 'code' => $unique);
    }

    public function getCategoryUniqueCodeByID($id_category)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $sql = 'SELECT `dssc`.`dss_category_code`
            FROM `'._DB_PREFIX_.'category` `c`
            '.Shop::addSqlAssociation('category', 'c').'
            INNER JOIN `'._DB_PREFIX_.'dss_categories` `dssc`
            ON `c`.`id_category` = `dssc`.`id_category`
            WHERE `c`.`active` = 1 AND `dssc`.`dss_category_active` = 1
            AND `dssc`.`id_category` = '.(int)$id_category.' ';
        if (Shop::isFeatureActive() && $id_shop) {
            $sql .= 'AND dssc.`id_shop` = '.(int)$id_shop;
        }
        return (string)Db::getInstance()->getValue($sql);
    }

    public function getAdditionalCategoriesUniqueCodeByIDProduct($id_product, $id_shop = false)
    {
        $sql = 'SELECT DISTINCT `dssc`.`dss_category_code`
            FROM `'._DB_PREFIX_.'category_product` `cp`
            INNER JOIN `'._DB_PREFIX_.'category` `c` 
            ON `c`.`id_category` = `cp`.`id_category`
            '.Shop::addSqlAssociation('category', 'c').'
            INNER JOIN `'._DB_PREFIX_.'dss_categories` `dssc`
            ON `c`.`id_category` = `dssc`.`id_category`
            WHERE `c`.`active` = 1 AND `dssc`.`dss_category_active` = 1 ';
        if (Shop::isFeatureActive() && $id_shop) {
            $sql .= ' AND (`dssc`.`id_shop` = '.(int)$id_shop.') ';
        }
        $sql .= 'AND `cp`.`id_product` = '.(int)$id_product.'
            AND `cp`.`id_category` <> (SELECT `p`.`id_category_default`
            FROM `'._DB_PREFIX_.'product` `p`
            '.Shop::addSqlAssociation('product', 'p').'
            WHERE `p`.`id_product` = `cp`.`id_product`)';

        $ret = Db::getInstance()->executeS($sql);

        $codes = array();
        foreach ($ret as $code) {
            $codes[] = $code['dss_category_code'];
        }
        return (string)implode(',', $codes);
    }

    public function countProducts($categories_codes = array())
    {
        if (empty($categories_codes)) {
            return 0;
        }
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_default_group = (int)$this->context->customer->id_default_group;

        $sql = 'SELECT COUNT(DISTINCT p.`id_product`) AS products
            FROM `'._DB_PREFIX_.'product` AS p
            '.Shop::addSqlAssociation('product', 'p').
            (Group::isFeatureActive() ? '
            INNER JOIN `'._DB_PREFIX_.'category_group` cg ON (cg.`id_category` = p.`id_category_default`) 
            AND cg.`id_group` = '.(int)$id_default_group : '').' 
            WHERE p.`id_category_default` IN (
                SELECT dssc.`id_category` 
                FROM `'._DB_PREFIX_.'dss_categories` AS dssc
                INNER JOIN `'._DB_PREFIX_.'category` c ON c.`id_category` = dssc.`id_category` '.
                (Group::isFeatureActive() ? '
                INNER JOIN `'._DB_PREFIX_.'category_group` cg ON cg.`id_category` = c.`id_category` ' : '').'
                WHERE c.`active` = 1 AND dssc.`dss_category_active` = 1 '.
                (Group::isFeatureActive() ? ' AND cg.id_group = '.(int)$id_default_group : '').Shop::addSqlRestrictionOnLang('dssc').'
                AND dssc.`dss_category_code` IN (\''.implode('\',\'', $categories_codes).'\')) 
            AND p.`visibility` IN ("both", "catalog") ';
        if (Group::isFeatureActive()) {
            $sql .= 'AND p.`id_manufacturer` IN (0, COALESCE((
                SELECT DISTINCT dssm.`id_manufacturer` 
                FROM `'._DB_PREFIX_.'dss_manufacturers` dssm
                WHERE dssm.`id_manufacturer` = p.`id_manufacturer` '.Shop::addSqlRestrictionOnLang('dssm').'
                AND dssm.`group` IN (0, '.(int)$id_default_group.')), 0)) '.'
            AND p.`id_supplier` IN (0, COALESCE((
                SELECT DISTINCT dsss.`id_supplier` 
                FROM `'._DB_PREFIX_.'dss_suppliers` dsss
                WHERE dsss.`id_supplier` = p.`id_supplier` '.Shop::addSqlRestrictionOnLang('dsss').'
                AND dsss.`group` IN (0, '.(int)$id_default_group.')), 0)) '.'
            AND cg.`id_group` NOT IN (
                SELECT dsspg.`group` 
                FROM `'._DB_PREFIX_.'dss_product_groups` dsspg 
                WHERE dsspg.`id_product` = p.`id_product` '.Shop::addSqlRestrictionOnLang('dsspg').')';
        }
        $ret = Db::getInstance()->getValue($sql);

        return isset($ret) ? (int)$ret : 0;
    }

    public function getSimpleProducts($id_lang, $groups = null, $id_category = null)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        if (isset($groups) && Group::isFeatureActive() && !is_array($groups)) {
            $groups = (array)$groups;
        }

        $sql = 'SELECT DISTINCT p.`id_product`, pl.`name`
            FROM `'._DB_PREFIX_.'product` p
            '.Shop::addSqlAssociation('product', 'p').'
            LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON (p.`id_product` = pl.`id_product` '.Shop::addSqlRestrictionOnLang('pl').')
            '.(isset($groups) && Group::isFeatureActive() ? '
            LEFT JOIN `'._DB_PREFIX_.'category_product` cp ON cp.`id_product` = p.`id_product` 
            LEFT JOIN `'._DB_PREFIX_.'category` c ON c.`id_category` = cp.`id_category`
            '.Shop::addSqlAssociation('category', 'c').'
            LEFT JOIN `'._DB_PREFIX_.'category_group` cg ON cg.`id_category` = cp.`id_category`' : '').'
            INNER JOIN `'._DB_PREFIX_.'dss_categories` dssc ON c.`id_category` = dssc.`id_category`
            WHERE dssc.`dss_category_active` = 1
            AND pl.`id_lang` = '.(int)$id_lang.' AND p.`visibility` IN ("both", "catalog")
            '.(isset($groups) && Group::isFeatureActive() ? ' AND cg.`id_group` NOT IN (
                SELECT dsspg.`group` 
                FROM `'._DB_PREFIX_.'dss_product_groups` dsspg 
                WHERE dsspg.`id_product` = p.`id_product` '.Shop::addSqlRestrictionOnLang('dsspg').') 
			AND cg.`id_group` IN ('.implode(',', $groups).') ' : ' ').'
            '.(isset($id_category) ? ' AND p.`id_category_default` = '.(int)$id_category : ' ').'
            ORDER BY pl.`name`';

        return Db::getInstance()->executeS($sql);
    }

    public function getProducts($id_lang, $start, $limit, $order_by, $order_way, $id_category = false, $only_active = false, $groups = null, $query = null)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
 
        if (isset($groups) && Group::isFeatureActive() && !is_array($groups)) {
            $groups = (array)$groups;
        }
        if ($order_by == 'id_product' || $order_by == 'price' || $order_by == 'date_add' || $order_by == 'date_upd') {
            $order_by_prefix = 'p';
        } elseif ($order_by == 'name') {
            $order_by_prefix = 'pl';
        } elseif ($order_by == 'position') {
            $order_by_prefix = 'c';
        }

        if (strpos($order_by, '.') > 0) {
            $order_by = explode('.', $order_by);
            $order_by_prefix = $order_by[0];
            $order_by = $order_by[1];
        }
        $sql = 'SELECT DISTINCT p.*, 
                pl.`id_lang`, pl.`description`, pl.`description_short`, pl.`link_rewrite`, 
                pl.`meta_description`, pl.`meta_keywords`, pl.`meta_title`, pl.`name`, pl.`available_now`, pl.`available_later`,
                m.`name` AS manufacturer_name, s.`name` AS supplier_name
                FROM `'._DB_PREFIX_.'product` p
                '.Shop::addSqlAssociation('product', 'p').'
                LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON (p.`id_product` = pl.`id_product` '.Shop::addSqlRestrictionOnLang('pl').')
                LEFT JOIN `'._DB_PREFIX_.'manufacturer` m ON (m.`id_manufacturer` = p.`id_manufacturer`)
                '.Shop::addSqlAssociation('manufacturer', 'm', false).'
                LEFT JOIN `'._DB_PREFIX_.'supplier` s ON (s.`id_supplier` = p.`id_supplier`)
                '.Shop::addSqlAssociation('supplier', 's', false).'
                LEFT JOIN `'._DB_PREFIX_.'category` c ON (c.`id_category` = p.`id_category_default`)
                '.Shop::addSqlAssociation('category', 'c').
                (isset($groups) && Group::isFeatureActive() ? '
                LEFT JOIN `'._DB_PREFIX_.'category_group` cg ON (cg.`id_category` = p.`id_category_default`) ' : ' ').'
                INNER JOIN `'._DB_PREFIX_.'dss_categories` dssc ON c.`id_category` = dssc.`id_category`
                WHERE dssc.`dss_category_active` = 1 AND pl.`id_lang` = '.(int)$id_lang.' '.
                    (isset($groups) && Group::isFeatureActive() ? 'AND p.`id_manufacturer` IN (0, COALESCE((
                        SELECT DISTINCT dssm.`id_manufacturer` FROM `'._DB_PREFIX_.'dss_manufacturers` dssm
                        WHERE dssm.`id_manufacturer` = p.`id_manufacturer` '.Shop::addSqlRestrictionOnLang('dssm').' 
                        AND dssm.`group` IN (0, '.implode(',', $groups).')), 0)) '.'
                    AND p.`id_supplier` IN (0, COALESCE((
                        SELECT DISTINCT dsss.`id_supplier` FROM `'._DB_PREFIX_.'dss_suppliers` dsss
                        WHERE dsss.`id_supplier` = p.`id_supplier` '.Shop::addSqlRestrictionOnLang('dsss').' 
                        AND dsss.`group` IN (0, '.implode(',', $groups).')), 0)) '.'
                    AND cg.`id_group` NOT IN (
                        SELECT dsspg.`group` 
                        FROM `'._DB_PREFIX_.'dss_product_groups` dsspg 
                        WHERE dsspg.`id_product` = p.`id_product` '.Shop::addSqlRestrictionOnLang('dsspg').') ' : ' ').'
                    '.($id_category ? ' AND c.`id_category` = '.(int)$id_category.' ' : '').'
                    AND p.`visibility` IN ("both", "catalog") '.($only_active ? ' AND p.`active` = 1' : ' ').'
                    '.(isset($groups) && Group::isFeatureActive() ? ' AND cg.`id_group` IN ('.implode(',', $groups).') ' : '').'
                    '.(isset($query) ? ' AND (pl.`name` LIKE \'%'.(string)$query.'%\' OR p.`reference` LIKE \'%'.(string)$query.'%\') ' : '').'
                ORDER BY '.(isset($order_by_prefix) ? pSQL($order_by_prefix).'.' : '').'`'.pSQL($order_by).'` '.pSQL($order_way).
                ($limit > 0 ? ' LIMIT '.(int)$start.','.(int)$limit : '');
        $rq = Db::getInstance()->executeS($sql);
        if ($order_by == 'price') {
            Tools::orderbyPrice($rq, $order_way);
        }
        foreach ($rq as &$row) {
            $row = Product::getTaxesInformations($row);
        }

        return ($rq);
    }

    public function getProductIDByReference($ref, $id_shop = false)
    {
        $count = (int)Db::getInstance()->getValue('
            SELECT COUNT(*) AS count
            FROM `'._DB_PREFIX_.'product_attribute` `pa`
            WHERE `pa`.`reference` = \''.pSQL($ref).'\'');

        if (!$count) {
            $sql = 'SELECT `p`.`id_product`, 0 AS id_product_attribute
                FROM `'._DB_PREFIX_.'product` `p` ';
            if (Shop::isFeatureActive() && $id_shop) {
                $sql .= 'INNER JOIN `'._DB_PREFIX_.'product_shop` `ps` ';
                $sql .= 'ON (`ps`.`id_product` = `p`.`id_product`) AND (`ps`.`id_shop` = '.(int)$id_shop.') ';
            }
            $sql .= 'WHERE `p`.`reference` = \''.pSQL($ref).'\'';
        } else {
            $sql = 'SELECT `p`.`id_product`, `pa`.`id_product_attribute`
                FROM `'._DB_PREFIX_.'product` `p` ';
            if (Shop::isFeatureActive() && $id_shop) {
                $sql .= 'INNER JOIN `'._DB_PREFIX_.'product_shop` `ps` ';
                $sql .= 'ON (`ps`.`id_product` = `p`.`id_product`) AND (`ps`.`id_shop` = '.(int)$id_shop.') ';
            }
            $sql .= 'LEFT JOIN `'._DB_PREFIX_.'product_attribute` `pa`
                ON `p`.`id_product` = `pa`.`id_product`
                WHERE `pa`.`reference` = \''.pSQL($ref).'\'';
        }

        return Db::getInstance()->getRow($sql);
    }

    public function getProductIDBySupplierRef($ref, $id_shop = false)
    {
        $sql = 'SELECT `p`.`id_product` 
            FROM `'._DB_PREFIX_.'product` `p` ';
        if (Shop::isFeatureActive() && $id_shop) {
            $sql .= 'INNER JOIN `'._DB_PREFIX_.'product_shop` `ps` ';
            $sql .= 'ON (`ps`.`id_product` = `p`.`id_product`) AND (`ps`.`id_shop` = '.(int)$id_shop.') ';
        }
        $sql .= 'WHERE `p`.`supplier_reference` = \''.pSQL($ref).'\'';

        return Db::getInstance()->getValue($sql);
    }

    public function getProductAttributeIDByRef($ref, $id_shop = false)
    {
        $sql = 'SELECT `pa`.`id_product_attribute` 
            FROM `'._DB_PREFIX_.'product_attribute` `pa` ';
        if (Shop::isFeatureActive() && $id_shop) {
            $sql .= 'INNER JOIN `'._DB_PREFIX_.'product_shop` `ps` ';
            $sql .= 'ON (`ps`.`id_product` = `pa`.`id_product`) AND (`ps`.`id_shop` = '.(int)$id_shop.') ';
        }
        $sql .= 'WHERE `pa`.`reference` = \''.pSQL($ref).'\'';

        return Db::getInstance()->getValue($sql);
    }

    public static function getIdProductAttributesByIdAttributes($id_product, $id_attributes, $find_best = false)
    {
        if (!is_array($id_attributes)) {
            return 0;
        }

        $id_product_attribute =  Db::getInstance()->getValue('
            SELECT pac.`id_product_attribute`
            FROM `'._DB_PREFIX_.'product_attribute_combination` pac
            INNER JOIN `'._DB_PREFIX_.'product_attribute` pa ON pa.id_product_attribute = pac.id_product_attribute
            WHERE id_product = '.(int)$id_product.' AND id_attribute IN ('.implode(',', array_map('intval', $id_attributes)).')
            GROUP BY id_product_attribute
            HAVING COUNT(id_product) = '.count($id_attributes));

        if ($id_product_attribute === false && $find_best) {
            //find the best possible combination
            //first we order $id_attributes by the group position
            $orderred = array();
            $result = Db::getInstance()->executeS('SELECT `id_attribute` FROM `'._DB_PREFIX_.'attribute` a
                INNER JOIN `'._DB_PREFIX_.'attribute_group` g ON a.`id_attribute_group` = g.`id_attribute_group`
                WHERE `id_attribute` IN ('.implode(',', array_map('intval', $id_attributes)).') ORDER BY g.`position` ASC');

            foreach ($result as $row) {
                $orderred[] = $row['id_attribute'];
            }

            while ($id_product_attribute === false && count($orderred) > 0) {
                array_pop($orderred);
                $id_product_attribute =  Db::getInstance()->getValue('
                    SELECT pac.`id_product_attribute`
                    FROM `'._DB_PREFIX_.'product_attribute_combination` pac
                    INNER JOIN `'._DB_PREFIX_.'product_attribute` pa ON pa.id_product_attribute = pac.id_product_attribute
                    WHERE id_product = '.(int)$id_product.' AND id_attribute IN ('.implode(',', array_map('intval', $orderred)).')
                    GROUP BY id_product_attribute
                    HAVING COUNT(id_product) = '.count($orderred));
            }
        }
        return $id_product_attribute;
    }

    public function getExtraDescription($langs, $group, $id_product, $id_product_attibute = -1, $id_shop = 0)
    {
        $arrdesc = array();
        foreach ($langs as $lang) {
            $arrdesc[$lang['id_lang']] = '';
        }
        if ($confs = Configuration::get('DSS_ENABLE_THIRD_MODULES', null, null, $id_shop)) {
            $confs = explode(',', Configuration::get('DSS_ENABLE_THIRD_MODULES', null, null, $id_shop));
        } else {
            $confs = array();
        }
        foreach ($confs as $conf) {
            //*** START MODULE - PRODUCT EXTRA TABS - ***//
            $mod_productextratabs = Module::getInstanceByName('productextratabs');
            if (Validate::isLoadedObject($mod_productextratabs) && $mod_productextratabs->active && $mod_productextratabs->id == $conf) {
                $sql = 'SELECT pt.`id_tab`, pt.`type`, ptl.`id_lang`, ptl.`name`, ptcl.`content`
                    FROM `'._DB_PREFIX_.'pet_tab` pt
                    INNER JOIN `'._DB_PREFIX_.'pet_tab_shop` pts ON pts.`id_tab` = pt.`id_tab`
                    INNER JOIN `'._DB_PREFIX_.'pet_tab_content` ptc ON ptc.`id_tab` = pt.`id_tab`
                    INNER JOIN `'._DB_PREFIX_.'pet_tab_lang` ptl ON ptl.`id_tab` = pt.`id_tab` '.Shop::addSqlRestrictionOnLang('ptl').'
                    INNER JOIN `'._DB_PREFIX_.'pet_tab_content_shop` ptcs ON ptcs.`id_tab_content` = ptc.`id_tab_content` AND pts.`id_shop` = ptcs.`id_shop`
                    INNER JOIN `'._DB_PREFIX_.'pet_tab_content_lang` ptcl ON ptcl.`id_tab_content` = ptc.`id_tab_content` AND ptcl.`id_lang` = ptl.`id_lang` '.Shop::addSqlRestrictionOnLang('ptcl').'
                    WHERE pt.`type` IN (\'content\', \'combination\') AND pts.`active` = 1 AND ptcs.`customer_group_show` IN (-1, '.(int)$group.')
                    AND ptcs.`id_product` IN (-1, '.(int)$id_product.') ';
                if ($id_product_attibute > -1) {
                    $sql .= 'AND ptcs.`id_combination` = '.(int)$id_product_attibute.' ';
                } else {
                    $sql .= 'AND ptcs.`id_combination` = -1 ';
                }
                $sql .= 'ORDER BY pts.`position`';
                $result = Db::getInstance()->executeS($sql);
                foreach ($result as $res) {
                    foreach ($langs as $lang) {
                        if ((int)$res['id_lang'] == (int)$lang['id_lang']) {
                            $arrdesc[$lang['id_lang']] .= '<br><br><h3>'.$res['name'].'</h3>'.htmlspecialchars_decode($res['content']);
                        }
                    }
                }
            }
        }
        //*** END MODULE - PRODUCT EXTRA TABS - ***//

        return (array)$arrdesc;
    }

    public function getMultiFeatures($langs, $id_product, $id_feature)
    {
        if (!Feature::isFeatureActive()) {
            return array();
        }

        $arrfeature = array();

        //*** START MODULE - MULTI FEATURES - ***//
        $mod_multifeatures = Module::getInstanceByName('multifeatures');
        if (Validate::isLoadedObject($mod_multifeatures) && $mod_multifeatures->active) {
            foreach ($langs as $lang) {
                $arrfeature[$lang['id_lang']] = array();
            }

            $feature_value_positions = Db::getInstance()->executeS('
                SELECT fp.*, fvl.id_lang, fvl.value 
                FROM `'._DB_PREFIX_.'feature_product` fp
                INNER JOIN `'._DB_PREFIX_.'feature_value_lang` fvl ON (fvl.id_feature_value = fp.id_feature_value)
                WHERE fp.`id_product` = '.(int)$id_product.' AND fp.`id_feature` = '.(int)$id_feature.'
                ORDER BY fp.`position` ASC');
            if ($feature_value_positions && count($feature_value_positions)) {
                foreach ($langs as $lang) {
                    foreach ($feature_value_positions as $feature_value_position) {
                        if ($feature_value_position['id_lang'] == $lang['id_lang']) {
                            //$arrfeature[$lang['id_lang']][$feature_value_position['id_feature_value']] = $feature_value_position['value'];
                            $arrfeature[$lang['id_lang']][] = $feature_value_position['value'];
                        }
                    }
                }
            }
        } else {
            foreach ($langs as $lang) {
                $arrfeature[$lang['id_lang']] = '';
            }

            $feature_values = Db::getInstance()->executeS('
                SELECT fp.*, fvl.id_lang, fvl.value
                FROM `'._DB_PREFIX_.'feature_product` fp
                INNER JOIN `'._DB_PREFIX_.'feature_value_lang` fvl ON (fvl.id_feature_value = fp.id_feature_value)
                WHERE `id_product` = '.(int)$id_product.' AND fp.`id_feature` = '.(int)$id_feature);

            if ($feature_values && count($feature_values)) {
                foreach ($langs as $lang) {
                    foreach ($feature_values as $feature_value) {
                        if ($feature_value['id_lang'] == $lang['id_lang']) {
                            //$arrfeature[$lang['id_lang']][$feature_value_position['id_feature_value']] = $feature_value_position['value'];
                            $arrfeature[$lang['id_lang']] = $feature_value['value'];
                        }
                    }
                }
            }
        }
        //*** END MODULE - MULTI FEATURES - ***//

        return count($arrfeature) ? $arrfeature : false;
    }

    public function getFeatures($id_product)
    {
        if (!Feature::isFeatureActive()) {
            return array();
        }
        $sql = 'SELECT DISTINCT fp.id_feature
            FROM `'._DB_PREFIX_.'feature_product` fp
            LEFT JOIN `'._DB_PREFIX_.'feature_value` fv ON (fp.id_feature_value = fv.id_feature_value)
            WHERE `id_product` = '.(int)$id_product;

        return Db::getInstance()->executeS($sql);
    }

    public function getDropshipperGroups()
    {
        $sql = 'SELECT DISTINCT c.`id_default_group`
            FROM `'._DB_PREFIX_.'customer` c 
            INNER JOIN `'._DB_PREFIX_.'category_group` cg ON cg.`id_group` = c.`id_default_group` 
            INNER JOIN `'._DB_PREFIX_.'dss_dropshipper` d ON d.`id_customer` = c.`id_customer` 
            WHERE d.`active` = 1 AND (d.`date_end` > now() OR d.`date_end` IS NULL)
            ORDER BY c.`id_default_group`';

        return Db::getInstance()->executeS($sql);
    }

    public function getGroupIDByName($name, $id_lang, $id_shop = false)
    {
        $shop_criteria = '';
        if ($id_shop) {
            $shop_criteria = Shop::addSqlAssociation('group', 'g');
        }

        $ret = Db::getInstance()->getValue('
            SELECT DISTINCT g.`id_group`
            FROM `'._DB_PREFIX_.'group` g
            LEFT JOIN `'._DB_PREFIX_.'group_lang` AS gl ON (g.`id_group` = gl.`id_group` AND gl.`id_lang` = '.(int)$id_lang.')
            '.$shop_criteria.'
            WHERE gl.`name` = \''.pSql($name).'\'');

        return isset($ret['id_group']) ? (int)$ret['id_group'] : 0;
    }

    public function getDisabledCategories($id_lang)
    {
        $sql = 'SELECT `c`.`id_category`, `cl`.`name`
            FROM `'._DB_PREFIX_.'category` `c` 
            '.Shop::addSqlAssociation('category', 'c').'
            INNER JOIN `'._DB_PREFIX_.'category_lang` cl
            ON cl.`id_category` = c.`id_category` AND cl.`id_lang` = '.(int)$id_lang.'
            '.Shop::addSqlRestrictionOnLang('cl').'
            INNER JOIN `'._DB_PREFIX_.'dss_categories` dssc
            ON c.`id_category` = dssc.`id_category`
            WHERE c.`active` = 1 AND dssc.`dss_category_active` = 0 
            ORDER BY c.`id_category`';

        $cats = Db::getInstance()->executeS($sql);

        $ret = array();
        foreach ($cats as $cat) {
            $ret[] = array('id' => (int)$cat['id_category'], 'name' => (string)$cat['name']);
        }
        return $ret;
    }

    public function getGroupCategories($id_group)
    {
        $sql = 'SELECT `c`.`id_category`
            FROM `'._DB_PREFIX_.'category` c
            '.Shop::addSqlAssociation('category', 'c').'
            INNER JOIN `'._DB_PREFIX_.'category_group` cg
            ON cg.`id_category` = c.`id_category` AND cg.`id_group` = '.(int)$id_group.'
            INNER JOIN `'._DB_PREFIX_.'dss_categories` dssc
            ON c.`id_category` = dssc.`id_category`
            WHERE c.`active` = 1 AND dssc.`dss_category_active` = 1 AND c.`level_depth` > 0';

        $cats = Db::getInstance()->executeS($sql);

        $ret = array();
        foreach ($cats as $cat) {
            $ret[] = $cat['id_category'];
        }
        return $ret;
    }

    public function getNestedCategories($root_category, $id_lang, $groups = null)
    {
        if (isset($groups) && Group::isFeatureActive() && !is_array($groups)) {
            $groups = (array)$groups;
        }

        $sql = 'SELECT c.`id_category`, c.`id_parent`, dssc.`dss_category_active`, dssc.`dss_category_code`, dssc.`dss_category_code_parent`, cl.`name`
            FROM `'._DB_PREFIX_.'category` c
            '.Shop::addSqlAssociation('category', 'c').'
            LEFT JOIN `'._DB_PREFIX_.'dss_categories` dssc ON c.`id_category` = dssc.`id_category`
            LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON c.`id_category` = cl.`id_category`'.Shop::addSqlRestrictionOnLang('cl').'
            '.(isset($groups) && Group::isFeatureActive() ? 'LEFT JOIN `'._DB_PREFIX_.'category_group` cg ON c.`id_category` = cg.`id_category`' : '').'
            '.(isset($root_category) ? 'RIGHT JOIN `'._DB_PREFIX_.'category` c2 ON c2.`id_category` = '.(int)$root_category.' AND c.`nleft` >= c2.`nleft` AND c.`nright` <= c2.`nright`' : '').'
            WHERE `id_lang` = '.(int)$id_lang.' AND c.`active` = 1
            '.(isset($groups) && Group::isFeatureActive() ? ' AND cg.`id_group` IN ('.implode(',', $groups).')' : '').'
            GROUP BY c.`id_category` 
            ORDER BY c.`level_depth` ASC, category_shop.`position` ASC';

        $result = Db::getInstance()->executeS($sql);

        $categories = array();
        $buff = array();

        if (!isset($root_category)) {
            $root_category = Category::getRootCategory()->id;
        }

        foreach ($result as $row) {
            $current = &$buff[$row['id_category']];
            $current = $row;

            if ($row['id_category'] == $root_category) {
                $categories[$row['id_category']] = &$current;
                $categories[$row['id_category']]['children'] = array();
            } else {
                $buff[$row['id_parent']]['children'][$row['id_category']] = &$current;
            }
        }

        return $categories;
    }

    public function getProductQuantityByID($id_product, $id_product_attribute = null)
    {
        return StockAvailable::getQuantityAvailableByProduct($id_product, $id_product_attribute);
    }

    public function generatePDF($template, $display = false)
    {
        $this->context = Context::getContext();
        $id_shop = (int)$this->context->shop->id;

        $pdf_renderer = new PDFGenerator((bool)Configuration::get('PS_PDF_USE_CACHE', null, null, $id_shop), 'P');
        $pdf_renderer->setFontForLang($this->context->language->iso_code);
        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            $pdf_renderer->addTTFfont(dirname(__FILE__).'/../views/fonts/courier.ttf', 'Courier', '', 32);
        } else {
            $fontname = TCPDF_FONTS::addTTFfont(dirname(__FILE__).'/../views/fonts/courier.ttf', 'Courier', '', 32);
            $pdf_renderer->SetFont($fontname, '', 12, '', 'false');
        }
        $pdf_renderer->startPageGroup();

        $pdf_renderer->createHeader($this->getHeader());
        $pdf_renderer->createFooter($this->getFooter());
        $pdf_renderer->createContent($this->getContent($template));
        $pdf_renderer->writePage();

        foreach (Shop::getShops(false) as $shop) {
            $_dir_path = dirname(__FILE__).'/../downloads/'.(int)$shop['id_shop'];
            if (!file_exists($_dir_path)) {
                @mkdir($_dir_path, 0755, true);
                @copy($_dir_path.'/../index.php', $_dir_path.'/index.php');
            }
        }

        if (!$display) {
            $pdf_path = dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/'.$template.'.pdf';
            if (file_exists($pdf_path)) {
                unlink($pdf_path);
            }
            $output = @fopen($pdf_path, 'w');
            fwrite($output, $pdf_renderer->render($template.'.pdf', false));
            @fclose($output);
        } else {
            return $pdf_renderer->render($template.'.pdf', true);
        }
        return true;
    }

    protected function getHeader()
    {
        $this->assignCommonHeaderData();

        return $this->context->smarty->fetch($this->getTemplate('header'));
    }

    protected function getFooter()
    {
        $id_shop = (int)$this->context->shop->id;

        $this->context->smarty->assign(array(
            'footer_text' => Configuration::get('DSS_WSM_FOOTER_TEXT', (int)$this->context->language->id, null, $id_shop),
        ));

        return $this->context->smarty->fetch($this->getTemplate('footer'));
    }

    protected function getLogo()
    {
        $logo = '';
        $id_shop = (int)$this->context->shop->id;

        if (Configuration::get('DSS_WSM_LOGO', null, null, $id_shop) != false && file_exists(_PS_IMG_DIR_.Configuration::get('DSS_WSM_LOGO', null, null, $id_shop))) {
            $logo = _PS_IMG_DIR_.Configuration::get('DSS_WSM_LOGO', null, null, $id_shop);
        }

        return $logo;
    }

    protected function getContent($template)
    {
        $id_shop = (int)$this->context->shop->id;

        $this->context->smarty->assign(array(
            'first_page_text' => Configuration::get('DSS_WSM_FIRST_PAGE_TEXT', (int)$this->context->language->id, null, $id_shop),
        ));

        return $this->context->smarty->fetch($this->getTemplate($template));
    }

    protected function assignCommonHeaderData()
    {
        $id_shop = (int)$this->context->shop->id;
        $shop_name = Configuration::get('PS_SHOP_NAME', null, null, $id_shop);
        $currency = new Currency((int)$this->context->currency->id);

        $path_logo = $this->getLogo();

        $width = 0;
        $height = 0;
        if (!empty($path_logo)) {
            list($width, $height) = getimagesize($path_logo);
        }

        // Limit the height of the logo for the PDF render
        $maximum_height = 50;
        if ($height > $maximum_height) {
            $ratio = $maximum_height / $height;
            $height *= $ratio;
            $width *= $ratio;
        }

        $this->context->smarty->assign(array(
            'logo_path' => $path_logo,
            'shop_name' => $shop_name,
            'currency' => $currency,
            'base_url' => _PS_BASE_URL_,
            'width_logo' => $width,
            'height_logo' => $height
        ));
    }

    protected function getTemplate($template_name)
    {
        $template = false;
        $default_template = rtrim(_PS_MODULE_DIR_, DIRECTORY_SEPARATOR).'/dropshipsystem/views/templates/front/pdf/'.$template_name.'.tpl';
        $overridden_template = _PS_ALL_THEMES_DIR_.$this->context->shop->getTheme().'/modules/dropshipsystem/views/templates/front/pdf/'.$template_name.'.tpl';
        if (file_exists($overridden_template)) {
            $template = $overridden_template;
        } elseif (file_exists($default_template)) {
            $template = $default_template;
        }
        return $template;
    }

    protected static function l($string)
    {
        return Translate::getPdfTranslation($string);
    }

    public function doCatalogs()
    {
        $id_shop = (int)Context::getContext()->shop->id;
        $id_home_category = (int)Configuration::get('PS_HOME_CATEGORY', null, null, $id_shop);
        $id_default_lang = (int)Configuration::get('PS_LANG_DEFAULT', null, null, $id_shop);

        $this->wholesale_base_price = (int)Configuration::get('DSS_WHOLESALE_BASE_PRICE', null, null, $id_shop);
        $this->base_price = (int)Configuration::get('DSS_BASE_PRICE', null, null, $id_shop);

        $groups = $this->getDropshipperGroups();

        foreach (Shop::getShops(false) as $shop) {
            $_dir_path = dirname(__FILE__).'/../downloads/'.(int)$shop['id_shop'];
            if (!file_exists($_dir_path)) {
                @mkdir($_dir_path, 0755, true);
                @copy($_dir_path.'/../index.php', $_dir_path.'/index.php');
            }
        }

        if ((int)Configuration::get('DSS_DOWNLOAD_BLOCK_ENABLE', null, null, $id_shop)) {
            $_dir_path = dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/';
            if (is_dir($_dir_path)) {
                if ($dh = opendir($_dir_path)) {
                    $file_exclusion = array('.', '..', 'index.php', '.htaccess', 'dropship_agreement.pdf', 'webservice_manual.pdf');
                    while (($_file = readdir($dh)) !== false) {
                        if (!is_dir($_dir_path.$_file) && !in_array($_file, $file_exclusion)) {
                            @unlink($_dir_path.$_file);
                        }
                    }
                    closedir($dh);
                }
            }

            foreach ($groups as $group) {
                $group = (int)$group['id_default_group'];

                if ((int)Configuration::get('DSS_FILE_CATEGORIES_ENABLE', null, null, $id_shop)) {
                    $this->csvFilename = dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/categories_'.$group.'.csv';
                    $this->xmlFilename = dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/categories_'.$group.'.xml';

                    if (file_exists($this->csvFilename)) {
                        unlink($this->csvFilename);
                    }
                    if (file_exists($this->xmlFilename)) {
                        unlink($this->xmlFilename);
                    }

                    $this->csvOutput = @fopen($this->csvFilename, 'w');
                    $this->xmlOutput = @fopen($this->xmlFilename, 'w');

                    $this->writeCategoryHeader();

                    //$categories = Category::getNestedCategories($id_home_category, $id_default_lang, true, 3);
                    $categories = $this->getNestedCategories($id_home_category, $id_default_lang, $group);

                    $this->xml = "<?xml version='1.0' encoding='UTF-8'?>\n";
                    $this->xml .= "<categories>\n";
                    $this->xml .= $this->getSubItems($categories[$id_home_category]['children'], 'categories', $id_default_lang, $group);
                    $this->xml .= "</categories>";

                    fwrite($this->xmlOutput, $this->xml);

                    @fclose($this->csvOutput);
                    @fclose($this->xmlOutput);
                    unset($categories);
                }

                if ((int)Configuration::get('DSS_FILE_PRODUCTS_ENABLE', null, null, $id_shop)) {
                    $this->csvFilename = dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/products_'.$group.'.csv';
                    $this->xmlFilename = dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/products_'.$group.'.xml';

                    if (file_exists($this->csvFilename)) {
                        unlink($this->csvFilename);
                    }
                    if (file_exists($this->xmlFilename)) {
                        unlink($this->xmlFilename);
                    }

                    $this->csvOutput = @fopen($this->csvFilename, 'w');
                    $this->xmlOutput = @fopen($this->xmlFilename, 'w');

                    $this->writeProductHeader();

                    //$categories = Category::getNestedCategories($id_home_category, $id_default_lang, true, $group);
                    $categories = $this->getNestedCategories($id_home_category, $id_default_lang, $group);

                    $this->xml = "<?xml version='1.0' encoding='UTF-8'?>\n";
                    $this->xml .= "<products>\n";
                    if (isset($categories[$id_home_category]['children'])) {
                        $this->xml .= $this->getSubItems($categories[$id_home_category]['children'], 'products', $id_default_lang, $group);
                    }
                    $this->xml .= "</products>";

                    fwrite($this->xmlOutput, $this->xml);

                    @fclose($this->csvOutput);
                    @fclose($this->xmlOutput);
                }
            }

            $dropshippers = DssDropshippersClass::getDrophippers();

            foreach ($dropshippers as $dropshipper) {
                if ((int)Configuration::get('DSS_FILE_PRICELIST_ENABLE', null, null, $id_shop)) {
                    $_country = new Address($dropshipper['id_address_invoice']);
                    $dropshipper['id_country'] = (int)$_country->id_country;
                    unset($_country);

                    $this->csvFilename = dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/pricelist_'.$dropshipper['id_dss_dropshipper'].'.csv';
                    $this->xmlFilename = dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/pricelist_'.$dropshipper['id_dss_dropshipper'].'.xml';

                    if (file_exists($this->csvFilename)) {
                        unlink($this->csvFilename);
                    }
                    if (file_exists($this->xmlFilename)) {
                        unlink($this->xmlFilename);
                    }

                    $this->csvOutput = @fopen($this->csvFilename, 'w');
                    $this->xmlOutput = @fopen($this->xmlFilename, 'w');

                    $this->writePricelistHeader();

                    //$categories = Category::getNestedCategories($id_home_category, $id_default_lang, true, (int)$dropshipper['id_default_group']);
                    $categories = $this->getNestedCategories($id_home_category, $id_default_lang, (int)$dropshipper['id_default_group']);

                    $this->xml = "<?xml version='1.0' encoding='UTF-8'?>\n";
                    $this->xml .= "<pricelist>\n";
                    if (isset($categories[$id_home_category]['children'])) {
                        $this->xml .= $this->getSubItems($categories[$id_home_category]['children'], 'pricelist', $id_default_lang, (int)$dropshipper['id_default_group'], $dropshipper);
                    }
                    $this->xml .= "</pricelist>";

                    fwrite($this->xmlOutput, $this->xml);

                    @fclose($this->csvOutput);
                    @fclose($this->xmlOutput);
                }

                if ((int)Configuration::get('DSS_FILE_ALL_ENABLE', null, null, $id_shop)) {
                    if (extension_loaded('zip') && class_exists('ZipArchive')) {
                        $zip = new ZipArchive();
                        $zip->open(dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/all_'.$dropshipper['id_dss_dropshipper'].'.zip', ZipArchive::CREATE);

                        $zip->addFile(dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/categories_'.$dropshipper['id_default_group'].'.csv', 'csv/categories.csv');
                        $zip->addFile(dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/categories_'.$dropshipper['id_default_group'].'.xml', 'xml/categories.xml');
                        $zip->addFile(dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/products_'.$dropshipper['id_default_group'].'.csv', 'csv/products.csv');
                        $zip->addFile(dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/products_'.$dropshipper['id_default_group'].'.xml', 'xml/products.xml');
                        $zip->addFile(dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/pricelist_'.$dropshipper['id_dss_dropshipper'].'.csv', 'csv/pricelist.csv');
                        $zip->addFile(dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/pricelist_'.$dropshipper['id_dss_dropshipper'].'.xml', 'xml/pricelist.xml');
                        $zip->close();
                    }
                }
            }
        }

        $htaccess = array(dirname(__FILE__).'/../downloads/'.(int)$id_shop.'/.htaccess', dirname(__FILE__).'/../downloads/clients/.htaccess');
        foreach ($htaccess as $hta) {
            if (!$write_fd = @fopen($hta, 'w')) {
                return false;
            }
            fwrite($write_fd, "Order Deny,Allow\n");
            fwrite($write_fd, "Deny from all\n\n");
            fwrite($write_fd, "# .htaccess automaticaly generated by DropShip System Server module\n");
            fclose($write_fd);
        }
        return true;
    }

    private function getSubItems($categories, $type, $id_default_lang, $group, $dropshipper = null)
    {
        if (!isset($categories)) {
            return false;
        }
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        foreach ($categories as $category) {
            if (!(int)$category['dss_category_active']) {
                continue;
            }

            if ($type == 'categories') {
                $this->writeLine($this->csvOutput, array(
                    (string)$category['dss_category_code'],
                    (string)$category['dss_category_code_parent'],
                    (string)$category['name'],
                ));
    
                $this->xml .= "<category>\n";
                $this->xml .= "<reference>".(string)$category['dss_category_code']."</reference>\n";
                $this->xml .= "<parent>".(string)$category['dss_category_code_parent']."</parent>\n";
                $this->xml .= "<name><![CDATA[".(string)$category['name']."]]></name>\n";
                $this->xml .= "</category>\n";
                if (isset($category['children']) && $category['children'] != '') {
                    $this->xml .= $this->getSubItems($category['children'], $type, $id_default_lang, $group);
                }
            } elseif ($type == 'products') {
                $products = $this->getProducts($id_default_lang, 0, 0, 'id_product', 'asc', (int)$category['id_category'], true, $group);

                foreach ($products as $product) {
                    if (!(int)$product['active'] || !(int)$product['available_for_order']) {
                        continue;
                    }

                    $_product = new Product((int)$product['id_product']);
                    $image_link = '';
                    $images = $_product->getImages($id_default_lang);
                    if (is_array($images) && sizeof($images)) {
                        foreach ($images as $image) {
                            $image_link .= $this->context->link->getImageLink('image'.(int)$image['id_image'], (int)$image['id_image']).';';
                        }
                    }

                    $product_link = $this->context->link->getProductLink($product);

                    if (!$_product->hasAttributes()) {
                        $this->writeLine($this->csvOutput, array(
                            (string)$product['reference'],
                            (string)$product['name'],
                            (string)$category['dss_category_code'],
                            (string)$category['name'],
                            (string)$product['ean13'],
                            (string)$product_link,
                            (string)$product['description_short'],
                            (string)$product['description'],
                            '',
                            (string)$image_link,
                            (string)$product['manufacturer_name'],
                            ''
                        ));

                        $this->xml .= "<product>\n";
                        $this->xml .= "<code>".(string)$product['reference']."</code>\n";
                        $this->xml .= "<name><![CDATA[".(string)$product['name']."]]></name>\n";
                        $this->xml .= "<category_code>".(string)$category['dss_category_code']."</category_code>\n";
                        $this->xml .= "<category_name><![CDATA[".(string)$category['name']."]]></category_name>\n";
                        $this->xml .= "<ean13>".(string)$product['ean13']."</ean13>\n";
                        $this->xml .= "<url>".(string)$product_link."</url>\n";
                        $this->xml .= "<description_short><![CDATA[".(string)htmlspecialchars(Tools::substr($product['description_short'], 0, 255), ENT_COMPAT, 'UTF-8')."]]></description_short>\n";
                        $this->xml .= "<description><![CDATA[".(string)htmlspecialchars($product['description'], ENT_COMPAT, 'UTF-8')."]]></description>\n";
                        $this->xml .= "<features></features>\n";
                        $this->xml .= "<image>".(string)$image_link."</image>\n";
                        $this->xml .= "<manufacturer><![CDATA[".(string)$product['manufacturer_name']."]]></manufacturer>\n";
                        $this->xml .= "</product>\n";
                    } else {
                        $attributes = $_product->getAttributeCombinations($id_default_lang);
                        if (!empty($attributes)) {
                            $id_product_attribute = '';
                            foreach ($attributes as $attribute) {
                                if ((int)$attribute['id_product_attribute'] != (int)$id_product_attribute) {
                                    $id_product_attribute = (int)$attribute['id_product_attribute'];
                                
                                    $attribute_combinations = $_product->getAttributeCombinationsById($attribute['id_product_attribute'], $id_default_lang);

                                    $attribute_name = array();
                                    foreach ($attribute_combinations as $attribute_combination) {
                                        $attribute_name[] = '['.(string)$attribute_combination['group_name'].':'.(string)$attribute_combination['attribute_name'].']';

                                        $this->xml .= "<product>\n";
                                        $this->xml .= "<code>".(string)$attribute_combination['reference']."</code>\n";
                                        $this->xml .= "<name><![CDATA[".(string)$product['name']."]]></name>\n";
                                        $this->xml .= "<category_code>".(string)$category['dss_category_code']."</category_code>\n";
                                        $this->xml .= "<category_name><![CDATA[".(string)$category['name']."]]></category_name>\n";
                                        $this->xml .= "<ean13>".(string)$attribute_combination['ean13']."</ean13>\n";
                                        $this->xml .= "<url>".(string)$product_link."</url>\n";
                                        $this->xml .= "<description_short><![CDATA[".(string)htmlspecialchars(Tools::substr($product['description_short'], 0, 255), ENT_COMPAT, 'UTF-8')."]]></description_short>\n";
                                        $this->xml .= "<description><![CDATA[".(string)htmlspecialchars($product['description'], ENT_COMPAT, 'UTF-8')."]]></description>\n";
                                        $this->xml .= "<features></features>\n";
                                        $this->xml .= "<attribute_group>".(string)$attribute_combination['group_name']."</attribute_group>\n";
                                        $this->xml .= "<attribute_name>".(string)$attribute_combination['attribute_name']."</attribute_name>\n";
                                        $this->xml .= "<image>".(string)$image_link."</image>\n";
                                        $this->xml .= "<manufacturer><![CDATA[".(string)$product['manufacturer_name']."]]></manufacturer>\n";
                                        $this->xml .= "</product>\n";
                                    }

                                    $this->writeLine($this->csvOutput, array(
                                        (string)$attribute['reference'],
                                        (string)$product['name'],
                                        (string)$category['dss_category_code'],
                                        (string)$category['name'],
                                        (string)$attribute['ean13'],
                                        (string)$product_link,
                                        (string)$product['description_short'],
                                        (string)$product['description'],
                                        '',
                                        (string)$image_link,
                                        (string)$product['manufacturer_name'],
                                        implode(',', $attribute_name)
                                    ));
                                }
                            }
                        }
                    }
                }
                if (isset($category['children']) && $category['children'] != '') {
                    $this->xml .= $this->getSubItems($category['children'], $type, $id_default_lang, $group);
                }
            } elseif ($type == 'pricelist') {
                $ps_tax = (int)Configuration::get('PS_TAX', null, null, $id_shop);
                $prices_vat = (float)Configuration::get('DSS_PRICES_VAT', null, null, $id_shop);
                $mask_qt_value = (int)Configuration::get('DSS_MASK_REAL_QUANTITY_VALUE', null, null, $id_shop);
                $id_default_currency = new Currency((int)Configuration::get('PS_CURRENCY_DEFAULT', null, null, $id_shop));
                $products = $this->getProducts($id_default_lang, 0, 0, 'id_product', 'asc', (int)$category['id_category'], true, $group);

                $customer_wholesale_discount = (float)$dropshipper['wholesale_reduction'];
                $customer_discount = (float)$dropshipper['reduction'];

                foreach ($products as $product) {
                    if (!(int)$product['active'] || !(int)$product['available_for_order']) {
                        continue;
                    }
                    $_product = new Product((int)$product['id_product'], true);

                    $prices_vat = $ps_tax ? 0 : $prices_vat;

                    $wholesale_price = (float)$this->vatExtraction((float)$_product->wholesale_price, $prices_vat);
                    $base_price = (float)$this->vatExtraction((float)$_product->base_price, $prices_vat);
                    $price = (float)$this->vatExtraction((float)$_product->price, $prices_vat);

                    if (!(int)$dropshipper['feed_type']) {
                        $specific_wholesale_price = DssSpecificWholesalePriceClass::getSpecificWholesalePrice(
                            (int)$_product->id,
                            (int)$this->context->customer->id_shop,
                            (int)$this->context->currency->id,
                            (int)$dropshipper['id_country'],
                            (int)$group,
                            0
                        );
                        if ($this->wholesale_base_price == 0) {
                            if (isset($specific_wholesale_price) && $specific_wholesale_price) {
                                $wholesale_price = (float)$wholesale_price * ((100 + (float)$specific_wholesale_price['value']) / 100);
                            } else {
                                $wholesale_price = (float)$wholesale_price * ((100 + (float)$customer_wholesale_discount) / 100);
                            }
                        } else if ($this->wholesale_base_price == 1) {
                            if (isset($specific_wholesale_price) && $specific_wholesale_price) {
                                $wholesale_price = (float)$base_price * ((100 + (float)$specific_wholesale_price['value']) / 100);
                            } else {
                                $wholesale_price = (float)$base_price * ((100 + (float)$customer_wholesale_discount) / 100);
                            }
                        }

                        $price = (float)$price * ((100 + $customer_discount) / 100);

                        if ($this->base_price == 0) {
                            $base_price = (float)$product->base_price;
                            $price = (float)$price * ((100 + $customer_discount) / 100);
                        } elseif ($this->base_price == 1) {
                            $base_price = (float)$wholesale_price;
                            $price = (float)$wholesale_price * ((100 + $customer_discount) / 100);
                        }
                    }

                    if (!$_product->hasAttributes()) {
                        if ($dropshipper['mask_quantity'] && (int)$_product->quantity > (int)$mask_qt_value) {
                            $quantity = (int)$mask_qt_value;
                        } else {
                            $quantity = (int)$_product->quantity;
                        }
                        $this->writeLine($this->csvOutput, array(
                            (string)$_product->reference,
                            (int)$quantity,
                            Tools::displayPrice((float)$wholesale_price, $id_default_currency, true),
                            Tools::displayPrice((float)$base_price, $id_default_currency, true),
                            Tools::displayPrice((float)$price, $id_default_currency, true),
                        ));

                        $this->xml .= "<product>\n";
                        $this->xml .= "<code>".(string)$_product->reference."</code>\n";
                        $this->xml .= "<qty>".(int)$quantity."</qty>\n";
                        $this->xml .= "<wholesale_price>".Tools::displayPrice((float)$wholesale_price, $id_default_currency)."</wholesale_price>\n";
                        $this->xml .= "<base_price>".Tools::displayPrice((float)$base_price, $id_default_currency)."</base_price>\n";
                        $this->xml .= "<price>".Tools::displayPrice((float)$price, $id_default_currency)."</price>\n";
                        $this->xml .= "</product>\n";
                    } else {
                        $attributes = $_product->getAttributeCombinations($id_default_lang);
                        if (!empty($attributes)) {
                            $id_product_attribute = '';

                            foreach ($attributes as $attribute) {
                                if ((int)$attribute['id_product_attribute'] != (int)$id_product_attribute) {
                                    $id_product_attribute = (int)$attribute['id_product_attribute'];

                                    $attribute_wholesale_price = (float)$this->vatExtraction((float)$attribute['wholesale_price'], $prices_vat);
                                    $attribute_base_price = (float)$this->vatExtraction((float)$_product->base_price, $prices_vat);
                                    $attribute_price = (float)$this->vatExtraction((float)$_product->price + (float)$attribute['price'], $prices_vat);

                                    if (!(int)$dropshipper['feed_type']) {
                                        $specific_wholesale_price = DssSpecificWholesalePriceClass::getSpecificWholesalePrice(
                                            (int)$_product->id,
                                            (int)$this->context->customer->id_shop,
                                            (int)$this->context->currency->id,
                                            (int)$dropshipper['id_country'],
                                            (int)$group,
                                            (int)$attribute['id_product_attribute']
                                        );
                                        if ($this->wholesale_base_price == 0) {
                                            if (isset($specific_wholesale_price) && $specific_wholesale_price) {
                                                $attribute_wholesale_price = (float)$attribute_wholesale_price * ((100 + (float)$specific_wholesale_price['value']) / 100);
                                            } else {
                                                $attribute_wholesale_price = (float)$attribute_wholesale_price * ((100 + (float)$customer_wholesale_discount) / 100);
                                            }
                                        } else if ($this->wholesale_base_price == 1) {
                                            if (isset($specific_wholesale_price) && $specific_wholesale_price) {
                                                $attribute_wholesale_price = (float)$attribute_base_price * ((100 + (float)$specific_wholesale_price['value']) / 100);
                                            } else {
                                                $attribute_wholesale_price = (float)$attribute_base_price * ((100 + (float)$customer_wholesale_discount) / 100);
                                            }
                                        }
                                        $attribute_price = (float)$attribute_price * ((100 + $customer_discount) / 100);
                                    }

                                    $attribute_combinations = $_product->getAttributeCombinationsById($attribute['id_product_attribute'], $id_default_lang);

                                    $attribute_name = array();
                                    foreach ($attribute_combinations as $attribute_combination) {
                                        if ($dropshipper['mask_quantity'] && (int)$attribute_combination['quantity'] > (int)$mask_qt_value) {
                                            $attribute_combinations_quantity = (int)$mask_qt_value;
                                        } else {
                                            $attribute_combinations_quantity = (int)$attribute_combination['quantity'];
                                        }
                                        $attribute_name[] = '['.(string)$attribute_combination['group_name'].':'.(string)$attribute_combination['attribute_name'].']';

                                        $this->xml .= "<product>\n";
                                        $this->xml .= "<code>".(string)$attribute_combination['reference']."</code>\n";
                                        $this->xml .= "<qty>".(int)$attribute_combinations_quantity."</qty>\n";
                                        $this->xml .= "<wholesale_price>".Tools::displayPrice((float)$attribute_wholesale_price, $id_default_currency)."</wholesale_price>\n";
                                        $this->xml .= "<base_price>".Tools::displayPrice((float)$attribute_base_price, $id_default_currency)."</base_price>\n";
                                        $this->xml .= "<price>".Tools::displayPrice((float)$attribute_price, $id_default_currency)."</price>\n";
                                        $this->xml .= "</product>\n";
                                    }

                                    if ($dropshipper['mask_quantity'] && (int)$attribute['quantity'] > (int)$mask_qt_value) {
                                        $attribute_quantity = (int)$mask_qt_value;
                                    } else {
                                        $attribute_quantity = (int)$attribute['quantity'];
                                    }
                                    $this->writeLine($this->csvOutput, array(
                                        (string)$attribute['reference'],
                                        (int)$attribute_quantity,
                                        Tools::displayPrice((float)$attribute_wholesale_price, $id_default_currency, true),
                                        Tools::displayPrice((float)$attribute_base_price, $id_default_currency, true),
                                        Tools::displayPrice((float)$attribute_price, $id_default_currency, true),
                                    ));
                                }
                            }
                        }
                    }
                }
                if (isset($category['children']) && $category['children'] != '') {
                    $this->xml .= $this->getSubItems($category['children'], $type, $id_default_lang, $group, $dropshipper);
                }
            }
        }
    }

    public static function checkRegistration($reg_order, $reg_key)
    {
        $lic = null;
        $exp = null;
        $data = array(
            'reg_order' => $reg_order,
            'reg_key' => $reg_key
        );

        //$response = DssClass::getData(base64_encode(serialize($data)));
        $response = DssClass::getData(self::str2hex(serialize($data)));

        if ($response) {
            $doc = new DOMDocument('1.0', 'UTF-8');
            @$doc->loadXML($response);

            //$version = isset($doc->getElementsByTagName('version')->item(0)->nodeValue) ? $doc->getElementsByTagName('version')->item(0)->nodeValue : $this->version;
            $lic = isset($doc->getElementsByTagName('status')->item(0)->nodeValue) ? (string)$doc->getElementsByTagName('status')->item(0)->nodeValue : null;
            $exp = isset($doc->getElementsByTagName('expire')->item(0)->nodeValue) ? (string)$doc->getElementsByTagName('expire')->item(0)->nodeValue : '';
            unset($doc);

            return array('lic' => $lic, 'exp' => $exp);
        }
        return false;
    }

    private static function str2hex($str)
    {
        return @array_shift(unpack('H*', $str));
    }

    public static function getData($data = null)
    {
        $context = Context::getContext();
        $id_shop = (int)$context->shop->id;

        $module = Module::getInstanceByName('dropshipsystem');

        $request = http_build_query(array(
            'app' => $module->name,
            'version' => $module->version,
            'data' => $data,
            'email' => Configuration::get('PS_SHOP_EMAIL', null, null, $id_shop)
        ), '', '&');

        $response = '';
        if (function_exists('curl_init') && $ch = @curl_init('www.prestabiz.com/checkmodule.php')) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $request);
            curl_setopt($ch, CURLOPT_TIMEOUT, 50);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_REFERER, 'http://'.$_SERVER['HTTP_HOST']);
            $response = @curl_exec($ch);
            @curl_close($ch);
        } elseif (ini_get('allow_url_fopen')) {
            $errno = -1;
            $errstr = '';
            if ($fp = @fsockopen('www.prestabiz.com', 80, $errno, $errstr, 15)) {
                fputs($fp, "GET /checkmodule.php?".(string)$request." HTTP/1.1\r\n");
                fputs($fp, "Host: www.prestabiz.com\r\n");
                fputs($fp, "Content-Type: application/x-www-form-urlencoded\r\n");
                fputs($fp, "Referer: ".'http://'.$_SERVER['HTTP_HOST']."\r\n");
                fputs($fp, "Connection: Close\r\n\r\n");
                if ($fp) {
                    while (!feof($fp)) {
                        $response .= fgets($fp, 8192);
                    }
                }
                $response = strstr($response, "<feed>");
                $response = "\n".$response;
                $response = strstr($response, "\r\n0\r\n", true);
                fclose($fp);
            } else {
                return false;
            }
        } else {
            return false;
        }
        return $response;
    }

    public static function isHashedPassword($hashedPasswd)
    {
        return (Tools::strlen($hashedPasswd) == 32 || Tools::strlen($hashedPasswd) == 60);
    }

    private function writeCategoryHeader()
    {
        $this->writeLine($this->csvOutput, array(
            'parent',
            'code',
            'name',
        ));
    }

    private function writeProductHeader()
    {
        $this->writeLine($this->csvOutput, array(
            'code',
            'name',
            'category_code',
            'category_name',
            'ean13',
            'url',
            'description_short',
            'description',
            'features',
            'image',
            'manufacturer',
            'attribute',
        ));
    }

    private function writePricelistHeader()
    {
        $this->writeLine($this->csvOutput, array(
            'code',
            'qty',
            'wholesale_price',
            'base_price',
            'price',
        ));
    }

    private function writeLine($output, $fields)
    {
        $result = fputcsv($output, $fields, ';', '"');
        if ($result === false) {
            throw new Exception('Cannot write CSV line.');
        }
        return $result;
    }

    public function vatExtraction($price, $value)
    {
        return $value > 0 ? ($price / (($value + 100) / 100)) : $price;
    }

    public function purify($str, $is_name = false)
    {
        if ($is_name) {
            $str = str_replace(array('"', '&', "'", '<', '>', ';', '=', '#', '{', '}'), '', $str);
        }
        //$str = htmlspecialchars($str, ENT_COMPAT, 'UTF-8');
        //return preg_replace("/[^a-zA-Z0-9àèìòù,.:;!?()<>$%=&@#\/\$$\[\]{}\"\'\s+-]/", "", $str);
        return htmlentities($str, null, "UTF-8");
    }

    private function xmlsafe($string)
    {
        $replace = array(
            '"'=> "&quot;",
            //"&" => "&amp;",
            //"'"=> "&apos;",
            //"<" => "&lt;",
            //">"=> "&gt;"
        );
        return strtr($string, $replace);
    }
}
