<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class DssProductGroupsClass extends ObjectModel
{
    /** @var integer id*/
    public $id;

    /** @var integer id_product*/
    public $id_product;

    /** @var int ID Shop */
    public $id_shop;

    /** @var integer group */
    public $group;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'dss_product_groups',
        'primary' => 'id_product',
        'fields' => array(
            'id_product'    => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt', 'required' => true),
            'id_shop'       => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true),
            'group'         => array('type' => self::TYPE_INT, 'validate' => 'isunsignedInt', 'required' => true),
        ),
    );

    public static function getProductGroups($id_product = null)
    {
        $context = Context::getContext();
        $id_shop = (int)$context->shop->id;

        if (!$id_product) {
            return Db::getInstance()->executeS('
                SELECT `id_product`, `group`
                FROM `'._DB_PREFIX_.'dss_product_groups`
                WHERE `id_shop` = '.(int)$id_shop.'
                ORDER BY `id_product`');
        } else {
            return Db::getInstance()->executeS('
                SELECT `group`
                FROM `'._DB_PREFIX_.'dss_product_groups` 
                WHERE `id_product` = '.(int)$id_product.' AND `id_shop` = '.(int)$id_shop);
        }
    }

    public function existsProductGroup($id_product, $group)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        return (int)Db::getInstance()->getValue('
            SELECT COUNT(*) AS count 
            FROM `'._DB_PREFIX_.'dss_product_groups` 
            WHERE `id_product` = '.(int)$id_product.'
            AND `id_shop` = '.(int)$id_shop.'
            AND `group` = '.(int)$group);
    }

    public function delete()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        if (parent::delete()) {
            Db::getInstance()->execute('
                DELETE FROM `'._DB_PREFIX_.'dss_product_groups`
                WHERE `id_product` = '.(int)$this->id_product.'
                AND `id_shop` = '.(int)$id_shop.'
                AND `group` = '.(int)$this->group);
            return true;
        }
        return false;
    }

    public static function clearProductGroups($id_product, $groups)
    {
        $context = Context::getContext();
        $id_shop = (int)$context->shop->id;
        if (!isset($groups) || !is_array($groups)) {
            $groups = array();
        }
        $_groups = DssProductGroupsClass::getProductGroups($id_product);
        if (isset($_groups) && $_groups) {
            foreach ($_groups as $_group) {
                if (!in_array((int)$_group['group'], $groups)) {
                    Db::getInstance()->execute('
                        DELETE FROM `'._DB_PREFIX_.'dss_product_groups`
                        WHERE `id_product` = '.(int)$id_product.'
                        AND `id_shop` = '.(int)$id_shop.'
                        AND (`group` = 0 OR`group` = '.(int)$_group['group'].')');
                }
            }
        }
    }
}
