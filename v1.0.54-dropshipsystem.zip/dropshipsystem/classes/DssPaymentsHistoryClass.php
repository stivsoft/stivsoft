<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

include_once(_PS_MODULE_DIR_.'dropshipsystem/dropshipsystem.php');

class DssPaymentsHistoryClass extends ObjectModel
{
    public $id;
    public $id_payment_history;
    public $id_customer;
    public $id_operator;
    public $request_date;
    public $status;
    public $currency;
    public $previous_credit;
    public $id_product;
    public $buyed_credit;
    public $current_credit;
    public $id_invoice;
    public $id_order;
    public $token;
    public $payment_link;
    public $transaction_id;
    public $payment_status;
    public $payment_date;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'dss_payments_history',
        'primary' => 'id_payment_history',
        'fields' => array(
            'id_customer' =>            array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
            'id_operator' =>            array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId'),
            'request_date' =>           array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
            'status' =>                 array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'currency' =>               array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'previous_credit' =>        array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat', 'required' => true),
            'id_product' =>             array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            'buyed_credit' =>           array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat', 'required' => true),
            'current_credit' =>         array('type' => self::TYPE_FLOAT, 'validate' => 'isFloat', 'required' => true),
            'id_invoice' =>             array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            'id_order' =>               array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            'token' =>                  array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'payment_link' =>           array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'transaction_id' =>         array('type' => self::TYPE_STRING, 'validate' => 'isString'),
            'payment_status' =>         array('type' => self::TYPE_STRING, 'allow_null' => true, 'validate' => 'isString'),
            'payment_date' =>           array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
        ),
    );

    public function getAllPayments($id_lang, $id_customer)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
            SELECT o.`reference`, pl.`name` AS product_name, ph.* 
            FROM `'._DB_PREFIX_.'dss_payments_history` ph 
            LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON pl.`id_product` = ph.`id_product` 
            '.Shop::addSqlAssociation('product_lang', 'pl').'
            LEFT JOIN `'._DB_PREFIX_.'orders` o ON o.`id_order` = ph.`id_order` 
            LEFT JOIN `'._DB_PREFIX_.'order_detail` od ON od.`id_order` = o.`id_order` 
            WHERE pl.`id_lang` = '.(int)$id_lang.' AND ph.`id_customer` = '.(int)$id_customer);
    }

    public static function getPaymentHistoryID($id_customer, $token)
    {
        return (int)Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
            SELECT `id_payment_history`
            FROM `'._DB_PREFIX_.'dss_payments_history`
            WHERE `id_customer` = '.(int)$id_customer.' AND `token` = \''.pSql($token).'\'');
    }

    public function getCustomerIDByDropshipperID($id_dss_dropshipper)
    {
        return (int)Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
            SELECT a.`id_customer`
            FROM `'._DB_PREFIX_.'dss_dropshipper` a
            WHERE a.`id_dss_dropshipper` = '.(int)$id_dss_dropshipper);
    }

    public function getDropshipperIDByPaymentHistoryID($id_payment_history)
    {
        return (int)Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
            SELECT DISTINCT a.`id_dss_dropshipper`
            FROM `'._DB_PREFIX_.'dss_dropshipper` a
            INNER JOIN `'._DB_PREFIX_.'dss_payments_history` b ON b.`id_customer` = a.`id_customer`
            WHERE b.`id_payment_history` = '.(int)$id_payment_history);
    }

    public function getPaymentDetails($id_lang)
    {
        return (object)Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow('
            SELECT COALESCE(CONCAT(e.`lastname`, \' \', e.`firstname`), \'System\') AS operator_name, 
            o.`reference`, pl.`name` AS product_name, ph.* 
            FROM `'._DB_PREFIX_.'dss_payments_history` ph 
            LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON pl.`id_product` = ph.`id_product` 
            '.Shop::addSqlAssociation('product_lang', 'pl').'
            LEFT JOIN `'._DB_PREFIX_.'employee` e ON e.`id_employee` = ph.`id_operator` 
            LEFT JOIN `'._DB_PREFIX_.'orders` o ON o.`id_order` = ph.`id_order` 
            LEFT JOIN `'._DB_PREFIX_.'order_detail` od ON od.`id_order` = o.`id_order` 
            WHERE pl.`id_lang` = '.(int)$id_lang.' AND ph.`id_payment_history` = '.(int)$this->id);
    }

    public static function getLastPayment($id_customer)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow('
            SELECT ph.* 
            FROM `'._DB_PREFIX_.'dss_payments_history` ph 
            WHERE ph.`status` = \'accepted\' AND ph.`id_customer` = '.(int)$id_customer).' 
            ORDER BY ph.`request_date` DESC LIMIT 1';
    }
}
