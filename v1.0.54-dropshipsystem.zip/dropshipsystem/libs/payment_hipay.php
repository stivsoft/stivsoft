<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class payment_hipay extends DssPaymentClass
{
    public $gateway_version = '1.0';
    public $gateway_active = false;
    public $gateway_name;
    public $tplfile;
    public $tpldata;
    public $has_css = false;
    public $has_js = false;
    public $register_js = false;

    protected $client = false;

    public function __construct($pagedata = false)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $this->gateway_name = $this->l('HiPay', 'payment_hipay');
        $this->gateway_active = (int)Configuration::get('DSS_HIPAY_ACTIVE', null, null, $id_shop);

        parent::__construct();
    }

    public function getFieldsKeys()
    {
        return array(
            'DSS_HIPAY_ACTIVE',
            'DSS_HIPAY_TEST',
            'DSS_HIPAY_ACCOUNT_ID',
            'DSS_HIPAY_SITE_ID',
            'DSS_HIPAY_WS_LOGIN',
            'DSS_HIPAY_WS_PASSWORD',
        );
    }

    public function getFieldsForm()
    {
        $tab_name = (string)get_class($this);

        return array(
            'DSS_HIPAY_INFO' => array(
                'type' => 'html',
                'tab' => $tab_name,
                'html_content' => "<div class='alert alert-info'>".
                    $this->l('Please register to HiPay Professional from this link and get the API keys:', 'payment_hipay')."<br />
                    <span>LIVE:</span>&nbsp;<a href='https://www.hipaydirect.com/registration/register' target='_blank'>https://www.hipaydirect.com/registration/register</a><br />
                    <span>TEST:</span>&nbsp;<a href='https://test-www.hipaydirect.com/registration/register' target='_blank'>https://test-www.hipaydirect.com/registration/register</a>
                </div>"
            ),
            'DSS_HIPAY_ACTIVE' => array(
                'type' => 'bool',
                'title' => $this->l('Active', 'payment_hipay'),
                'name' => 'DSS_HIPAY_ACTIVE',
                'tab' => $tab_name,
            ),
            'DSS_HIPAY_TEST' => array(
                'type' => 'bool',
                'title' => $this->l('Test mode', 'payment_hipay'),
                'name' => 'DSS_HIPAY_TEST',
                'tab' => $tab_name,
            ),
            'DSS_HIPAY_ACCOUNT_ID' => array(
                'type' => 'text',
                'title' => $this->l('Account ID', 'payment_hipay'),
                'name' => 'DSS_HIPAY_ACCOUNT_ID',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_HIPAY_SITE_ID' => array(
                'type' => 'text',
                'title' => $this->l('Site ID', 'payment_hipay'),
                'name' => 'DSS_HIPAY_SITE_ID',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_HIPAY_WS_LOGIN' => array(
                'type' => 'text',
                'title' => $this->l('WS Login', 'payment_hipay'),
                'name' => 'DSS_HIPAY_WS_LOGIN',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_HIPAY_WS_PASSWORD' => array(
                'type' => 'password',
                'title' => $this->l('WS Password', 'payment_hipay'),
                'name' => 'DSS_HIPAY_WS_PASSWORD',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
        );
    }

    public function getFieldsValues()
    {
        $id_shop = (int)$this->context->shop->id;

        return array(
            'DSS_HIPAY_ACTIVE' => Tools::getValue('DSS_HIPAY_ACTIVE', Configuration::get('DSS_HIPAY_ACTIVE', null, null, $id_shop)),
            'DSS_HIPAY_TEST' => Tools::getValue('DSS_HIPAY_TEST', Configuration::get('DSS_HIPAY_TEST', null, null, $id_shop)),
            'DSS_HIPAY_ACCOUNT_ID' => Tools::getValue('DSS_HIPAY_SITE_ID', Configuration::get('DSS_HIPAY_SITE_ID', null, null, $id_shop)),
            'DSS_HIPAY_SITE_ID' => Tools::getValue('DSS_HIPAY_SITE_ID', Configuration::get('DSS_HIPAY_SITE_ID', null, null, $id_shop)),
            'DSS_HIPAY_WS_LOGIN' => Tools::getValue('DSS_HIPAY_WS_LOGIN', Configuration::get('DSS_HIPAY_WS_LOGIN', null, null, $id_shop)),
            'DSS_HIPAY_WS_PASSWORD' => Tools::getValue('DSS_HIPAY_WS_PASSWORD', Configuration::get('DSS_HIPAY_WS_PASSWORD', null, null, $id_shop)),
        );
    }

    public function getAuth()
    {
        return true;
    }

    public function getPaymentPage($params)
    {
        $id_shop = (int)$this->context->shop->id;

        $token = new DssPaymentsTokenClass();
        $token->token = (string)$params['token'];
        $token->id_order = isset($params['id_order']) ? (int)$params['id_order'] : 0;
        $token->is_credit = (int)$params['is_credit'];
        $token->name = (string)$params['name'];
        $token->custom_reference = (string)$params['custom_reference'];
        $token->currency = (string)Tools::strtolower($this->context->currency->iso_code);
        $token->amount = (float)$params['total'];
        $token->return_url = isset($params['return_url']) ? (string)$params['return_url'].'&token='.(string)$params['token'] : null;
        $token->cancel_url = isset($params['cancel_url']) ? (string)$params['cancel_url'].'&token='.(string)$params['token'] : null;

        if (!$token->save()) {
            return array(
                'success' => false,
                'error' => 'TOKEN_ERROR'
            );
        }

        $id_dropshipper = DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
        $dropshipper = new DssDropshippersClass((int)$id_dropshipper);
        $customer = new Customer((int)$this->context->customer->id);
        $address = new Address((int)$dropshipper->id_address_invoice);
        $address = new Address((int)$dropshipper->id_address_invoice);
        $country = new Country((int)$address->id_country);



        $hipay_account_id = (int)Configuration::get('DSS_HIPAY_ACCOUNT_ID', null, null, $id_shop);
        $hipay_website_id = (int)Configuration::get('DSS_HIPAY_SITE_ID', null, null, $id_shop);

        $args = array(
            'websiteId' => (int)$hipay_website_id,
            'amount' => (float)$params['total'],
            'categoryId' => 0,
            'currency' => (string)$this->context->currency->iso_code,
            'customerEmail' => (string)$this->context->customer->email,
            'customerIpAddress' => Tools::getRemoteAddr(),
            'description' => (string)$params['name'],
            'merchantReference' => (string)$params['name'],
            'emailCallback' => (string)Configuration::get('PS_SHOP_EMAIL', null, null, $id_shop),
            'executionDate' => date('Y-m-d\TH:i:s'),
            'locale' => 'it_IT',
            'manualCapture' => 0,
            'rating' => 'ALL',
            'wsSubAccountId' => (int)$hipay_account_id,
            'method' => '',

            // URLs
            'urlAccept' => (string)$params['return_url'].'&token='.(string)$params['token'],
            'urlCallback' => (string)$this->context->link->getBaseLink($this->context->shop->id, true)."modules/dropshipsystem/libs/HiPay/callback.php",
            'urlCancel' => (string)$params['cancel_url'].'&token='.(string)$params['token'],
            'urlDecline' => (string)$params['cancel_url'].'&token='.(string)$params['token'],
            'urlLogo' => '',

            'freeData' => array(
                'item' => array(
                    array('key' => 'customer_id', 'value' => $this->context->customer->id),
                    array('key' => 'secure_key', 'value' => $this->context->customer->secure_key),
                    array('key' => 'token', 'value' => (string)$params['token']),
                ),
            ),
        );

        $results = $this->executeQuery('generate', $args);

        if (isset($results->generateResult) && $results->generateResult->redirectUrl) {
            $paymentlink = (string)$results->generateResult->redirectUrl;

            return array(
                'success' => true,
                'currency' => (string)Tools::strtoupper($this->context->currency->iso_code),
                'custom_reference' => (string)$params['custom_reference'],
                'paymentlink' => (string)$paymentlink,
                'token' => (string)$params['token']
            );
        } else {
            $description = $results->generateResult->description;

            return array(
                'success' => false,
                'error' => sprintf($this->l('An error occurred while getting transaction informations: %s', 'payment_hipay'), $description),
            );
        }
    }

    public function processPayment($params)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $dss_payment_token = new DssPaymentsTokenClass((string)$params['token']);
        if (isset($dss_payment_token) && $dss_payment_token->id) {
            if ($dss_payment_token->status == 'valid' && empty($dss_payment_token->params)) {
                $try = (int)Tools::getValue('try');
                if ($try < 9) {
                    sleep(3);
                    $try++;
                    Tools::redirect((string)$dss_payment_token->return_url.'&try='.(int)$try);
                }
            } elseif ($dss_payment_token->status == 'cbok') {
                $order = Tools::jsonDecode((string)$dss_payment_token->params);
                $operation = (string)$order->result->operation;
                $status = (string)$order->result->status;
                $transid = (string)$order->result->transid;

                if ($operation == 'authorization' && $status == 'ok') {
                    return array(
                        'success' => true,
                        'currency' => (string)$dss_payment_token->currency,
                        'amount' => (float)$dss_payment_token->amount,
                        'payment_date' => time(true),
                        'transaction_id' => (string)$transid,
                        'token' => (string)$params['token']
                    );
                } else {
                    return array(
                        'success' => false,
                        'error' => $this->l('Payment error. Authorization declined.', 'payment_hipay'),
                        'token' => (string)$params['token']
                    );
                }
            } else {
                return array(
                    'success' => false,
                    'error' => $this->l('Payment error. Invalid token status.', 'payment_hipay'),
                    'token' => (string)$params['token']
                );
            }
        } else {
            return array(
                'success' => false,
                'error' => $this->l('Payment error. Invalid token.', 'payment_hipay'),
                'token' => (string)$params['token']
            );
        }
    }

    public function executeQuery($function, $params = array(), $sandbox = false)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        try {
            if ($this->client === false) {
                $this->client = $this->getClient();
            }

            if ($this->client === false) {
                return array(
                    'success' => false,
                    'error' => $this->l('An error occurred while trying to contact the web service', 'payment_hipay'),
                );
            }

            if ((int)Configuration::get('DSS_HIPAY_TEST', null, null, $id_shop) || $sandbox == true) {
                $params['wsLogin'] = (string)Configuration::get('DSS_HIPAY_WS_LOGIN', null, null, $id_shop);
                $params['wsPassword'] = (string)Configuration::get('DSS_HIPAY_WS_PASSWORD', null, null, $id_shop);
            } else {
                $params['wsLogin'] = (string)Configuration::get('DSS_HIPAY_WS_LOGIN', null, null, $id_shop);
                $params['wsPassword'] = (string)Configuration::get('DSS_HIPAY_WS_PASSWORD', null, null, $id_shop);
            }

            $output = $this->client->__call($function, array(array('parameters' => $params)));

            unset($this->client);

            return $output;
        } catch (Exception $exception) {
            return array(
                'success' => false,
                'error' => $this->l('An error occurred while trying to contact the web service', 'payment_hipay'),
            );
        }
    }

    public function getClient()
    {
        try {
            $ws_options = array(
                'compression' => SOAP_COMPRESSION_ACCEPT | SOAP_COMPRESSION_GZIP,
                'cache_wsdl' => WSDL_CACHE_NONE,
                'connection_timeout' => 20,
                'soap_version' => SOAP_1_1,
                'encoding' => 'UTF-8'
            );

            return new SoapClient($this->getWsClientURL(), $ws_options);
        } catch (SoapFault $exception) {
            return false;
        }
    }

    public function getWsClientURL()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        if ((int)Configuration::get('DSS_HIPAY_TEST', null, null, $id_shop)) {
            return 'https://test-ws.hipay.com/soap/payment-v2?wsdl';
        } else {
            return 'https://ws.hipay.com/soap/payment-v2?wsdl';
        }
    }
}
