<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$useSSL = true;

include(dirname(__FILE__).'/../../../../config/config.inc.php');
//include(dirname(__FILE__).'/../../../../init.php');

include_once(dirname(__FILE__).'/../../dropshipsystem.php');

class payment_hipayCallBack
{
    public function init()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $dss = new DropShipSystem();
        if (Tools::getValue('xml')) {
            $xml = (string)Tools::getValue('xml');
            $count = Tools::strlen($xml);
            $start = Tools::strpos($xml, '<result>');
            $end = Tools::strpos($xml, '</result>') + 9;
            $endchars = ($count - $end) * -1;
            $result_string = Tools::substr($xml, $start, $endchars);

            $order = Tools::jsonDecode(Tools::jsonEncode((array)simplexml_load_string($xml)), 1);

            $dss->writeLog($order);

            $md5content = (string)$order['md5content'];
            $operation = (string)$order['result']['operation'];
            $status = (string)$order['result']['status'];
            $transid = (string)$order['result']['transid'];
            $amount = (float)$order['result']['origAmount'];

            $token = (string)$order['result']['merchantDatas']['_aKey_token'];
            $customer_id = (int)$order['result']['merchantDatas']['_aKey_customer_id'];
            $secure_key = (string)$order['result']['merchantDatas']['_aKey_secure_key'];

            $password = (string)Configuration::get('DSS_HIPAY_WS_PASSWORD', null, null, $id_shop);
            if ((int)Configuration::get('DSS_HIPAY_TEST', null, null, $id_shop)) {
                $signature = md5($result_string);
            } else {
                $signature = md5($result_string.$password);
            }

            if ($md5content == $signature) {
                if ($operation == 'authorization' && $status == 'ok') {
                    $dss_payment_token = new DssPaymentsTokenClass((string)$token);
                    if (isset($dss_payment_token) && $dss_payment_token->id) {
                        if ((string)$dss_payment_token->status == 'valid') {
                            $dss_payment_token->status = 'cbok';
                            $dss_payment_token->params = Tools::jsonEncode($order);
                            if ($dss_payment_token->save()) {
                                $dss->writeLog('CALLBACK HIPAY AUTH OK');
                                die('OK');
                            }
                        }
                    }
                } elseif ($operation == 'capture' && $status == 'ok') {
                    $dss->writeLog('CALLBACK HIPAY CAPTURE OK');
                    die('OK');
                }
            }
        }
        $dss->writeLog('KO');
        die('KO');
    }
}

$callback = new payment_hipayCallBack();
$callback->init();
