<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

use PayPal\CoreComponentTypes\BasicAmountType;
use PayPal\EBLBaseComponents\AddressType;
use PayPal\EBLBaseComponents\BillingAgreementDetailsType;
use PayPal\EBLBaseComponents\PaymentDetailsItemType;
use PayPal\EBLBaseComponents\PaymentDetailsType;
use PayPal\EBLBaseComponents\SetExpressCheckoutRequestDetailsType;
use PayPal\PayPalAPI\SetExpressCheckoutReq;
use PayPal\PayPalAPI\SetExpressCheckoutRequestType;
use PayPal\Service\PayPalAPIInterfaceServiceService;

require_once(_PS_MODULE_DIR_.'dropshipsystem/libs/PayPal/PPBootStrap.php');

class SetExpressCheckout
{
    public function execute($data)
    {
        $id_shop = (int)Context::getContext()->shop->id;

        //$url = dirname('http'.(Configuration::get('PS_SSL_ENABLED', null, null, $id_shop) ? 's' : '').
        //               '://' . $_SERVER['SERVER_NAME'] . ':' . $_SERVER['SERVER_PORT'] . $_SERVER['REQUEST_URI']);
        if (Configuration::get('PS_SSL_ENABLED', null, null, $id_shop)) {
            $url = 'https://'.Configuration::get('PS_SHOP_DOMAIN_SSL', null, null, $id_shop).__PS_BASE_URI__;
        } else {
            $url = 'http://'.Configuration::get('PS_SHOP_DOMAIN', null, null, $id_shop).__PS_BASE_URI__;
        }

        if (!isset($data['returnURL'])) {
            $returnUrl = $url.'ws?mode=1&ref='.(string)$data['order_reference'].'&action=payment-return';
        } else {
            $returnUrl = (string)$data['returnURL'];
        }
        if (!isset($data['cancelURL'])) {
            $cancelUrl = $url.'ws?mode=1&ref='.(string)$data['order_reference'].'&action=payment-cancel';
        } else {
            $cancelUrl = (string)$data['cancelURL'];
        }

        $currencyCode = $data['currencyCode'];

        // total shipping amount
        $shippingTotal = new BasicAmountType($currencyCode, $data['shippingTotal']);
        //total handling amount if any
        $handlingTotal = new BasicAmountType($currencyCode, $data['handlingTotal']);
        //total insurance amount if any
        $insuranceTotal = new BasicAmountType($currencyCode, $data['insuranceTotal']);

        // shipping address
        $address = new AddressType();
        $address->CityName = $data['city'];
        $address->Name = $data['name'];
        $address->Street1 = $data['street'];
        $address->StateOrProvince = $data['state'];
        $address->PostalCode = $data['postalCode'];
        $address->Country = $data['countryCode'];
        $address->Phone = $data['phone'];
        
        // details about payment
        $paymentDetails = new PaymentDetailsType();
        $itemTotalValue = 0;
        $taxTotalValue = 0;
        /*
         * iterate trhough each item and add to atem detaisl
         */

        //for($i=0; $i < count($data['items']); $i++) {
        foreach ($data['items'] as $key => $item) {
            $itemAmount = new BasicAmountType($currencyCode, $item['Amount']);
            $itemTotalValue += $item['Amount'] * $item['Quantity'];
            $taxTotalValue += $item['SalesTax'] * $item['Quantity'];
            $itemDetails = new PaymentDetailsItemType();
            $itemDetails->Name = $item['Name'];
            $itemDetails->Amount = $itemAmount;
            $itemDetails->Quantity = $item['Quantity'];
            /*
             * Indicates whether an item is digital or physical. For digital goods, this field is required and must be set to Digital. It is one of the following values:
        
            Digital
        
            Physical
        
             */
            $itemDetails->ItemCategory = $item['Category'];
            $itemDetails->Tax = new BasicAmountType($currencyCode, $item['SalesTax']);

            $paymentDetails->PaymentDetailsItem[$key] = $itemDetails;
        }

        /*
         * The total cost of the transaction to the buyer. If shipping cost and tax charges are known, include them in this value. If not, this value should be the current subtotal of the order. If the transaction includes one or more one-time purchases, this field must be equal to the sum of the purchases. If the transaction does not include a one-time purchase such as when you set up a billing agreement for a recurring payment, set this field to 0.
         */
        $orderTotalValue = $shippingTotal->value + $handlingTotal->value + $insuranceTotal->value + $itemTotalValue + $taxTotalValue;

        //Payment details
        $paymentDetails->ShipToAddress = $address;
        $paymentDetails->ItemTotal = new BasicAmountType($currencyCode, $itemTotalValue);
        $paymentDetails->TaxTotal = new BasicAmountType($currencyCode, $taxTotalValue);
        $paymentDetails->OrderTotal = new BasicAmountType($currencyCode, $orderTotalValue);
        
        /*
         * How you want to obtain payment. When implementing parallel payments, this field is required and must be set to Order. When implementing digital goods, this field is required and must be set to Sale. If the transaction does not include a one-time purchase, this field is ignored. It is one of the following values:
        
            Sale – This is a final sale for which you are requesting payment (default).
        
            Authorization – This payment is a basic authorization subject to settlement with PayPal Authorization and Capture.
        
            Order – This payment is an order authorization subject to settlement with PayPal Authorization and Capture.
        
         */
        $paymentDetails->PaymentAction = $data['paymentType'];
        
        $paymentDetails->HandlingTotal = $handlingTotal;
        $paymentDetails->InsuranceTotal = $insuranceTotal;
        $paymentDetails->ShippingTotal = $shippingTotal;

        /*
         *  Your URL for receiving Instant Payment Notification (IPN) about this transaction. If you do not specify this value in the request, the notification URL from your Merchant Profile is used, if one exists.
         */
        if (isset($data['notifyURL'])) {
            $paymentDetails->NotifyURL = $data['notifyURL'];
        }
        
        $setECReqDetails = new SetExpressCheckoutRequestDetailsType();
        $setECReqDetails->PaymentDetails[0] = $paymentDetails;
        /*
         * (Required) URL to which the buyer is returned if the buyer does not approve the use of PayPal to pay you. For digital goods, you must add JavaScript to this page to close the in-context experience.
         */
        $setECReqDetails->CancelURL = $cancelUrl;
        /*
         * (Required) URL to which the buyer's browser is returned after choosing to pay with PayPal. For digital goods, you must add JavaScript to this page to close the in-context experience.
         */
        $setECReqDetails->ReturnURL = $returnUrl;
        /*
         * Determines where or not PayPal displays shipping address fields on the PayPal pages. For digital goods, this field is required, and you must set it to 1. It is one of the following values:
            0 – PayPal displays the shipping address on the PayPal pages.
            1 – PayPal does not display shipping address fields whatsoever.
            2 – If you do not pass the shipping address, PayPal obtains it from the buyer's account profile.
         */
        $setECReqDetails->NoShipping = $data['noShipping'];
        /*
         *  (Optional) Determines whether or not the PayPal pages should display the shipping address set by you in this SetExpressCheckout request, not the shipping address on file with PayPal for this buyer. Displaying the PayPal street address on file does not allow the buyer to edit that address. It is one of the following values:
            0 – The PayPal pages should not display the shipping address.
            1 – The PayPal pages should display the shipping address.
         */
        $setECReqDetails->AddressOverride = $data['addressOverride'];
        /*
         * Indicates whether or not you require the buyer's shipping address on file with PayPal be a confirmed address. For digital goods, this field is required, and you must set it to 0. It is one of the following values:
            0 – You do not require the buyer's shipping address be a confirmed address.
            1 – You require the buyer's shipping address be a confirmed address.
         */
        $setECReqDetails->ReqConfirmShipping = $data['reqConfirmShipping'];

        // Billing agreement details
        $billingAgreementDetails = new BillingAgreementDetailsType($data['billingType']);
        $billingAgreementDetails->BillingAgreementDescription = $data['billingAgreementText'];
        $setECReqDetails->BillingAgreementDetails = array($billingAgreementDetails);

        // Display options
        $setECReqDetails->cppheaderimage = $data['cppheaderimage'];
        $setECReqDetails->cppheaderbordercolor = $data['cppheaderbordercolor'];
        $setECReqDetails->cppheaderbackcolor = $data['cppheaderbackcolor'];
        $setECReqDetails->cpppayflowcolor = $data['cpppayflowcolor'];
        $setECReqDetails->cppcartbordercolor = $data['cppcartbordercolor'];
        $setECReqDetails->cpplogoimage = $data['cpplogoimage'];
        $setECReqDetails->PageStyle = $data['pageStyle'];
        $setECReqDetails->BrandName = $data['brandName'];

        // Advanced options
        $setECReqDetails->AllowNote = $data['allowNote'];

        // Custom options
        $setECReqDetails->Custom = $data['custom'];
        
        $setECReqType = new SetExpressCheckoutRequestType();
        $setECReqType->SetExpressCheckoutRequestDetails = $setECReqDetails;
        $setECReq = new SetExpressCheckoutReq();
        $setECReq->SetExpressCheckoutRequest = $setECReqType;

        /*
         *      ## Creating service wrapper object
        Creating service wrapper object to make API call and loading
        Configuration::getAcctAndConfig() returns array that contains credential and config parameters
        */
        $paypalService = new PayPalAPIInterfaceServiceService(PayPalConfiguration::getAcctAndConfig());
        try {
            /* wrap API method calls on the service object with a try catch */
            $setECResponse = $paypalService->SetExpressCheckout($setECReq);
        } catch (Exception $ex) {
            //include_once("../Error.php");
            //exit;
        }

        //echo htmlspecialchars($paypalService->getLastRequest());
        //echo '<br><br>';
        //echo htmlspecialchars($paypalService->getLastResponse());

        return isset($setECResponse) ? $setECResponse : 0;
    }
}
