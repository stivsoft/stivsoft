<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

use PayPal\PayPalAPI\GetExpressCheckoutDetailsReq;
use PayPal\PayPalAPI\GetExpressCheckoutDetailsRequestType;
use PayPal\Service\PayPalAPIInterfaceServiceService;

require_once(_PS_MODULE_DIR_.'dropshipsystem/libs/PayPal/PPBootStrap.php');

class GetExpressCheckout
{
    public function execute($data)
    {
        $token = $data['token'];

        $getExpressCheckoutDetailsRequest = new GetExpressCheckoutDetailsRequestType($token);
        
        $getExpressCheckoutReq = new GetExpressCheckoutDetailsReq();
        $getExpressCheckoutReq->GetExpressCheckoutDetailsRequest = $getExpressCheckoutDetailsRequest;
        
        /*
         *      ## Creating service wrapper object
        Creating service wrapper object to make API call and loading
        Configuration::getAcctAndConfig() returns array that contains credential and config parameters
        */
        $paypalService = new PayPalAPIInterfaceServiceService(PayPalConfiguration::getAcctAndConfig());
        try {
            /* wrap API method calls on the service object with a try catch */
            $getECResponse = $paypalService->GetExpressCheckoutDetails($getExpressCheckoutReq);
        } catch (Exception $ex) {
            //include_once("../Error.php");
            //exit;
        }
        
        //echo htmlspecialchars($paypalService->getLastRequest());
        //echo '<br><br>';
        //echo htmlspecialchars($paypalService->getLastResponse());
        
        return isset($getECResponse) ? $getECResponse : 0;
    }
}
