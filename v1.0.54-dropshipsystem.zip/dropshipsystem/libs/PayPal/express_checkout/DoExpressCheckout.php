<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

use PayPal\CoreComponentTypes\BasicAmountType;
use PayPal\EBLBaseComponents\DoExpressCheckoutPaymentRequestDetailsType;
use PayPal\EBLBaseComponents\PaymentDetailsType;
use PayPal\PayPalAPI\DoExpressCheckoutPaymentReq;
use PayPal\PayPalAPI\DoExpressCheckoutPaymentRequestType;
use PayPal\PayPalAPI\GetExpressCheckoutDetailsReq;
use PayPal\PayPalAPI\GetExpressCheckoutDetailsRequestType;
use PayPal\Service\PayPalAPIInterfaceServiceService;

require_once(_PS_MODULE_DIR_.'dropshipsystem/libs/PayPal/PPBootStrap.php');

/*
 * The DoExpressCheckoutPayment API operation completes an Express Checkout transaction. If you set up a billing agreement in your SetExpressCheckout API call, the billing agreement is created when you call the DoExpressCheckoutPayment API operatio
 */

/*
 * The total cost of the transaction to the buyer. If shipping cost (not applicable to digital goods) and tax charges are known, include them in this value. If not, this value should be the current sub-total of the order. If the transaction includes one or more one-time purchases, this field must be equal to the sum of the purchases. Set this field to 0 if the transaction does not include a one-time purchase such as when you set up a billing agreement for a recurring payment that is not immediately charged. When the field is set to 0, purchase-specific fields are ignored.
 * For digital goods, the following must be true:
 * total cost > 0
 * total cost <= total cost passed in the call to SetExpressCheckout
*/

class DoExpressCheckout
{
    public function execute($data)
    {
        $token = urlencode($data['token']);

        /*
         *  Unique PayPal buyer account identification number as returned in the GetExpressCheckoutDetails response
        */
        $payerId = urlencode($data['payerID']);
        $paymentAction = urlencode($data['paymentAction']);

        // ------------------------------------------------------------------
        // this section is optional if parameters required for DoExpressCheckout is retrieved from your database
        $getExpressCheckoutDetailsRequest = new GetExpressCheckoutDetailsRequestType($token);
        $getExpressCheckoutReq = new GetExpressCheckoutDetailsReq();
        $getExpressCheckoutReq->GetExpressCheckoutDetailsRequest = $getExpressCheckoutDetailsRequest;
        /*
        Configuration::getAcctAndConfig() returns array that contains credential and config parameters
        */
        $paypalService = new PayPalAPIInterfaceServiceService(PayPalConfiguration::getAcctAndConfig());
        try {
            /* wrap API method calls on the service object with a try catch */
            //$getECResponse = $paypalService->GetExpressCheckoutDetails($getExpressCheckoutReq);
        } catch (Exception $ex) {
            //include_once("../Error.php");
            //exit;
        }
        //----------------------------------------------------------------------------

        /*
         * The total cost of the transaction to the buyer. If shipping cost (not applicable to digital goods) and tax charges are known, include them in this value. If not, this value should be the current sub-total of the order. If the transaction includes one or more one-time purchases, this field must be equal to the sum of the purchases. Set this field to 0 if the transaction does not include a one-time purchase such as when you set up a billing agreement for a recurring payment that is not immediately charged. When the field is set to 0, purchase-specific fields are ignored.
        */
        $orderTotal = new BasicAmountType();
        $orderTotal->currencyID = $data['currencyCode'];
        $orderTotal->value = $data['amt'];

        $paymentDetails= new PaymentDetailsType();
        $paymentDetails->OrderTotal = $orderTotal;

        /*
         * Your URL for receiving Instant Payment Notification (IPN) about this transaction. If you do not specify this value in the request, the notification URL from your Merchant Profile is used, if one exists.
         */
        if (isset($data['notifyURL'])) {
            $paymentDetails->NotifyURL = $data['notifyURL'];
        }

        $DoECRequestDetails = new DoExpressCheckoutPaymentRequestDetailsType();
        $DoECRequestDetails->PayerID = $payerId;
        $DoECRequestDetails->Token = $token;
        $DoECRequestDetails->PaymentAction = $paymentAction;
        $DoECRequestDetails->PaymentDetails[0] = $paymentDetails;

        $DoECRequest = new DoExpressCheckoutPaymentRequestType();
        $DoECRequest->DoExpressCheckoutPaymentRequestDetails = $DoECRequestDetails;

        $DoECReq = new DoExpressCheckoutPaymentReq();
        $DoECReq->DoExpressCheckoutPaymentRequest = $DoECRequest;

        try {
            /* wrap API method calls on the service object with a try catch */
            $DoECResponse = $paypalService->DoExpressCheckoutPayment($DoECReq);
        } catch (Exception $ex) {
            //include_once("../Error.php");
            //exit;
        }

        return isset($DoECResponse) ? $DoECResponse : 0;
    }
}
