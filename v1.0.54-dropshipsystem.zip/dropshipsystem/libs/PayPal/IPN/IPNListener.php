<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

use PayPal\IPN\PPIPNMessage;

require(dirname(__FILE__).'../../../../../../config/config.inc.php');
require_once(dirname(__FILE__).'../../../../../../init.php');

require_once(_PS_MODULE_DIR_.'dropshipsystem/libs/PayPal/PPBootStrap.php');
require_once(_PS_MODULE_DIR_.'dropshipsystem/libs/PayPal/express_checkout/DoExpressCheckout.php');

// first param takes ipn data to be validated. if null, raw POST data is read from input stream
$ipnMessage = new PPIPNMessage(null, PayPalConfiguration::getConfig());
foreach ($ipnMessage->getRawData() as $key => $value) {
    error_log("IPN: $key => $value");
}

if ($ipnMessage->validate()) {
    //$DoExpressCheckout = new DoExpressCheckout();
    //$PPExecute = $DoExpressCheckout->execute($data);
    error_log("Success: Got valid IPN data");
} else {
    error_log("Error: Got invalid IPN data");
}
