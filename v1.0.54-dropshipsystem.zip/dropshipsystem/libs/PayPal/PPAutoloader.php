<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class PPAutoloader
{
    private static $vendorDir = '';
    private static $map = array();

    public static function register()
    {
        self::$vendorDir = dirname(__FILE__);
        self::$map = array();
        spl_autoload_register(array(__CLASS__, 'loadClass'), true);
    }

    public static function loadClass($class)
    {
        return false;
        if ('\\' == $class[0]) {
            $class = Tools::substr($class, 1);
        }

        if (false !== $pos = strrpos($class, '\\')) {
            // namespaced class name
            $classPath = str_replace('\\', DIRECTORY_SEPARATOR, Tools::substr($class, 0, $pos)) . DIRECTORY_SEPARATOR;
            $className = Tools::substr($class, $pos + 1);
        } else {
            // PEAR-like class name
            $classPath = null;
            $className = $class;
        }

        $classPath .= str_replace('_', DIRECTORY_SEPARATOR, $className) . '.php';
        foreach (self::$map as $prefix => $dirs) {
            if (0 === strpos($class, $prefix)) {
                foreach ($dirs as $dir) {
                    if (file_exists($dir . DIRECTORY_SEPARATOR . $classPath)) {
                        include $dir . DIRECTORY_SEPARATOR . $classPath;
                        return;
                    }
                }
            }
        }
    }
}
