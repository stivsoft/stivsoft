<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

use PayPal\PayPalAPI\GetPalDetailsReq;
use PayPal\PayPalAPI\GetPalDetailsRequestType;
use PayPal\Service\PayPalAPIInterfaceServiceService;

require_once(_PS_MODULE_DIR_.'dropshipsystem/libs/PayPal/PPBootStrap.php');
/*
 * Obtain your Pal ID, which is the PayPal-assigned merchant account number, and other informaton about your account. You need the account number when working with dynamic versions of PayPalbuttons and logos
 */

class GetPalDetails
{
    public function getAccount()
    {
        $getPalDetailsRequest = new GetPalDetailsRequestType();
        $getPalDetailsReq = new GetPalDetailsReq();
        $getPalDetailsReq->GetPalDetailsRequest = $getPalDetailsRequest;

        /*
         *      ## Creating service wrapper object
        Creating service wrapper object to make API call and loading
        Configuration::getAcctAndConfig() returns array that contains credential and config parameters
        */
        $paypalService = new PayPalAPIInterfaceServiceService(PayPalConfiguration::getAcctAndConfig());
        try {
            /* wrap API method calls on the service object with a try catch */
            $getPalDetailsResponse = $paypalService->GetPalDetails($getPalDetailsReq);
        } catch (Exception $ex) {
            //include_once("../Error.php");
            //exit;
        }

        return isset($getPalDetailsResponse) ? $getPalDetailsResponse : 0;
    }
}
