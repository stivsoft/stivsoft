<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

require_once(_PS_MODULE_DIR_.'dropshipsystem/libs/PayPal/Configuration.php');
/*
 * @constant PP_CONFIG_PATH required if credentoal and configuration is to be used from a file
* Let the SDK know where the sdk_config.ini file resides.
*/
//define('PP_CONFIG_PATH', dirname(__FILE__));

/*
 * use autoloader
*/
if (file_exists(dirname(__FILE__).'/vendor/autoload.php')) {
    require dirname(__FILE__).'/vendor/autoload.php';
} else {
    //require _PS_MODULE_DIR_.'dropship/libs/PayPal/PPAutoloader.php';
    //PPAutoloader::register();
}
