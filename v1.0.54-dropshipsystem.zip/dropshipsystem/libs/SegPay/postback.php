<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$useSSL = true;

include(dirname(__FILE__).'/../../../../config/config.inc.php');
//include(dirname(__FILE__).'/../../../../init.php');

include_once(dirname(__FILE__).'/../../dropshipsystem.php');

class payment_segpayPostBack
{
    public function init()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $action = (string)Tools::getValue('action');
        $approved = (string)Tools::getValue('approved');
        $trantype = (string)Tools::getValue('trantype');

        $token = (string)Tools::getValue('extra_token');

        $dss = new DropShipSystem();
        if ($action == 'Auth' && $approved == 'Yes' && $trantype == 'Sale') {
            $dss_payment_token = new DssPaymentsTokenClass((string)$token);
            if (isset($dss_payment_token) && $dss_payment_token->id) {
                if ((string)$dss_payment_token->status == 'valid') {
                    $dss_payment_token->status = 'cbok';
                    $dss_payment_token->params = Tools::jsonEncode($_POST);
                    if ($dss_payment_token->save()) {
                        $dss->writeLog('CALLBACK SEGPAY OK');
                        die('OK');
                    }
                }
            }
        }
        $dss->writeLog('CALLBACK SEGPAY KO');
        die('KO');
    }
}

$postback = new payment_segpayPostBack();
$postback->init();
