<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$useSSL = true;

include(dirname(__FILE__).'/../../../../config/config.inc.php');
//include(dirname(__FILE__).'/../../../../init.php');

include_once(dirname(__FILE__).'/../../dropshipsystem.php');

class payment_molpayIPN
{
    public function init()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        $id_shop = (int)$this->context->shop->id;

        $nbcb = (string)Tools::getValue('nbcb'); 
        $amount = (string)Tools::getValue('amount');             
        $id_order = (string)Tools::getValue('orderid');
        $id_tran = (string)Tools::getValue('tranID');
        $status = (string)Tools::getValue('status');
        $domain = (string)Tools::getValue('domain'); 
        $currency = (string)Tools::getValue('currency');
        $appcode = (string)Tools::getValue('appcode');
        $paydate = (string)Tools::getValue('paydate');
        $skey = (string)Tools::getValue('skey');

        $vkey = (string)Configuration::get('DSS_MOLPAY_MERCHANT_SKEY', null, null, $id_shop);

        $key0 = md5($id_tran.$id_order.$status.$domain.$amount.$currency);
        $key1 = md5($paydate.$domain.$key0.$appcode.$vkey);

		echo "CBTOKEN:MPSTATOK";
		exit;
    }
}

$ipn = new payment_molpayIPN();
$ipn->init();
