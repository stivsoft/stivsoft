{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{if $tpldata.channels}
<form id="molpay_form" method="post" action="{$tpldata.payment_url|escape:'html':'UTF-8'}" class="hidden" role="molpayseamless">
    <input name="payment_token" type="hidden" value="{$payment_token|escape:'html':'UTF-8'}" />
    <div class="container">
        <div class="row">
            <h3>{l s='Pay by MOLPay' mod='dropshipsystem'}</h3>
            <p>{l s='Please select one channel listed below to proceed' mod='dropshipsystem'}</p>
        </div>
        <div class="row">
            <center>
                <ul class="text-center">
                {foreach from=$tpldata.channels key=k item=v}
                    <li>
                        <label for="dss_molpay_{$k|escape:'html':'UTF-8'}">
                            <img class="img-responsive" title="{$v['name']|escape:'html':'UTF-8'}" src="{$v['logo']|escape:'html':'UTF-8'}">
                        </label>
                        <input id="dss_molpay_{$k|escape:'html':'UTF-8'}" name="payment_options" type="radio" class="hidden" value="{$k|escape:'html':'UTF-8'}" required>
                    </li>
                {/foreach}
                </ul>
            <center>
        </div>
    </div>
</form>
{else}
    <div class="alert alert-danger">{l s='There is no payment option available for this currency. Please use others currency.' mod='dropshipsystem'}</div>
{/if}
