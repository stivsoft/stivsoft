<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$useSSL = true;

include(dirname(__FILE__).'/../../../../config/config.inc.php');
//include(dirname(__FILE__).'/../../../../init.php');

include_once(dirname(__FILE__).'/../../dropshipsystem.php');

class payment_comnpayIPN
{
    public function init()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        $id_shop = (int)$this->context->shop->id;

        $dss = new DropShipSystem();
        $result = Tools::getValue('result');
        $token = (string)Tools::getValue('data');

        $pkey = (string)Configuration::get('DSS_COMNPAY_SECRET', null, null, $id_shop);

        if (!$this->validSec($_POST, $pkey)) {
            header("Status: 400 Bad Request", false, 400);
            exit();
        }

        if ($result == 'OK') {
            $dss_payment_token = new DssPaymentsTokenClass((string)$token);
            if (isset($dss_payment_token) && $dss_payment_token->id) {
                if ((string)$dss_payment_token->status == 'valid') {
                    $dss_payment_token->status = 'cbok';
                    $dss_payment_token->params = Tools::jsonEncode($_POST);
                    if ($dss_payment_token->save()) {
                        $dss->writeLog('CALLBACK COMNPAY OK');
                        die('OK');
                    }
                }
            }
        }
		exit();
    }

    public function validSec($values, $secret_key)
    {
        if (isset($values['sec']) && $values['sec'] != "") {
            $sec = $values['sec'];
            unset($values['sec']);
            return Tools::strtoupper(hash("sha512", base64_encode(implode("|", $values)."|".$secret_key))) == Tools::strtoupper($sec);
        } else {
            return false;
        }
    }
}

$ipn = new payment_comnpayIPN();
$ipn->init();
