{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<form id="comnpay_form" method="post" action="{$tpldata.payment_url|escape:'html':'UTF-8'}" class="hidden">
    {foreach from=$tpldata.data key=k item=v}
        <input type="hidden" name="{$k|escape:'html':'UTF-8'}" value="{$v|escape:'html':'UTF-8'}">
    {/foreach}
</form>
<div class="container">
    <div class="row">
        <center>
            <h3>{l s='Pay by ConNpay' mod='dropshipsystem'}</h3>
            <p>{l s='Waiting...' mod='dropshipsystem'}</p>
        </center>
    </div>
</div>
