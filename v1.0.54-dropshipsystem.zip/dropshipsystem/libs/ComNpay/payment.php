<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$useSSL = true;

include(dirname(__FILE__).'/../../../../config/config.inc.php');
//include(dirname(__FILE__).'/../../../../init.php');

include_once(dirname(__FILE__).'/../../dropshipsystem.php');

header('Content-Type: application/json');

if ($token = (string)Tools::getValue('payment_token')) {
    $context = Context::getContext();
    $payment_token = new DssPaymentsTokenClass($token);

    if (isset($payment_token) && $payment_token->id) {
        $id_shop = (int)$context->shop->id;

        $mp_merchantid = (string)Configuration::get('DSS_MOLPAY_MERCHANT_ID', null, null, $id_shop);
        $mp_verifykey = (string)Configuration::get('DSS_MOLPAY_MERCHANT_VKEY', null, null, $id_shop);
        $channel = (string)Tools::getValue('payment_options');

        $amount = number_format((float)$payment_token->amount, 2, '.', '');

        $id_dropshipper = DssDropshippersClass::getDrophipperIDByCustomerID($context->customer->id);
        $dropshipper = new DssDropshippersClass((int)$id_dropshipper);
        $customer = new Customer((int)$context->customer->id);
        $address = new Address((int)$dropshipper->id_address_invoice);
        $country = new Country((int)$address->id_country);

        $id_order = (int)$payment_token->is_credit ? (string)$payment_token->id.'-'.(string)$payment_token->custom_reference : (int)$payment_token->id_order;

        $vcode = (string)md5((string)$amount.(string)$mp_merchantid.(string)$id_order.(string)$mp_verifykey);

        $molpayparams = array(
            'status'            => true,
            'mpsmerchantid'     => (string)$mp_merchantid,
            'mpsamount'         => $amount,
            'mpsorderid'        => (string)$id_order,
            'mpsbill_name'      => (string)$customer->firstname.' '.(string)$customer->lastname,
            'mpsbill_email'     => (string)$customer->email,
            'mpsbill_mobile'    => (empty($address->phone) ? (string)$address->phone_mobile : (string)$address->phone),
            'mpsbill_desc'      => (string)$payment_token->name,
            'mpscountry'        => (string)Tools::strtoupper($country->iso_code),
            'mpschannel'        => (string)$channel,
            'mpsvcode'          => (string)$vcode,
            'mpscurrency'       => (string)Tools::strtoupper($payment_token->currency),
            'mpsreturnurl'      => (string)$payment_token->return_url
        );
    } else {
        $molpayparams = array(
            'status'            => false,
            'error_code'        => "500",
            'error_desc'        => "Internal Server Error",
            'failureurl'        => (string)$payment_token->cancel_url
        );
    }
} else {
    $molpayparams = array(
        'status'            => false,
        'error_code'        => "500",
        'error_desc'        => "Internal Server Error",
        //'failureurl'        => (string)$payment_token->cancel_url
    );
}
echo json_encode($molpayparams);
exit;
