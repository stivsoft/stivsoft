<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$useSSL = true;

include(dirname(__FILE__).'/../../../../config/config.inc.php');
//include(dirname(__FILE__).'/../../../../init.php');

include_once(dirname(__FILE__).'/../../dropshipsystem.php');

$unique_id = (string)Tools::getValue('t');
$transaction_id = (string)Tools::getValue('s');

$dss = new DropShipSystem();
if (!empty($unique_id) && !empty($transaction_id)) {
    $context = Context::getContext();
    $id_shop = (int)$context->shop->id;

    $merchantid = (string)trim(Configuration::get('DSS_VIVAWALLET_MERCHANTID', null, null, $id_shop));
    $password = (string)html_entity_decode(Configuration::get('DSS_VIVAWALLET_MERCHANTPASS', null, null, $id_shop));

    if ((int)Configuration::get('DSS_VIVAWALLET_TEST', null, null, $id_shop)) {
        $baseurl = 'https://demo.vivapayments.com';
    } else {
        $baseurl = 'https://www.vivapayments.com';
    }

    $curl = curl_init($baseurl."/api/transactions/".$unique_id);
    curl_setopt($curl, CURLOPT_PORT, 443);
    curl_setopt($curl, CURLOPT_POST, false);
    curl_setopt($curl, CURLOPT_HEADER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_USERPWD, $merchantid.':'.$password); 
    $curlversion = curl_version();
    if (!preg_match("/NSS/" , $curlversion['ssl_version'])){
        curl_setopt($curl, CURLOPT_SSL_CIPHER_LIST, "TLSv1");
    }

    // execute curl
    $response = curl_exec($curl);

    if (curl_error($curl)) {
        curl_setopt($curl, CURLOPT_PORT, 443);
        curl_setopt($curl, CURLOPT_POST, false);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_USERPWD, $merchantid.':'.$password);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($curl);
    }

    curl_close($curl);

    $result_obj = Tools::jsonDecode($response);

    $transactions = null;
    if ($result_obj->ErrorCode == 0) {
        $transactions = $result_obj->Transactions[0];
        $error_code = $result_obj->ErrorCode;
        $error_text = $result_obj->ErrorText;
    } else {
        $dss->writeLog('INVALID VIVAWALLET TRANSACTION');
        //Tools::redirect((string)$payment_token->cancel_url);
    }

    if (isset($transactions) && (string)$transactions->Order->OrderCode == (string)$transaction_id) {
        $token = (string)$transactions->Order->Tags[0];
        $payment_token = new DssPaymentsTokenClass($token);

        if ($payment_token->id) {
            if ($transactions->StatusId == 'F') {
                if ((string)$payment_token->status == 'valid') {
                    $payment_token->params = Tools::jsonEncode($result_obj->Transactions[0]);
                    $payment_token->status = 'cbok';
                    if ($payment_token->save()) {
                        $dss->writeLog('PAYMENT VIVAWALLET OK');
                    }
                }

                Tools::redirect((string)$payment_token->return_url);
            } else {
                $dss->writeLog('PAYMENT VIVAWALLET FAILED');
                Tools::redirect((string)$payment_token->cancel_url);
            }
        } else {
            $dss->writeLog('PAYMENT VIVAWALLET FAILED. INVALID TOKEN');
            echo 'PAYMENT VIVAWALLET FAILED. INVALID TOKEN';
            //Tools::redirect((string)$payment_token->cancel_url);
        }
    } else {
        $dss->writeLog('PAYMENT VIVAWALLET FAILED. INVALID TRANSACTION ID');
        echo 'PAYMENT VIVAWALLET FAILED. INVALID TRANSACTION ID';
        //Tools::redirect((string)$payment_token->cancel_url);
    }
} else {
        $dss->writeLog('PAYMENT VIVAWALLET FAILED. INVALID UNIQUE ID');
        echo 'PAYMENT VIVAWALLET FAILED. INVALID UNIQUE ID';
        //Tools::redirect((string)$payment_token->cancel_url);
}
exit;
