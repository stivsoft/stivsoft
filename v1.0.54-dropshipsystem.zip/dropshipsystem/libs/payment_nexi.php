<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class payment_nexi extends DssPaymentClass
{
    public $gateway_version = '1.0';
    public $gateway_active = false;
    public $gateway_name;
    public $tplfile;
    public $tpldata;
    public $has_css = false;
    public $has_js = false;
    public $register_js = false;

    public function __construct($pagedata = false)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $this->gateway_name = $this->l('Nexi XPay', 'payment_nexi');
        $this->gateway_active = (int)Configuration::get('DSS_NEXI_ACTIVE', null, null, $id_shop);

        parent::__construct();
    }

    public function getFieldsKeys()
    {
        return array(
            'DSS_NEXI_ACTIVE',
            'DSS_NEXI_TEST',
            'DSS_NEXI_ALIAS',
            'DSS_NEXI_MAC',
            'DSS_NEXI_GROUP',
        );
    }

    public function getFieldsForm()
    {
        $tab_name = (string)get_class($this);

        return array(
            'DSS_NEXI_ACTIVE' => array(
                'type' => 'bool',
                'title' => $this->l('Active', 'payment_nexi'),
                'name' => 'DSS_NEXI_ACTIVE',
                'tab' => $tab_name,
            ),
            'DSS_NEXI_TEST' => array(
                'type' => 'bool',
                'title' => $this->l('Test mode', 'payment_nexi'),
                'name' => 'DSS_NEXI_TEST',
                'tab' => $tab_name,
            ),
            'DSS_NEXI_ALIAS' => array(
                'type' => 'text',
                'title' => $this->l('Alias', 'payment_nexi'),
                'name' => 'DSS_NEXI_ALIAS',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_NEXI_MAC' => array(
                'type' => 'password',
                'title' => $this->l('MAC Key', 'payment_nexi'),
                'name' => 'DSS_NEXI_MAC',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_NEXI_GROUP' => array(
                'type' => 'text',
                'title' => $this->l('Group', 'payment_nexi'),
                'name' => 'DSS_NEXI_GROUP',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
        );
    }

    public function getFieldsValues()
    {
        $id_shop = (int)$this->context->shop->id;

        return array(
            'DSS_NEXI_ACTIVE' => Tools::getValue('DSS_NEXI_ACTIVE', Configuration::get('DSS_NEXI_ACTIVE', null, null, $id_shop)),
            'DSS_NEXI_TEST' => Tools::getValue('DSS_NEXI_TEST', Configuration::get('DSS_NEXI_TEST', null, null, $id_shop)),
            'DSS_NEXI_ALIAS' => Tools::getValue('DSS_NEXI_ALIAS', Configuration::get('DSS_NEXI_ALIAS', null, null, $id_shop)),
            'DSS_NEXI_MAC' => Tools::getValue('DSS_NEXI_MAC', Configuration::get('DSS_NEXI_MAC', null, null, $id_shop)),
            'DSS_NEXI_GROUP' => Tools::getValue('DSS_NEXI_GROUP', Configuration::get('DSS_NEXI_GROUP', null, null, $id_shop)),
        );
    }

    public function getAuth()
    {
        return true;
    }

    public function getPaymentPage($params)
    {
        $id_shop = (int)$this->context->shop->id;

        $token = new DssPaymentsTokenClass();
        $token->token = (string)$params['token'];
        $token->id_order = isset($params['id_order']) ? (int)$params['id_order'] : 0;
        $token->is_credit = (int)$params['is_credit'];
        $token->name = (string)$params['name'];
        $token->custom_reference = (string)$params['custom_reference'];
        $token->currency = (string)Tools::strtolower($this->context->currency->iso_code);
        $token->amount = (float)$params['total'];
        $token->return_url = isset($params['return_url']) ? (string)$params['return_url'].'&token='.(string)$params['token'] : null;
        $token->cancel_url = isset($params['cancel_url']) ? (string)$params['cancel_url'].'&token='.(string)$params['token'] : null;

        if (!$token->save()) {
            return array(
                'success' => false,
                'error' => 'TOKEN_ERROR'
            );
        }

        $id_dropshipper = DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
        $dropshipper = new DssDropshippersClass((int)$id_dropshipper);
        $customer = new Customer((int)$this->context->customer->id);
        $address = new Address((int)$dropshipper->id_address_invoice);
        $country = new Country((int)$address->id_country);

        $alias = (string)Configuration::get('DSS_NEXI_ALIAS', null, null, $id_shop);
        $mac_key = (string)Configuration::get('DSS_NEXI_MAC', null, null, $id_shop);

        if ((int)Configuration::get('DSS_NEXI_TEST', null, null, $id_shop)) {
            $url = "https://int-ecommerce.nexi.it/ecomm/ecomm/DispatcherServlet?";
        } else {
            $url = "https://ecommerce.nexi.it/ecomm/ecomm/DispatcherServlet?";
        }

        if ((int)$params['is_credit']) {
            $cod_trans = 'CR_'.(string)$params['custom_reference'].'_'.(int)$token->id;
        } else {
            $cod_trans = 'OR_'.(string)$params['custom_reference'].'_'.(int)$token->id;
        }

        $divisa = (string)Tools::strtoupper($this->context->currency->iso_code);
        $importo = (int)((float)$params['total'] * 100);

        $mac = (string)sha1('codTrans='.$cod_trans.'divisa='.$divisa.'importo='.$importo.$mac_key);

        $args = array(
            'alias' => (string)$alias,
            'importo' => $importo,
            'divisa' => (string)$divisa,
            'codTrans' => (string)$cod_trans,
            'url' => (string)$params['return_url'].'&token='.(string)$params['token'],
            'url_back' => (string)$params['cancel_url'].'&token='.(string)$params['token'],
            'mac' => (string)$mac,
            'descrizione' => (string)$params['name'],
            'mail' => (string)$customer->email,
        );

        $paymentlink = $url.$this->encode($args);

        return array(
            'success' => true,
            'currency' => (string)Tools::strtoupper($this->context->currency->iso_code),
            'custom_reference' => (string)$params['custom_reference'],
            'paymentlink' => (string)$paymentlink,
            'token' => (string)$params['token']
        );
    }

    public function processPayment($params)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $esito = (string)Tools::getValue('esito');
        $mac = (string)Tools::getValue('mac');
        $cod_aut = (string)Tools::getValue('codAut');
        $cod_trans = (string)Tools::getValue('codTrans');
        $importo = (int)Tools::getValue('importo');
        $divisa = (string)Tools::getValue('divisa');
        $data = (string)Tools::getValue('data');
        $orario = (string)Tools::getValue('orario');
        $messaggio = (string)Tools::getValue('messaggio');

        if ((string)$esito == 'OK') {
            $mac_key = (string)Configuration::get('DSS_NEXI_MAC', null, null, $id_shop);
            $mac_calc = (string)sha1('codTrans='.$cod_trans.'esito='.$esito.'importo='.$importo.'divisa='.$divisa.'data='.$data.'orario='.$orario.'codAut='.$cod_aut.$mac_key);

            if ((string)$mac == (string)$mac_calc) {
                $importo = (float)((int)$importo / 100);

                return array(
                    'success' => true,
                    'currency' => (string)$divisa,
                    'amount' => (float)$importo,
                    'payment_date' => time(true),
                    'transaction_id' => (string)$cod_trans,
                    'token' => (string)$params['token']
                );
            } else {
                return array(
                    'success' => false,
                    'error' => $this->l('Payment error. MAC is invalid.', 'payment_nexi'),
                    'token' => (string)$params['token']
                );
            }
        } else {
            return array(
                'success' => false,
                'error' => (string)$messaggio,
                'token' => (string)$params['token']
            );
        }
    }

	public function encode($args)
    {
        $params = array();
        foreach ($args as $key => $value) {
            $params[] = $key.'='.urlencode($value);
        }
        return implode('&', $params);
    }
}
