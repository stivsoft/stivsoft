<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class payment_comnpay extends DssPaymentClass
{
    public $gateway_version = '1.0';
    public $gateway_active = false;
    public $gateway_name;
    public $tplfile;
    public $tpldata;
    public $has_css = false;
    public $has_js = array('ComNpay/comnpay.js');
    public $register_js = false;

    public function __construct($pagedata = false)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $this->gateway_name = $this->l('ComNpay', 'payment_comnpay');
        $this->gateway_active = (int)Configuration::get('DSS_COMNPAY_ACTIVE', null, null, $id_shop);

        if ($pagedata) {
            if ((int)Configuration::get('DSS_COMNPAY_TEST', null, null, $id_shop)) {
                $url = "https://secure.homologation.comnpay.com";
            } else {
                $url = "https://secure.comnpay.com";
            }

            $token = (string)Tools::getValue('payment_token');
            $payment_token = new DssPaymentsTokenClass((string)$token);
            $smarty = (array)Tools::jsonDecode((string)$payment_token->params);

            $this->tplfile = 'module:dropshipsystem/libs/ComNpay/payment.tpl';
            $this->tpldata = array(
                'payment_url' => (string)$url,
                'data' => $smarty
            );
        }

        parent::__construct();
    }

    public function getFieldsKeys()
    {
        return array(
            'DSS_COMNPAY_ACTIVE',
            'DSS_COMNPAY_TEST',
            'DSS_COMNPAY_VPOSID',
            'DSS_COMNPAY_SECRET',
        );
    }

    public function getFieldsForm()
    {
        $tab_name = (string)get_class($this);

        return array(
            'DSS_COMNPAY_ACTIVE' => array(
                'type' => 'bool',
                'title' => $this->l('Active', 'payment_comnpay'),
                'name' => 'DSS_COMNPAY_ACTIVE',
                'tab' => $tab_name,
            ),
            'DSS_COMNPAY_TEST' => array(
                'type' => 'bool',
                'title' => $this->l('Test mode', 'payment_comnpay'),
                'name' => 'DSS_COMNPAY_TEST',
                'tab' => $tab_name,
            ),
            'DSS_COMNPAY_VPOSID' => array(
                'type' => 'text',
                'title' => $this->l('Virtual POS ID', 'payment_comnpay'),
                'name' => 'DSS_COMNPAY_VPOSID',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_COMNPAY_SECRET' => array(
                'type' => 'password',
                'title' => $this->l('Private Key', 'payment_comnpay'),
                'name' => 'DSS_COMNPAY_SECRET',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
        );
    }

    public function getFieldsValues()
    {
        $id_shop = (int)$this->context->shop->id;

        return array(
            'DSS_COMNPAY_ACTIVE' => Tools::getValue('DSS_COMNPAY_ACTIVE', Configuration::get('DSS_COMNPAY_ACTIVE', null, null, $id_shop)),
            'DSS_COMNPAY_TEST' => Tools::getValue('DSS_COMNPAY_TEST', Configuration::get('DSS_COMNPAY_TEST', null, null, $id_shop)),
            'DSS_COMNPAY_VPOSID' => Tools::getValue('DSS_COMNPAY_VPOSID', Configuration::get('DSS_COMNPAY_VPOSID', null, null, $id_shop)),
            'DSS_COMNPAY_SECRET' => Tools::getValue('DSS_COMNPAY_SECRET', Configuration::get('DSS_COMNPAY_SECRET', null, null, $id_shop)),
        );
    }

    public function getAuth()
    {
        return true;
    }

    public function getPaymentPage($params)
    {
        $id_shop = (int)$this->context->shop->id;

        $token = new DssPaymentsTokenClass();
        $token->token = (string)$params['token'];
        $token->id_order = isset($params['id_order']) ? (int)$params['id_order'] : 0;
        $token->is_credit = (int)$params['is_credit'];
        $token->name = (string)$params['name'];
        $token->custom_reference = (string)$params['custom_reference'];
        $token->currency = (string)Tools::strtolower($this->context->currency->iso_code);
        $token->amount = (float)$params['total'];
        $token->return_url = isset($params['return_url']) ? (string)$params['return_url'].'&token='.(string)$params['token'] : null;
        $token->cancel_url = isset($params['cancel_url']) ? (string)$params['cancel_url'].'&token='.(string)$params['token'] : null;

        $id_dropshipper = DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
        $dropshipper = new DssDropshippersClass((int)$id_dropshipper);
        $customer = new Customer((int)$this->context->customer->id);
        $address = new Address((int)$dropshipper->id_address_invoice);
        $country = new Country((int)$address->id_country);

        $vpos = (string)Configuration::get('DSS_COMNPAY_VPOSID', null, null, $id_shop);
        $pkey = (string)Configuration::get('DSS_COMNPAY_SECRET', null, null, $id_shop);

        $customer_data = Tools::jsonEncode(array(
            'adresse' => $address->address1,
            'codePostal' => $address->postcode,
            'email' => $customer->email,
            'nom' => $customer->lastname,
            'pays' => $address->country,
            'prenom' => $customer->firstname,
            'qualite' => 'Particulier',
            'telephone' => (!empty($address->phone) ? $address->phone : $address->phone_mobile),
            'ville' => $address->city,
            'refPorteur' => $customer->secure_key
        ));

        $data = array(
            'montant' => (string)number_format((float)$params['total'], 2, '.', ''),
            'idTPE' => (string)$vpos,
            'idTransaction' => time(),
            'devise' => (string)Tools::strtoupper($this->context->currency->iso_code),
            'lang' => Language::getIsoById($this->context->language->id),
            'nom_produit' => (string)$params['name'],
            'source' => (string)$this->context->link->getBaseLink($this->context->shop->id, true),
            'urlRetourOK' => (string)$params['return_url'].'&token='.(string)$params['token'],
            'urlRetourNOK' => (string)$params['cancel_url'].'&token='.(string)$params['token'],
            'urlIPN' => (string)$this->context->link->getBaseLink($this->context->shop->id, true)."modules/dropshipsystem/libs/ComNpay/ipn.php",
            'extension' => 'prestashop-dropshipsystem-'.(string)$this->gateway_version,
            'data' => (string)$params['token'],
            'typeTr' => 'D',
            'porteur' => base64_encode($customer_data),
            'codeTemplate' => '',
            'panier' => '',
            'key' => (string)$pkey,
        );

        $data_with_key = base64_encode(implode("|", $data));
        unset($data['key']);
        $data['sec'] = hash("sha512", $data_with_key);

        $smarty = array();
        foreach ($data as $key => $value) {
            $smarty[$key] = $value;
        }
        $token->params = Tools::jsonEncode($smarty);

        if (!$token->save()) {
            return array(
                'success' => false,
                'error' => 'TOKEN_ERROR'
            );
        }

        $paymentlink = (string)$this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount', array('action' => 'PaymentPage'), true);

        return array(
            'success' => true,
            'currency' => (string)Tools::strtoupper($this->context->currency->iso_code),
            'custom_reference' => (string)$params['custom_reference'],
            'paymentlink' => $paymentlink.'&payment_token='.(string)$params['token'],
            'token' => (string)$params['token']
        );
    }

    public function processPayment($params)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $result = (string)Tools::getValue('result');
        $reason = (string)Tools::getValue('reason');

        if ((string)$result == 'OK') {
            $dss_payment_token = new DssPaymentsTokenClass((string)$params['token']);
            if (isset($dss_payment_token) && $dss_payment_token->id) {
                if ($dss_payment_token->status == 'cbok') {
                    $order = Tools::jsonDecode((string)$dss_payment_token->params);
                    $cbresult = (string)$order->result;
                    $trans_id = (string)$order->idTransaction;

                    if ((string)$cbresult == 'OK') {
                        return array(
                            'success' => true,
                            'currency' => (string)$dss_payment_token->currency,
                            'amount' => (float)$dss_payment_token->amount,
                            'payment_date' => time(true),
                            'transaction_id' => (string)$trans_id,
                            'token' => (string)$params['token']
                        );
                    } else {
                        return array(
                            'success' => false,
                            'error' => $this->l('Payment error. Authorization declined.', 'payment_comnpay'),
                            'token' => (string)$params['token']
                        );
                    }
                } else {
                    return array(
                        'success' => false,
                        'error' => $this->l('Payment error. Invalid token status.', 'payment_comnpay'),
                        'token' => (string)$params['token']
                    );
                }
            }
        } else {
            return array(
                'success' => false,
                'error' => (string)$reason,
                'token' => (string)$params['token']
            );
        }
    }
}
