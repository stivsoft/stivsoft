<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$useSSL = true;

include(dirname(__FILE__).'/../../../../config/config.inc.php');
//include(dirname(__FILE__).'/../../../../init.php');

include_once(dirname(__FILE__).'/../../dropshipsystem.php');

$dss = new DropShipSystem();
if ($token = (string)Tools::getValue('payment_token')) {
    $context = Context::getContext();
    $payment_token = new DssPaymentsTokenClass($token);

    if (isset($payment_token) && $payment_token->id) {
        require_once(_PS_MODULE_DIR_.'dropshipsystem/libs/PayTPV/paycomet_bankstore.php');

        $id_shop = (int)$context->shop->id;

        $merchant = (string)Configuration::get('DSS_PTPV_CUSTOMER', null, null, $id_shop);
        $password = (string)Configuration::get('DSS_PTPV_SECRET', null, null, $id_shop);
        $terminal = (string)Configuration::get('DSS_PTPV_TERMINAL', null, null, $id_shop);
        $jetid = (string)Configuration::get('DSS_PTPV_JETID', null, null, $id_shop);

        $paycomet_token = (string)Tools::getValue('paytpvToken');
        $amount = (string)Tools::getValue('amount');
        $cardholder = (string)Tools::getValue('cardholder');

        $paycomet = new Paycomet_Bankstore($merchant, $terminal, $password, $jetid);

        $resp = $paycomet->AddUserToken($paycomet_token);

        if ($resp->RESULT == 'OK') {
            $idUser = $resp->DS_IDUSER;
            $tokenUser = $resp->DS_TOKEN_USER;

            $amount = (int)((float)$payment_token->amount * 100);

            //$id_dropshipper = DssDropshippersClass::getDrophipperIDByCustomerID($context->customer->id);
            //$dropshipper = new DssDropshippersClass((int)$id_dropshipper);
            //$customer = new Customer((int)$context->customer->id);
            //$address = new Address((int)$dropshipper->id_address_invoice);
            //$country = new Country((int)$address->id_country);

            $id_order = (int)$payment_token->is_credit ? (string)$payment_token->id.'-'.(string)$payment_token->custom_reference : (int)$payment_token->id_order;

            $purchase_result = $paycomet->ExecutePurchase(
                $idUser,
                $tokenUser,
                $amount,
                $id_order,
                (string)Tools::strtoupper($payment_token->currency),
                'ORDER '.$id_order,
                (string)$cardholder
            );

            if ((string)$purchase_result->DS_RESPONSE == '1') {
                if ((string)$payment_token->status == 'valid') {
                    $payment_token->params = Tools::jsonEncode($purchase_result);
                    if ($payment_token->save()) {
                        $dss->writeLog('PAYMENT PAYTPV OK');
                    }
                }

                Tools::redirect((string)$payment_token->return_url);
            } else {
                $dss->writeLog('PAYMENT PAYTPV FAILED.');
                Tools::redirect((string)$payment_token->cancel_url);
            }
        } else {
            $dss->writeLog('PAYMENT PAYTPV FAILED. INVALID USER TOKEN');
            Tools::redirect((string)$payment_token->cancel_url);
        }
    }
}
echo 'Error, missing token';
return false;
