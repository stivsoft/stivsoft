{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{if $ssl}
<div class="row paytpv-payment">
    <div class="col-xs-12">
        <div class="card">
            <div class="card-body">

                <form id="paycometPaymentForm" method="post" action="{$tpldata.payment_url|escape:'html':'UTF-8'}" role="form">
                    <input name="payment_token" type="hidden" value="{$payment_token|escape:'html':'UTF-8'}" />
                    <input name="amount" type="hidden" value="1234">
                    <input type="hidden" data-paycomet="apiID" value="{$tpldata.jetid|escape:'html':'UTF-8'}">

                    <h3 class="paytpv_title">{l s='Pay by card' mod='dropshipsystem'}</h3>

                    <div class="alert alert-success" style="display:none;"></div>

                    <div class="form-box">
                        <div class="form-group">
                            <label for="cardholder">{l s='Full name (on the card)' mod='dropshipsystem'}</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fa fa-user"></i></span>
                                </div>
                                <input name="cardholder" data-paycomet="cardHolderName" class="form-control" type="text" placeholder="" required="">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="cardNumber">{l s='Card number' mod='dropshipsystem'}</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fa fa-credit-card"></i></span>
                                </div>
                                <div id="paycomet-pan" style="padding:0px; height:36px;"></div>
                                <input name="cardNumber" 
                                    paycomet-name="pan"
                                    paycomet-style="border: 1px solid #cccccc;
                                        -webkit-border-radius: 2px;
                                        -moz-border-radius: 2px;
                                        border-radius: 2px;
                                        height: 36px;
                                        margin-left: 0;
                                        margin-bottom: 15px;
                                        padding: 5px 10px;
                                        box-sizing: border-box;
                                        font-size: 15px;
                                        width: 100%;"
                                    class="form-control" type="text" placeholder="">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-8">
                                <div class="form-group">
                                    <label><span class="hidden-xs">{l s='Expiration' mod='dropshipsystem'}</span> </label>
                                    <div class="form-inline">
                                        <select class="form-control" style="width:45%" data-paycomet="dateMonth">
                                            <option>MM</option>
                                            {for $m=1 to 12}
                                            <option value="{$m|intval}">{"%02d"|sprintf:$m|escape:'html':'UTF-8'}</option>
                                            {/for}
                                        </select>
                                        <span style="width:10%; text-align: center"> / </span>
                                        <select class="form-control" style="width:45%" data-paycomet="dateYear">
                                            <option>YY</option>
                                            {for $y=date('Y') to date('Y')+10}
                                            <option value="{$y|substr:-2|intval}">{$y|escape:'html':'UTF-8'}</option>
                                            {/for}
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label data-toggle="tooltip" title=""
                                        data-original-title="3 digits code on back side of the card">
                                        {l s='CVV' mod='dropshipsystem'} <i class="fa fa-question-circle"></i>
                                    </label>
                                    <div id="paycomet-cvc2" style="height: 36px; padding:0px;"></div>
                                    <input paycomet-name="cvc2"
                                        paycomet-style="border: 1px solid #cccccc;
                                            -webkit-border-radius: 2px;
                                            -moz-border-radius: 2px;
                                            border-radius: 2px;
                                            height: 36px;
                                            margin-left: 0;
                                            margin-bottom: 15px;
                                            padding: 5px 10px;
                                            box-sizing: border-box;
                                            font-size: 15px;
                                            width: 99%;"
                                        class="form-control" required="" type="text">
                                </div>
                            </div>
                        </div>
                        <button class="subscribe btn btn-primary btn-block" type="submit">{l s='Confirm' mod='dropshipsystem'}</button>
                        <div class="clearfix"></div>
                        <div class="row">
                            <center>
                                <img class="img-card" src="{$module_dir|escape:'html':'UTF-8'}libs/PayTPV/img/pay-visa.png"/>
                                <img class="img-card" src="{$module_dir|escape:'html':'UTF-8'}libs/PayTPV/img/pay-mastercard.png"/>
                                <img class="img-card" src="{$module_dir|escape:'html':'UTF-8'}libs/PayTPV/img/pay-american-ex.png"/>
                            </center>
                        </div>
                    </div>

                </form>
                <div id="paymentErrorMsg"></div>

            </div>
        </div>

    </div>
</div>
{else}
<div class="row paytpv-payment">
    <div class="col-xs-12">
        <p class="alert alert-danger">{l s='SSL is off, please activate it.' mod='dropshipsystem'}</p>
    </div>
</div>
{/if}
