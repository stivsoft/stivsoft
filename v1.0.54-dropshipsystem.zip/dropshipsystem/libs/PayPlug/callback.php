<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$useSSL = true;

include(dirname(__FILE__).'/../../../../config/config.inc.php');
//include(dirname(__FILE__).'/../../../../init.php');

include_once(dirname(__FILE__).'/../../dropshipsystem.php');

class payment_payplugCallBack
{
    public function init()
    {
        if (!class_exists('Payplug')) {
            require_once(_PS_MODULE_DIR_.'dropshipsystem/libs/PayPlug/init.php');
        }

        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $dss = new DropShipSystem();

        $private_key = (string)Configuration::get('DSS_PAYPLUG_PRIVATE_KEY', null, null, $id_shop);
        $publish_key = (string)Configuration::get('DSS_PAYPLUG_PUBLISHABLE_KEY', null, null, $id_shop);

        Payplug\Payplug::setSecretKey($private_key);

        $input = file_get_contents('php://input');

        try {
            $resource = \Payplug\Notification::treat($input);

            if ($resource instanceof \Payplug\Resource\Payment && $resource->is_paid) {
//                $payment_id = $resource->id;
//                $payment_state = $resource->is_paid;
//                $payment_date = $resource->hosted_payment->paid_at;
//                $payment_amount = $resource->amount / 100;
//                $payment_id_customer = $resource->metadata[customer_id];

                $token = $resource->metadata[token];

                $dss_payment_token = new DssPaymentsTokenClass((string)$token);
                if (isset($dss_payment_token) && $dss_payment_token->id) {
                    $dss_payment_token->status = 'cbok';
                    $dss_payment_token->params = (string)$input;
                    if ($dss_payment_token->save()) {
                        $dss->writeLog('OK');
                        die('OK');
                    }
                }
            }
        } catch (\Payplug\Exception\PayplugException $exception) {
            echo $exception;
        }
        die('KO');
    }
}

$callback = new payment_payplugCallBack();
$callback->init();
