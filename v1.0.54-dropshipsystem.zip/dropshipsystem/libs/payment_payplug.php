<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class payment_payplug extends DssPaymentClass
{
    public $gateway_version = '1.0';
    public $gateway_active = false;
    public $gateway_name;
    public $tplfile;
    public $tpldata;
    public $has_css = false;
    public $has_js = false;
    public $register_js = false;

    public function __construct($pagedata = false)
    {
        if (!class_exists('Payplug')) {
            require_once(_PS_MODULE_DIR_.'dropshipsystem/libs/PayPlug/init.php');
        }

        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $this->gateway_name = $this->l('PayPlug', 'payment_payplug');
        $this->gateway_active = (int)Configuration::get('DSS_PAYPLUG_ACTIVE', null, null, $id_shop);

        parent::__construct();
    }

    public function getFieldsKeys()
    {
        return array(
            'DSS_PAYPLUG_ACTIVE',
            'DSS_PAYPLUG_TEST',
            'DSS_PAYPLUG_PRIVATE_KEY',
            'DSS_PAYPLUG_PUBLISHABLE_KEY',
        );
    }

    public function getFieldsForm()
    {
        $tab_name = (string)get_class($this);

        return array(
            'DSS_PAYPLUG_ACTIVE' => array(
                'type' => 'bool',
                'title' => $this->l('Active', 'payment_payplug'),
                'name' => 'DSS_PAYPLUG_ACTIVE',
                'tab' => $tab_name,
            ),
            'DSS_PAYPLUG_TEST' => array(
                'type' => 'bool',
                'title' => $this->l('Test mode', 'payment_payplug'),
                'name' => 'DSS_PAYPLUG_TEST',
                'tab' => $tab_name,
            ),
            'DSS_PAYPLUG_PRIVATE_KEY' => array(
                'type' => 'password',
                'title' => $this->l('Private Key', 'payment_payplug'),
                'name' => 'DSS_PAYPLUG_PRIVATE_KEY',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_PAYPLUG_PUBLISHABLE_KEY' => array(
                'type' => 'password',
                'title' => $this->l('Publishable Key', 'payment_payplug'),
                'name' => 'DSS_PAYPLUG_PUBLISHABLE_KEY',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
        );
    }

    public function getFieldsValues()
    {
        $id_shop = (int)$this->context->shop->id;

        return array(
            'DSS_PAYPLUG_ACTIVE' => Tools::getValue('DSS_PAYPLUG_ACTIVE', Configuration::get('DSS_PAYPLUG_ACTIVE', null, null, $id_shop)),
            'DSS_PAYPLUG_TEST' => Tools::getValue('DSS_PAYPLUG_TEST', Configuration::get('DSS_PAYPLUG_TEST', null, null, $id_shop)),
            'DSS_PAYPLUG_PRIVATE_KEY' => Tools::getValue('DSS_PAYPLUG_PRIVATE_KEY', Configuration::get('DSS_PAYPLUG_PRIVATE_KEY', null, null, $id_shop)),
            'DSS_PAYPLUG_PUBLISHABLE_KEY' => Tools::getValue('DSS_PAYPLUG_PUBLISHABLE_KEY', Configuration::get('DSS_PAYPLUG_PUBLISHABLE_KEY', null, null, $id_shop)),
        );
    }

    public function getAuth()
    {
        return true;
    }

    public function getPaymentPage($params)
    {
        $id_shop = (int)$this->context->shop->id;

        $token = new DssPaymentsTokenClass();
        $token->token = (string)$params['token'];
        $token->id_order = isset($params['id_order']) ? (int)$params['id_order'] : 0;
        $token->is_credit = (int)$params['is_credit'];
        $token->name = (string)$params['name'];
        $token->custom_reference = (string)$params['custom_reference'];
        $token->currency = (string)Tools::strtolower($this->context->currency->iso_code);
        $token->amount = (float)$params['total'];
        $token->return_url = isset($params['return_url']) ? (string)$params['return_url'].'&token='.(string)$params['token'] : null;
        $token->cancel_url = isset($params['cancel_url']) ? (string)$params['cancel_url'].'&token='.(string)$params['token'] : null;

        if (!$token->save()) {
            return array(
                'success' => false,
                'error' => 'TOKEN_ERROR'
            );
        }

        $id_dropshipper = DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
        $dropshipper = new DssDropshippersClass((int)$id_dropshipper);
        $customer = new Customer((int)$this->context->customer->id);
        $address = new Address((int)$dropshipper->id_address_invoice);
        $country = new Country((int)$address->id_country);

        $amount = number_format((float)$params['total'], 2, '.', '');

        $private_key = (string)Configuration::get('DSS_PAYPLUG_PRIVATE_KEY', null, null, $id_shop);

        Payplug\Payplug::setSecretKey($private_key);

        $payment = Payplug\Payment::create(array(
                'amount' => ($amount * 100),
                'currency' => (string)Tools::strtoupper($this->context->currency->iso_code),
                'customer' => array(
                    'email' => (string)$customer->email,
                    'first_name' => (string)$customer->firstname,
                    'last_name' => (string)$customer->lastname,
                ),
                'hosted_payment' => array(
                    'return_url' => (string)$params['return_url'].'&token='.(string)$params['token'],
                    'cancel_url' => (string)$params['cancel_url'].'&token='.(string)$params['token']
                ),
                'notification_url' => (string)$this->context->link->getBaseLink($this->context->shop->id, true)."modules/dropshipsystem/libs/PayPlug/callback.php",
                'metadata' => array(
                    'customer_id' => (int)$this->context->customer->id,
                    'token' => (string)$params['token']
                )
        ));

        if (isset($payment) && $payment->object == 'payment') {
            $paymentlink = $payment->hosted_payment->payment_url;

            return array(
                'success' => true,
                'currency' => (string)Tools::strtoupper($this->context->currency->iso_code),
                'custom_reference' => (string)$params['custom_reference'],
                'paymentlink' => (string)$paymentlink,
                'token' => (string)$params['token']
            );
        } else {
            return array(
                'success' => false,
                'error' => sprintf($this->l('An error occurred while getting transaction informations: %s', 'payment_payplug'), $description),
            );
        }
    }

    public function processPayment($params)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $dss_payment_token = new DssPaymentsTokenClass((string)$params['token']);
        if (isset($dss_payment_token) && $dss_payment_token->id) {
            if ($dss_payment_token->status == 'cbok') {
                $order = Tools::jsonDecode((string)$dss_payment_token->params);
                $payment_id = (string)$order->id;

                $private_key = (string)Configuration::get('DSS_PAYPLUG_PRIVATE_KEY', null, null, $id_shop);

                Payplug\Payplug::setSecretKey($private_key);

                $payment = \Payplug\Payment::retrieve($payment_id);

                if (isset($payment) && $payment->is_paid) {
                    return array(
                        'success' => true,
                        'currency' => (string)$dss_payment_token->currency,
                        'amount' => (float)$dss_payment_token->amount,
                        'payment_date' => time(true),
                        'transaction_id' => (string)$payment_id,
                        'token' => (string)$params['token']
                    );
                } else {
                    return array(
                        'success' => false,
                        'error' => $this->l('Payment not executed.', 'payment_payplug'),
                        'token' => (string)$params['token']
                    );
                }
            } else {
                return array(
                    'success' => false,
                    'error' => $this->l('Payment error. Invalid token status.', 'payment_payplug'),
                    'token' => (string)$params['token']
                );
            }
        } else {
            return array(
                'success' => false,
                'error' => $this->l('Payment error. Invalid token.', 'payment_payplug'),
                'token' => (string)$params['token']
            );
        }
    }
}
