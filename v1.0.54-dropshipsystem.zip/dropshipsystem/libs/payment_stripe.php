<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class payment_stripe extends DssPaymentClass
{
    public $gateway_version = '1.0';
    public $gateway_active = false;
    public $gateway_name;
    public $tplfile;
    public $tpldata;
    public $has_css = 'Stripe/stripe.css';
    public $has_js = array('Stripe/jquery.the-modal.js', 'Stripe/stripe.js');
    public $register_js = array(
        array(
            'name' => 'dropship-stipeV2',
            'url' => 'https://js.stripe.com/v2/',
            'array' => array('server' => 'remote'),
        ),
        array(
            'name' => 'dropship-stipeV3',
            'url' => 'https://js.stripe.com/v3/',
            'array' => array('server' => 'remote'),
        )
    );

    public function __construct($pagedata = false)
    {
        if (!class_exists('Stripe\Stripe')) {
            require_once(_PS_MODULE_DIR_.'dropshipsystem/libs/Stripe/vendor/stripe/stripe-php/init.php');
        }

        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $base_dir = $this->context->link->getBaseLink($this->context->shop->id, true);

        $this->gateway_name = $this->l('Stripe', 'payment_stripe');
        $this->gateway_active = (int)Configuration::get('DSS_STRIPE_ACTIVE', null, null, $id_shop);
        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            $this->tplfile = _PS_MODULE_DIR_.'dropshipsystem/libs/Stripe/payment.tpl';
        } else {
            $this->tplfile = 'module:dropshipsystem/libs/Stripe/payment.tpl';
        }
        $this->tpldata = array(
            'public_api_key' => (string)Configuration::get('DSS_STRIPE_PUBLIC_API_KEY', null, null, $id_shop),
            'secret_api_key' => (string)Configuration::get('DSS_STRIPE_SECRET_API_KEY', null, null, $id_shop),
            'language_iso' => (string)$this->context->language->iso_code,
            'secure_mode' => (bool)Configuration::get('DSS_STRIPE_3DSECURE', null, null, $id_shop),
            'ajax_url' => (string)$base_dir.'modules/dropshipsystem/libs/Stripe/ajax.php'
        );

        parent::__construct();
    }

    public function getFieldsKeys()
    {
        return array(
            'DSS_STRIPE_ACTIVE',
            'DSS_STRIPE_TEST',
            'DSS_STRIPE_PUBLIC_API_KEY',
            'DSS_STRIPE_SECRET_API_KEY',
            'DSS_STRIPE_3DSECURE',
        );
    }

    public function getFieldsForm()
    {
        $tab_name = (string)get_class($this);

        return array(
            'DSS_STRIPE_ACTIVE' => array(
                'type' => 'bool',
                'title' => $this->l('Active', 'payment_stripe'),
                'name' => 'DSS_STRIPE_ACTIVE',
                'tab' => $tab_name,
            ),
            'DSS_STRIPE_TEST' => array(
                'type' => 'bool',
                'title' => $this->l('Test mode', 'payment_stripe'),
                'name' => 'DSS_STRIPE_TEST',
                'tab' => $tab_name,
            ),
            'DSS_STRIPE_PUBLIC_API_KEY' => array(
                'type' => 'password',
                'title' => $this->l('Public API KEY', 'payment_stripe'),
                'name' => 'DSS_STRIPE_PUBLIC_API_KEY',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_STRIPE_SECRET_API_KEY' => array(
                'type' => 'password',
                'title' => $this->l('Secret API KEY', 'payment_stripe'),
                'name' => 'DSS_STRIPE_SECRET_API_KEY',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_STRIPE_3DSECURE' => array(
                'type' => 'bool',
                'title' => $this->l('Enable 3D Secure', 'payment_stripe'),
                'name' => 'DSS_STRIPE_3DSECURE',
                'tab' => $tab_name,
            ),
        );
    }

    public function getFieldsValues()
    {
        $id_shop = (int)$this->context->shop->id;

        return array(
            'DSS_STRIPE_ACTIVE' => Tools::getValue('DSS_STRIPE_ACTIVE', Configuration::get('DSS_STRIPE_ACTIVE', null, null, $id_shop)),
            'DSS_STRIPE_TEST' => Tools::getValue('DSS_STRIPE_TEST', Configuration::get('DSS_STRIPE_TEST', null, null, $id_shop)),
            'DSS_STRIPE_PUBLIC_API_KEY' => Tools::getValue('DSS_STRIPE_PUBLIC_API_KEY', Configuration::get('DSS_STRIPE_PUBLIC_API_KEY', null, null, $id_shop)),
            'DSS_STRIPE_SECRET_API_KEY' => Tools::getValue('DSS_STRIPE_SECRET_API_KEY', Configuration::get('DSS_STRIPE_SECRET_API_KEY', null, null, $id_shop)),
            'DSS_STRIPE_3DSECURE' => Tools::getValue('DSS_STRIPE_3DSECURE', Configuration::get('DSS_STRIPE_3DSECURE', null, null, $id_shop)),
        );
    }

    public function getAuth()
    {
        $id_shop = (int)$this->context->shop->id;

        //$is_test = (int)Configuration::get('DSS_STRIPE_TEST', null, null, $id_shop);
        $public_api_key = (string)Configuration::get('DSS_STRIPE_PUBLIC_API_KEY', null, null, $id_shop);
        $secret_api_key = (string)Configuration::get('DSS_STRIPE_SECRET_API_KEY', null, null, $id_shop);

        \Stripe\Stripe::setApiKey($secret_api_key);

        try {
            $res = \Stripe\Balance::retrieve();

            if (isset($res->available)) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $e) {
            //$err = $e->jsonBody['error']['message'];
            return false;
        }
    }

    public function getPaymentPage($params)
    {
        $id_shop = (int)$this->context->shop->id;

        if ($this->getAuth()) {
            $paymentlink = (string)$this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount', array('action' => 'PaymentPage'), true);

            $token = new DssPaymentsTokenClass();
            $token->token = (string)$params['token'];
            $token->id_order = isset($params['id_order']) ? (int)$params['id_order'] : 0;
            $token->is_credit = (int)$params['is_credit'];
            $token->name = (string)$params['name'];
            $token->custom_reference = (string)$params['custom_reference'];
            $token->currency = (string)Tools::strtolower($this->context->currency->iso_code);
            $token->amount = (float)$params['total'];
            $token->return_url = isset($params['return_url']) ? (string)$params['return_url'] : null;
            $token->cancel_url = isset($params['cancel_url']) ? (string)$params['cancel_url'] : null;

            if (!$token->save()) {
                return array(
                    'success' => false,
                    'error' => 'TOKEN_ERROR'
                );
            }

            return array(
                'success' => true,
                'currency' => (string)Tools::strtoupper($this->context->currency->iso_code),
                'custom_reference' => (string)$params['custom_reference'],
                'paymentlink' => $paymentlink.'&payment_token='.(string)$params['token'],
                'token' => (string)$params['token']
            );
        } else {
            return array(
                'success' => false,
                'error' => 'NO_LOGGED'
            );
        }
    }

    public function processPayment($params)
    {
        if ($this->getAuth()) {
            try {
                \Stripe\Stripe::setAppInfo("DropshipStripePrestashop", $this->version, Configuration::get('PS_SHOP_DOMAIN_SSL'));
                \Stripe\Account::retrieve();
            } catch (Exception $e) {
                return array(
                    'success' => false,
                    'error' => $e->getMessage(),
                    'token' => (string)$params['token']
                );
            }
        } else {
            return array(
                'success' => false,
                'error' => $this->module->l('Invalid Stripe credentials, please check your configuration.', 'payment_stripe'),
                'token' => (string)$params['token']
            );
        }

        try {
            $stripe_token = (string)Tools::getValue('stoken');

            $payment_token = new DssPaymentsTokenClass((string)$params['token']);
            $amount = (float)$payment_token->amount;

            // @see: https://support.stripe.com/questions/which-zero-decimal-currencies-does-stripe-support
            $zeroDecimalCurrencies = array('BIF', 'CLP', 'DJF', 'GNF', 'JPY', 'KMF', 'KRW', 'MGA', 'PYG', 'RWF', 'VND', 'VUV', 'XAF', 'XOF', 'XPF');

            if (!in_array(Tools::strtoupper($payment_token->currency), $zeroDecimalCurrencies)) {
                $amount *= 100;
            }

            if ($payment_token->is_credit) {
                $description = 'CREDIT ORDER: '.$payment_token->name;
            } else {
                $description = 'DROPSHIP ORDER: '.$payment_token->name;
            }

            $source = \Stripe\Source::retrieve($stripe_token);
            $charge = \Stripe\Charge::create(
                array(
                    "amount" => $amount, // amount in cents, again
                    "currency" => (string)$payment_token->currency,
                    "source" => (string)$stripe_token,
                    "description" => $description.' - '.$source->owner->email,
                    "shipping" => array(
                        "address" => array(
                            "city" => (string)$source->owner->address->city,
                            "country" => (string)$source->owner->address->country,
                            "line1" => (string)$source->owner->address->line1,
                            "line2" => (string)$source->owner->address->line2,
                            "postal_code" => (string)$source->owner->address->postal_code,
                            "state" => (string)$source->owner->address->state
                        ),
                        "name" => (string)$source->owner->name
                    ),
                    "metadata" => array(
                        "cart_id" => 0,
                        "verification_url" => Configuration::get('PS_SHOP_DOMAIN'),
                    )
                )
            );

            if ($charge->status == 'succeeded' && $charge->object == 'charge' && $charge->id) {
                return array(
                    'success' => true,
                    'currency' => (string)$charge->currency,
                    'amount' => (float)$charge->amount / 100,
                    'payment_date' => time(true),
                    'transaction_id' => (string)$charge->id,
                    'token' => (string)$params['token']
                );
            } else {
                return array(
                    'success' => false,
                    'error' => $this->module->l('Payment declined. Unknown error, please use another card or contact us.', 'payment_stripe'),
                    'token' => (string)$params['token']
                );
            }
        } catch (\Stripe\Error\Card $e) {
            return array(
                'success' => false,
                'error' => $e->getMessage(),
                'token' => (string)$params['token']
            );
        }
    }
}
