<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class payment_segpay extends DssPaymentClass
{
    public $gateway_version = '1.0';
    public $gateway_active = false;
    public $gateway_name;
    public $tplfile;
    public $tpldata;
    public $has_css = false;
    public $has_js = false;
    public $register_js = false;

    public function __construct($pagedata = false)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $this->gateway_name = $this->l('SegPay', 'payment_segpay');
        $this->gateway_active = (int)Configuration::get('DSS_SEGPAY_ACTIVE', null, null, $id_shop);

        parent::__construct();
    }

    public function getFieldsKeys()
    {
        return array(
            'DSS_SEGPAY_ACTIVE',
            'DSS_SEGPAY_TEST',
            'DSS_SEGPAY_USERNAME',
            'DSS_SEGPAY_PASSWORD',
            'DSS_SEGPAY_ETICKET_ID',
        );
    }

    public function getFieldsForm()
    {
        $tab_name = (string)get_class($this);

        return array(
            'DSS_SEGPAY_INFO' => array(
                'type' => 'html',
                'tab' => $tab_name,
                'html_content' => "<div class='alert alert-info'>".
                    $this->l('Please configure the follow URL in postback configuration page of SegPay Merchant portal.', 'payment_segpay')."<br />
                    <span>".(string)$this->context->link->getBaseLink($this->context->shop->id, true)."modules/dropshipsystem/libs/SegPay/postback.php</span><br />
                    <span>".$this->l('Positive response', 'payment_segpay').": <strong>OK</strong></span><br />
                    <span>".$this->l('Negative response', 'payment_segpay').": <strong>KO</strong></span>
                </div>"
            ),
            'DSS_SEGPAY_ACTIVE' => array(
                'type' => 'bool',
                'title' => $this->l('Active', 'payment_segpay'),
                'name' => 'DSS_SEGPAY_ACTIVE',
                'tab' => $tab_name,
            ),
            'DSS_SEGPAY_TEST' => array(
                'type' => 'bool',
                'title' => $this->l('Test mode', 'payment_segpay'),
                'name' => 'DSS_SEGPAY_TEST',
                'tab' => $tab_name,
            ),
            'DSS_SEGPAY_USERNAME' => array(
                'type' => 'text',
                'title' => $this->l('Username', 'payment_segpay'),
                'name' => 'DSS_SEGPAY_USERNAME',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_SEGPAY_PASSWORD' => array(
                'type' => 'password',
                'title' => $this->l('Password', 'payment_segpay'),
                'name' => 'DSS_SEGPAY_PASSWORD',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_SEGPAY_ETICKET_ID' => array(
                'type' => 'text',
                'title' => $this->l('eTicket ID', 'payment_segpay'),
                'name' => 'DSS_SEGPAY_ETICKET_ID',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
        );
    }

    public function getFieldsValues()
    {
        $id_shop = (int)$this->context->shop->id;

        return array(
            'DSS_SEGPAY_ACTIVE' => Tools::getValue('DSS_SEGPAY_ACTIVE', Configuration::get('DSS_SEGPAY_ACTIVE', null, null, $id_shop)),
            'DSS_SEGPAY_TEST' => Tools::getValue('DSS_SEGPAY_TEST', Configuration::get('DSS_SEGPAY_TEST', null, null, $id_shop)),
            'DSS_SEGPAY_USERNAME' => Tools::getValue('DSS_SEGPAY_USERNAME', Configuration::get('DSS_SEGPAY_USERNAME', null, null, $id_shop)),
            'DSS_SEGPAY_PASSWORD' => Tools::getValue('DSS_SEGPAY_PASSWORD', Configuration::get('DSS_SEGPAY_PASSWORD', null, null, $id_shop)),
            'DSS_SEGPAY_ETICKET_ID' => Tools::getValue('DSS_SEGPAY_ETICKET_ID', Configuration::get('DSS_SEGPAY_ETICKET_ID', null, null, $id_shop)),
        );
    }

    public function getAuth()
    {
        return true;
    }

    public function getPaymentPage($params)
    {
        $id_shop = (int)$this->context->shop->id;

        $token = new DssPaymentsTokenClass();
        $token->token = (string)$params['token'];
        $token->id_order = isset($params['id_order']) ? (int)$params['id_order'] : 0;
        $token->is_credit = (int)$params['is_credit'];
        $token->name = (string)$params['name'];
        $token->custom_reference = (string)$params['custom_reference'];
        $token->currency = (string)Tools::strtolower($this->context->currency->iso_code);
        $token->amount = (float)$params['total'];
        $token->return_url = isset($params['return_url']) ? (string)$params['return_url'].'&token='.(string)$params['token'] : null;
        $token->cancel_url = isset($params['cancel_url']) ? (string)$params['cancel_url'].'&token='.(string)$params['token'] : null;

        if (!$token->save()) {
            return array(
                'success' => false,
                'error' => 'TOKEN_ERROR'
            );
        }

        $id_dropshipper = DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
        $dropshipper = new DssDropshippersClass((int)$id_dropshipper);
        $customer = new Customer((int)$this->context->customer->id);
        $address = new Address((int)$dropshipper->id_address_invoice);
        $country = new Country((int)$address->id_country);

        $total = number_format((float)$params['total'], 2, '.', '');

        $price_hash_url = 'https://srs.segpay.com/PricingHash/PricingHash.svc/GetDynamicTrans?value='.$total;
        $response = file_get_contents($price_hash_url);
        $xml = simplexml_load_string($response);
        $dynamictrans = (string)$xml;

        $eticketid = Configuration::get('DSS_SEGPAY_ETICKET_ID', null, null, $id_shop);

        $args = array(
            'userId' => (int)$id_dropshipper,
            //'invoiceId' => isset($params['id_order']) ? (int)$params['id_order'] : 0,
            'invoiceId' => (string)$params['token'],
            'amount' => $total,
            'dynamicdesc' => (string)$params['name'],
            'dynamictrans' => urldecode($dynamictrans),
            'x-billname' => (string)$customer->firstname.' '.(string)$customer->lastname,
            'x-billemail' => (string)$customer->email,
            'x-billaddr' => (string)$address->address1,
            'x-billcity' => (string)$address->city,
            'x-billzip' => (string)$address->postcode,
            'x-billcntry' => (string)$country->iso_code,
            'x-auth-link' => (string)$params['return_url'].'&token='.(string)$params['token'],
            'x-auth-text' => $this->l('Click here to go back to the store', 'payment_segpay'),
            'x-decl-link' => (string)$params['cancel_url'].'&token='.(string)$params['token'],
            'x-decl-text' => $this->l('Click here to go back to the store', 'payment_segpay'),
            //'paypagelanguage' => (string)$this->context->language->iso_code,
            'DMCURRENCY' => (string)Tools::strtoupper($this->context->currency->iso_code),
            'extra token' => (string)$params['token']
        );

        $str = (string)$this->encode($args);

        if (Configuration::get('DSS_SEGPAY_TEST', null, null, $id_shop)) {
            $str .= '&TESTTRANS=1';
        }

        $paymentlink = "https://secure2.segpay.com/billing/poset.cgi?x-eticketid=".$eticketid.$str;

        return array(
            'success' => true,
            'currency' => (string)Tools::strtoupper($this->context->currency->iso_code),
            'custom_reference' => (string)$params['custom_reference'],
            'paymentlink' => $paymentlink.'&payment_token='.(string)$params['token'],
            'token' => (string)$params['token']
        );
    }

    public function processPayment($params)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $dss_payment_token = new DssPaymentsTokenClass((string)$params['token']);
        if (isset($dss_payment_token) && $dss_payment_token->id) {
            if ($dss_payment_token->status == 'cbok') {
                $order = Tools::jsonDecode((string)$dss_payment_token->params);
                $action = (string)$order->action;
                $approved = (string)$order->approved;
                $trantype = (string)$order->trantype;
                $tranid = (string)$order->tranid;

                if ($action == 'Auth' && $approved == 'Yes' && $trantype == 'Sale') {
                    return array(
                        'success' => true,
                        'currency' => (string)$dss_payment_token->currency,
                        'amount' => (float)$dss_payment_token->amount,
                        'payment_date' => time(true),
                        'transaction_id' => (string)$tranid,
                        'token' => (string)$params['token']
                    );
                } else {
                    return array(
                        'success' => false,
                        'error' => $this->l('Payment error. Authorization declined.', 'payment_segpay'),
                        'token' => (string)$params['token']
                    );
                }
            } else {
                return array(
                    'success' => false,
                    'error' => $this->l('Payment error. Invalid token status.', 'payment_segpay'),
                    'token' => (string)$params['token']
                );
            }
        }
    }

	public function encode($args)
    {
        $str = '';
        foreach ($args as $key => $value) {
            $str .= '&'.$key.'='.urlencode($value);
        }
        return $str;
    }
}
