<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class payment_paypal extends DssPaymentClass
{
    public $gateway_version = '1.0';
    public $gateway_active = false;
    public $gateway_name;
    public $tplfile;
    public $tpldata;
    public $has_css = false;
    public $has_js = false;
    public $register_js = false;

    public function __construct($pagedata = false)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $this->gateway_name = $this->l('PayPal', 'payment_paypal');
        $this->gateway_active = (int)Configuration::get('DSS_PAYPAL_ACTIVE', null, null, $id_shop);

        parent::__construct();
    }

    public function getFieldsKeys()
    {
        return array(
            'DSS_PAYPAL_ACTIVE',
            'DSS_PAYPAL_SANDBOX',
            'DSS_PAYPAL_USERNAME',
            'DSS_PAYPAL_PASSWORD',
            'DSS_PAYPAL_SIGNATURE',
        );
    }

    public function getFieldsForm()
    {
        $tab_name = (string)get_class($this);

        return array(
            'DSS_PAYPAL_INFO' => array(
                'type' => 'html',
                'tab' => $tab_name,
                'html_content' => "<div class='alert alert-info'>".
                    $this->l('Click the follow link to retrive the PayPal API credentials:', 'payment_paypal')."<br />
                    <a href='https://www.paypal.com/us/cgi-bin/webscr?cmd=_get-api-signature&generic-flow=true' target='_blank'>
                        https://www.paypal.com/us/cgi-bin/webscr?cmd=_get-api-signature&generic-flow=true
                    </a>
                </div>"
            ),
            'DSS_PAYPAL_ACTIVE' => array(
                'type' => 'bool',
                'title' => $this->l('Active', 'payment_paypal'),
                'name' => 'DSS_PAYPAL_ACTIVE',
                'tab' => $tab_name,
            ),
            'DSS_PAYPAL_SANDBOX' => array(
                'type' => 'bool',
                'title' => $this->l('Sandbox', 'payment_paypal'),
                'name' => 'DSS_PAYPAL_SANDBOX',
                'tab' => $tab_name,
            ),
            'DSS_PAYPAL_USERNAME' => array(
                'type' => 'text',
                'title' => $this->l('API Username', 'payment_paypal'),
                'name' => 'DSS_PAYPAL_USERNAME',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_PAYPAL_PASSWORD' => array(
                'type' => 'password',
                'title' => $this->l('API Password', 'payment_paypal'),
                'name' => 'DSS_PAYPAL_PASSWORD',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_PAYPAL_SIGNATURE' => array(
                'type' => 'password',
                'title' => $this->l('API Signature', 'payment_paypal'),
                'name' => 'DSS_PAYPAL_SIGNATURE',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
        );
    }

    public function getFieldsValues()
    {
        $id_shop = (int)$this->context->shop->id;

        return array(
            'DSS_PAYPAL_ACTIVE' => Tools::getValue('DSS_PAYPAL_ACTIVE', Configuration::get('DSS_PAYPAL_ACTIVE', null, null, $id_shop)),
            'DSS_PAYPAL_SANDBOX' => Tools::getValue('DSS_PAYPAL_SANDBOX', Configuration::get('DSS_PAYPAL_SANDBOX', null, null, $id_shop)),
            'DSS_PAYPAL_USERNAME' => Tools::getValue('DSS_PAYPAL_USERNAME', Configuration::get('DSS_PAYPAL_USERNAME', null, null, $id_shop)),
            'DSS_PAYPAL_PASSWORD' => Tools::getValue('DSS_PAYPAL_PASSWORD', Configuration::get('DSS_PAYPAL_PASSWORD', null, null, $id_shop)),
            'DSS_PAYPAL_SIGNATURE' => Tools::getValue('DSS_PAYPAL_SIGNATURE', Configuration::get('DSS_PAYPAL_SIGNATURE', null, null, $id_shop)),
        );
    }

    public function getAuth()
    {
        require_once (_PS_MODULE_DIR_.'dropshipsystem/libs/PayPal/admin_calls/GetPalDetails.php');

        $GetPalDetails = new GetPalDetails();
        $PPAccess = $GetPalDetails->getAccount();

        if (isset($PPAccess) && $PPAccess->Ack == 'Failure') {
            if (isset($PPAccess->Errors) && count($PPAccess->Errors) > 0) {
                foreach ($PPAccess->Errors as $error) {
                    DssEventsClass::setEvent('error', sprintf($this->l('Error: %s<br>Description: %s', 'payment_paypal'), $error->ErrorCode, $error->ShortMessage));
                }
            }
            return false;
        }
        return true;
    }

    public function getPaymentPage($params)
    {
        require_once (_PS_MODULE_DIR_.'dropshipsystem/libs/PayPal/express_checkout/SetExpressCheckout.php');

        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $state = new State((int)Configuration::get('PS_SHOP_STATE_ID', null, null, $id_shop));

        $shop_name = (string)$this->context->shop->name;
        $shop_address = (string)Configuration::get('PS_SHOP_ADDR1', null, null, $id_shop);
        $shop_city = (string)Configuration::get('PS_SHOP_CITY', null, null, $id_shop);
        $shop_cap = (string)Configuration::get('PS_SHOP_CODE', null, null, $id_shop);
        $shop_coutry = (string)Country::getIsoById((int)Configuration::get('PS_SHOP_COUNTRY_ID', null, null, $id_shop));
        $shop_state = (string)$state->iso_code;
        $shop_phone = (string)Configuration::get('PS_SHOP_PHONE', null, null, $id_shop);

        $shop_logo = 'http'.(Configuration::get('PS_SSL_ENABLED', null, null, $id_shop) ? 's' : '').
            '://'.Tools::getShopDomain(false, true).__PS_BASE_URI__.
            'img/'.(string)Configuration::get('PS_LOGO', null, null, $id_shop);

        $notify_url = 'http'.(Configuration::get('PS_SSL_ENABLED', null, null, $id_shop) ? 's' : '').
            '://'.Tools::getShopDomain(false, true).__PS_BASE_URI__.
            'modules/dropshipsystem/libs/PayPal/IPN/IPNListener.php';

        if (isset($params) && (float)$params['total'] > 0) {
            $currency = new Currency(Configuration::get('PS_CURRENCY_DEFAULT', null, null, $id_shop));

            $data = array(
                'currencyCode' => (string)$currency->iso_code,
                'shippingTotal' => 0,
                'handlingTotal' => 0,
                'insuranceTotal' => 0,
                'city' => $shop_city,
                'name' => $shop_name,
                'street' => $shop_address,
                'state' => $shop_state,
                'postalCode' => $shop_cap,
                'countryCode' => $shop_coutry,
                'phone' => $shop_phone,
                'paymentType' => 'Sale',
                'notifyURL' => $notify_url,
                'noShipping' => 1,
                'addressOverride' => 0,
                'reqConfirmShipping' => 0,
                'billingType' => 'None',
                'billingAgreementText' => '',
                'cppheaderimage' => '',
                'cppheaderbordercolor' => '',
                'cppheaderbackcolor' => '',
                'cpppayflowcolor' => '',
                'cppcartbordercolor' => '',
                'cpplogoimage' => $shop_logo,
                'pageStyle' => '',
                'brandName' => $shop_name,
                'allowNote' => 0
            );

            $data['items'][] = array(
                'Amount' => (float)Tools::ps_round((float)$params['total'], 2),
                'Quantity' => 1,
                'SalesTax' => 0,
                'Name' => ((bool)$params['is_credit'] ? 'PREPAID CREDIT: '.(string)Tools::displayPrice((float)$params['total'], $currency) : 'DROPSHIP ORDER: '.(string)$params['name']),
                'Category' => ((bool)$params['is_credit'] ? 'Digital' : 'Physical')
            );

            if (isset($params['return_url'])) {
                $data['returnURL'] = (string)$params['return_url'];
            }
            if (isset($params['cancel_url'])) {
                $data['cancelURL'] = (string)$params['cancel_url'];
            }
            if (isset($params['custom_reference'])) {
                $data['custom'] = (string)$params['custom_reference'];
            }

            $SetExpressCheckout = new SetExpressCheckout();
            $PPCheckout = $SetExpressCheckout->execute($data);

            if ($PPCheckout && $PPCheckout->Ack != 'Failure') {
                $paypal_token = (string)$PPCheckout->Token;
                if ((int)Configuration::get('DSS_PAYPAL_SANDBOX', null, null, $id_shop) == 1) {
                    $paymentlink = 'https://www.sandbox.paypal.com/webscr?cmd=_express-checkout&token='.$paypal_token;
                } else {
                    $paymentlink = 'https://www.paypal.com/webscr?cmd=_express-checkout&token='.$paypal_token;
                }

                $token = new DssPaymentsTokenClass();
                $token->token = (string)$paypal_token;
                $token->id_order = isset($params['id_order']) ? (int)$params['id_order'] : 0;
                $token->is_credit = (int)$params['is_credit'];
                $token->name = (string)$params['name'];
                $token->custom_reference = (string)$params['custom_reference'];
                $token->currency = (string)Tools::strtolower($this->context->currency->iso_code);
                $token->amount = (float)$params['total'];
                $token->return_url = isset($params['return_url']) ? (string)$params['return_url'] : null;
                $token->cancel_url = isset($params['cancel_url']) ? (string)$params['cancel_url'] : null;

                if (!$token->save()) {
                    return array(
                        'success' => false,
                        'error' => 'TOKEN_ERROR'
                    );
                }

                return array(
                    'success' => true,
                    'currency' => (string)$currency->iso_code,
                    'custom_reference' => (string)$params['custom_reference'],
                    'paymentlink' => (string)$paymentlink,
                    'token' => (string)$paypal_token
                );
            } else {
                $errors = array();
                if ($PPCheckout->Errors) {
                    foreach ($PPCheckout->Errors as $pperror) {
                        DssEventsClass::setEvent('error', sprintf($this->l('Error: %s<br>Description: %s', 'payment_paypal'), $pperror->ErrorCode, $pperror->ShortMessage));
                        $errors[] = (string)$pperror->ErrorCode.': '.(string)$pperror->LongMessage;
                    }

                    return array(
                        'success' => false,
                        'error' => $errors
                    );
                } else {
                    return array(
                        'success' => false,
                        'error' => 'NO_LOGGED'
                    );
                }
            }
        } else {
            return array(
                'success' => false,
                'error' => 'INVALID_PRODUCT'
            );
        }
    }

    public function processPayment($params)
    {
        require_once (_PS_MODULE_DIR_.'dropshipsystem/libs/PayPal/express_checkout/GetExpressCheckout.php');
        require_once (_PS_MODULE_DIR_.'dropshipsystem/libs/PayPal/express_checkout/DoExpressCheckout.php');

        $GetExpressCheckout = new GetExpressCheckout();
        $PPResult = $GetExpressCheckout->execute($params);

        if (isset($PPResult) && $PPResult->Ack != 'Failure') {
            $pp_custom = (string)$PPResult->GetExpressCheckoutDetailsResponseDetails->Custom;
            $pp_checkout_status = (string)$PPResult->GetExpressCheckoutDetailsResponseDetails->CheckoutStatus;
            $pp_authorized_amount = (float)$PPResult->GetExpressCheckoutDetailsResponseDetails->PaymentDetails[0]->OrderTotal->value;

            if ($pp_authorized_amount > 0) {
                if ($pp_checkout_status == 'PaymentActionNotInitiated') {
                    $data = array(
                        'token' => (string)$PPResult->GetExpressCheckoutDetailsResponseDetails->Token,
                        'payerID' => (string)$PPResult->GetExpressCheckoutDetailsResponseDetails->PayerInfo->PayerID,
                        'paymentAction' => (string)$PPResult->GetExpressCheckoutDetailsResponseDetails->PaymentDetails[0]->PaymentAction,
                        'currencyCode' => (string)$PPResult->GetExpressCheckoutDetailsResponseDetails->PaymentDetails[0]->OrderTotal->currencyID,
                        'amt' => $pp_authorized_amount
                    );

                    $DoExpressCheckout = new DoExpressCheckout();
                    $PPExecute = $DoExpressCheckout->execute($data);

                    if (isset($PPExecute) && $PPExecute->Ack != 'Failure') {
                        $pp_payment_status = $PPExecute->DoExpressCheckoutPaymentResponseDetails->PaymentInfo[0]->PaymentStatus;

                        if ($pp_payment_status == 'Completed' || $pp_payment_status == 'Completed_Funds_Held') {
                            $pp_payment_date = (string)$PPExecute->DoExpressCheckoutPaymentResponseDetails->PaymentInfo[0]->PaymentDate;
                            $pp_transaction_id = (string)$PPExecute->DoExpressCheckoutPaymentResponseDetails->PaymentInfo[0]->TransactionID;
                            $pp_currency = (string)$PPExecute->DoExpressCheckoutPaymentResponseDetails->PaymentInfo[0]->GrossAmount->currencyID;
                            $pp_gross_amount = (float)$PPExecute->DoExpressCheckoutPaymentResponseDetails->PaymentInfo[0]->GrossAmount->value;

                            $pp_payment_date = strtotime($pp_payment_date);

                            return array(
                                'success' => true,
                                'currency' => (string)$pp_currency,
                                'amount' => (float)$pp_gross_amount,
                                'payment_date' => $pp_payment_date,
                                'transaction_id' => (string)$pp_transaction_id,
                                //'custom' => (string)$pp_custom,
                                'token' => (string)$params['token']
                            );
                        } else {
                            return array(
                                'success' => false,
                                'error' => (string)$pp_payment_status,
                                'token' => (string)$params['token']
                            );
                        }
                    } else {
                        return array(
                            'success' => false,
                            'error' => $this->l('Paypal \'do express checkout\' ack failure', 'payment_paypal'),
                            'token' => (string)$params['token']
                        );
                    }
                } elseif ($pp_checkout_status == 'PaymentActionCompleted') {
                    return array(
                        'success' => false,
                        'error' => $this->l('Payment already completed', 'payment_paypal'),
                        'token' => (string)$params['token']
                    );
                }
            } else {
                return array(
                    'success' => false,
                    'error' => $this->l('Invalid payment import', 'payment_paypal'),
                    'token' => (string)$params['token']
                );
            }
        } else {
            if (isset($PPExecute->Errors) && count($PPExecute->Errors) > 0) {
                foreach ($PPExecute->Errors as $error) {
                    DssEventsClass::setEvent('error', sprintf($this->l('Error: %s<br>Description: %s', 'payment_paypal'), $error->ErrorCode, $error->ShortMessage));
                }
            }

            return array(
                'success' => false,
                'error' => $this->l('Paypal \'get express checkout\' ack failure', 'payment_paypal'),
                'token' => (string)$params['token']
            );
        }
    }
}
