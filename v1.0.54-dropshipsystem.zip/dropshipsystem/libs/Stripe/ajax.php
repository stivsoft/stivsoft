<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

include(dirname(__FILE__).'/../../../../config/config.inc.php');

/* Check to security token */
if (!Module::isInstalled('dropshipsystem')) {
    die('Module not installed');
}

include_once(dirname(__FILE__).'/../../dropshipsystem.php');

class payment_stripeAjax
{
    public $ssl = true;
    private $stripe;

    public function init()
    {
        $this->context = Context::getContext();

        if ($token = (string)Tools::getValue('paymentToken')) {
            $payment_token = new DssPaymentsTokenClass($token);

            if (isset($payment_token) && $payment_token->id) {
                $params = array(
                    'code' => '1',
                    'token' => (string)$payment_token->token,
                    'stoken' => (string)Tools::getValue('stripeToken'),
                    'return_url' => (string)$payment_token->return_url,
                );
                return die(Tools::jsonEncode($params));
            } else {
                die('Invalid token');
            }
        } else {
            die('Missing token');
        }
    }
}

$ajax = new payment_stripeAjax();
$ajax->init();
