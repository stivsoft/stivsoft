<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

include(dirname(__FILE__).'/../../../../config/config.inc.php');
//include(dirname(__FILE__).'/../../../../init.php');

//include_once(_PS_MODULE_DIR_.'dropshipsystem/dropshipsystem.php');
//require_once(dirname(__FILE__).'/init.php');

class payment_stripeWebhook //extends FrontController
{
    public function init()
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }

        $id_shop = (int)$this->context->shop->id;
        
        dump($id_shop);
    }
    
}

$webhook = new payment_stripeWebhook();
$webhook->init();
