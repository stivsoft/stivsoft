{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{if $ssl}
<div class="row stripe-payment">
    <div class="col-xs-12">
        <input type="hidden" id="stripe-incorrect_number" value="{l s='The card number is incorrect.' mod='dropshipsystem'}">
        <input type="hidden" id="stripe-invalid_number" value="{l s='The card number is not a valid credit card number.' mod='dropshipsystem'}">
        <input type="hidden" id="stripe-invalid_expiry_month" value="{l s='The card\'s expiration month is invalid.' mod='dropshipsystem'}">
        <input type="hidden" id="stripe-invalid_expiry_year" value="{l s='The card\'s expiration year is invalid.' mod='dropshipsystem'}">
        <input type="hidden" id="stripe-invalid_cvc" value="{l s='The card\'s security code is invalid.' mod='dropshipsystem'}">
        <input type="hidden" id="stripe-expired_card" value="{l s='The card has expired.' mod='dropshipsystem'}">
        <input type="hidden" id="stripe-incorrect_cvc" value="{l s='The card\'s security code is incorrect.' mod='dropshipsystem'}">
        <input type="hidden" id="stripe-incorrect_zip" value="{l s='The card\'s zip code failed validation.' mod='dropshipsystem'}">
        <input type="hidden" id="stripe-card_declined" value="{l s='The card was declined.' mod='dropshipsystem'}">
        <input type="hidden" id="stripe-missing" value="{l s='There is no card on a customer that is being charged.' mod='dropshipsystem'}">
        <input type="hidden" id="stripe-processing_error" value="{l s='An error occurred while processing the car.' mod='dropshipsystem'}">
        <input type="hidden" id="stripe-rate_limit" value="{l s='An error occurred due to requests hitting the API too quickly. Please let us know if you\'re consistently running into this error.' mod='dropshipsystem'}">
        <input type="hidden" id="stripe-3d_declined" value="{l s='The card doesn\'t support 3DS.' mod='dropshipsystem'}">
        <input type="hidden" id="stripe-no_api_key" value="{l s='There\'s an error with your API keys.' mod='dropshipsystem'}">

        <div id="stripe-ajax-loader">
            <img src="{$module_dir|escape:'html':'UTF-8'}libs/Stripe/img/ajax-loader.gif" alt="" /> {l s='Transaction in progress, please wait.' mod='dropshipsystem'}
        </div>

        <form id="stripe-payment-form" action="#">
            <input type="hidden" id="stripe-publishable-key" value="{$tpldata.public_api_key|escape:'html':'UTF-8'}"/>

            <h3 class="stripe_title">{l s='Pay by card' mod='dropshipsystem'}</h3>

            <div class="stripe-payment-errors">{if isset($smarty.get.stripe_error)}{$smarty.get.stripe_error|escape:'html':'UTF-8'}{/if}</div>

            <div id="card-errors" role="alert"></div>

            <div class="form-box">
                <div class="row">
                    <div class="col-xs-12">
                        <label>{l s='Amount' mod='dropshipsystem'}:</label>
                        <span class="price">{Tools::displayPrice($payment_amount, $currency)|escape:'html':'UTF-8'}</span>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xs-12">
                        <label>{l s='Description' mod='dropshipsystem'}:</label>
                        <span class="price">{$payment_description|escape:'htmlall':'UTF-8'}</span>
                    </div>
                </div>

                <div class="clear separator"></div>

                <div class="row">
                    <div class="col-xs-12">
                        <label>{l s='Card holder\'s Name' mod='dropshipsystem'}</label><em class="required"> </em>
                        <input name="card-holdername" type="text" autocomplete="off" class="stripe-holdername" data-stripe="holdername" />
                    </div>
                </div>

                <div class="row">
                    <div class="col-xs-12 col-sm-8">
                        <label for="cardNumber">{l s='Card Number' mod='dropshipsystem'}</label><em class="required"> </em>
                        <div id="cardNumber-element"></div>
                    </div>
                    <div class="col-xs-12 col-sm-4">
                        <label for="cardCvc">{l s='CVC/CVV' mod='dropshipsystem'}</label><em class="required"> </em>
                        <div id="cardCvc-element"></div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xs-12">
                        <label for="cardExpiry">{l s='Expiry date' mod='dropshipsystem'}</label><em class="required"> </em>
                        <div id="cardExpiry-element"></div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xs-12 pull-left">
                        <input name="card-privacy" type="checkbox" class="stripe-privacy" value="1" />
                        <label for="card-privacy" class="js-terms">
                            {l s='I accept our' mod='dropshipsystem'} <a class="tos iframe" href="{$tos_url|escape:'htmlall':'UTF-8'}">{l s='Terms of Service' mod='dropshipsystem'}</a> {l s='and' mod='dropshipsystem'} <a class="privacy iframe" href="{$privacy_url|escape:'htmlall':'UTF-8'}">{l s='Privacy Policy' mod='dropshipsystem'}</a>
                            <em class="required"> </em>
                        </label>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xs-12">
                        <button name="submitStripe" type="button" class="btn btn-primary">
                            <span>{l s='Pay now' mod='dropshipsystem'}</span>
                        </button>
                        <a href="#" class="cancel-payment" rel="nofollow">{l s='Cancel payment' mod='dropshipsystem'}</a>
                    </div>
                </div>
            </div>

            <div class="clear"></div>
            <img class="powered_stripe" alt="" src="{$module_dir|escape:'html':'UTF-8'}libs/Stripe/img/verified_by_visa.png"/>
            <img class="powered_stripe" alt="" src="{$module_dir|escape:'html':'UTF-8'}libs/Stripe/img/mastercard_securecode.png"/>
            <img class="powered_stripe" alt="" src="{$module_dir|escape:'html':'UTF-8'}libs/Stripe/img/powered_by_stripe.png"/>
        </form>
    </div>
</div>

<div id="modal_stripe" class="modal" style="display: none">
    <div id="result_3d"> </div>
</div>

<div class="modal fade" id="modal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="{l s='Close' mod='dropshipsystem'}">
                <span aria-hidden="true">&times;</span>
            </button>
            <div class="js-modal-content"></div>
        </div>
    </div>
</div>

<script type="text/javascript">
    var module_dir = "{$module_dir|escape:'html':'UTF-8'}";
    var baseDir = "{$baseDir|escape:'html':'UTF-8'}";
    var payment_token = "{$payment_token|escape:'html':'UTF-8'}";
    var billing_address = "{$payment_billing_address|escape:'html':'UTF-8'}";
    var stripe_amount = "{($payment_amount * 100)|intval}";
    var stripe_currency = "{$payment_currency|escape:'html':'UTF-8'}";
    var stripe_ajax_url = "{$tpldata.ajax_url|escape:'html':'UTF-8'}";
    var stripe_pub_key = "{$tpldata.public_api_key|escape:'html':'UTF-8'}";
    var stripe_language_iso = "{$tpldata.language_iso|escape:'html':'UTF-8'}";
    var stripe_secure_mode = "{$tpldata.secure_mode|boolval}";
</script>
{else}
<div class="row stripe-payment">
    <div class="col-xs-12">
        <p class="alert alert-danger">{l s='SSL is off, please activate it.' mod='dropshipsystem'}</p>
    </div>
</div>
{/if}