<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class payment_molpay extends DssPaymentClass
{
    public $gateway_version = '1.0';
    public $gateway_active = false;
    public $gateway_name;
    public $tplfile;
    public $tpldata;
    public $has_css = 'MOLPay/molpay.css';
    public $has_js = array('MOLPay/molpay.js');
    public $register_js;

	private $molpay_channels = array(
        'credit'            => array('name' => "Credit Card / Debit Card", 'logo' => "http://molpay.com/v3/images/molpay/channel/credit.png", 'currency' => array("MYR")),
        'maybank2u'         => array('name' => "Maybank (Maybank2u)", 'logo' => "http://molpay.com/v3/images/molpay/channel/maybank2u.png", 'currency' => array("MYR")),
        'cimbclicks'        => array('name' => "CIMB Bank (CIMB Clicks)", 'logo' => "http://molpay.com/v3/images/molpay/channel/cimb.png", 'currency' => array("MYR")),
        'affinonline'       => array('name' => "Affin Bank (Affin Online)", 'logo' => "http://molpay.com/v3/images/molpay/channel/affin-epg.png", 'currency' => array("MYR")),
        'amb'               => array('name' => "Am Bank (Am Online)", 'logo' => "http://molpay.com/v3/images/molpay/channel/amb.png", 'currency' => array("MYR")),
        'fpx'               => array('name' => "MyClear FPX (Maybank2u, CIMB Clicks, HLB Connect, RHB Now, PBB Online, Bank Islam, etc)", 'logo' => "http://molpay.com/v3/images/molpay/channel/fpx.png", 'currency' => array("MYR")),
        'fpx_amb'           => array('name' => "FPX Am Bank (Am Online)", 'logo' => "http://molpay.com/v3/images/molpay/channel/amb.png", 'currency' => array("MYR")),
        'fpx_bimb'          => array('name' => "FPX Bank Islam", 'logo' => "http://molpay.com/v3/images/molpay/channel/bankislam.png", 'currency' => array("MYR")),
        'fpx_cimbclicks'    => array('name' => "FPX CIMB Bank (CIMB Clicks)", 'logo' => "http://molpay.com/v3/images/molpay/channel/cimb.png", 'currency' => array("MYR")),
        'fpx_hlb'           => array('name' => "FPX Hong Leong Bank (HLB Connect)", 'logo' => "http://molpay.com/v3/images/molpay/channel/hlb.png", 'currency' => array("MYR")),
        'fpx_mb2u'          => array('name' => "FPX Maybank (Maybank2u)", 'logo' => "http://molpay.com/v3/images/molpay/channel/maybank2u.png", 'currency' => array("MYR")),
        'fpx_pbb'           => array('name' => "FPX PublicBank (PBB Online)", 'logo' => "http://molpay.com/v3/images/molpay/channel/publicbank.png", 'currency' => array("MYR")),
        'fpx_rhb'           => array('name' => "FPX RHB Bank (RHB Now)", 'logo' => "http://molpay.com/v3/images/molpay/channel/rhb.png", 'currency' => array("MYR")),
        'hlb'               => array('name' => "Hong Leong Bank (HLB Connect)", 'logo' => "http://molpay.com/v3/images/molpay/channel/hlb.png", 'currency' => array("MYR")),
        'pbb'               => array('name' => "PublicBank (PBB Online)", 'logo' => "http://molpay.com/v3/images/molpay/channel/publicbank.png", 'currency' => array("MYR")),
        'rhb'               => array('name' => "RHB Bank (RHB Now)", 'logo' => "http://molpay.com/v3/images/molpay/channel/rhb.png", 'currency' => array("MYR")),
        'cash-711'          => array('name' => "7-Eleven (MOLPay Cash)", 'logo' => "http://molpay.com/v3/images/molpay/channel/cash.png", 'currency' => array("MYR")),
        'ATMVA'             => array('name' => "ATM Transfer via Permata Bank", 'logo' => "http://molpay.com/v3/images/molpay/channel/Cash-PermataBank.png", 'currency' => array("IDR")),
        'dragonpay'         => array('name' => "Dragonpay", 'logo' => "http://molpay.com/v3/images/molpay/channel/dragonpay.png", 'currency' => array("PHP")),
        'paysbuy'           => array('name' => "PaysBuy", 'logo' => "http://molpay.com/v3/images/molpay/channel/paysbuy.png", 'currency' => array("THB","AUD","GBP","EUR","HKD","JPY","NZD","SGD","CHF","USD")),
        'Point-BCard'       => array('name' => "Bcard points", 'logo' => "http://molpay.com/v3/images/molpay/channel/pointbcard.png", 'currency' => array("MYR")),
        'NGANLUONG'         => array('name' => "NGANLUONG", 'logo' => "http://molpay.com/v3/images/molpay/channel/nganluong.png", 'currency' => array("VND","USD")),
        'enetsD'            => array('name' => "eNETS", 'logo' => "http://molpay.com/v3/images/molpay/channel/enetsD.png", 'currency' => array("SGD")),
        'UPOP'              => array('name' => "China Union pay", 'logo' => "http://molpay.com/v3/images/molpay/channel/Unionpay.png", 'currency' => array("MYR","USD","CNY")),
        'alipay'            => array('name' => "Alipay", 'logo' => "http://molpay.com/v3/images/molpay/channel/alipay.png", 'currency' => array("MYR","USD","CNY")),
        'paypal'            => array('name' => "PayPal", 'logo' => "http://molpay.com/v3/images/molpay/channel/paypal.png", 'currency' => array("USD","AUD","GBP","CAD","CZK","DKK","EUR","HKD","HUF","ILS","JPY","MYR","MXN","NZD","NOK","PHP","PLN","SGD","SEK","CHF","TWD","THB")),
        'cash-epay'         => array('name' => "e-Pay", 'logo' => "http://molpay.com/v3/images/molpay/channel/epay.png", 'currency' => array("MYR")),
        'molwallet'         => array('name' => "MOLWallet", 'logo' => "http://molpay.com/v3/images/molpay/channel/MOLWallet.png", 'currency' => array("MYR")),
        'PEXPLUS'           => array('name' => "PEx+", 'logo' => "http://molpay.com/v3/images/molpay/channel/pexplus.png", 'currency' => array("MYR")),
        'jompay'            => array('name' => "JOMPay", 'logo' => "http://molpay.com/v3/images/molpay/channel/jompay.png", 'currency' => array("MYR")),
        'Cash-Esapay'       => array('name' => "Cash Esapay", 'logo' => "http://molpay.com/v3/images/molpay/channel/esapay.png", 'currency' => array("MYR"))
    );

    public function __construct($pagedata = false)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $this->gateway_name = $this->l('MOLPay', 'payment_molpay');
        $this->gateway_active = (int)Configuration::get('DSS_MOLPAY_ACTIVE', null, null, $id_shop);
        if ((int)Configuration::get('DSS_MOLPAY_TEST', null, null, $id_shop)) {
            $this->register_js = array(
                array(
                    'name' => 'molpay_seamless',
                    'url' => 'https://sandbox.molpay.com/MOLPay/API/seamless/latest/js/MOLPay_seamless.deco.js',
                    'array' => array('server' => 'remote'),
                ),
            );
        } else {
            $this->register_js = array(
                array(
                    'name' => 'molpay_seamless',
                    'url' => 'https://www.onlinepayment.com.my/MOLPay/API/seamless/latest/js/MOLPay_seamless.deco.js',
                    'array' => array('server' => 'remote'),
                ),
            );
        }

        $default_currency = (string)Tools::strtoupper($this->context->currency->iso_code);

        $channels = array();
		foreach ($this->molpay_channels as $key => $value) {
			if (in_array($key, explode(',', Configuration::get('DSS_MOLPAY_CHANNELS', null, null, $id_shop))) &&
                in_array($default_currency, $value['currency'])) {
				$channels[$key] = $value;
            }
		}

        $this->tplfile = 'module:dropshipsystem/libs/MOLPay/payment.tpl';
        $this->tpldata = array(
            'payment_url' => (string)$this->context->link->getBaseLink($this->context->shop->id, true).'modules/dropshipsystem/libs/MOLPay/payment.php',
            'channels' => $channels,
        );

        parent::__construct();
    }

    public function getFieldsKeys()
    {
        return array(
            'DSS_MOLPAY_ACTIVE',
            'DSS_MOLPAY_TEST',
            'DSS_MOLPAY_MERCHANT_ID',
            'DSS_MOLPAY_MERCHANT_VKEY',
            'DSS_MOLPAY_MERCHANT_SKEY',
            'DSS_MOLPAY_CHANNELS'
        );
    }

    public function getFieldsForm()
    {
        $tab_name = (string)get_class($this);

        $channels = array();
        foreach ($this->molpay_channels as $key => $channel) {
            $channels[] = array('id' => $key, 'name' => $channel['name']);
        }

        return array(
            'DSS_MOLPAY_ACTIVE' => array(
                'type' => 'bool',
                'title' => $this->l('Active', 'payment_molpay'),
                'name' => 'DSS_MOLPAY_ACTIVE',
                'tab' => $tab_name,
            ),
            'DSS_MOLPAY_TEST' => array(
                'type' => 'bool',
                'title' => $this->l('Test mode', 'payment_molpay'),
                'name' => 'DSS_MOLPAY_TEST',
                'tab' => $tab_name,
            ),
            'DSS_MOLPAY_MERCHANT_ID' => array(
                'type' => 'text',
                'title' => $this->l('Merchant ID', 'payment_molpay'),
                'name' => 'DSS_MOLPAY_MERCHANT_ID',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_MOLPAY_MERCHANT_VKEY' => array(
                'type' => 'password',
                'title' => $this->l('Merchant Verify KEY', 'payment_molpay'),
                'name' => 'DSS_MOLPAY_MERCHANT_VKEY',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_MOLPAY_MERCHANT_SKEY' => array(
                'type' => 'password',
                'title' => $this->l('Merchant Secret KEY', 'payment_molpay'),
                'name' => 'DSS_MOLPAY_MERCHANT_SKEY',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_MOLPAY_CHANNELS' => array(
                'type' => 'checklist',
                'title' => $this->l('Channels', 'payment_molpay'),
                'name' => 'DSS_MOLPAY_CHANNELS',
                'tab' => $tab_name,
                'choices' => $channels,
                'auto_value' => false
            ),
        );
    }

    public function getFieldsValues()
    {
        $id_shop = (int)$this->context->shop->id;

        return array(
            'DSS_MOLPAY_ACTIVE' => Tools::getValue('DSS_MOLPAY_ACTIVE', Configuration::get('DSS_MOLPAY_ACTIVE', null, null, $id_shop)),
            'DSS_MOLPAY_TEST' => Tools::getValue('DSS_MOLPAY_TEST', Configuration::get('DSS_MOLPAY_TEST', null, null, $id_shop)),
            'DSS_MOLPAY_MERCHANT_ID' => Tools::getValue('DSS_MOLPAY_MERCHANT_ID', Configuration::get('DSS_MOLPAY_MERCHANT_ID', null, null, $id_shop)),
            'DSS_MOLPAY_MERCHANT_VKEY' => Tools::getValue('DSS_MOLPAY_MERCHANT_VKEY', Configuration::get('DSS_MOLPAY_MERCHANT_VKEY', null, null, $id_shop)),
            'DSS_MOLPAY_MERCHANT_SKEY' => Tools::getValue('DSS_MOLPAY_MERCHANT_SKEY', Configuration::get('DSS_MOLPAY_MERCHANT_SKEY', null, null, $id_shop)),
            'DSS_MOLPAY_CHANNELS' => Tools::getValue('DSS_MOLPAY_CHANNELS', explode(',', Configuration::get('DSS_MOLPAY_CHANNELS', null, null, $id_shop))),
        );
    }

    public function getAuth()
    {
        return true;

//        $id_shop = (int)$this->context->shop->id;
//
//        $post = array(
//            'molpay_merchantid' => Configuration::get('DSS_MOLPAY_MERCHANT_ID', null, null, $id_shop),
//            'molpay_verifykey' => Configuration::get('DSS_MOLPAY_MERCHANT_VKEY', null, null, $id_shop),
//            'molpay_ptype' => "Dropship - MOLPay Gateway",
//            'molpay_pversion' => (string)$this->gateway_version,
//            'domain' => (string)$this->context->link->getBaseLink($this->context->shop->id, true),
//        );
//
//        if (Configuration::get('DSS_MOLPAY_TEST', null, null, $id_shop)) {
//            $url = "https://sandbox.molpay.com/MOLPay/API/shoppingcart/index.php";
//        } else {
//            $url = "https://www.onlinepayment.com.my/MOLPay/API/shoppingcart/index.php";
//        }
//
//        $ch = curl_init($url);
//        curl_setopt($ch, CURLOPT_URL, $url);
//        curl_setopt($ch, CURLOPT_POST, true);
//        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
//        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
//        curl_setopt($ch, CURLOPT_HEADER, true);
//        curl_setopt($ch, CURLOPT_VERBOSE, true);
//        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
//        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
//        curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1);
//
//        $response = curl_exec($ch);
//
//        curl_close($ch);
//        unset($post);
//
//        $response_data = explode("\r\n\r\n", "$response", 2);
//        $response_header = $response_data[0];
//        $response_body = $response_data[1];
//
//        $json = Tools::jsonDecode($response_body);
//
//        if (!$json->status || $json->status != "success") {
//            return false;
//        }
//        return true;
    }

    public function getPaymentPage($params)
    {
        $id_shop = (int)$this->context->shop->id;

        if ($this->getAuth()) {
            $paymentlink = (string)$this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount', array('action' => 'PaymentPage'), true);

            $token = new DssPaymentsTokenClass();
            $token->token = (string)$params['token'];
            $token->id_order = isset($params['id_order']) ? (int)$params['id_order'] : 0;
            $token->is_credit = (int)$params['is_credit'];
            $token->name = (string)$params['name'];
            $token->custom_reference = (string)$params['custom_reference'];
            $token->currency = (string)Tools::strtolower($this->context->currency->iso_code);
            $token->amount = (float)$params['total'];
            $token->return_url = isset($params['return_url']) ? (string)$params['return_url'].'&token='.(string)$params['token'] : null;
            $token->cancel_url = isset($params['cancel_url']) ? (string)$params['cancel_url'].'&token='.(string)$params['token'] : null;

            if (!$token->save()) {
                return array(
                    'success' => false,
                    'error' => 'TOKEN_ERROR'
                );
            }

            return array(
                'success' => true,
                'currency' => (string)Tools::strtoupper($this->context->currency->iso_code),
                'custom_reference' => (string)$params['custom_reference'],
                'paymentlink' => $paymentlink.'&payment_token='.(string)$params['token'],
                'token' => (string)$params['token']
            );
        } else {
            return array(
                'success' => false,
                'error' => 'NO_LOGGED'
            );
        }
    }

    public function processPayment($params)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $amount = (string)Tools::getValue('amount');             
        $id_order = (string)Tools::getValue('orderid');
        $id_tran = (string)Tools::getValue('tranID');
        $status = (string)Tools::getValue('status');
        $domain = (string)Tools::getValue('domain'); 
        $currency = (string)Tools::getValue('currency');
        $appcode = (string)Tools::getValue('appcode');
        $paydate = (string)Tools::getValue('paydate');
        $skey = (string)Tools::getValue('skey');

        $error_code = (string)Tools::getValue('error_code');
        $error_desc = (string)Tools::getValue('error_desc');

        $vkey = (string)Configuration::get('DSS_MOLPAY_MERCHANT_SKEY', null, null, $id_shop);

        $key0 = md5($id_tran.$id_order.$status.$domain.$amount.$currency);
        $key1 = md5($paydate.$domain.$key0.$appcode.$vkey);

        if ($status == '00') {
            if ($skey == $key1) {
                return array(
                    'success' => true,
                    'currency' => (string)Tools::strtolower($currency),
                    'amount' => (float)$amount,
                    'payment_date' => time(true),
                    'transaction_id' => (string)$id_tran,
                    'token' => (string)$params['token']
                );
            } else {
                return array(
                    'success' => false,
                    'error' => $this->module->l('Payment error. Validation key is invalid.', 'payment_molpay'),
                    'token' => (string)$params['token']
                );
            }
        } elseif ($status == '22') {
            //Pending - IPN
            return array(
                'success' => false,
                'error' => 'pending',
                'token' => (string)$params['token']
            );
        } else {
            return array(
                'success' => false,
                'error' => sprintf($this->module->l('Payment declined. %s: %s', 'payment_molpay'), $error_code, $error_desc),
                'token' => (string)$params['token']
            );
        }
    }
}
