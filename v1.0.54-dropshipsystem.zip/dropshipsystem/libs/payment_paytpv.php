<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class payment_paytpv extends DssPaymentClass
{
    public $gateway_version = '1.0';
    public $gateway_active = false;
    public $gateway_name;
    public $tplfile;
    public $tpldata;
    public $has_css = array('PayTPV/paytpv.css');
    public $has_js = array('PayTPV/paytpv.js');
    public $register_js = array(
        array(
            'name' => 'dropship-paytpv',
            'url' => 'https://api.paycomet.com/gateway/paycomet.jetiframe.js?lang=en',
            'array' => array('server' => 'remote'),
        ),
    );

    public function __construct($pagedata = false)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $this->gateway_name = $this->l('PayTPV', 'payment_paytpv');
        $this->gateway_active = (int)Configuration::get('DSS_PTPV_ACTIVE', null, null, $id_shop);
        if (version_compare(_PS_VERSION_, '1.7', '<')) {
            $this->tplfile = _PS_MODULE_DIR_.'dropshipsystem/libs/PayTPV/payment.tpl';
        } else {
            $this->tplfile = 'module:dropshipsystem/libs/PayTPV/payment.tpl';
        }

        $jetid = (string)Configuration::get('DSS_PTPV_JETID', null, null, $id_shop);

        $this->tpldata = array(
            'language_iso' => (string)$this->context->language->iso_code,
            'payment_url' => (string)$this->context->link->getBaseLink($this->context->shop->id, true).'modules/dropshipsystem/libs/PayTPV/payment.php',
            'jetid' => (string)$jetid
        );

        parent::__construct();
    }

    public function getFieldsKeys()
    {
        return array(
            'DSS_PTPV_ACTIVE',
            'DSS_PTPV_TEST',
            'DSS_PTPV_SECRET',
            'DSS_PTPV_CUSTOMER',
            'DSS_PTPV_TERMINAL',
            'DSS_PTPV_JETID'
        );
    }

    public function getFieldsForm()
    {
        $tab_name = (string)get_class($this);

        return array(
            'DSS_PTPV_INFO' => array(
                'type' => 'html',
                'tab' => $tab_name,
                'html_content' => "<div class='alert alert-info'>".
                    $this->l('Please configure the follow URL in configuration page of PayTPV Merchant portal.', 'payment_paytpv')."<br />
                    <span>".$this->l('Positive response', 'payment_paytpv').": ".(string)$this->context->link->getBaseLink($this->context->shop->id, true)."modules/dropshipsystem/libs/PayTPV/postback.php?result=ok</span><br />
                    <span>".$this->l('Negative response', 'payment_paytpv').": ".(string)$this->context->link->getBaseLink($this->context->shop->id, true)."modules/dropshipsystem/libs/PayTPV/postback.php?result=ko</span>
                </div>"
            ),
            'DSS_PTPV_ACTIVE' => array(
                'type' => 'bool',
                'title' => $this->l('Active', 'payment_paytpv'),
                'name' => 'DSS_PTPV_ACTIVE',
                'tab' => $tab_name,
            ),
//            'DSS_PTPV_TEST' => array(
//                'type' => 'bool',
//                'title' => $this->l('Test mode', 'payment_paytpv'),
//                'name' => 'DSS_PTPV_TEST',
//                'tab' => $tab_name,
//            ),
            'DSS_PTPV_TERMINAL' => array(
                'type' => 'text',
                'title' => $this->l('Terminal', 'payment_paytpv'),
                'name' => 'DSS_PTPV_TERMINAL',
                'class' => 'fixed-width-sm',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_PTPV_CUSTOMER' => array(
                'type' => 'text',
                'title' => $this->l('Customer', 'payment_paytpv'),
                'name' => 'DSS_PTPV_CUSTOMER',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_PTPV_SECRET' => array(
                'type' => 'password',
                'title' => $this->l('Secret', 'payment_paytpv'),
                'name' => 'DSS_PTPV_SECRET',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_PTPV_JETID' => array(
                'type' => 'password',
                'title' => $this->l('JET ID', 'payment_paytpv'),
                'name' => 'DSS_PTPV_JETID',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
        );
    }

    public function getFieldsValues()
    {
        $id_shop = (int)$this->context->shop->id;

        return array(
            'DSS_PTPV_ACTIVE' => Tools::getValue('DSS_PTPV_ACTIVE', Configuration::get('DSS_PTPV_ACTIVE', null, null, $id_shop)),
            'DSS_PTPV_TEST' => Tools::getValue('DSS_PTPV_TEST', Configuration::get('DSS_PTPV_TEST', null, null, $id_shop)),
            'DSS_PTPV_SECRET' => Tools::getValue('DSS_PTPV_SECRET', Configuration::get('DSS_PTPV_SECRET', null, null, $id_shop)),
            'DSS_PTPV_CUSTOMER' => Tools::getValue('DSS_PTPV_CUSTOMER', Configuration::get('DSS_PTPV_CUSTOMER', null, null, $id_shop)),
            'DSS_PTPV_TERMINAL' => Tools::getValue('DSS_PTPV_TERMINAL', Configuration::get('DSS_PTPV_TERMINAL', null, null, $id_shop)),
            'DSS_PTPV_JETID' => Tools::getValue('DSS_PTPV_JETID', Configuration::get('DSS_PTPV_JETID', null, null, $id_shop)),
        );
    }

    public function getAuth()
    {
        return true;
    }

    public function getPaymentPage($params)
    {
        $id_shop = (int)$this->context->shop->id;

        if ($this->getAuth()) {
            $paymentlink = (string)$this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount', array('action' => 'PaymentPage'), true);

            $token = new DssPaymentsTokenClass();
            $token->token = (string)$params['token'];
            $token->id_order = isset($params['id_order']) ? (int)$params['id_order'] : 0;
            $token->is_credit = (int)$params['is_credit'];
            $token->name = (string)$params['name'];
            $token->custom_reference = (string)$params['custom_reference'];
            $token->currency = (string)Tools::strtolower($this->context->currency->iso_code);
            $token->amount = (float)$params['total'];
            $token->return_url = isset($params['return_url']) ? (string)$params['return_url'].'&token='.(string)$params['token'] : null;
            $token->cancel_url = isset($params['cancel_url']) ? (string)$params['cancel_url'].'&token='.(string)$params['token'] : null;

            if (!$token->save()) {
                return array(
                    'success' => false,
                    'error' => 'TOKEN_ERROR'
                );
            }

            return array(
                'success' => true,
                'currency' => (string)Tools::strtoupper($this->context->currency->iso_code),
                'custom_reference' => (string)$params['custom_reference'],
                'paymentlink' => $paymentlink.'&payment_token='.(string)$params['token'],
                'token' => (string)$params['token']
            );
        } else {
            return array(
                'success' => false,
                'error' => 'NO_LOGGED'
            );
        }
    }

    public function processPayment($params)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $dss_payment_token = new DssPaymentsTokenClass((string)$params['token']);
        if (isset($dss_payment_token) && $dss_payment_token->id) {
            if ($dss_payment_token->status == 'valid') {
                $order = Tools::jsonDecode((string)$dss_payment_token->params);
                $ds_result = (string)$order->RESULT;
                $ds_response = (string)$order->DS_RESPONSE;

                if ($ds_result == 'OK' && $ds_response == '1') {
                    return array(
                        'success' => true,
                        'currency' => (string)$dss_payment_token->currency,
                        'amount' => (float)$dss_payment_token->amount,
                        'payment_date' => time(true),
                        'transaction_id' => null,
                        'token' => (string)$params['token']
                    );
                } else {
                    return array(
                        'success' => false,
                        'error' => $this->l('Payment error. Authorization declined.', 'payment_paytpv'),
                        'token' => (string)$params['token']
                    );
                }
            } else {
                return array(
                    'success' => false,
                    'error' => $this->l('Payment error. Invalid token status.', 'payment_paytpv'),
                    'token' => (string)$params['token']
                );
            }
        }
    }
}
