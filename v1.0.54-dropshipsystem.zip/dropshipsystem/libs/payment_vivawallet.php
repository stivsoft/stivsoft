<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class payment_vivawallet extends DssPaymentClass
{
    public $gateway_version = '1.0';
    public $gateway_active = false;
    public $gateway_name;
    public $tplfile;
    public $tpldata;
    public $has_css = false;
    public $has_js = array('VivaWallet/vivawallet.js');
    public $register_js = false;

    protected $client = false;

    public function __construct($pagedata = false)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $this->gateway_name = $this->l('VivaWallet', 'payment_vivawalet');
        $this->gateway_active = (int)Configuration::get('DSS_VIVAWALLET_ACTIVE', null, null, $id_shop);

        if ($pagedata) {
            if ((int)Configuration::get('DSS_VIVAWALLET_TEST', null, null, $id_shop)) {
                $url = 'https://demo.vivapayments.com/web/newtransaction.aspx';
            } else {
                $url = 'https://www.vivapayments.com/web/newtransaction.aspx';
            }

            $token = (string)Tools::getValue('payment_token');
            $payment_token = new DssPaymentsTokenClass((string)$token);
            $smarty = (array)Tools::jsonDecode((string)$payment_token->params);

            $this->tplfile = 'module:dropshipsystem/libs/VivaWallet/payment.tpl';
            $this->tpldata = array(
                'payment_url' => (string)$url,
                'data' => $smarty
            );
        }

        parent::__construct();
    }

    public function getFieldsKeys()
    {
        return array(
            'DSS_VIVAWALLET_ACTIVE',
            'DSS_VIVAWALLET_TEST',
            'DSS_VIVAWALLET_MERCHANTID',
            'DSS_VIVAWALLET_MERCHANTPASS',
            'DSS_VIVAWALLET_SOURCE',
        );
    }

    public function getFieldsForm()
    {
        $tab_name = (string)get_class($this);

        return array(
            'DSS_VIVAWALLET_INFO' => array(
                'type' => 'html',
                'tab' => $tab_name,
                'html_content' => "<div class='alert alert-info'>".
                    $this->l('Please register to VivaWallet and get the API keys.', 'payment_vivawalet')."<br />".
                    $this->l('Then set a new Site WEB/APP with this link in the success / failed string', 'payment_vivawalet').":<br />
                    <span>&lt;".$this->l('your domain', 'payment_vivawalet')."&gt;</span>&nbsp;<strong>modules/dropshipsystem/libs/VivaWallet/payment.php</strong><br />
                </div>"
            ),
            'DSS_VIVAWALLET_ACTIVE' => array(
                'type' => 'bool',
                'title' => $this->l('Active', 'payment_vivawalet'),
                'name' => 'DSS_VIVAWALLET_ACTIVE',
                'tab' => $tab_name,
            ),
            'DSS_VIVAWALLET_TEST' => array(
                'type' => 'bool',
                'title' => $this->l('Test mode', 'payment_vivawalet'),
                'name' => 'DSS_VIVAWALLET_TEST',
                'tab' => $tab_name,
            ),
            'DSS_VIVAWALLET_MERCHANTID' => array(
                'type' => 'text',
                'title' => $this->l('Merchant ID', 'payment_vivawalet'),
                'name' => 'DSS_VIVAWALLET_MERCHANTID',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_VIVAWALLET_MERCHANTPASS' => array(
                'type' => 'text',
                'title' => $this->l('API Key', 'payment_vivawalet'),
                'name' => 'DSS_VIVAWALLET_MERCHANTPASS',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
            'DSS_VIVAWALLET_SOURCE' => array(
                'type' => 'text',
                'title' => $this->l('Source code', 'payment_vivawalet'),
                'name' => 'DSS_VIVAWALLET_SOURCE',
                'class' => 'fixed-width-xxl',
                'autocomplete' => false,
                'tab' => $tab_name,
            ),
        );
    }

    public function getFieldsValues()
    {
        $id_shop = (int)$this->context->shop->id;

        return array(
            'DSS_VIVAWALLET_ACTIVE' => Tools::getValue('DSS_VIVAWALLET_ACTIVE', Configuration::get('DSS_VIVAWALLET_ACTIVE', null, null, $id_shop)),
            'DSS_VIVAWALLET_TEST' => Tools::getValue('DSS_VIVAWALLET_TEST', Configuration::get('DSS_VIVAWALLET_TEST', null, null, $id_shop)),
            'DSS_VIVAWALLET_MERCHANTID' => Tools::getValue('DSS_VIVAWALLET_MERCHANTID', Configuration::get('DSS_VIVAWALLET_MERCHANTID', null, null, $id_shop)),
            'DSS_VIVAWALLET_MERCHANTPASS' => Tools::getValue('DSS_VIVAWALLET_MERCHANTPASS', Configuration::get('DSS_VIVAWALLET_MERCHANTPASS', null, null, $id_shop)),
            'DSS_VIVAWALLET_SOURCE' => Tools::getValue('DSS_VIVAWALLET_SOURCE', Configuration::get('DSS_VIVAWALLET_SOURCE', null, null, $id_shop)),
        );
    }

    public function getAuth()
    {
        return true;
    }

    public function getPaymentPage($params)
    {
        $id_shop = (int)$this->context->shop->id;

        $currency = $this->context->currency;

        $token = new DssPaymentsTokenClass();
        $token->token = (string)$params['token'];
        $token->id_order = isset($params['id_order']) ? (int)$params['id_order'] : 0;
        $token->is_credit = (int)$params['is_credit'];
        $token->name = (string)$params['name'];
        $token->custom_reference = (string)$params['custom_reference'];
        $token->currency = (string)Tools::strtolower($currency->iso_code);
        $token->amount = (float)$params['total'];
        $token->return_url = isset($params['return_url']) ? (string)$params['return_url'].'&token='.(string)$params['token'] : null;
        $token->cancel_url = isset($params['cancel_url']) ? (string)$params['cancel_url'].'&token='.(string)$params['token'] : null;

        if (!$token->save()) {
            return array(
                'success' => false,
                'error' => 'TOKEN_ERROR'
            );
        }

        $id_dropshipper = DssDropshippersClass::getDrophipperIDByCustomerID($this->context->customer->id);
        $dropshipper = new DssDropshippersClass((int)$id_dropshipper);
        $customer = new Customer((int)$this->context->customer->id);
        $address = new Address((int)$dropshipper->id_address_invoice);
        $country = new Country((int)$address->id_country);

        $dest_currency = array();
        $dest_currency['iso_code'] = $currency->iso_code;
        $dest_currency['id'] = $currency->id;
        $currency_override = $currency->id;

        $currency_symbol ='';
        $language_code ='';
        $eb_total ='';
        $ebfullname ='';

        $currency_symbol ='';
        switch ($dest_currency['iso_code']) {
            case 'EUR':
                $currency_symbol = 978;
                break;
            case 'GBP':
                $currency_symbol = 826;
                break;
            case 'BGN':
                $currency_symbol = 975;
                break;
            case 'RON':
                $currency_symbol = 946;
                break;
            default:
                $currency_symbol = 978;
        }

        $amount = number_format((float)$params['total'], 2, '.', '');

		$wb_total = number_format($amount, 2, '.', '');		
		$wb_instal_total = round($amount);

		$wb_total_cents = number_format($amount, 2, '.', '') * 100;		
		$wb_total_cents = round($wb_total_cents);

        $merchantid = (string)trim(Configuration::get('DSS_VIVAWALLET_MERCHANTID', null, null, $id_shop));
        $password = (string)html_entity_decode(Configuration::get('DSS_VIVAWALLET_MERCHANTPASS', null, null, $id_shop));

        if ((int)Configuration::get('DSS_VIVAWALLET_TEST', null, null, $id_shop)) {
            $baseurl = 'https://demo.vivapayments.com';
        } else {
            $baseurl = 'https://www.vivapayments.com';
        }

        $maxperiod = '1';

        $args = array(
            'Amount' => $wb_total_cents,
            'RequestLang' => 'en-US',
            'Email' => $customer->email,
            'MerchantTrns' => (string)$params['custom_reference'],
            'SourceCode' => (string)Configuration::get('DSS_VIVAWALLET_SOURCE', null, null, $id_shop),
            'CurrencyCode' => $currency_symbol,
            'PaymentTimeOut' => '300',
            'Tags' => array((string)$params['token'])
        );

        $postargs = 'Amount='.urlencode($args['Amount']).'&RequestLang='.urlencode($args['RequestLang']).'&Email='.urlencode($args['Email']).'&MaxInstallments='.urlencode($maxperiod).'&MerchantTrns='.urlencode($args['MerchantTrns']).'&SourceCode='.urlencode($args['SourceCode']).'&CurrencyCode='.urlencode($args['CurrencyCode']).'&PaymentTimeOut='.(int)$args['PaymentTimeOut'].'&Tags='.urlencode(implode(',', $args['Tags'])).'&DisableIVR=true';

        $curl = curl_init($baseurl."/api/orders");
        curl_setopt($curl, CURLOPT_PORT, 443);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postargs);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_USERPWD, $merchantid.':'.$password); 
        $curlversion = curl_version();
        if (!preg_match("/NSS/" , $curlversion['ssl_version'])){
            curl_setopt($curl, CURLOPT_SSL_CIPHER_LIST, "TLSv1");
        }
	
        // execute curl
        $response = curl_exec($curl);

        if (curl_error($curl)) {
            curl_setopt($curl, CURLOPT_PORT, 443);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $postargs);
            curl_setopt($curl, CURLOPT_HEADER, false);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_USERPWD, $merchantid.':'.$password);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($curl);
        }

        curl_close($curl);

        $result_obj = Tools::jsonDecode($response);

		if ($result_obj->ErrorCode == 0) {
            $order_code = $result_obj->OrderCode;
            $error_code = $result_obj->ErrorCode;
            $error_text = $result_obj->ErrorText;
		} else {
            return array(
                'success' => false,
                'error' => $this->l('Unable to create payment order', 'payment_vivawalet'),
            );
		}

		$data = array(
		  'Ref' => $order_code
        );

        $smarty = array();
        foreach ($data as $key => $value) {
            $smarty[$key] = $value;
        }
        $token->params = Tools::jsonEncode($smarty);

        if (!$token->save()) {
            return array(
                'success' => false,
                'error' => 'TOKEN_ERROR'
            );
        }

        $paymentlink = (string)$this->context->link->getModuleLink('dropshipsystem', 'mydropshipaccount', array('action' => 'PaymentPage'), true);

        return array(
            'success' => true,
            'currency' => (string)Tools::strtoupper($this->context->currency->iso_code),
            'custom_reference' => (string)$params['custom_reference'],
            'paymentlink' => $paymentlink.'&payment_token='.(string)$params['token'],
            'token' => (string)$params['token']
        );
    }

    public function processPayment($params)
    {
        if (!isset($this->context)) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;

        $dss_payment_token = new DssPaymentsTokenClass((string)$params['token']);
        if (isset($dss_payment_token) && $dss_payment_token->id) {
            if ($dss_payment_token->status == 'cbok') {
                $order = Tools::jsonDecode((string)$dss_payment_token->params);

                if (isset($order->StatusId) && $order->StatusId == 'F') {
                    return array(
                        'success' => true,
                        'currency' => (string)$dss_payment_token->currency,
                        'amount' => (float)$dss_payment_token->amount,
                        'payment_date' => time(true),
                        'transaction_id' => null,
                        'token' => (string)$params['token']
                    );
                } else {
                    return array(
                        'success' => false,
                        'error' => $this->l('Payment error. Authorization declined.', 'payment_vivawalet'),
                        'token' => (string)$params['token']
                    );
                }
            } else {
                return array(
                    'success' => false,
                    'error' => $this->l('Payment error. Invalid token status.', 'payment_vivawalet'),
                    'token' => (string)$params['token']
                );
            }
        }
    }
}
