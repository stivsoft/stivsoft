/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$(document).ready(function() {
    var self = this;

    this.toggleSpecificWholesalePrice = function () {
        $('body').on('click', '#show_specific_wholesale_price', function() {
            $('#add_specific_wholesale_price').slideToggle();

            $('#add_specific_wholesale_price').append('<input type="hidden" name="submitPriceWholesaleAddition"/>');

            $('#hide_specific_wholesale_price').show();
            $('#show_specific_wholesale_price').hide();
            return false;
        });

        $('body').on('click', '#hide_specific_wholesale_price', function() {
            $('#add_specific_wholesale_price').slideToggle();
            $('#add_specific_wholesale_price').find('input[name=submitPriceWholesaleAddition]').remove();
            $('#hide_specific_wholesale_price').hide();
            $('#show_specific_wholesale_price').show();
            return false;
        });
    }

	this.bindDeleteSpecificWholesalePrice = function() {
		$('body').on('click', '#specific_wholesale_prices_list a[name="delete_link"]', function(e) {
			e.preventDefault();
			if (confirm(delete_wholesale_price_rule)) {
                self.deleteSpecificWholesalePrice(this.href, $(this).parents('tr'));
            }
		})
	};

	this.loadInformations = function(select_id, action) {
		id_shop = $('#swp_id_shop').val();
		$.ajax({
			url: product_url + '&action='+action+'&ajax=true&id_shop='+id_shop,
			success: function(data) {
				$(select_id + ' option').not(':first').remove();
				$(select_id).append(data);
			}
		});
	}
    
    this.deleteSpecificWholesalePrice = function (url, parent) {
        if (typeof url !== 'undefined') {
            $.ajax({
                url: url,
                data: {
                    ajax: true
                },
                dataType: 'json',
                context: this,
                success: function(data) {
                    if (data !== null) {
                        if (data.status == 'ok') {
                            showSuccessMessage(data.message);
                            parent.remove();
                        } else {
                            showErrorMessage(data.message);
                        }
                    }
                }
            });
        }
    };
    
    self.toggleSpecificWholesalePrice();
    self.deleteSpecificWholesalePrice();
    self.bindDeleteSpecificWholesalePrice();

    $('#swp_id_shop').change(function() {
        self.loadInformations('#swp_id_group','getGroupsOptions');
        //self.loadInformations('#spm_currency_0', 'getCurrenciesOptions');
        self.loadInformations('#swp_id_country', 'getCountriesOptions');
    });
    //if (display_multishop_checkboxes) {
    //    ProductMultishop.checkAllPrices();
    //}
});
