/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$(document).ready(function() {
    $('#dropshippers_notif').appendTo('#header_notifs_icon_wrapper');
    $('#dropshippers_notif').show();

    $('body').on('click', '.dss-notifs', function(){
        var wrapper_id = $(this).parent().attr("id");

        if (typeof dss_notif_url !== 'undefined') {
            $.post(
                dss_notif_url + '?rand=' + new Date().getTime(),
                {
                    ajax: true,
                    token: dss_notif_token,
                    action: 'setNotifications',
                    //element_employee_type: $(this).parent().attr('data-type')
                },
                function(data) {
                    if (data) {
                        $("#" + wrapper_id + "_value").html(0);
                        $("#" + wrapper_id + "_number_wrapper").hide();
                    }				
                }
            );
        }
    });

    getDSSPush(1);
});

function getDSSPush(time)
{
    if (typeof dss_notif_url !== 'undefined') {
        $.ajax({
            type: 'POST',
            url: dss_notif_url + '?rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: dss_notif_token,
                action: 'getNotifications',
            },
            traditional: true,
            success: function(json) {
                if (json) {
                    // Add dropshippers notifications to the list
                    html = "";
                    $.each(json.results, function(property, value) {
                        html += "<a href='index.php?tab=AdminDropShip&token={getAdminToken tab='AdminDropShip'}&updatedss_dropshipper&id_dss_dropshipper=" + parseInt(value.id_dss_dropshipper) + "'>";
                        html += "<p><strong>" + value.dropshipper_name + "</strong></p>";
                        html += "<small class='text-muted'><i class='icon-time'></i> " +  moment(value.add_date).fromNow() + " </small>";
                        html += "</a>";
                    });
                    if (parseInt(json.total) > 0) {
                        $("#list_dropshippers_notif").empty().append(html);
                        $("#dropshippers_notif_value").text(json.total);
                        $("#dropshippers_notif_number_wrapper").removeClass('hide');
                    } else {
                        $("#dropshippers_notif_number_wrapper").addClass('hide');
                    }
                }
                if (time) {
                    setTimeout("getDSSPush(1)", 120000);
                }
            },
            //error: function(XMLHttpRequest, textStatus, errorThrown) {
            //    showErrorMessage(errorThrown);
            //}
        });
    }
}
