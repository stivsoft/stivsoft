/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$(document).ready(function() {
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        localStorage.setItem('lastTab', $(this).attr('href'));
    });

    var lastTab = localStorage.getItem('lastTab');
    if (lastTab) {
        $('[href="' + lastTab + '"]').tab('show');
    }

    var $table = $('table.dss'),
        $bodyCells = $table.find('tbody tr:first').children(),
        colWidth;

	$('body').on('click', '.dss .nav li a', function(e) {
		SetCellSize();
	});

    $(window).on('resize', function() {
  		SetCellSize();
    }).resize();

	function SetCellSize() {
		setTimeout(function() {
			// Get the tbody columns width array
			colWidth = $bodyCells.map(function() {
				return $(this).width();
			}).get();
			// Set the width of thead columns
			$table.find('thead tr').children().each(function(i, v) {
				$(v).width(colWidth[i]);
			});
		}, 250);
	}

	$('.title_box span').each(function(e) {
        var len = $(this).text().trim().length;
        if (len > 20) {
            $(this).text($(this).text().substr(0, 20) + '...');
        }
    });

    $('body').on('click', '.dss button.list-action-enable-all, .dss a.list-action-enable', function(e) {
        e.preventDefault();

        var obj = $(this);
        var type = obj.data('type');
        var action;

        if (type == 'manufacturer') {
            action = 'SetManufacturerGroup';
        } else if (type == 'supplier') {
            action = 'SetSupplierGroup';
        }

        $.ajax({
            type: 'POST',
            url: dss_ajaxurl + '&rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: false,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: dss_token,
                action: action,
                id: obj.data('id'),
                id_group: obj.data('group'),
            },
            traditional: true,
            success: function(data) {
                if (data.success) {
					if (data.single) {
						if (data.enabled) {
							obj.removeClass('action-disabled').addClass('action-enabled');
							obj.find('.icon-check').removeClass('hidden');
							obj.find('.icon-remove').addClass('hidden');
						} else {
							obj.removeClass('action-enabled').addClass('action-disabled');
							obj.find('.icon-check').addClass('hidden');
							obj.find('.icon-remove').removeClass('hidden');
						}
					} else {
                        if ($('.dss td.items a').length > 0) {
                            $.each($('.dss td.items a'), function(index, item) {
                                if ($(item).data('type') == type && $(item).data('group') == obj.data('group')) {
                                    if (data.enabled) {
                                        $(item).removeClass('action-disabled').addClass('action-enabled');
                                        $(item).find('.icon-check').removeClass('hidden');
                                        $(item).find('.icon-remove').addClass('hidden');
                                    } else {
                                        $(item).removeClass('action-enabled').addClass('action-disabled');
                                        $(item).find('.icon-check').addClass('hidden');
                                        $(item).find('.icon-remove').removeClass('hidden');
                                    }
                                }
                            });
                        }
					}
                    showSuccessMessage(data.text);
                } else {
                    showErrorMessage(data.text);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                showErrorMessage(textStatus + ': ' + errorThrown);
            }
        });
    });

    $('select[name=DSS_GROUP]').on('change', function(e) {
        var id_group = $(this).val();
        var panel = $('ul#categories_treeview').parent().parent();

        $.ajax({
            type: 'POST',
            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: dss_token,
                action: 'render_categories',
                id_group: id_group,
            },
            traditional: true,
            beforeSend: function() {
                panel.append('<div class="loading-overlay"></div>');
            },
            success: function(data) {
                if (data.success) {
                    panel.html(data.html);
                } else {
                    showErrorMessage(data.text);
                }
                $('.dss .loading-overlay').remove();
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                showErrorMessage(textStatus + ': ' + errorThrown);
            }
        });
    });

    $(document).on('click', 'a#check-all-categories_treeview', function (e) {
        var id_group = $('select[name=DSS_GROUP]').val();
        var id_categories = $('input[type="checkbox"][name="DSS_CATEGORY_GROUP\\[\\]"]:checked').map(function() {
            return this.value;
        }).get();

        SetCategoriesGroup(null, id_group, id_categories, 'true');
    });

    $(document).on('click', 'a#uncheck-all-categories_treeview', function (e) {
        var id_group = $('select[name=DSS_GROUP]').val();
        var id_categories = $('input[type="checkbox"][name="DSS_CATEGORY_GROUP\\[\\]"]:not(:checked)').map(function() {
            return this.value;
        }).get();

        SetCategoriesGroup(null, id_group, id_categories, 'false');
    });

    $(document).on('click', '#categories_treeview input[type=checkbox]', function (e) {
        var chkobj = $(this);
        var id_group = $('select[name=DSS_GROUP]').val();
        var id_category = chkobj.val();
        var is_checked = chkobj.is(':checked');

        SetCategoriesGroup(chkobj, id_group, id_category, is_checked);
    });

    function SetCategoriesGroup(chkobj = null, id_group, id_categories, is_checked)
    {
        $.ajax({
            type: 'POST',
            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: dss_token,
                action: 'set_category_group',
                id_group: id_group,
                id_categories: encodeURIComponent(id_categories),
                is_checked: is_checked
            },
            traditional: true,
            success: function(data) {
                if (data.success) {
                    showSuccessMessage(data.text);
                } else {
                    if (chkobj != null) {
                        chkobj.prop('checked', false);
                    }
                    showErrorMessage(data.text);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                if (chkobj != null) {
                    chkobj.prop('checked', false);
                }
                showErrorMessage(textStatus + ': ' + errorThrown);
            }
        });
    }

    $('body').on('click', '#generateuniquecodes', function(e) {
        e.preventDefault();

        $.confirm({
            title: $(this).data('title'),
            content: '<h3>' + $(this).data('text') + '</h3>',
            columnClass: 'col-xs-12 col-sm-offset-3 col-sm-6',
            onOpenBefore: function() {
                $('.jconfirm').addClass('bootstrap');
            },
            buttons: {
                cancel: {
                    text: $(this).data('cancel-button'),
                    btnClass: 'btn-default',
                    action: function() {}
                },
                confirm_no_overwrite: {
                    text: $(this).data('confirm-button'),
                    btnClass: 'btn-warning',
                    action: function() {
                        $.ajax({
                            type: 'POST',
                            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
                            headers: { "cache-control": "no-cache" },
                            async: true,
                            cache: false,
                            dataType: 'json',
                            data: {
                                ajax: true,
                                token: dss_token,
                                action: 'GenerateUniqueCodes',
                                overwrite: 1
                            },
                            traditional: true,
                            success: function(data) {
                                if (data.success) {
                                    showSuccessMessage(data.text);
                                } else {
                                    showErrorMessage(data.text);
                                }
                            },
                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                showErrorMessage(textStatus + ': ' + errorThrown);
                            }
                        });
                    }
                },
                confirm_overwrite: {
                    text: $(this).data('confirm-button-overwrite'),
                    btnClass: 'btn-danger',
                    action: function() {
                        $.ajax({
                            type: 'POST',
                            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
                            headers: { "cache-control": "no-cache" },
                            async: true,
                            cache: false,
                            dataType: 'json',
                            data: {
                                ajax: true,
                                token: dss_token,
                                action: 'GenerateUniqueCodes',
                                overwrite: 2
                            },
                            traditional: true,
                            success: function(data) {
                                if (data.success) {
                                    showSuccessMessage(data.text);
                                } else {
                                    showErrorMessage(data.text);
                                }
                            },
                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                showErrorMessage(textStatus + ': ' + errorThrown);
                            }
                        });
                    }
                },
            }
        });
    });

    $('body').on('click', '.remove_plugin', function(e) {
        e.preventDefault();

        var plugin = $(this).data('plugin');

        $.confirm({
            title: false,
            content: '<h4>' + dss_l['do_you_want_remove'] + '</h4>',
            onOpenBefore: function() {
                $('.jconfirm').addClass('bootstrap');
            },
            buttons: {
                cancel: {
                    text: dss_l['cancel'],
                    btnClass: 'btn-default',
                    action: function() {}
                },
                remove: {
                    text: dss_l['remove'],
                    btnClass: 'btn-danger',
                    action: function() {
                        $.ajax({
                            type: 'POST',
                            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
                            headers: { "cache-control": "no-cache" },
                            async: true,
                            cache: false,
                            dataType: 'json',
                            data: {
                                ajax: true,
                                token: dss_token,
                                action: 'RemovePlugin',
                                plugin: plugin,
                            },
                            traditional: true,
                            success: function(data) {
                                if (data.success) {
                                    showSuccessMessage(data.text);
                                    window.location.href = data.redirect;
                                } else {
                                    showErrorMessage(data.text);
                                }
                            },
                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                showErrorMessage(textStatus + ': ' + errorThrown);
                            }
                        });
                    }
                },
            }
        });
    });
});
