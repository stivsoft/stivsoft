/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$(document).ready(function() {

    $('body').on('click', '#generatesecret', function(e) {
        e.preventDefault();

        $.confirm({
            title: $(this).data('title'),
            content: '<h4>' + $(this).data('text') + '</h4>',
            onOpenBefore: function() {
                $('.jconfirm').addClass('bootstrap');
            },
            buttons: {
                cancel: {
                    text: $(this).data('cancel-button'),
                    btnClass: 'btn-default',
                    action: function() {}
                },
                confirm: {
                    text: $(this).data('confirm-button'),
                    btnClass: 'btn-primary',
                    action: function() {
                        var secret = "";
                        var possible = "abcdefghijklmnopqrstuvwxyz0123456789";
                        for( var i=0; i < 32; i++ ) {
                            secret += possible.charAt(Math.floor(Math.random() * possible.length));
                        }
                        $('#secret').val(secret);
                        return true;
                    }
                },
            }
        });
    });

    if ($('button[id=gotocustomer]').length > 0) {
        $('button[id=gotocustomer]').on('click', function(e) {
            e.preventDefault();
            var id_customer = $('select[id=id_customer] option:selected').val();

            $.ajax({
                type: 'POST',
                url: dss_ajaxurl + '&rand=' + new Date().getTime(),
                headers: { "cache-control": "no-cache" },
                cache: false,
                dataType: 'json',
                data: {
                    ajax: true,
                    token: dss_token,
                    action: 'GetCustomerLink',
                    id_customer: id_customer,
                },
                traditional: true,
                success: function(data) {
                    window.location = data.href;
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    showErrorMessage(textStatus + ': ' + errorThrown);
                }
            });
        });
    }

    if ($('select[name=feed_type]').length > 0) {
        changeFeedType($('select[name=feed_type] option:selected').val());
        $('select[name=feed_type]').on('change', function() {
            changeFeedType($('select[name=feed_type] option:selected').val());
        });
    }
    
    function changeFeedType(val) {
        if (val == 0) {
            $('input:radio[name=simple_feed]').attr('disabled', false);
            $('select[name=payment_type]').attr('disabled', false);
            $('select[name=payment_method]').attr('disabled', false);
        } else if (val == 1) {
            $('input:radio[name=simple_feed]').attr('disabled', true);
            $('input:radio[name=simple_feed]:nth(1)').attr('checked', true);
            $('select[name=payment_type]').attr('disabled', true);
            $('select[name=payment_type]').val('none');
            $('select[name=payment_method]').attr('disabled', true);
            $('select[name=payment_method]').val('');
        }
    }
});
