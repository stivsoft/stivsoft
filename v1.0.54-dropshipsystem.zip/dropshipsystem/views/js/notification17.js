/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$(document).ready(function() {
    $('body').on('click', '#dropshippers_notif > .dss_notification', function() {
        $(this).parent().toggleClass('open');
        var wrapper_id = $(this).parent().attr("id");

        if (typeof dss_notif_url !== 'undefined') {
            $.post(
                dss_notif_url + '?rand=' + new Date().getTime(), {
                    ajax: true,
                    token: dss_notif_token,
                    action: 'setNotifications',
                },
                function(data) {
                    if (data) {
                        $("#" + wrapper_id + "_value").html(0);
                        $("#" + wrapper_id + "_number_wrapper").addClass('hidden');
                    }				
                }
            );
        }
    });

    $('body').on('click', function (e) {
        if (!$('#dropshippers_notif.dropdown').is(e.target)
            && $('#dropshippers_notif.dropdown').has(e.target).length === 0
            && $('.open').has(e.target).length === 0
        ) {
            if ($('#dropshippers_notif.dropdown').hasClass('open')) {
                getDSSPush(1);
            }
            $('#dropshippers_notif.dropdown').removeClass('open');
        }
    });

    getDSSPush(1);
});

function getDSSPush(time)
{
    if (typeof dss_notif_url !== 'undefined') {
        $.ajax({
            type: 'POST',
            headers: { "cache-control": "no-cache" },
            url: dss_notif_url + '?rand=' + new Date().getTime(),
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: dss_notif_token,
                action: 'getNotifications',
            },
            success: function(json) {
                if (json) {
                    moment.lang(full_language_code);

                    // Add dropshippers notifications to the list
                    html = "";
                    $.each(json.results, function(property, value) {
                        html += "<a class='notif' href='" + baseAdminDir + "index.php?tab=AdminDropShip&token={getAdminToken tab='AdminDropShip'}&updatedss_dropshipper&id_dss_dropshipper=" + parseInt(value.id_dss_dropshipper) + "'>";
                        html += "<p><strong>" + value.dropshipper_name + "</strong></p>";
                        html += "<small class='text-muted'><i class='icon-time'></i> " + moment(value.add_date).fromNow() + " </small>";
                        html += "</a>";
                    });
                    if (parseInt(json.total) > 0) {
                        $("#list_dropshippers_notif").empty().append(html);
                        $("#dropshippers_notif_value").text(json.total);
                        $("#dropshippers_notif_number_wrapper").removeClass('hidden');
                    } else {
                        $("#dropshippers_notif_number_wrapper").addClass('hidden');
                    }
                }
                if (time) {
                    setTimeout("getDSSPush(1)", 120000);
                }
            },
            //error: function(XMLHttpRequest, textStatus, errorThrown) {
            //    showErrorMessage(errorThrown);
            //}
        });
    }
}
