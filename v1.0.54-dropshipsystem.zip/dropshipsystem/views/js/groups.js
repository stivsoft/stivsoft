/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$(document).ready(function() {
    var obj;

    makeModal();

    $('.ajax_dss_supplier_link > a').on('click', function(e) {
        e.preventDefault();
        obj = $(this);
        obj.parent().prop('onclick', null).off('click');
        $.post($(this).attr('href') + '&ajax=1&action=dropshipsuppliergroups', function (data) {
            if (data.success == 1) {
                if ($('body').find('.modal_groups').length == 0) {
                    makeModal();
                }
                $('.modal_groups .modal-body').html(data.html);
                $('.modal_groups').modal('show');
            } else {
                showErrorMessage(data.text);
            }
        }, 'json').fail(function(XMLHttpRequest, textStatus, errorThrown) {
            showErrorMessage(textStatus + ': ' + errorThrown);
        });
        return false;
    });

    $('.ajax_dss_manufacturer_link > a').on('click', function(e) {
        e.preventDefault();
        obj = $(this);
        obj.parent().prop('onclick', null).off('click');
        $.post($(this).attr('href') + '&ajax=1&action=dropshipmanufacturergroups', function (data) {
            if (data.success == 1) {
                if ($('body').find('.modal_groups').length == 0) {
                    makeModal();
                }
                $('.modal_groups .modal-body').html(data.html);
                $('.modal_groups').modal('show');
            } else {
                showErrorMessage(data.text);
            }
        }, 'json').fail(function(XMLHttpRequest, textStatus, errorThrown) {
            showErrorMessage(textStatus + ': ' + errorThrown);
        });
        return false;
    });

    $('body').on('click', '.modal_groups button.submitgroups', function(e) {
        e.preventDefault();

        var groups = [];
        $.each($(".modal_groups input[name='groupBox[]']:checked"), function () {
            groups.push($(this).val());
        });

        $.ajax({
            type: 'POST',
            url: $(this).data('url') + '?rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: false,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: $(this).data('token'),
                action: $(this).data('action'),
                id_dss: $(this).data('id'),
                selected_groups: groups.join(','),
                save: 1,
            },
            traditional: true,
            success: function(data) {
                if (data.success == 1) {
                    if (data.count > 0) {
                        obj.removeClass('action-disabled').addClass('action-enabled');
                        obj.find('.icon-check').removeClass('hidden');
                        obj.find('.icon-remove').addClass('hidden');
                    } else {
                        obj.removeClass('action-enabled').addClass('action-disabled');
                        obj.find('.icon-check').addClass('hidden');
                        obj.find('.icon-remove').removeClass('hidden');
                    }
                    showSuccessMessage(data.text);
                } else {
                    showErrorMessage(data.text);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                showErrorMessage(textStatus + ': ' + errorThrown);
            }
        });
        $('.modal_groups').modal('hide');
    });

    $('body').on('click', '.modal_groups .closebtn', function(e) {
        $('.modal_groups').modal('hide');
    });

    function makeModal()
    {
        var str = '<div id="modal" class="bootstrap modal_groups modal fade"><div class="modal-dialog" role="document"><div class="modal-content">';
            str += '<div class="modal-body"></div>';
            str += '</div></div></div>';
            $('body').append(str);
    }
});

function checkGroupBoxes()
{
    var chk = $('.modal_groups thead input[name=checkme]').is(':checked');
    $(".modal_groups tbody input:checkbox").prop('checked', chk);
}