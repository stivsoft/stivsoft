/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

(function($){
$.fn.serializeAny = function() {
    var ret = [];
    $.each($(this).find('input[type=radio]:checked'), function() {
        ret.push(encodeURIComponent(this.name) + "=" + encodeURIComponent($(this).val()));
    });
    $.each($(this).find('select'), function() {
        ret.push(encodeURIComponent(this.name) + "=" + encodeURIComponent($(this).val()));
    });
    return ret.join("&").replace(/%20/g, "+");
}
})(jQuery);

$(document).ready(function() {

    if ($('.dss-product-add-to-cart .product-price').data('hidden')) {
        $('.dss-product-add-to-cart .product-price span').mouseover(function() {
            $(this).removeClass('price-hide');
        }).mouseout(function() {
            $(this).addClass('price-hide');
        });
    }

    $(document).on('keyup', '.cart-item.template .js-product-search', function(e) {
        e.preventDefault();

        var query_string = $(this).val();

        if (query_string != '' && query_string.length >= 3) {
            $.ajax({
                type: 'POST',
                url: dss_ajaxurl + '?rand=' + new Date().getTime(),
                headers: { "cache-control": "no-cache" },
                async: true,
                cache: false,
                dataType: 'json',
                data: {
                    ajax: true,
                    token: token,
                    action: 'SearchProduct',
                    query: query_string,
                },
                traditional: true,
                success: function(data) {
                    $('#search-result').html(data.preview).show();
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    alert(textStatus + ': ' + errorThrown);
                }
            });
        } else {
            $('#search-result').fadeOut();
        }
        return false;
    });

//    $(document).on('click', '#search-result', function(e) {
//        var $clicked = $(e.target);
//        var $name = $clicked.find('.name').html();
//        var decoded = $('<div/>').html($name).text();
//        $('.cart-item.template .js-product-search').val(decoded);
//    });

    $(document).on('click', function(e) {
        var $clicked = $(e.target);
        if (!$clicked.hasClass('search')) {
            $('#search-result').fadeOut();
        }
    });

    $(document).on('click', '.cart-item.template .js-product-search', function() {
        if ($(this).val().length >= 3) {
            $('#search-result').fadeIn();
        }
    });

    $(document).on('click', 'li.search-item', function() {
        ResetForm();

        var id_product = $(this).data('id-product');
        //var product_reference = $(this).data('product-reference');
        var product_name = $(this).data('product-name');
        var product_reference = $(this).data('product-reference');
        var product_price = $(this).data('product-price');
        var product_quantity = $('.cart-item.template input.dss-cart-product-quantity').val();
        var product_url = $(this).data('product-url');
        var has_attributes = $(this).data('has-attributes');

        $.ajax({
            type: 'POST',
            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: token,
                action: 'getPrices',
                product_price: product_price,
                product_quantity: product_quantity
            },
            traditional: true,
            success: function(data) {
                if (data.success) {
                    $('.cart-item.template .js-product-search').val(product_reference);

                    var $cart = $('.cart-item.template a.add-from-dss-cart');
                    $cart.data('id-product', id_product);
                    $cart.data('price', product_price);
                    $cart.data('quantity', product_quantity);
                    $cart.data('has-attributes', has_attributes);

                    $('.cart-item.template a.product-name').attr('href', product_url);
                    $('.cart-item.template a.product-name').html(product_name);
                    $('.cart-item.template .product-price').html(data.formatted_price);
                    $('.cart-item.template .product-price.total').html(data.formatted_total);

                    if (has_attributes > 1) {
                        $('#set_attributes').show();
                    } else {
                        $('#set_attributes').hide();
                    }

                    getTotals();
                } else {
                    alert(data.error);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(textStatus + ': ' + errorThrown);
            }
        });
    });

    function ResetForm()
    {
        var $cart = $('.cart-item.template a.add-from-dss-cart');
        $cart.data('id-product', 0);
        $cart.data('id-product-attribute', 0);
        $cart.data('price', 0);
        $cart.data('quantity', 0);
        $cart.data('has-attributes', 0);

        $('.cart-item.template a.product-name').attr('href', '#');
        $('.cart-item.template a.product-name').html('...');
        $('.cart-item.template .product-price').html('...');
        $('.cart-item.template .dss-cart-product-quantity').val(1);
        $('.cart-item.template .product-price.total').html('...');

        $('.cart-item.template .product-variants').removeClass('open loaded');
        $('.cart-item.template .product-variants').html('').hide();
        $('#set_attributes').find('.material-icons').html('keyboard_arrow_down').hide();
    }

    $(document).on('click', '#set_attributes', function(e) {
        e.preventDefault();

        var $obj = $(this);
        var id_product = $('a.add-from-dss-cart').data('id-product');
        var has_attributes = $('a.add-from-dss-cart').data('has-attributes');
        var is_open, is_loaded = false;

        if ($('.cart-item.template .product-variants').hasClass('open')) {
            $('.cart-item.template .product-variants').removeClass('open');
            $('.cart-item.template .product-variants').hide();
            $obj.find('.material-icons').html('keyboard_arrow_down');
            is_open = true;
        }
        if ($('.cart-item.template .product-variants').hasClass('loaded')) {
            is_loaded = true;
        }

        if (has_attributes > 1 && !is_loaded && !is_open) {
            $.ajax({
                type: 'POST',
                url: dss_ajaxurl + '?rand=' + new Date().getTime(),
                headers: { "cache-control": "no-cache" },
                async: false,
                cache: false,
                dataType: 'json',
                data: {
                    ajax: true,
                    token: token,
                    action: 'getVariants',
                    id_product: id_product,
                },
                traditional: true,
                success: function(data) {
                    if (data.success) {
                        if (!$('.cart-item.template .product-variants').hasClass('loaded')) {
                            $('.cart-item.template .product-variants').addClass('loaded');
                            is_loaded = true;
                        }
                        $('.cart-item.template .product-variants').html(data.preview);
                    } else {
                        $('.cart-item.template .product-variants').html();
                        is_loaded = false;
                        alert(data.error);
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    $('.cart-item.template .product-variants').html();
                    is_loaded = false;
                    alert(textStatus + ': ' + errorThrown);
                }
            });
        }
        if (has_attributes > 1 && is_loaded && !is_open) {
            if (!$('.cart-item.template .product-variants').hasClass('open')) {
                $('.cart-item.template .product-variants').addClass('open');
            }
            $('.cart-item.template .product-variants').show();
            $obj.find('.material-icons').html('keyboard_arrow_up');
        }
    });

    $(document).on('change', '.cart-item.template .product-variants select', function() {
        var obj = $('.cart-item.template .product-variants').serializeAny();
        changeVariants(obj);
    });
    $(document).on('click', '.cart-item.template .product-variants input[type=radio]', function() {
        var obj = $('.cart-item.template .product-variants').serializeAny();
        changeVariants(obj);
    });

    function changeVariants(query)
    {
        var $obj = $('.cart-item.template .dss-cart-line-product-actions a');
        var id_product = $obj.data('id-product');
        var product_quantity = $('.cart-item.template .dss-cart-product-quantity').val();

        $.ajax({
            type: 'POST',
            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: token,
                action: 'GetProductAttribute',
                id_product: id_product,
                product_quantity: product_quantity,
                query: query,
            },
            traditional: true,
            success: function(data) {
                if (data.success) {
                    var $cart = $('.cart-item.template a.add-from-dss-cart');
                    $cart.data('id-product-attribute', data.id_product_attribute);
                    $cart.data('price', data.price);

                    $('.cart-item.template .product-price').html(data.formatted_price);
                    $('.cart-item.template .product-price.total').html(data.formatted_total);
                } else {
                    alert(data.error);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(textStatus + ': ' + errorThrown);
            }
        });
    }

    $(document).on('change', 'input.dss-cart-product-quantity', function(e) {
        e.preventDefault();

        var $obj = $(this);
        var $target = $obj.parent().parent().parent().parent().parent();
        var id_product = $target.find('.dss-cart-line-product-actions a').data('id-product');
        var id_product_attribute = $target.find('.dss-cart-line-product-actions a').data('id-product-attribute');
        var product_price = $target.find('.dss-cart-line-product-actions a').data('price');
        var product_quantity = $obj.val();

        var update = !$target.parent().parent().hasClass('template');

        $.ajax({
            type: 'POST',
            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: token,
                action: 'getPrices',
                id_product: id_product,
                id_product_attribute: id_product_attribute,
                product_price: product_price,
                product_quantity: product_quantity,
                update: update
            },
            traditional: true,
            success: function(data) {
                if (data.success) {
                    $target.find('.product-price.total').html(data.formatted_total);
                    $target.find('.dss-cart-line-product-actions a').data('price', product_price);
                    $target.find('.dss-cart-line-product-actions a').data('quantity', product_quantity);
                    getTotals();
                } else {
                    alert(data.error);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(textStatus + ': ' + errorThrown);
            }
        });
    });
    
    $(document).on('click', '.dss-cart-line-product-actions a', function(e) {
        e.preventDefault();

        var action = $(this).data('link-action');
        var id_product = $(this).data('id-product');
        var id_product_attribute = $(this).data('id-product-attribute');
        var product_price = $(this).data('price');
        var product_quantity = $(this).data('quantity');

        if (action == 'add-to-dss-cart') {
            addCart(id_product, id_product_attribute, product_price, product_quantity);
        } else if (action == 'delete-from-dss-cart') {
            deleteCart(id_product, id_product_attribute);
        }
    });

    $(document).on('click', '.dss-product-add-to-cart .dss-add-to-cart', function(e) {
        e.preventDefault();

        var query = $('form').serialize();
        //var id_product = $('#product_page_product_id').val();
        //var id_product_attribute = $('#product_customization_id, #idCombination').val();
        var product_price = $('.dss-product-add-to-cart .product-price').data('price');
        var product_quantity = $('.dss-product-add-to-cart .dss-cart-product-quantity').val();

        $.ajax({
            type: 'POST',
            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: token,
                action: 'AddProductToCart',
                query: query,
                //id_product: id_product,
                //id_product_attribute: id_product_attribute,
                product_price: product_price,
                product_quantity: product_quantity
            },
            traditional: true,
            success: function(data) {
                if (data.success) {
                    var $modal = $('#dss-blockcart-modal');
                    $modal.find('img.product-image').attr('src', data.product.image_url);
                    $modal.find('h6.product-name').html(data.product.name);
                    $modal.find('p.product-price span').html(data.product.price);

                    if (data.product.combinations.length > 0) {
                        var html = '';
                        $.each(data.product.combinations, function(index, value) {
                            html += '<span><strong>' + value.group_name + '</strong>: ' + value.attribute_name + '</span><br>';
                        });
                        $modal.find('div.variants').html(html);
                    }

                    $modal.find('p.cart-products-count').html(data.dss_cart.count);
                    $modal.find('p.cart-total span').html(data.dss_cart.formatted_total);
                    $modal.modal("show");
                } else {
                    alert(data.error);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(textStatus + ': ' + errorThrown);
            }
        });
    });

    function loadCart()
    {
        $.ajax({
            type: 'POST',
            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: token,
                action: 'getCart',
            },
            traditional: true,
            success: function(data) {
                if (data.success) {
                    $('.cart-container').html(data.preview);
                    getTotals();
                } else {
                    alert(data.error);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(textStatus + ': ' + errorThrown);
            }
        });
    }

    function addCart(id_product, id_product_attribute, product_price, product_quantity)
    {
        $.ajax({
            type: 'POST',
            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: token,
                action: 'AddProductToCart',
                id_product: id_product,
                id_product_attribute: id_product_attribute,
                product_price: product_price,
                product_quantity: product_quantity
            },
            traditional: true,
            success: function(data) {
                if (data.success) {
                    loadCart();
                } else {
                    alert(data.error);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(textStatus + ': ' + errorThrown);
            }
        });
    }

    function deleteCart(id_product, id_product_attribute)
    {
        $.ajax({
            type: 'POST',
            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: token,
                action: 'RemoveProductFromCart',
                id_product: id_product,
                id_product_attribute: id_product_attribute
            },
            traditional: true,
            success: function(data) {
                if (data.success) {
                    loadCart();
                } else {
                    alert(data.error);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(textStatus + ': ' + errorThrown);
            }
        });
    }

    function getTotals()
    {
        $.ajax({
            type: 'POST',
            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: token,
                action: 'getTotals',
            },
            traditional: true,
            success: function(data) {
                if (data.success) {
                    $('.dss-cart-shipping .value').html(data.dss_cart.totals.formatted_shipping);
                    $('.dss-cart-subtotal .value').html(data.dss_cart.totals.formatted_subtotal);
                    $('.dss-cart-total .value').html(data.dss_cart.totals.formatted_total);

                    if ($('.dss-cart-current-credit').length > 0) {
                        $('.dss-cart-current-credit .value').html(data.dss_cart.totals.formatted_current_credit);
                        $('.dss-cart-remain-credit .value').html(data.dss_cart.totals.formatted_remain_credit);
                    }

                    if ($('#submitOrder').hasClass('disabled') && $('select[name=dss_order_shipping_method]').val() > 0 && data.dss_cart.totals.subtotal > 0) {
                        $('#submitOrder').removeClass('disabled');
                    }
                } else {
                    if (!$('#submitOrder').hasClass('disabled')) {
                        $('#submitOrder').addClass('disabled');
                    }
                    alert(data.error);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                if (!$('#submitOrder').hasClass('disabled')) {
                    $('#submitOrder').addClass('disabled');
                }
                alert(textStatus + ': ' + errorThrown);
            }
        });
    }

    $(document).on('change', '.js-address-form input, .js-address-form select', function(e) {
        e.preventDefault();

        var $parent = $('.js-dss-country').parent().parent(); 
        var form_data = $('#form_dss_order').serialize();

        $.ajax({
            type: 'POST',
            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: token,
                action: 'setAddress',
                form_data: form_data,
            },
            traditional: true,
            success: function(data) {
                if (data.success) {
                    if ($('.js-dss-states').length > 0) {
                        $('.js-dss-states').remove();
                    }
                    $(data.preview).insertAfter($parent);
                    $('select[name=dss_order_shipping_method] :nth-child(1)').prop('selected', true);
                    getTotals();
                } else {
                    //alert(data.error);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                $('.js-dss-states').remove();
                alert(textStatus + ': ' + errorThrown);
            }
        });
    });

//    $(document).on('change', '.js-dss-country', function(e) {
//        e.preventDefault();
//
//        var $parent = $('').parent().parent(); 
//        var id_country = $(this).val();
//
//        if (contains_states) {
//            $.ajax({
//                type: 'POST',
//                url: dss_ajaxurl + '?rand=' + new Date().getTime(),
//                headers: { "cache-control": "no-cache" },
//                async: true,
//                cache: false,
//                dataType: 'json',
//                data: {
//                    ajax: true,
//                    token: token,
//                    action: 'getStates',
//                    id_country: id_country,
//                },
//                traditional: true,
//                success: function(data) {
//                    if ($('.js-dss-states').length > 0) {
//                        $('.js-dss-states').remove();
//                    }
//                    $(data.preview).insertAfter($parent);
//                },
//                error: function(XMLHttpRequest, textStatus, errorThrown) {
//                    alert(textStatus + ': ' + errorThrown);
//                }
//            });
//        } else {
//            $('.js-dss-states').remove();
//        }
//    });

    $(document).on('change', 'select[name=dss_order_shipping_method]', function(e) {
        e.preventDefault();

        var id_carrier = $(this).val();

        $.ajax({
            type: 'POST',
            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: token,
                action: 'setCarrier',
                id_carrier: id_carrier,
            },
            traditional: true,
            success: function(data) {
                if (data.success) {
                    getTotals();
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(textStatus + ': ' + errorThrown);
            }
        });
    });

    $(document).on('click', '#submitOrder', function(e) {
        if ($('#submitOrder').hasClass('disabled')) {
            e.preventDefault();
            return false;
        }
    });
});
