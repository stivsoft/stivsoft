/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$(document).ready(function() {
    setDownloadUrl();

    $('[data-toggle="popover"]').popover();

    $(document).on('change', 'select[name=dropshipclient]', function(e) {
        e.preventDefault();
        setDownloadUrl();
    });

    $(document).on('submit', 'form[name=dropship_signup]', function(e) {
        if ($('#check_agreement').length && !$('input#check_agreement:checked').length) {
            e.preventDefault();
            if (!!$.prototype.fancybox) {
                $.fancybox.open([
                {
                    type: 'inline',
                    autoScale: true,
                    minHeight: 30,
                    content: '<p class="fancybox-error">' + msg_check_agreement + '</p>'
                }],
                {
                    padding: 0
                });
            } else {
                alert(msg_check_agreement);
            }
        }
    });

    $(document).on('click', 'a[data-mode="modal"]', function(e) {
        e.preventDefault();

        var size = $(this).data('size');
        if ($("#modal .modal-dialog").hasClass("modal-lg")) {
            $("#modal .modal-dialog").removeClass("modal-lg");
        }
        if (size == 'large') {
            $("#modal .modal-dialog").addClass("modal-lg");
        } else if (size == 'small') {
            $("#modal .modal-dialog").addClass("modal-sm");
        }
        $.get($(this).attr("href"), function(content) {
            $("#modal .js-modal-content").html(content);
            $("#modal").modal("show");
        });
    });

    $(document).on('click', '#creditdetails', function(e) {
        e.preventDefault();

        $.get($(this).attr("href"), function(content) {
            console.log(content);
            $("#modal2 .js-modal-content").html(content);
            $("#modal2").modal("show");
        });
    });

    $(document).on('click', 'button[name=submitAddCredit]', function(e) {
        e.preventDefault();
        var ref_credit = $('select[name=credits]').val();
        if (ref_credit != '0') {
            var $btn = $(this);
            //$btn.button('loading');
            $btn.prop('disabled', true);

            $.ajax({
                type: 'POST',
                url: dss_ajaxurl + '?rand=' + new Date().getTime(),
                headers: { "cache-control": "no-cache" },
                async: true,
                cache: false,
                dataType: 'json',
                data: {
                    ajax: true,
                    token: token,
                    action: 'getPaymentPage',
                    ref_credit: ref_credit,
                },
                traditional: true,
                success: function(data) {
                    if (data['success']) {
                        $('#modal').modal('hide');
                        parent.document.location.href = data['paymentlink'];
                    } else {
                        alert(data['error']);
                        //$btn.button('reset');
                        $btn.prop('disabled', false);
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    alert(textStatus + ': ' + errorThrown);
                    $('#modal').modal('hide');
                }
            });
        } else {
            alert(err_nocredit);
        }
        return false;
    });
/*
    $('#payments-history .history_date > a').on('click', function(e) {
        e.preventDefault();
        var id_payment = $(this).data('value');
        if (id_payment > 0) {
            $.ajax({
                type: 'POST',
                url: dss_ajaxurl,
                headers: { "cache-control": "no-cache" },
                async: true,
                cache: false,
                dataType: 'json',
                data: {
                    ajax: true,
                    token: token,
                    action: 'getPaymentDetails',
                    id_payment: id_payment,
                },
                traditional: true,
                success: function(data) {
                    if (data['success']) {
                        $('#creditdetails').modal('show');
                        alert(data['dssph'].request_date);
                    } else {
                        alert(data['error']);
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    alert(textStatus + ': ' + errorThrown);
                }
            });
        } else {
            alert(err_invalid_payment);
        }
    });
*/
});

function setDownloadUrl()
{
    var sel = $('select[name=dropshipclient]').val();

    if (sel == '') {
        $('#submitDownloadPlugin').addClass('disabled');
        $('#submitDownloadPlugin').attr('href', '#');
    } else {
        $('#submitDownloadPlugin').removeClass('disabled');
        $('#submitDownloadPlugin').attr('href', dss_pluginurl + '?client=' + sel);
    }
}
