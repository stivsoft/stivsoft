/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$(document).ready(function() {
    var self = this;

    var id_product = $('#form_id_product').val();
    var elem = $('#js-specific-wholesale-price-list');

    specificWholesalePrices.init(id_product, elem);

    this.toggleSpecificWholesalePrice = function () {
        $('body').on('click', '#show_specific_wholesale_price', function() {
            $('#specific-wholesale-price-form').slideToggle();

            $('#specific-wholesale-price-form').append('<input type="hidden" name="submitPriceWholesaleAddition"/>');

            $('#hide_specific_wholesale_price').show();
            $('#show_specific_wholesale_price').hide();
            return false;
        });

        $('body').on('click', '#hide_specific_wholesale_price, #specific-wholesale-price-form .js-cancel', function() {
            $('#specific-wholesale-price-form').slideToggle();
            $('#specific-wholesale-price-form').find('input[name=submitPriceWholesaleAddition]').remove();
            $('#hide_specific_wholesale_price').hide();
            $('#show_specific_wholesale_price').show();
            return false;
        });
    }

    self.toggleSpecificWholesalePrice();
});

var specificWholesalePrices = (function() {
    var id_product;
    var elem;
    var initSpecificWholesalePriceForm = new Object();

    function getInitSpecificWholesalePriceForm() {
        $('#specific-wholesale-price-form').find('select,input').each(function() {
            initSpecificWholesalePriceForm[$(this).attr('id')] = $(this).val();
        });
        $('#specific-wholesale-price-form').find('input:checkbox').each(function() {
            initSpecificWholesalePriceForm[$(this).attr('id')] = $(this).prop('checked');
        });
    }

    function getAll() {
        var url = elem.attr('data');

        $.ajax({
            type: 'POST',
            url: url + '&rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                action: 'GetSpecificWholesalePriceList',
                id_product: id_product
            },
            success: function(specific_wholesale_prices) {
                var tbody = elem.find('tbody');
                tbody.find('tr').remove();

                if (specific_wholesale_prices.length > 0) {
                  elem.removeClass('hide');
                } else {
                  elem.addClass('hide');
                }

                $.each(specific_wholesale_prices, function(key, specific_wholesale_price) {
                    var row = '<tr>' +
                        /*'<td>' + specific_wholesale_price.rule_name + '</td>' */
                        '<td>' + specific_wholesale_price.attributes_name + '</td>' +
                        '<td>' + specific_wholesale_price.currency + '</td>' +
                        '<td>' + specific_wholesale_price.country + '</td>' +
                        '<td>' + specific_wholesale_price.group + '</td>' +
                        '<td>' + specific_wholesale_price.value + '</td>' +
                        '<td>' + specific_wholesale_price.period + '</td>' +
                        '<td>' + (specific_wholesale_price.can_delete ? '<a href="' + $('#js-specific-wholesale-price-list').attr('data-action-delete') + '&id_specific_wholesale_price=' + specific_wholesale_price.id_specific_wholesale_price + '" class="js-delete delete"><i class="material-icons">delete</i></a>' : '') + '</td>' +
                        '</tr>';

                    tbody.append(row);
                });
            }
        });
    }

    function add(elem) {
        $.ajax({
            type: 'POST',
            url: $('#specific-wholesale-price-form').attr('data-action') + '&rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                action: 'AddSpecificWholesalePrice',
                data: $('#specific-wholesale-price-form input, #specific-wholesale-price-form select, #form_id_product').serialize(),
            },
            beforeSend: function() {
                elem.attr('disabled', 'disabled');
            },
            success: function(data) {
                if (data.success) {
                    showSuccessMessage(translate_javascripts['Form update success']);
                    $('#specific-wholesale-price-form .js-cancel').click();
                    getAll();
                } else {
                    showErrorMessage(data.errors);
                }
            },
            complete: function() {
                elem.removeAttr('disabled');
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                showErrorMessage(textStatus + ': ' + errorThrown);
            }
        });
    }

    function remove(elem) {
        modalConfirmation.create(translate_javascripts['This will delete the specific price. Do you wish to proceed?'], null, {
            onContinue: function() {
                $.ajax({
                    type: 'POST',
                    url: elem.attr('href') + '&rand=' + new Date().getTime(),
                    headers: { "cache-control": "no-cache" },
                    async: true,
                    cache: false,
                    dataType: 'json',
                    data: {
                        ajax: true,
                        action: 'deleteSpecificWholesalePrice',
                    },
                    beforeSend: function() {
                        elem.attr('disabled', 'disabled');
                    },
                    success: function(response) {
                        getAll();
                        resetForm();
                        showSuccessMessage(response.message);
                    },
                    complete: function() {
                        elem.removeAttr('disabled');
                    },
                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                        showErrorMessage(textStatus + ': ' + errorThrown);
                    }
                });
            }
        }).show();
    }

    /** refresh combinations list selector for specific price form */
    function refreshCombinationsList() {
        var elem = $('#swp_id_product_attribute');
        var url = elem.attr('data-action').replace(/product-combinations\/\d+/, 'product-combinations/' + id_product);

        $.ajax({
            type: 'GET',
            url: url,
            success: function(combinations) {
                /** remove all options except first one */
                elem.find('option:gt(0)').remove();
                $.each(combinations, function(key, combination) {
                    elem.append('<option value="' + combination.id + '">' + combination.name + '</option>');
                });
            }
        });
    }

    function resetForm() {
        $('#specific-wholesale-price-form').find('input').each(function() {
            $(this).val(initSpecificWholesalePriceForm[$(this).attr('id')]);
        });
        $('#specific-wholesale-price-form').find('select').each(function() {
            $(this).val(initSpecificWholesalePriceForm[$(this).attr('id')]).change();
        });
        $('#specific-wholesale-price-form').find('input:checkbox').each(function() {
            $(this).prop("checked", true);
        });
    }

    return {
        'init': function(id, el) {
            id_product = id;
            elem = el;

            this.getAll();

            //$('#specific-wholesale-price .add').click(function() {
            //    $(this).hide();
            //});

            $('#specific-wholesale-price-form .js-cancel').click(function() {
                resetForm();
                $('#specific-wholesale-price > a').click();
                $('#specific-wholesale-price .add').click().show();
            });

            $('#specific-wholesale-price-form .js-save').click(function() {
                add($(this));
            });

            $(document).on('click', '#js-specific-wholesale-price-list .js-delete', function(e) {
                e.preventDefault();
                remove($(this));
            });

            this.refreshCombinationsList();
            this.getInitSpecificWholesalePriceForm();
        },
        'getAll': function() {
            getAll();
        },
        'refreshCombinationsList': function() {
            refreshCombinationsList();
        },
        'getInitSpecificWholesalePriceForm' : function() {
            getInitSpecificWholesalePriceForm();
        }
    };
})();
