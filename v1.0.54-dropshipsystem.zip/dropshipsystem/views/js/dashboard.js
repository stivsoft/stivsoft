/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

$(document).ready(function() {

    $('.dss_filters').on('click', function(e) {
        //e.preventDefault();

        $.ajax({
            type: 'POST',
            url: dss_ajaxurl + '?rand=' + new Date().getTime(),
            headers: { "cache-control": "no-cache" },
            async: true,
            cache: false,
            dataType: 'json',
            data: {
                ajax: true,
                token: dss_token,
                action: 'set_dashboard_filter',
                id: this.name,
            },
            traditional: true,
            success: function() {
                refreshDashboard('dropshipsystem');
                showSuccessMessage(dashboad_filter_edit);
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                showErrorMessage(err_dashboad_filter_edit);
            }
        });
    });
});
