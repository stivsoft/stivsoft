{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div id="mydropshipaccount">
    {capture name=path}
        <a href="{$link->getPageLink('my-account', true)|escape:'html':'UTF-8'}">
            {l s='My account' mod='dropshipsystem'}
        </a>
        <span class="navigation-pipe">
            {$navigationPipe|escape:'htmlall':'UTF-8'}
        </span>
        <span class="navigation_page">
            {l s='Add New Dropship Order' mod='dropshipsystem'}
        </span>
    {/capture}

    <div class="text-left">
        <h1 class="page-heading">{l s='Add New Dropship Order' mod='dropshipsystem'}</h1>

        {include file="$tpl_dir./errors.tpl"}

        <p class="text">{l s='Here you can send the dropship orders for your customers.' mod='dropshipsystem'}</p>
    {if $dss_customer->id|intval neq 0}
        {if $dropshipper->id|intval neq 0}
        {*<p class="required"><sup>*</sup>{l s='Required field' mod='dropshipsystem'}</p>*}
        <form id="form_dss_order" action="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'neworder'], true)|escape:'html':'UTF-8'}" method="post" class="std">
            <div class="box cart-container">
            {include file='./order-form.tpl'}
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-7">
                    <div class="box address-container">
                        <h3 class="col-xs-12 page-subheading">{l s='Shipping Address' mod='dropshipsystem'}</h3>
                        {include file='./order-address.tpl'}
                    </div>
                </div>
                <div class="col-xs-12 col-sm-5">
                    <div class="box shipping-methods-container">
                        <h3 class="col-xs-12 page-subheading">{l s='Shipping Method' mod='dropshipsystem'}</h3>
                        {include file='./order-shipping-methods.tpl'}
                    </div>
                    <div class="clearfix"></div>
                    <div class="box totals-container">
                        <h3 class="col-xs-12 page-subheading">{l s='Totals' mod='dropshipsystem'}</h3>
                        {include file='./order-totals.tpl'}
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-sm-12">
                        <input type="hidden" name="token" value="{$token|escape:'htmlall':'UTF-8'}" />
                        <button type="submit" name="submitOrder" id="submitOrder" class="btn btn-default button button-medium pull-right disabled">
                            <span>{l s='Confirm Order' mod='dropshipsystem'}<i class="icon-chevron-right right"></i></span>
                        </button>
                    </div>
                </div>
            </div>
        </form>
        {else}
            {l s='You have not access to this page.' mod='dropshipsystem'}
        {/if}
    {/if}
        <br><br>
        <div class="clearfix main-page-indent">
            <ul class="footer_links clearfix">
                <li>
                    <a class="btn btn-default button button-small" href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', array(), true)|escape:'html':'UTF-8'}">
                        <span>
                            <i class="icon-chevron-left"></i>{l s='Back to Your Account' mod='dropshipsystem'}
                        </span>
                    </a>
                </li>
                <li>
                    <a class="btn btn-default button button-small" href="{$base_dir|escape:'html':'UTF-8'}">
                        <span>
                            <i class="icon-chevron-left"></i>{l s='Home' mod='dropshipsystem'}
                        </span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
