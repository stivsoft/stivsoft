{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{capture name=path}
    <a href="{$link->getPageLink('my-account', true)|escape:'html':'UTF-8'}">
        {l s='My account' mod='dropshipsystem'}
    </a>
    <span class="navigation-pipe">
        {$navigationPipe|escape:'htmlall':'UTF-8'}
    </span>
    <span class="navigation_page">
    {if $iscredit}
        {l s='Dropship credit details' mod='dropshipsystem'}
    {else}
        {l s='Dropship order status' mod='dropshipsystem'}
    {/if}
    </span>
{/capture}

<div class="text-center">
    {if $iscredit}
    <p class="h2">{l s='Dropship credit' mod='dropshipsystem'}</p>
    {else}
    <p class="h2">{l s='Dropship order status' mod='dropshipsystem'}</p>
    {/if}

    {include file="$tpl_dir./errors.tpl"}

    {if $status == 'success'}
    <p>
        {if $iscredit}
            {l s='Your dropship credit on %s is charged.' sprintf=$shop_name mod='dropshipsystem'}
            <br /><br />{l s='Amount' mod='dropshipsystem'} <span class="price"><strong>{convertPrice price=$total|floatval}</strong></span>
            <br /><br />{l s='Current credit' mod='dropshipsystem'} <span class="price"><strong>{convertPrice price=$credit|floatval}</strong></span>
        {else}
            {l s='Your dropship order on %s is complete.' sprintf=$shop_name mod='dropshipsystem'}
            <br /><br />{l s='Amount' mod='dropshipsystem'} <span class="price"><strong>{convertPrice price=$total|floatval}</strong></span>
        {/if}
        <br /><br />{l s='An email has been sent with this information.' mod='dropshipsystem'}
        <br /><br />{l s='If you have questions, comments or concerns, please contact our' mod='dropshipsystem'} <a href="{$link->getPageLink('contact', true)|escape:'htmlall':'UTF-8'}">{l s='expert customer support team' mod='dropshipsystem'}</a>.
    </p>
    {elseif $status == 'cancel'}
    <p class="warning">
        {if $iscredit}
            {l s='Your dropship credit on %s is not charged.' sprintf=$shop_name mod='dropshipsystem'}
        {else}
            {l s='Your dropship order on %s is not complete.' sprintf=$shop_name mod='dropshipsystem'}
        {/if}
        <br /><br />
        {l s='The payment has been cancelled by the user.' mod='dropshipsystem'}
        {if !$iscredit}
        <br /><br />
        <a class="btn btn-primary btn-lg" href="{$payment_link|escape:'htmlall':'UTF-8'}">
            {l s='Retry the payment' mod='dropshipsystem'}
        </a>
        {/if}
        <br /><br />
        {l s='If you think this is an error, feel free to contact our' mod='dropshipsystem'}
        <a href="{$contact_url|escape:'htmlall':'UTF-8'}">{l s='expert customer support team' mod='dropshipsystem'}</a>.
    </p>
    {else}
    <p class="warning">
        {if $iscredit}
            {l s='We noticed a problem with your credit.' mod='dropshipsystem'}
        {else}
            {l s='We noticed a problem with your order.' mod='dropshipsystem'}
        {/if}

        {if $errors}
        <div class="error">
            <ul>
                {foreach $errors as $error}
                    <li>{$error|escape:'htmlall':'UTF-8'}</li>
                {/foreach}
            </ul>
        </div>
        {/if}

        {l s='If you think this is an error, feel free to contact our' mod='dropshipsystem'}
        <a href="{$contact_url|escape:'htmlall':'UTF-8'}">{l s='expert customer support team' mod='dropshipsystem'}</a>.
    </p>
    {/if}

    {if $iscredit}
    <div class="clearfix main-page-indent">
        <ul class="footer_links clearfix">
            <li>
                <a class="btn btn-default button button-small" href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', array(), true)|escape:'html':'UTF-8'}">
                    <span>
                        <i class="icon-chevron-left"></i>{l s='Back to Your Account' mod='dropshipsystem'}
                    </span>
                </a>
            </li>
            <li>
                <a class="btn btn-default button button-small" href="{$base_dir|escape:'html':'UTF-8'}">
                    <span>
                        <i class="icon-chevron-left"></i>{l s='Home' mod='dropshipsystem'}
                    </span>
                </a>
            </li>
        </ul>
    </div>
    {/if}
</div>
