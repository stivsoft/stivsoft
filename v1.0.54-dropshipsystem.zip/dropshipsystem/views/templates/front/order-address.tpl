{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div class="col-xs-12 address-form">
    <div class="row js-address-form">
        {*include file='_partials/form-errors.tpl' errors=$errors['']*}

        <section class="form-fields">
            <div class="form-group row">
                <label class="col-md-3 form-control-label required">
                    {l s='First Name' mod='dropshipsystem'}
                </label>
                <div class="col-md-9">
                    <input class="form-control" name="dss_address_firstname" type="text" value="{if isset($smarty.post.dss_address_firstname)}{$smarty.post.dss_address_firstname|escape:'htmlall':'UTF-8'}{else}{if isset($dss_cart.delivery_address->firstname)}{$dss_cart.delivery_address->firstname|escape:'html':'UTF-8'}{/if}{/if}">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3 form-control-label required">
                    {l s='Last Name' mod='dropshipsystem'}
                </label>
                <div class="col-md-9">
                    <input class="form-control" name="dss_address_lastname" type="text" value="{if isset($smarty.post.dss_address_lastname)}{$smarty.post.dss_address_lastname|escape:'htmlall':'UTF-8'}{else}{if isset($dss_cart.delivery_address->lastname)}{$dss_cart.delivery_address->lastname|escape:'html':'UTF-8'}{/if}{/if}">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3 form-control-label">
                    {l s='Company' mod='dropshipsystem'}
                </label>
                <div class="col-md-9">
                    <input class="form-control" name="dss_address_company" type="text" value="{if isset($smarty.post.dss_address_company)}{$smarty.post.dss_address_company|escape:'htmlall':'UTF-8'}{else}{if isset($dss_cart.delivery_address->company)}{$dss_cart.delivery_address->company|escape:'html':'UTF-8'}{/if}{/if}">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3 form-control-label required">
                    {l s='Address' mod='dropshipsystem'}
                </label>
                <div class="col-md-9">
                    <input class="form-control" name="dss_address_address1" type="text" value="{if isset($smarty.post.dss_address_address1)}{$smarty.post.dss_address_address1|escape:'htmlall':'UTF-8'}{else}{if isset($dss_cart.delivery_address->address1)}{$dss_cart.delivery_address->address1|escape:'html':'UTF-8'}{/if}{/if}">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3 form-control-label">
                    {l s='Address (Line 2)' mod='dropshipsystem'}
                </label>
                <div class="col-md-9">
                    <input class="form-control" name="dss_address_address2" type="text" value="{if isset($smarty.post.dss_address_address2)}{$smarty.post.dss_address_address2|escape:'htmlall':'UTF-8'}{else}{if isset($dss_cart.delivery_address->address2)}{$dss_cart.delivery_address->address2|escape:'html':'UTF-8'}{/if}{/if}">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3 form-control-label required">
                    {l s='Zip Code' mod='dropshipsystem'}
                </label>
                <div class="col-md-9">
                    <input class="form-control" name="dss_address_postcode" type="text" value="{if isset($smarty.post.dss_address_postcode)}{$smarty.post.dss_address_postcode|escape:'htmlall':'UTF-8'}{else}{if isset($dss_cart.delivery_address->postcode)}{$dss_cart.delivery_address->postcode|escape:'html':'UTF-8'}{/if}{/if}">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3 form-control-label required">
                    {l s='City' mod='dropshipsystem'}
                </label>
                <div class="col-md-9">
                    <input class="form-control" name="dss_address_city" type="text" value="{if isset($smarty.post.dss_address_city)}{$smarty.post.dss_address_city|escape:'htmlall':'UTF-8'}{else}{if isset($dss_cart.delivery_address->city)}{$dss_cart.delivery_address->city|escape:'html':'UTF-8'}{/if}{/if}">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3 form-control-label required">
                    {l s='Country' mod='dropshipsystem'}
                </label>
                <div class="col-md-9">
                    <select class="form-control form-control-select js-dss-country" name="dss_address_country" required>
                        <option value disabled selected>{l s='-- please choose --' mod='dropshipsystem'}</option>
                        {if $countries}
                            {foreach from=$countries key="value" item="country"}
                            <option value="{$value|intval}"
                                {if isset($dss_cart.delivery_address->id_country)}{if $value eq $dss_cart.delivery_address->id_country} selected {/if}{/if}>
                                    {$country.name|escape:'html':'UTF-8'}
                            </option>
                            {/foreach}
                        {/if}
                    </select>
                </div>
            </div>
            {if isset($dss_cart.delivery_address->id_state) && $dss_cart.delivery_address->id_state > 0}
                {include file='./states.tpl'}
            {/if}
            <div class="form-group row">
                <label class="col-md-3 form-control-label">
                    {l s='Phone' mod='dropshipsystem'}
                </label>
                <div class="col-md-9">
                    <input class="form-control" name="dss_address_phone" type="text" value="{if isset($smarty.post.dss_address_phone)}{$smarty.post.dss_address_phone|escape:'htmlall':'UTF-8'}{else}{if isset($dss_cart.delivery_address->phone)}{$dss_cart.delivery_address->phone|escape:'html':'UTF-8'}{/if}{/if}">
                </div>
            </div>
        </section>
    </div>
</div>
