{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{capture name=path}
    <a href="{$link->getPageLink('my-account', true)|escape:'html':'UTF-8'}">
        {l s='My account' mod='dropshipsystem'}
    </a>
    <span class="navigation-pipe">
        {$navigationPipe|escape:'htmlall':'UTF-8'}
    </span>
    <span class="navigation_page">
    {if $iscredit}
        {l s='Dropship credit payment' mod='dropshipsystem'}
    {else}
        {l s='Dropship order payment' mod='dropshipsystem'}
    {/if}
    </span>
{/capture}

    <h1 class="page-heading">{l s='My Dropship Account' mod='dropshipsystem'}</h1>

    {include file="$tpl_dir./errors.tpl"}

    {include file=$tplfile}

    <div class="clearfix main-page-indent">
        <ul class="footer_links clearfix">
            <li>
                <a class="btn btn-default button button-small" href="{$link->getPageLink('my-account', true)|escape:'html':'UTF-8'}">
                    <span>
                        <i class="icon-chevron-left"></i>{l s='Back to Your Account' mod='dropshipsystem'}
                    </span>
                </a>
            </li>
            <li>
                <a class="btn btn-default button button-small" href="{$base_dir|escape:'html':'UTF-8'}">
                    <span>
                        <i class="icon-chevron-left"></i>{l s='Home' mod='dropshipsystem'}
                    </span>
                </a>
            </li>
        </ul>
    </div>
