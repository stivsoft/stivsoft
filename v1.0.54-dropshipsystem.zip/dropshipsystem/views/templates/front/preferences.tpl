{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div id="mydropshipaccount">
    {capture name=path}
        <a href="{$link->getPageLink('my-account', true)|escape:'html':'UTF-8'}">
            {l s='My account' mod='dropshipsystem'}
        </a>
        <span class="navigation-pipe">
            {$navigationPipe|escape:'htmlall':'UTF-8'}
        </span>
        <span class="navigation_page">
            {l s='Account preferences' mod='dropshipsystem'}
        </span>
    {/capture}
    
    <div class="text-left">
        <h1 class="page-heading">{l s='Dropshipper preferences' mod='dropshipsystem'}</h1>
    
        {include file="$tpl_dir./errors.tpl"}
    
        {if $dss_customer->id|intval neq 0}
            {if $dropshipper->id|intval neq 0}
            <form action="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'preferences'], true)|escape:'html':'UTF-8'}" method="post" class="std">
                <div class="row required form-group">
                    <label class="col-sm-3" for="low_credit_threshold">{l s='Low credit threshold' mod='dropshipsystem'}</label>
                    <div class="col-sm-2">
                        <input type="text" id="low_credit_threshold" name="low_credit_threshold" class="validate form-control text-right" 
                            data-validate="{$preference_validation.low_credit_threshold.validate|escape:'htmlall':'UTF-8'}" 
                            value="{if isset($smarty.post.low_credit_threshold)}{$smarty.post.low_credit_threshold|floatval}{else}{if isset($dropshipper->low_credit_threshold)}{$dropshipper->low_credit_threshold|floatval}{/if}{/if}" />
                    </div>
                    <a href="#" data-container="body" data-toggle="popover" data-placement="right" 
                        data-content="{l s='Receive an email when the credit threshold is reached. (0 for disable)' mod='dropshipsystem'}">
                        <i class="fa-dss fa-dss-info-circle nohover"></i>
                    </a>
                </div>
                <div class="row form-group">
                    <label class="col-sm-3" for="hidden_product_prices">{l s='Hidden product prices' mod='dropshipsystem'}</label>
                    <div class="col-sm-2">
                        <input type="checkbox" id="hidden_product_prices" name="hidden_product_prices" class="form-control" 
                            value="1" {if (isset($smarty.post.hidden_product_prices) && $smarty.post.hidden_product_prices == 1) || (isset($dropshipper->hidden_product_prices) && $dropshipper->hidden_product_prices == 1)}checked{/if} />
                    </div>
                    <a href="#" data-container="body" data-toggle="popover" data-placement="right" 
                        data-content="{l s='Check to hide the product price by default' mod='dropshipsystem'}">
                        <i class="fa-dss fa-dss-info-circle nohover"></i>
                    </a>
                </div>
                <p class="submit2">
                    <input type="hidden" name="token" value="{$token|escape:'htmlall':'UTF-8'}" />
                    <button type="submit" name="submitPreferences" id="submitPreferences" class="btn btn-default button button-medium">
                        <span>
                            {l s='Save' mod='dropshipsystem'}
                            <i class="icon-chevron-right right"></i>
                        </span>
                    </button>
                </p>
            </form>
            {else}
                {l s='You have not access to this page.' mod='dropshipsystem'}
            {/if}
        {/if}
        <div class="clearfix main-page-indent">
            <ul class="footer_links clearfix">
                <li>
                    <a class="btn btn-default button button-small" href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', array(), true)|escape:'html':'UTF-8'}">
                        <span>
                            <i class="icon-chevron-left"></i>{l s='Back to Your Account' mod='dropshipsystem'}
                        </span>
                    </a>
                </li>
                <li>
                    <a class="btn btn-default button button-small" href="{$base_dir|escape:'html':'UTF-8'}">
                        <span>
                            <i class="icon-chevron-left"></i>{l s='Home' mod='dropshipsystem'}
                        </span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
