{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div class="col-xs-12">
    <div class="row js-shipping-method-form">
        <section class="form-fields">
            <div class="form-group row">
                <label class="col-md-4 form-control-label required">
                    {l s='Shipping' mod='dropshipsystem'}
                </label>
                <div class="col-md-8">
                    <select class="form-control form-control-select" name="dss_order_shipping_method" required>
                        <option value disabled selected>{l s='-- please choose --' mod='dropshipsystem'}</option>
                        {if $shipping_methods}
                            {foreach from=$shipping_methods key="value" item="label"}
                            <option value="{$value|intval}" {if $value == $dss_cart.id_carrier}selected{/if}>{$label|escape:'html':'UTF-8'}</option>
                            {/foreach}
                        {/if}
                    </select>
                </div>
            </div>
        </section>
    </div>
</div>
