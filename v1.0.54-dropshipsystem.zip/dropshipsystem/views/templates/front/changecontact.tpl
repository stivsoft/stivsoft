{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div id="mydropshipaccount">
    {capture name=path}
        <a href="{$link->getPageLink('my-account', true)|escape:'html':'UTF-8'}">
            {l s='My account' mod='dropshipsystem'}
        </a>
        <span class="navigation-pipe">
            {$navigationPipe|escape:'htmlall':'UTF-8'}
        </span>
        <span class="navigation_page">
            {l s='Change your contacts' mod='dropshipsystem'}
        </span>
    {/capture}
    
    <div class="text-left">
        <h1 class="page-heading">{l s='Change your contacts' mod='dropshipsystem'}</h1>
    
        {include file="$tpl_dir./errors.tpl"}
    
        {if $dss_customer->id|intval neq 0}
            {if $dropshipper->id|intval neq 0}
            <p class="required"><sup>*</sup>{l s='Required field' mod='dropshipsystem'}</p>
            <form action="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'changecontact'], true)|escape:'html':'UTF-8'}" method="post" class="std">
                <div class="row required form-group">
                    <label class="col-sm-2" for="contact_name">{l s='Contact name' mod='dropshipsystem'} <sup>*</sup></label>
                    <div class="col-sm-5">
                        <input class="is_required validate form-control" data-validate="{$contact_validation.contact_name.validate|escape:'htmlall':'UTF-8'}" type="text" id="contact_name" name="contact_name" value="{if isset($smarty.post.contact_name)}{$smarty.post.contact_name|escape:'htmlall':'UTF-8'}{else}{if isset($dropshipper->contact_name)}{$dropshipper->contact_name|escape:'html':'UTF-8'}{/if}{/if}" />
                    </div>
                </div>
                <div class="row required form-group">
                    <label class="col-sm-2" for="contact_email">{l s='Contact email' mod='dropshipsystem'} <sup>*</sup></label>
                    <div class="col-sm-5">
                        <input class="is_required validate form-control" data-validate="{$contact_validation.contact_email.validate|escape:'htmlall':'UTF-8'}" type="text" id="contact_email" name="contact_email" value="{if isset($smarty.post.contact_email)}{$smarty.post.contact_email|escape:'htmlall':'UTF-8'}{else}{if isset($dropshipper->contact_email)}{$dropshipper->contact_email|escape:'html':'UTF-8'}{/if}{/if}" />
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-sm-2" for="contact_phone">{l s='Contact phone' mod='dropshipsystem'}</label>
                    <div class="col-sm-5">
                        <input class="validate form-control" data-validate="{$contact_validation.contact_phone.validate|escape:'htmlall':'UTF-8'}" type="text" id="contact_phone" name="contact_phone" value="{if isset($smarty.post.contact_phone)}{$smarty.post.contact_phone|escape:'htmlall':'UTF-8'}{else}{if isset($dropshipper->contact_phone)}{$dropshipper->contact_phone|escape:'html':'UTF-8'}{/if}{/if}" />
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-sm-2" for="contact_mobile">{l s='Contact mobile' mod='dropshipsystem'}</label>
                    <div class="col-sm-5">
                        <input class="validate form-control" data-validate="{$contact_validation.contact_mobile.validate|escape:'htmlall':'UTF-8'}" type="text" id="contact_mobile" name="contact_mobile" value="{if isset($smarty.post.contact_mobile)}{$smarty.post.contact_mobile|escape:'htmlall':'UTF-8'}{else}{if isset($dropshipper->contact_mobile)}{$dropshipper->contact_mobile|escape:'html':'UTF-8'}{/if}{/if}" />
                    </div>
                </div>
                <div class="row required form-group">
                    <label class="col-sm-2" for="website">{l s='Website' mod='dropshipsystem'} <sup>*</sup></label>
                    <div class="col-sm-5">
                        <input class="validate form-control" data-validate="{$contact_validation.website.validate|escape:'htmlall':'UTF-8'}" type="text" id="website" name="website" value="{if isset($smarty.post.website)}{$smarty.post.website|escape:'htmlall':'UTF-8'}{else}{if isset($dropshipper->website)}{$dropshipper->website|escape:'html':'UTF-8'}{/if}{/if}" />
                    </div>
                </div>
                <p class="submit2">
                    <input type="hidden" name="token" value="{$token|escape:'htmlall':'UTF-8'}" />
                    <button type="submit" name="submitContact" id="submitContact" class="btn btn-default button button-medium">
                        <span>
                            {l s='Save' mod='dropshipsystem'}
                            <i class="icon-chevron-right right"></i>
                        </span>
                    </button>
                </p>
            </form>
            {else}
                {l s='You have not access to this page.' mod='dropshipsystem'}
            {/if}
        {/if}
        <div class="clearfix main-page-indent">
            <ul class="footer_links clearfix">
                <li>
                    <a class="btn btn-default button button-small" href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', array(), true)|escape:'html':'UTF-8'}">
                        <span>
                            <i class="icon-chevron-left"></i>{l s='Back to Your Account' mod='dropshipsystem'}
                        </span>
                    </a>
                </li>
                <li>
                    <a class="btn btn-default button button-small" href="{$base_dir|escape:'html':'UTF-8'}">
                        <span>
                            <i class="icon-chevron-left"></i>{l s='Home' mod='dropshipsystem'}
                        </span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
