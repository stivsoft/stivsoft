{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{capture name=path}
    <a href="{$link->getPageLink('my-account', true)|escape:'html':'UTF-8'}">
        {l s='My account' mod='dropshipsystem'}
    </a>
    <span class="navigation-pipe">
        {$navigationPipe|escape:'htmlall':'UTF-8'}
    </span>
    <span class="navigation_page">
        {l s='Credit history' mod='dropshipsystem'}
    </span>
{/capture}

<div class="text-left">
    <h1 class="page-heading">{l s='Credit history' mod='dropshipsystem'}</h1>

    {include file="$tpl_dir./errors.tpl"}

    {if $dss_customer->id|intval neq 0}
        {if $dropshipper->id|intval neq 0}
        <div class="box">
           {if $paymentshistory && count($paymentshistory)}
                <table id="payments-history" class="table footab">
                    <thead>
                        <tr>
                            <th class="first_item" data-sort-ignore="true">{l s='Order reference' mod='dropshipsystem'}</th>
                            <th class="item">{l s='Date' mod='dropshipsystem'}</th>
                            <th class="item">{l s='Description' mod='dropshipsystem'}</th>
                            <th data-hide="price" class="item">{l s='Price' mod='dropshipsystem'}</th>
                            <th class="item">{l s='Status' mod='dropshipsystem'}</th>
                            <th data-sort-ignore="true" data-hide="phone,tablet" class="item">{l s='Invoice' mod='dropshipsystem'}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {foreach from=$paymentshistory item=payment name=myLoop}
                            <tr class="{if $smarty.foreach.myLoop.first}first_item{elseif $smarty.foreach.myLoop.last}last_item{else}item{/if} {if $smarty.foreach.myLoop.index % 2}alternate_item{/if}">
                                <td class="history_link bold">
                                    <a class="color-myaccount" href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'orderdetails', 'id_order' => "{$payment.id_order|intval}"], true)|escape:'html':'UTF-8'}">
                                        {Order::getUniqReferenceOf($payment.id_order)|escape:'htmlall':'UTF-8'}
                                    </a>
                                </td>
                                <td data-value="{$payment.request_date|escape:'htmlall':'UTF-8'|regex_replace:"/[\-\:\ ]/":""}" class="history_date bold">
                                    <a id="creditdetails" class="color-myaccount" data-value="{$payment.id_payment_history|intval}" rel="nofollow" href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'creditdetails', 'content_only' => 1, 'id_payment' => $payment.id_payment_history|intval], true)|escape:'html':'UTF-8'}">
                                        {dateFormat date=$payment.request_date full=0}
                                    </a>
                                </td>
                                <td>
                                    {if $payment.status == 'accepted'}
                                        {if $payment.id_order && !$payment.id_operator}
                                            {l s='"%s" has been processed' sprintf=$payment.product_name mod='dropshipsystem'}
                                        {else}
                                            {l s='Credit has been processed by the operator' sprintf=$payment.product_name mod='dropshipsystem'}
                                        {/if}
                                    {elseif $payment.status == 'pending'}
                                        {l s='"%s" has failed and not processed' sprintf=$payment.product_name mod='dropshipsystem'}
                                    {elseif $payment.status == 'rejected'}
                                        {l s='"%s" has failed and not processed' sprintf=$payment.product_name mod='dropshipsystem'}
                                    {elseif $payment.status == 'error'} 
                                        {if $payment.id_order && !$payment.id_operator}
                                            {l s='"%s" has failed and cannot be processed' sprintf=$payment.product_name mod='dropshipsystem'}
                                        {else}
                                            {l s='Credit has failed and cannot be processed by the operator' sprintf=$payment.product_name mod='dropshipsystem'}
                                        {/if}
                                    {/if}
                                </td>
                                <td class="history_price" data-value="{$payment.buyed_credit|floatval}">
                                    <span class="price">
                                        {displayPrice price=$payment.buyed_credit currency=$payment.currency no_utf8=false convert=false}
                                    </span>
                                </td>
                                <td{if isset($payment.status)} data-value="{$payment.status|escape:'htmlall':'UTF-8'}"{/if} class="history_state">
                                    {if isset($payment.status)}{$payment.status|escape:'html':'UTF-8'}{/if}
                                </td>
                                <td class="history_invoice">
                                    {if (isset($payment.id_order) && $payment.id_order) && isset($invoiceAllowed) && $invoiceAllowed == true}
                                        <a class="link-button" href="{$link->getPageLink('pdf-invoice', true, NULL, "id_order={$payment.id_order}")|escape:'html':'UTF-8'}" title="{l s='Invoice' mod='dropshipsystem'}" target="_blank">
                                            <i class="icon-file-text large"></i>{l s='PDF' mod='dropshipsystem'}
                                        </a>
                                    {else}
                                        -
                                    {/if}
                                </td>
                            </tr>
                        {/foreach}
                    </tbody>
                </table>
                <div id="block-order-detail" class="unvisible">&nbsp;</div>
            {else}
                <p class="alert alert-warning">{l s='You have not placed any credit orders.' mod='dropshipsystem'}</p>
            {/if}
        </div>
        {else}
            {l s='You have not access to this page.' mod='dropshipsystem'}
        {/if}
    {/if}
    <div class="clearfix main-page-indent">
        <ul class="footer_links clearfix">
            <li>
                <a class="btn btn-default button button-small" href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', array(), true)|escape:'html':'UTF-8'}">
                    <span>
                        <i class="icon-chevron-left"></i>{l s='Back to Your Account' mod='dropshipsystem'}
                    </span>
                </a>
            </li>
            <li>
                <a class="btn btn-default button button-small" href="{$base_dir|escape:'html':'UTF-8'}">
                    <span>
                        <i class="icon-chevron-left"></i>{l s='Home' mod='dropshipsystem'}
                    </span>
                </a>
            </li>
        </ul>
    </div>
</div>
{strip}
{addJsDef dss_ajaxurl=$link->getModuleLink('dropshipsystem', 'mydropshipaccount', array(), true)|escape:'quotes':'UTF-8'}
{addJsDefL name=err_invalid_payment}{l s='Invalid payment selected' mod='dropshipsystem' js=1}{/addJsDefL}
{/strip}
