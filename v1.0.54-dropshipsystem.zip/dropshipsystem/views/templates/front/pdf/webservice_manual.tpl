{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<style type="text/css">
table { font-size: 8pt; }
table td.codehead { font-size: 8pt; }
table td.tablehead { font-size: 10pt; height:15px; }
table.specific td { border-style:solid solid solid solid; border-width:0.5rem 0.5rem 0.5rem 0.5rem; }
table.code td { background-color:#f8f8f8; font-size:8pt; border-style:solid solid solid solid; border-width:0.5rem 0.5rem 0.5rem 0.5rem; }
table.code td.request { border-color:#c90101; }
table.code td.response { border-color:#0d00b9; }
pre { color:#3f3b36; width:100%; }
pre font { color:#ff0000; }
pre span { color:#0000ff; }
pre label { color:#a0a0a0; }
</style>

{if isset($first_page_text) && strlen($first_page_text) > 0}
    {html_entity_decode(($first_page_text|escape:'htmlall':'UTF-8'), $smarty.const.ENT_QUOTES)}
    <div style="page-break-before:always;"></div>
{/if}

<h1>API Test</h1>
<p>{l s='This method is for test the personal credentials only. If the response is "OK" your credential are valid, if the response is "ERROR" your credential are not valid or maybe there are some issue with your supplier.' mod='dropshipsystem' pdf='true'}</p>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Request:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="request">
<pre>
{$base_url|escape:'htmlall':'UTF-8'}/ws?action=<font>apitest</font>&amp;u=<span>&lt;{l s='YOUR USERNAME' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;p=<span>&lt;{l s='YOUR PASSWORD' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;s=<span>&lt;{l s='YOUR SECRET KEY' mod='dropshipsystem' pdf='true'}&gt;</span>
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="response">
<pre>
&lt;?xml version=&#39;1.0&#39; encoding=&#39;UTF-8&#39;?&gt;<br>
&lt;apitest&gt;OK&lt;/apitest&gt;&nbsp;&nbsp;<label>&lt;--&nbsp;{l s='If the test is valid, the value OK will be received.' mod='dropshipsystem' pdf='true'}</label>
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="tablehead">
            {l s='Specific XML response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="specific" cellpadding="3" cellspacing="0">
                <tr>
                    <td width="20%">xml</td>
                    <td>version=1.0</td>
                </tr>
                <tr>
                    <td>encoding</td>
                    <td>UTF-8</td>
                </tr>
                <tr>
                    <td>apitest</td>
                    <td>{l s='If the test is valid, the value OK will be received.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<div style="page-break-before:always;"></div>


<h1>Get Info</h1>
<p>

</p>

<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Request:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="request">
<pre>
{$base_url|escape:'htmlall':'UTF-8'}/ws?action=<font>getInfo</font>&amp;u=<span>&lt;{l s='YOUR USERNAME' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;p=<span>&lt;{l s='YOUR PASSWORD' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;s=<span>&lt;{l s='YOUR SECRET KEY' mod='dropshipsystem' pdf='true'}&gt;</span>
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="response">
<pre>
&lt;?xml version=&#39;1.0&#39; encoding=&#39;UTF-8&#39;?&gt;<br>
&lt;infos&gt;<br>
    &lt;lang id=&quot;0&quot; iso=&quot;it&quot;&gt;Italiano (Italian)&lt;/lang&gt;<br>
    &lt;lang id=&quot;1&quot; iso=&quot;en&quot;&gt;Inglese (English)&lt;/lang&gt;<br>
    &lt;shop_name&gt;{$shop_name|escape:'htmlall':'UTF-8'}&lt;/shop_name&gt;<br>
    &lt;currency&gt;EUR&lt;/currency&gt;<br>
    &lt;payment_type&gt;prepayed&lt;/payment_type&gt;<br>
    &lt;current_credit&gt;589.04&lt;/current_credit&gt;<br>
    &lt;tax_percent&gt;22&lt;/tax_percent&gt;<br>
    &lt;last_order&gt;2016-08-27 14:39:19&lt;/last_order&gt;<br>
    &lt;expiration_date&gt;2017-12-31&lt;/expiration_date&gt;<br>
    &lt;categories&gt;9&lt;/categories&gt;<br>
    &lt;shipping_methods&gt;<br>
        &lt;shipping id=&quot;1&quot;&gt;<br>
            &lt;name&gt;{l s='Express courier' mod='dropshipsystem' pdf='true'}&lt;/name&gt;<br>
        &lt;/shipping&gt;<br>
        &lt;shipping id=&quot;2&quot;&gt;<br>
            &lt;name&gt;{l s='Express courier with appointment' mod='dropshipsystem' pdf='true'}&lt;/name&gt;<br>
        &lt;/shipping&gt;<br>
        &lt;shipping id=&quot;3&quot;&gt;<br>
            &lt;name&gt;{l s='Stock pickup' mod='dropshipsystem' pdf='true'}&lt;/name&gt;<br>
        &lt;/shipping&gt;<br>
    &lt;/shipping_methods&gt;<br>
    &lt;attributes_groups&gt;<br>
        &lt;attribute_group&gt;<br>
            &lt;name&gt;{l s='Color' mod='dropshipsystem' pdf='true'}&lt;/name&gt;<br>
        &lt;/attribute_group&gt;<br>
        &lt;attribute_group&gt;<br>
            &lt;name&gt;{l s='Size' mod='dropshipsystem' pdf='true'}&lt;/name&gt;<br>
        &lt;/attribute_group&gt;<br>
    &lt;/attributes_groups&gt;<br>
&lt;/infos&gt;
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="tablehead">
            {l s='Specific XML response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="specific" cellpadding="3" cellspacing="0">
                <tr>
                    <td width="20%">xml</td>
                    <td>version=1.0</td>
                </tr>
                <tr>
                    <td>encoding</td>
                    <td>UTF-8</td>
                </tr>
                <tr>
                    <td>infos</td>
                    <td>{l s='The container tag for info' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>lang</td>
                    <td>
                        {l s='Attributes' mod='dropshipsystem' pdf='true'}:
                        <ul>
                            <li><i>id</i>: {l s='Index id of language' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>iso</i>: {l s='2 char ISO for language. (Es. IT, EN, DE)' mod='dropshipsystem' pdf='true'}</li>
                        </ul>
                        <br>
                        {l s='Name of language' mod='dropshipsystem' pdf='true'}
                    </td>
                </tr>
                <tr>
                    <td>shop_name</td>
                    <td>{l s='The name of the supplier' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>currency</td>
                    <td>{l s='Currency used for account' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>payment_type</td>
                    <td>{l s='Define the type of contract with your supplier' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>current_credit</td>
                    <td>{l s='The current credit for prepayed accounts' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>tax_percent</td>
                    <td>{l s='Tax in % for your contract' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>last_order</td>
                    <td>{l s='Date of your last order to the supplier' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>expiration_date</td>
                    <td>{l s='Expiration date of customer contract ("blank" for not applicable)' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>categories</td>
                    <td>{l s='Numbers of accessible categories' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>shipping_methods</td>
                    <td>{l s='Container tag of the shipping list' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>shipping</td>
                    <td>
                        {l s='Attributes' mod='dropshipsystem' pdf='true'}:
                        <ul>
                            <li><i>id</i>: {l s='Index id of the shipping type' mod='dropshipsystem' pdf='true'}</li>
                        </ul>
                        <br>
                        name: {l s='Name of shipping type' mod='dropshipsystem' pdf='true'}
                    </td>
                </tr>
                <tr>
                    <td>attributes_groups</td>
                    <td>{l s='Container tag of the attributes list' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>attribute_group</td>
                    <td>
                        name: {l s='Reference name of attribute' mod='dropshipsystem' pdf='true'}<br>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<div style="page-break-before:always;"></div>


<h1>Get Categories</h1>
<p>

</p>

<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Request:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="request">
<pre>
{$base_url|escape:'htmlall':'UTF-8'}/ws?action=<font>getCategories</font>&amp;u=<span>&lt;{l s='YOUR USERNAME' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;p=<span>&lt;{l s='YOUR PASSWORD' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;s=<span>&lt;{l s='YOUR SECRET KEY' mod='dropshipsystem' pdf='true'}&gt;</span>
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="response">
<pre>
&lt;?xml version=&#39;1.0&#39; encoding=&#39;UTF-8&#39;?&gt;<br>
&lt;categories&gt;<br>
    &lt;category&gt;<br>
        &lt;parent&gt;&lt;/parent&gt;<br>
        &lt;reference&gt;FAL&lt;/reference&gt;<br>
        &lt;name lang=&quot;it&quot;&gt;Falli&lt;/name&gt;<br>
        &lt;name lang=&quot;en&quot;&gt;Falli&lt;/name&gt;<br>
    &lt;/category&gt;<br>
    &lt;category&gt;<br>
        ...<br>
    &lt;/category&gt;<br>
&lt;/categories&gt;
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="tablehead">
            {l s='Specific XML response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="specific" cellpadding="3" cellspacing="0">
                <tr>
                    <td width="20%">xml</td>
                    <td>version=1.0</td>
                </tr>
                <tr>
                    <td>encoding</td>
                    <td>UTF-8</td>
                </tr>
                <tr>
                    <td>categories</td>
                    <td>{l s='The container tag for categories' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>category</td>
                    <td>{l s='The category tag group' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>parent</td>
                    <td>{l s='The parent code of category' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>reference</td>
                    <td>{l s='The unique code of category' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>name</td>
                    <td>{l s='The name of category' mod='dropshipsystem' pdf='true'}</td>
                </tr>
            </table>
        </td>
    </tr>
</table>

<div style="page-break-before:always;"></div>


<h1>Get Quantities</h1>
<p>

</p>

<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Request:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="request">
<pre>
{$base_url|escape:'htmlall':'UTF-8'}/ws?action=<font>getQuantities</font>&amp;u=<span>&lt;{l s='YOUR USERNAME' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;p=<span>&lt;{l s='YOUR PASSWORD' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;s=<span>&lt;{l s='YOUR SECRET KEY' mod='dropshipsystem' pdf='true'}&gt;</span>
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="response">
<pre>
&lt;?xml version=&#39;1.0&#39; encoding=&#39;UTF-8&#39;?&gt;<br>
&lt;quantities&gt;<br>
    &lt;quantity&gt;<br>
        &lt;reference&gt;00100723&lt;/reference&gt;<br>
        &lt;active&gt;1&lt;/active&gt;<br>
        &lt;quantity&gt;10&lt;/quantity&gt;<br>
        &lt;available_for_order&gt;1&lt;/available_for_order&gt;<br>
        &lt;available_date&gt;0000-00-00&lt;/available_date&gt;<br>
    &lt;/quantity&gt;<br>
    &lt;quantity&gt;<br>
        ...<br>
    &lt;/quantity&gt;<br>
&lt;quantities&gt;
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="tablehead">
            {l s='Specific XML response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="specific" cellpadding="3" cellspacing="0">
                <tr>
                    <td width="20%">xml</td>
                    <td>version=1.0</td>
                </tr>
                <tr>
                    <td>encoding</td>
                    <td>UTF-8</td>
                </tr>
                <tr>
                    <td>quantities</td>
                    <td>{l s='The container tag for quantities' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>quantity</td>
                    <td>{l s='The quantity tag group' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>reference</td>
                    <td>{l s='The unique code of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>active</td>
                    <td>{l s='If value is 1 the product is active' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>quantity</td>
                    <td>{l s='Get the quantity of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>available_for_order</td>
                    <td>{l s='If value is 1 the product is available for order' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>available_date</td>
                    <td>{l s='Get the available date of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<div style="page-break-before:always;"></div>


<h1>Check Products</h1>
<p>

</p>

<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Request:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="request">
<pre>
{$base_url|escape:'htmlall':'UTF-8'}/ws?action=<font>checkProducts</font>&amp;u=<span>&lt;{l s='YOUR USERNAME' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;p=<span>&lt;{l s='YOUR PASSWORD' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;s=<span>&lt;{l s='YOUR SECRET KEY' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;items=<span>00100061</span>,<span>00100062</span>,ecc..
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="response">
<pre>
&lt;?xml version=&#39;1.0&#39; encoding=&#39;UTF-8&#39;?&gt;<br>
&lt;products&gt;<br>
    &lt;product&gt;<br>
        &lt;reference&gt;00100061&lt;/reference&gt;<br>
        &lt;active&gt;1&lt;/active&gt;<br>
        &lt;quantity&gt;10&lt;/quantity&gt;<br>
        &lt;available_for_order&gt;1&lt;/available_for_order&gt;<br>
        &lt;available_date&gt;0000-00-00&lt;/available_date&gt;<br>
    &lt;/product&gt;<br>
    &lt;product&gt;<br>
        &lt;reference&gt;00100062&lt;/reference&gt;<br>
        &lt;error&gt;Invalid product&lt;/error&gt;<br>
    &lt;/product&gt;<br>
&lt;/products&gt;
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="tablehead">
            {l s='Specific XML response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="specific" cellpadding="3" cellspacing="0">
                <tr>
                    <td width="20%">xml</td>
                    <td>version=1.0</td>
                </tr>
                <tr>
                    <td>encoding</td>
                    <td>UTF-8</td>
                </tr>
                <tr>
                    <td>products</td>
                    <td>{l s='The container tag for products' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>product</td>
                    <td>{l s='The product tag group' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>reference</td>
                    <td>{l s='The unique code of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>active</td>
                    <td>{l s='If value is 1 the product is active' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>quantity</td>
                    <td>{l s='Get the quantity of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>available_for_order</td>
                    <td>{l s='If value is 1 the product is available for order' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>available_date</td>
                    <td>{l s='Get the available date of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>error</td>
                    <td>{l s='If the requested product is invalid, an error message will be returned' mod='dropshipsystem' pdf='true'}</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<div style="page-break-before:always;"></div>


<h1>Get Products</h1>
<p>

</p>

<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Request:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="request">
<pre>
{$base_url|escape:'htmlall':'UTF-8'}/ws?action=<font>getProducts</font>&amp;u=<span>&lt;{l s='YOUR USERNAME' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;p=<span>&lt;{l s='YOUR PASSWORD' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;s=<span>&lt;{l s='YOUR SECRET KEY' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;categoryid=<span>&lt;{l s='CATEGORY ID' mod='dropshipsystem' pdf='true'}&gt;</span>
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="response">
<pre>
&lt;?xml version=&#39;1.0&#39; encoding=&#39;UTF-8&#39;?&gt;<br>
&lt;products&gt;<br>
    &lt;product&gt;<br>
        &lt;reference&gt;00100061&lt;/reference&gt;<br>
        &lt;category/&gt;<br>
        &lt;name lang=&quot;it&quot;&gt;Giarrettiera Fucsia Twisted Leg Garter&lt;/name&gt;<br>
        &lt;name lang=&quot;en&quot;&gt;Giarrettiera Fucsia Twisted Leg Garter&lt;/name&gt;<br>
        &lt;ean13&gt;4890808018736&lt;/ean13&gt;<br>
        &lt;upc/&gt;<br>
        &lt;description lang=&quot;it&quot;&gt;&lt;/description&gt;<br>
        &lt;description lang=&quot;en&quot;&gt;&lt;/description&gt;<br>
        &lt;images&gt;<br>
            &lt;image&gt;<br>
                &lt;url&gt;{$base_url|escape:'htmlall':'UTF-8'}/1/image1.jpg&lt;/url&gt;<br>
            &lt;/image&gt;<br>
            &lt;image&gt;<br>
                ...<br>
            &lt;/image&gt;<br>
        &lt;/images&gt;<br>
        &lt;attributes&gt;<br>
            &lt;attribute&gt;<br>
                &lt;group_name lang=&quot;it&quot;&gt;size&lt;/group_name&gt;<br>
                &lt;group_name lang=&quot;en&quot;&gt;size&lt;/group_name&gt;<br>
                &lt;attribute_name lang=&quot;it&quot;&gt;UNICA&lt;/attribute_name&gt;<br>
                &lt;attribute_name lang=&quot;en&quot;&gt;UNICA&lt;/attribute_name&gt;<br>
                &lt;reference&gt;00100061&lt;/reference&gt;<br>
                &lt;ean13/&gt;<br>
                &lt;upc/&gt;<br>
                &lt;quantity&gt;999&lt;/quantity&gt;<br>
                &lt;weight&gt;0&lt;/weight&gt;<br>
                &lt;available_date&gt;0000-00-00&lt;/available_date&gt;<br>
            &lt;/attribute&gt;<br>
        &lt;/attributes&gt;<br>
        &lt;accessories&gt;<br>
            &lt;references&gt;012341,012342,0123453&lt;/references&gt;<br>
        &lt;/accessories/&gt;<br>
        &lt;features&gt;<br>
            &lt;feature&gt;<br>
                &lt;name lang=&quot;it&quot;&gt;COLORE&lt;/name&gt;<br>
                &lt;name lang=&quot;en&quot;&gt;COLORE&lt;/name&gt;<br>
                &lt;value lang=&quot;it&quot;&gt;FUCSIA&lt;/value&gt;<br>
                &lt;value lang=&quot;en&quot;&gt;FUCSIA&lt;/value&gt;<br>
            &lt;/feature&gt;<br>
            &lt;feature&gt;<br>
                ...<br>
            &lt;/feature&gt;<br>
        &lt;/features&gt;<br>
        &lt;quantity&gt;999&lt;/quantity&gt;<br>
        &lt;wholesale_price&gt;5.2418035&lt;/wholesale_price&gt;<br>
        &lt;base_price&gt;10.483607&lt;/base_price&gt;<br>
        &lt;price&gt;10.483607&lt;/price&gt;<br>
        &lt;width&gt;0&lt;/width&gt;<br>
        &lt;height&gt;0&lt;/height&gt;<br>
        &lt;depth&gt;0&lt;/depth&gt;<br>
        &lt;weight&gt;0&lt;/weight&gt;<br>
        &lt;out_of_stock&gt;2&lt;/out_of_stock&gt;<br>
        &lt;active&gt;1&lt;/active&gt;<br>
        &lt;available_for_order&gt;1&lt;/available_for_order&gt;<br>
        &lt;available_date&gt;0000-00-00&lt;/available_date&gt;<br>
        &lt;manufacturer_name&gt;ELECTRIC LINGERIE&lt;/manufacturer_name&gt;<br>
        &lt;last_update&gt;2016-07-11 19:09:27&lt;/last_update&gt;<br>
    &lt;/product&gt;<br>
    &lt;product&gt;<br>
        &lt;reference&gt;00100062&lt;/reference&gt;<br>
        ...<br>
    &lt;/product&gt;<br>
&lt;/products&gt;
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="tablehead">
            {l s='Specific XML response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="specific" cellpadding="3" cellspacing="0">
                <tr>
                    <td width="20%">xml</td>
                    <td>version=1.0</td>
                </tr>
                <tr>
                    <td>encoding</td>
                    <td>UTF-8</td>
                </tr>
                <tr>
                    <td>products</td>
                    <td>{l s='The container tag for products' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>product</td>
                    <td>{l s='The product tag group' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>reference</td>
                    <td>{l s='The unique code of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>category</td>
                    <td>{l s='Default category of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>name</td>
                    <td>{l s='Name of product (Multilanguage)' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>ean13</td>
                    <td>{l s='EAN13 of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>upc</td>
                    <td>{l s='UPC of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>description</td>
                    <td>{l s='Description of product (Multilanguage)' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>images</td>
                    <td>{l s='The container tag for images of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>image</td>
                    <td>{l s='The image product tag group' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>url</td>
                    <td>{l s='The url of the product image' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>attributes</td>
                    <td>{l s='The container tag for product attributes' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>attribute</td>
                    <td>{l s='The product attribute tag group' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>group_name</td>
                    <td>{l s='Name of attribute group (Multilanguage)' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>attribute_name</td>
                    <td>{l s='Name of attribute (Multilanguage)' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>reference</td>
                    <td>{l s='The unique code of product attribute' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>ean13</td>
                    <td>{l s='EAN13 of product attribute' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>upc</td>
                    <td>{l s='UPC of product attribute' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>quantity</td>
                    <td>{l s='Get the quantity of product attribute' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>weight</td>
                    <td>{l s='Get the weight of product attribute' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>available_date</td>
                    <td>{l s='Get the available date of product attribute' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>accessories</td>
                    <td>{l s='Contains le reference list of products assigned to the main product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>references</td>
                    <td>{l s='Related references code of product accessories (comma separated ",")' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>features</td>
                    <td>{l s='The container tag for product features' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>feature</td>
                    <td>{l s='The product features tag group' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>name</td>
                    <td>{l s='Name of product feature (Multilanguage)' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>value</td>
                    <td>{l s='Value of product feature (Multilanguage)' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>quantity</td>
                    <td>{l s='Get the total quantity of product (Attributes included)' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>wholesale_price</td>
                    <td>{l s='The wholesale price of product (Vat. excl.)' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>base_price</td>
                    <td>{l s='The base price of product (Vat. excl.)' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>price</td>
                    <td>{l s='The price of product (Vat. excl.)' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>width</td>
                    <td>{l s='Width of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>height</td>
                    <td>{l s='Height of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>depth</td>
                    <td>{l s='Depth of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>weight</td>
                    <td>{l s='Weight of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>out_of_stock</td>
                    <td>{l s='If value is 1 the product is temporarily not available' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>active</td>
                    <td>{l s='If value is 1 the product is active' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>available_for_order</td>
                    <td>{l s='If value is 1 the product is available for order' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>available_date</td>
                    <td>{l s='Get the available date of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>manufacturer_name</td>
                    <td>{l s='Manufacturer of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>last_update</td>
                    <td>{l s='Date of last update of product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<div style="page-break-before:always;"></div>


<h1>Get Order</h1>
<p>

</p>

<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Request:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="request">
<pre>
{$base_url|escape:'htmlall':'UTF-8'}/ws?action=<font>getOrder</font>&amp;u=<span>&lt;{l s='YOUR USERNAME' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;p=<span>&lt;{l s='YOUR PASSWORD' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;s=<span>&lt;{l s='YOUR SECRET KEY' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;ref=<span>&lt;{l s='ORDER REFERENCE' mod='dropshipsystem' pdf='true'}&gt;</span>
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="response">
<pre>
&lt;?xml version=&#39;1.0&#39; encoding=&#39;UTF-8&#39;?&gt;<br>
&lt;order&gt;<br>
    &lt;id&gt;1&lt;/id&gt;<br>
    &lt;reference&gt;PNCAJLQWC&lt;/reference&gt;<br>
    &lt;date&gt;2016-01-12 11:02:39&lt;/date&gt;<br>
    &lt;shipping_method&gt;0&lt;/shipping_method&gt;<br>
    &lt;total_products&gt;80.310000&lt;/total_products&gt;<br>
    &lt;total_shipping&gt;0.000000&lt;/total_shipping&gt;<br>
    &lt;total_discounts&gt;0.000000&lt;/total_discounts&gt;<br>
    &lt;total&gt;80.310000&lt;/total&gt;<br>
    &lt;currency&gt;EUR&lt;/currency&gt;<br>
    &lt;current_state&gt;PAYMENT_SUCCESS&lt;/current_state&gt;<br>
    &lt;payment_link&gt;&lt;/payment_link&gt;<br>
    &lt;tracking_link&gt;&lt;/tracking_link&gt;<br>
&lt;/order&gt;
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="tablehead">
            {l s='Specific XML response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="specific" cellpadding="3" cellspacing="0">
                <tr>
                    <td width="20%">xml</td>
                    <td>version=1.0</td>
                </tr>
                <tr>
                    <td>encoding</td>
                    <td>UTF-8</td>
                </tr>
                <tr>
                    <td>order</td>
                    <td>{l s='The container tag for order' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>id</td>
                    <td>{l s='Supplier order id number' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>reference</td>
                    <td>{l s='Supplier order reference code' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>date</td>
                    <td>{l s='Order date' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>shipping_method</td>
                    <td>{l s='Shipping method for order.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>total_products</td>
                    <td>{l s='Total products price.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>total_shipping</td>
                    <td>{l s='Total shipping price.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>total_discounts</td>
                    <td>{l s='Total discounts price.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>total</td>
                    <td>{l s='Total order price.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>currency</td>
                    <td>{l s='Currency for the order.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>current_state</td>
                    <td>{l s='State of order.' mod='dropshipsystem' pdf='true'}
                        <ul>
                            <li><i>PENDING_PAYMENT</i>: {l s='Waiting for payment' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>PAYMENT_SUCCESS</i>: {l s='Payment completed' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>PREPARATION_IN_PROGRESS</i>: {l s='Order preparation in progress' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>SHIPPING_IN_PROGRESS</i>: {l s='Order shipping in progress' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>DELIVERED</i>: {l s='Order delivered' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>CANCELLED</i>: {l s='Order cancelled' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>REFUNDED</i>: {l s='Order refunded' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>OUTOFSTOCK_PAID</i>: {l s='Order payed with out of stock products' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>OUTOFSTOCK_UNPAID</i>: {l s='Order waiting payment with out of stock products' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>ERROR</i>: {l s='Order error' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>UNKNOW_STATUS</i>: {l s='Unknow order status' mod='dropshipsystem' pdf='true'}</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <td>payment_link</td>
                    <td>{l s='Link to the order payment page' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>tracking_link</td>
                    <td>{l s='Link to the order shipping tracking' mod='dropshipsystem' pdf='true'}</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<div style="page-break-before:always;"></div>


<h1>Set Order</h1>
<p>{l s='This method is used to send the order to the supplier.' mod='dropshipsystem' pdf='true'}</p>

<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Request:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="request">
<pre>
{$base_url|escape:'htmlall':'UTF-8'}/ws?action=<font>setOrder</font>&amp;u=<span>&lt;{l s='YOUR USERNAME' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;p=<span>&lt;{l s='YOUR PASSWORD' mod='dropshipsystem' pdf='true'}&gt;</span>&amp;s=<span>&lt;{l s='YOUR SECRET KEY' mod='dropshipsystem' pdf='true'}&gt;</span>
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<p>{l s='To send the request, you have to prepare a POST data with an URLEncoded formatted string parameter "xmldata".' mod='dropshipsystem' pdf='true'}</p>

<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='XMLDATA Parameter:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="request">
<pre>
&lt;order&gt;<br>
    &lt;payment_status&gt;<span>PENDING_PAYMENT</span>&lt;/payment_status&gt;<br>
    &lt;payment_method&gt;<span>BANKWIRE</span>&lt;/payment_method&gt;<br>
    &lt;shipping_method&gt;<span>1</span>&lt;/shipping_method&gt;<br>
    &lt;shipping_company&gt;&lt;![CDATA[<span>Company name</span>]]&gt;&lt;/shipping_company&gt;<br>
    &lt;shipping_lastname&gt;&lt;![CDATA[<span>Last name</span>]]&gt;&lt;/shipping_lastname&gt;<br>
    &lt;shipping_firstname&gt;&lt;![CDATA[<span>First name</span>]]&gt;&lt;/shipping_firstname&gt;<br>
    &lt;shipping_address1&gt;&lt;![CDATA[<span>Shipping address, n. 123</span>]]&gt;&lt;/shipping_address1&gt;<br>
    &lt;shipping_address2&gt;&lt;![CDATA[<span>Shipping address line 2</span>]]&gt;&lt;/shipping_address2&gt;<br>
    &lt;shipping_cap&gt;&lt;![CDATA[<span>00100</span>]]&gt;&lt;/shipping_cap&gt;<br>
    &lt;shipping_city&gt;&lt;![CDATA[<span>Rome</span>]]&gt;&lt;/shipping_city&gt;<br>
    &lt;shipping_country&gt;&lt;![CDATA[<span>IT</span>]]&gt;&lt;/shipping_country&gt;<br>
    &lt;shipping_state&gt;&lt;![CDATA[<span>RM</span>]]&gt;&lt;/shipping_state&gt;<br>
    &lt;shipping_mobile&gt;&lt;![CDATA[<span>333123456</span>]]&gt;&lt;/shipping_mobile&gt;<br>
    &lt;shipping_email&gt;&lt;![CDATA[<span>xxx@yyy.com</span>]]&gt;&lt;/shipping_email&gt;<br>
    &lt;products&gt;<br>
        &lt;product&gt;<br>
            &lt;reference&gt;&lt;![CDATA[<span>00100061</span>]]&gt;&lt;/reference&gt;<br>
            &lt;quantity&gt;<span>1</span>&lt;/quantity&gt;<br>
        &lt;/product&gt;<br>
        &lt;product&gt;<br>
            &lt;reference&gt;&lt;![CDATA[<span>00100062</span>]]&gt;&lt;/reference&gt;<br>
            &lt;quantity&gt;<span>1</span>&lt;/quantity&gt;<br>
        &lt;/product&gt;<br>
    &lt;/products&gt;<br>
    &lt;comments&gt;&lt;![CDATA[<span>Order comments</span>]]&gt;&lt;/comments&gt;<br>
&lt;/order&gt;
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="tablehead">
            {l s='Specific XML request data:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="specific" cellpadding="3" cellspacing="0">
                <tr>
                    <td>order</td>
                    <td>{l s='The container tag for order' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>payment_status</td>
                    <td>{l s='Payment status for the order' mod='dropshipsystem' pdf='true'}
                        <ul>
                            <li><i>PENDING_PAYMENT</i>: {l s='Waiting for payment' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>PAYMENT_SUCCESS</i>: {l s='Payment completed' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>CANCELLED</i>: {l s='Payment cancelled' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>ERROR</i>: {l s='Payment error' mod='dropshipsystem' pdf='true'}</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <td>payment_method</td>
                    <td>{l s='Payment method for the order' mod='dropshipsystem' pdf='true'}
                        <ul>
                            <li><i>BANKWIRE</i>: {l s='Bankire payment' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>COD</i>: {l s='Cash on delivery payment' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>CHEQUE</i>: {l s='Cheque payment' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>PAYPAL</i>: {l s='PayPal payment' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>CC</i>: {l s='Credit card payment' mod='dropshipsystem' pdf='true'}</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <td>shipping_method</td>
                    <td>{l s='Shipping method for order.' mod='dropshipsystem' pdf='true'}
                        <ul>
                            <li><i>1</i>: {l s='See the method 1 of getInfo method' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>2</i>: {l s='See the method 2 of getInfo method' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>3</i>: {l s='See the method 3 of getInfo method' mod='dropshipsystem' pdf='true'}</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <td>shipping_company</td>
                    <td>{l s='Shipping company name.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>shipping_lastname</td>
                    <td>{l s='Shipping last name.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>shipping_firstname</td>
                    <td>{l s='Shipping first name.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>shipping_address1</td>
                    <td>{l s='Shipping address line 1.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>shipping_address2</td>
                    <td>{l s='Shipping address line 2.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>shipping_cap</td>
                    <td>{l s='Shipping zip code.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>shipping_city</td>
                    <td>{l s='Shipping city.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>shipping_country</td>
                    <td>{l s='Shipping country.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>shipping_state</td>
                    <td>{l s='Shipping state.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>shipping_mobile</td>
                    <td>{l s='Shipping mobile number' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>shipping_email</td>
                    <td>{l s='Shipping email address' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>products</td>
                    <td>{l s='The container tag for products' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>product</td>
                    <td>{l s='The container tag for each product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>reference</td>
                    <td>{l s='Reference code of the product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>quantity</td>
                    <td>{l s='Quantity of the product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>comments</td>
                    <td>{l s='Comment or message for the order' mod='dropshipsystem' pdf='true'}</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<div style="page-break-before:always;"></div>


<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="codehead">
            {l s='Response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="code" cellpadding="10" cellspacing="2">
                <tr>
                    <td class="response">
<pre>
&lt;?xml version=&#39;1.0&#39; encoding=&#39;UTF-8&#39;?&gt;<br>
&lt;order&gt;<br>
    &lt;id&gt;1&lt;/id&gt;<br>
    &lt;reference&gt;PNCAJLQWC&lt;/reference&gt;<br>
    &lt;date&gt;2016-01-12 11:02:39&lt;/date&gt;<br>
    &lt;shipping_method&gt;0&lt;/shipping_method&gt;<br>
    &lt;total_products&gt;80.310000&lt;/total_products&gt;<br>
    &lt;total_shipping&gt;0.000000&lt;/total_shipping&gt;<br>
    &lt;total_discounts&gt;0.000000&lt;/total_discounts&gt;<br>
    &lt;total&gt;80.310000&lt;/total&gt;<br>
    &lt;currency&gt;EUR&lt;/currency&gt;<br>
    &lt;current_state&gt;PAYMENT_SUCCESS&lt;/current_state&gt;<br>
    &lt;payment_link&gt;&lt;/payment_link&gt;<br>
    &lt;tracking_link&gt;&lt;/tracking_link&gt;<br>
    &lt;products&gt;<br>
        &lt;product&gt;<br>
            &lt;reference&gt;00100061&lt;/reference&gt;<br>
            &lt;name&gt;Giarrettiera Fucsia Twisted Leg Garter&lt;/name&gt;<br>
            &lt;quantity&gt;2&lt;/quantity&gt;<br>
            &lt;price&gt;5.2418035&lt;/price&gt;<br>
        &lt;/product&gt;<br>
        &lt;product&gt;<br>
            ...<br>
        &lt;/product&gt;<br>
    &lt;/products&gt;<br>
&lt;/order&gt;
</pre>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="tablehead">
            {l s='Specific XML response:' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="specific" cellpadding="3" cellspacing="0">
                <tr>
                    <td width="20%">xml</td>
                    <td>version=1.0</td>
                </tr>
                <tr>
                    <td>encoding</td>
                    <td>UTF-8</td>
                </tr>
                <tr>
                    <td>order</td>
                    <td>{l s='The container tag for order' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>id</td>
                    <td>{l s='Supplier order id number' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>reference</td>
                    <td>{l s='Supplier order reference code' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>date</td>
                    <td>{l s='Order date' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>shipping_method</td>
                    <td>{l s='Shipping method for order.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>total_products</td>
                    <td>{l s='Total products price.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>total_shipping</td>
                    <td>{l s='Total shipping price.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>total_discounts</td>
                    <td>{l s='Total discounts price.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>total</td>
                    <td>{l s='Total order price.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>currency</td>
                    <td>{l s='Currency for the order.' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>current_state</td>
                    <td>{l s='State of order.' mod='dropshipsystem' pdf='true'}
                        <ul>
                            <li><i>PENDING_PAYMENT</i>: {l s='Waiting for payment' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>PAYMENT_SUCCESS</i>: {l s='Payment completed' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>PREPARATION_IN_PROGRESS</i>: {l s='Order preparation in progress' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>SHIPPING_IN_PROGRESS</i>: {l s='Order shipping in progress' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>DELIVERED</i>: {l s='Order delivered' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>CANCELLED</i>: {l s='Order cancelled' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>REFUNDED</i>: {l s='Order refunded' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>OUTOFSTOCK_PAID</i>: {l s='Order payed with out of stock products' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>OUTOFSTOCK_UNPAID</i>: {l s='Order waiting payment with out of stock products' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>ERROR</i>: {l s='Order error' mod='dropshipsystem' pdf='true'}</li>
                            <li><i>UNKNOW_STATUS</i>: {l s='Unknow order status' mod='dropshipsystem' pdf='true'}</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <td>payment_link</td>
                    <td>{l s='Link to the order payment page' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>tracking_link</td>
                    <td>{l s='Link to the order shipping tracking' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>products</td>
                    <td>{l s='The container tag for products' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>product</td>
                    <td>{l s='The product tag group' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>reference</td>
                    <td>{l s='The unique code of ordered product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>name</td>
                    <td>{l s='The name of ordered product' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>quantity</td>
                    <td>{l s='The ordererd product quantity' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>price</td>
                    <td>{l s='The ordered product price' mod='dropshipsystem' pdf='true'}</td>
                </tr>
            </table>
        </td>
    </tr>
</table>


<div style="page-break-before:always;"></div>


<h1>{l s='Error definitions' mod='dropshipsystem' pdf='true'}</h1>
<p>

</p>

<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="tablehead">
            {l s='System errors' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="specific" cellpadding="3" cellspacing="0">
                <tr>
                    <td width="20%">1000</td>
                    <td>{l s='Invalid action' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>1001</td>
                    <td>{l s='Error during call webservice' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>1002</td>
                    <td>{l s='Username parameter not specified' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>1003</td>
                    <td>{l s='Password parameter not specified' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>1004</td>
                    <td>{l s='API Secret parameter not specified' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>1005</td>
                    <td>{l s='Action parameter not specified' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>1010</td>
                    <td>{l s='Your account isn\'t available at this time, please contact us' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>1011</td>
                    <td>{l s='Authentication failed' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>1012</td>
                    <td>{l s='Invalid Dropshipper profile' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>1013</td>
                    <td>{l s='Dropshipper profile is disabled' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>1014</td>
                    <td>{l s='Dropshipper profile is expired' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>1020</td>
                    <td>{l s='Category parameter not specified' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>1021</td>
                    <td>{l s='Items parameter not specified' mod='dropshipsystem' pdf='true'}</td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="tablehead">
            {l s='Categories errors' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="specific" cellpadding="3" cellspacing="0">
                <tr>
                    <td width="20%">2000</td>
                    <td>{l s='Invalid category' mod='dropshipsystem' pdf='true'}</td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td class="tablehead">
            {l s='Orders errors' mod='dropshipsystem' pdf='true'}
        </td>
    </tr>
    <tr>
        <td>
            <table class="specific" cellpadding="3" cellspacing="0">
                <tr>
                    <td width="20%">5000</td>
                    <td>{l s='Invalid order reference' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5001</td>
                    <td>{l s='Invalid product xxx' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5002</td>
                    <td>{l s='Product xxx is not available for order' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5003</td>
                    <td>{l s='Quantity value for product xxx is not valid' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5004</td>
                    <td>{l s='Quantity not available for product xxx' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5005</td>
                    <td>{l s='Minimal quantity not reached for xxx' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5006</td>
                    <td>{l s='Insufficient funds for order' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5007</td>
                    <td>{l s='Error during set new credit' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5008</td>
                    <td>{l s='Error retrive paypal link' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5009</td>
                    <td>{l s='Error retrive payment link' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5010</td>
                    <td>{l s='Error with PayPal authentication' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5011</td>
                    <td>{l s='Order reference not specified' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5012</td>
                    <td>{l s='Payment already processed for order' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5013</td>
                    <td>{l s='Error retrive paypal checkout' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5014</td>
                    <td>{l s='Error during payment confirmation' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5015</td>
                    <td>{l s='Order has been already fully payed' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5016</td>
                    <td>{l s='Authorized import is major of total order import' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5017</td>
                    <td>{l s='Error during create order' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5018</td>
                    <td>{l s='Unespected payment status' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5019</td>
                    <td>{l s='You are not authorized to get this order' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5020</td>
                    <td>
                        {l s='Missing data: xxx' mod='dropshipsystem' pdf='true'}<br>
                        {l s='Invalid data: xxx' mod='dropshipsystem' pdf='true'}
                    </td>
                </tr>
                <tr>
                    <td>5021</td>
                    <td>{l s='Products not specified' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5022</td>
                    <td>{l s='Some product are not available: xxx' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5023</td>
                    <td>{l s='Error adding product to cart' mod='dropshipsystem' pdf='true'}</td>
                </tr>
                <tr>
                    <td>5024</td>
                    <td>{l s='Error during create customer' mod='dropshipsystem' pdf='true'}</td>
                </tr>
            </table>
        </td>
    </tr>
</table>
