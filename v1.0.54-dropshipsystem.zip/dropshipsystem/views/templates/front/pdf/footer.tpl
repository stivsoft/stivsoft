{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<table style="width: 100%;">
    <tr>
        <td style="font-size: 6pt; color: #444; width:100%;">
            {if isset($footer_text)}
                {html_entity_decode(($footer_text|escape:'htmlall':'UTF-8'), $smarty.const.ENT_QUOTES)}
            {/if}
        </td>
    </tr>
</table>

