{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<table style="width: 100%;">
<tr>
    <td style="width: 50%">
        {if $logo_path}
            <img src="{$logo_path|escape:'htmlall':'UTF-8'}" style="width:{$width_logo|intval}px; height:{$height_logo|intval}px;" />
        {/if}
    </td>
    <td style="width: 50%; text-align: right;">
        <span style="font-weight: bold; font-size: 12pt; color: #444; width: 100%;">
            {l s='Drop Shipping WebService' mod='dropshipsystem' pdf='true'}<br>
            {l s='Documentation' mod='dropshipsystem' pdf='true'}
        </span>
    </td>
</tr>
</table>
