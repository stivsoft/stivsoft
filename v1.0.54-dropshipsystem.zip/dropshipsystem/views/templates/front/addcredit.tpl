{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div id="mydropshipaccount">
    <h1 class="page-heading">{l s='Add your credit' mod='dropshipsystem'}</h1>
    <form name="formAddCredit" action="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', array(), true)|escape:'html':'UTF-8'}" method="post">
        <p class="form-group credits">
            <label for="credits">{l s='Credit' mod='dropshipsystem'}</label>
            <select name="credits" class="form-control">
                <option value="0">{l s='-- Choose --' mod='dropshipsystem'}</option>
                {foreach from=$credits item=credit name=credits}
                    <option value="{$credit.reference|escape:'html':'UTF-8'}">{l s='Recharge credit' mod='dropshipsystem'} {convertPrice price=$credit.price|floatval}</option>
                {/foreach}
            </select>
        </p>
        <div class="clearfix">
            <ul class="footer_links">
                <li class="pull-right">
                    <button type="submit" name="submitAddCredit" class="btn btn-default button button-small" data-loading-text="{l s='Waiting' mod='dropshipsystem'}...">
                        <span>{l s='Confirm' mod='dropshipsystem'}<i class="icon-chevron-right right"></i></span>
                    </button>
                </li>
            </ul>
        </div>
    </form>
</div>
{strip}
{addJsDef dss_ajaxurl=$link->getModuleLink('dropshipsystem', 'mydropshipaccount', array(), true)|escape:'quotes':'UTF-8'}
{addJsDefL name=err_nocredit}{l s='No credit value has been selected' mod='dropshipsystem' js=1}{/addJsDefL}
{/strip}
