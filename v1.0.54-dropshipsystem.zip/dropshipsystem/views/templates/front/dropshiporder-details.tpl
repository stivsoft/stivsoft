{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div id="mydropshipaccount">
    {capture name=path}
        <a href="{$link->getPageLink('my-account', true)|escape:'html':'UTF-8'}">
            {l s='My account' mod='dropshipsystem'}
        </a>
        <span class="navigation-pipe">
            {$navigationPipe|escape:'htmlall':'UTF-8'}
        </span>
        <span class="navigation_page">
            {l s='Dropship Order Details' mod='dropshipsystem'}
        </span>
    {/capture}

    <h1 class="page-heading">{l s='Dropship Order Details' mod='dropshipsystem'}</h1>

    {if isset($order)}
        <div class="box box-small clearfix">
            <p class="dark">
                <strong>{l s='Order Reference %s - placed on' sprintf=$order->getUniqReference() mod='dropshipsystem'} {dateFormat date=$order->date_add full=0}</strong>
            </p>
        </div>
        <div class="info-order box">
            {if $carrier->id}<p><strong class="dark">{l s='Carrier' mod='dropshipsystem'}</strong> {if $carrier->name == "0"}{$shop_name|escape:'html':'UTF-8'}{else}{$carrier->name|escape:'html':'UTF-8'}{/if}</p>{/if}
            <p><strong class="dark">{l s='Payment method' mod='dropshipsystem'}</strong> <span class="color-myaccount">{$order->payment|escape:'html':'UTF-8'}</span></p>
            {if $invoice AND $invoiceAllowed}
            <p>
                <i class="icon-file-text"></i>
                <a target="_blank" href="{$link->getPageLink('pdf-invoice', true)|escape:'htmlall':'UTF-8'}?id_order={$order->id|intval}">{l s='Download your invoice as a PDF file.' mod='dropshipsystem'}</a>
            </p>
            {/if}
            {if !$paid}
            <p>
                <a href="{$payment_link|escape:'htmlall':'UTF-8'}" title="{l s='Pay now' mod='dropshipsystem'}" class="btn btn-primary">
                    <span>
                        {l s='Pay now' mod='dropshipsystem'}
                        <i class="icon-chevron-right right"></i>
                    </span>
                </a>
            </p>
            {/if}
        </div>

        {if count($order_history)}
        <h1 class="page-heading">{l s='Follow your order\'s status step-by-step' mod='dropshipsystem'}</h1>
        <div class="table_block">
            <table class="detail_step_by_step table table-bordered">
                <thead>
                    <tr>
                        <th class="first_item">{l s='Date' mod='dropshipsystem'}</th>
                        <th class="last_item">{l s='Status' mod='dropshipsystem'}</th>
                    </tr>
                </thead>
                <tbody>
                {foreach from=$order_history item=state name="orderStates"}
                    <tr class="{if $smarty.foreach.orderStates.first}first_item{elseif $smarty.foreach.orderStates.last}last_item{/if} {if $smarty.foreach.orderStates.index % 2}alternate_item{else}item{/if}">
                        <td class="step-by-step-date">{dateFormat date=$state.date_add full=0}</td>
                        <td><span{if isset($state.color) && $state.color} style="background-color:{$state.color|escape:'html':'UTF-8'}; border-color:{$state.color|escape:'html':'UTF-8'};"{/if} class="label{if isset($state.color) && Tools::getBrightness($state.color) > 128} dark{/if}">{$state.ostate_name|escape:'html':'UTF-8'}</span></td>
                    </tr>
                {/foreach}
                </tbody>
            </table>
        </div>
        {/if}

        {if isset($followup)}
        <p class="bold">{l s='Click the following link to track the delivery of your order' mod='dropshipsystem'}</p>
        <a href="{$followup|escape:'html':'UTF-8'}">{$followup|escape:'html':'UTF-8'}</a>
        {/if}

        <div class="adresses_bloc">
            <div class="row">
                <div class="col-xs-12 col-sm-6"{if $order->isVirtual()} style="display:none;"{/if}>
                    <ul class="address alternate_item box">
                        <li><h3 class="page-subheading">{l s='Delivery address' mod='dropshipsystem'}</h3></li>
                        {foreach from=$dlv_adr_fields name=dlv_loop item=field_item}
                            {if $field_item eq "company" && isset($address_delivery->company)}<li class="address_company">{$address_delivery->company|escape:'html':'UTF-8'}</li>
                            {elseif $field_item eq "address2" && $address_delivery->address2}<li class="address_address2">{$address_delivery->address2|escape:'html':'UTF-8'}</li>
                            {elseif $field_item eq "phone_mobile" && $address_delivery->phone_mobile}<li class="address_phone_mobile">{$address_delivery->phone_mobile|escape:'html':'UTF-8'}</li>
                            {else}
                                    {assign var=address_words value=" "|explode:$field_item}
                                    <li>{foreach from=$address_words item=word_item name="word_loop"}{if !$smarty.foreach.word_loop.first} {/if}<span class="address_{$word_item|replace:',':''}">{$deliveryAddressFormatedValues[$word_item|replace:',':'']|escape:'html':'UTF-8'}</span>{/foreach}</li>
                            {/if}
                        {/foreach}
                    </ul>
                </div>
                <div class="col-xs-12 col-sm-6">
                    <ul class="address item {if $order->isVirtual()}full_width{/if} box">
                        <li><h3 class="page-subheading">{l s='Invoice address' mod='dropshipsystem'}</h3></li>
                        {foreach from=$inv_adr_fields name=inv_loop item=field_item}
                            {if $field_item eq "company" && isset($address_invoice->company)}<li class="address_company">{$address_invoice->company|escape:'html':'UTF-8'}</li>
                            {elseif $field_item eq "address2" && $address_invoice->address2}<li class="address_address2">{$address_invoice->address2|escape:'html':'UTF-8'}</li>
                            {elseif $field_item eq "phone_mobile" && $address_invoice->phone_mobile}<li class="address_phone_mobile">{$address_invoice->phone_mobile|escape:'html':'UTF-8'}</li>
                            {else}
                                    {assign var=address_words value=" "|explode:$field_item}
                                    <li>{foreach from=$address_words item=word_item name="word_loop"}{if !$smarty.foreach.word_loop.first} {/if}<span class="address_{$word_item|replace:',':''}">{$invoiceAddressFormatedValues[$word_item|replace:',':'']|escape:'html':'UTF-8'}</span>{/foreach}</li>
                            {/if}
                        {/foreach}
                    </ul>
                </div>
            </div>
        </div>
        
        <form action="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'orderdetails', 'id_order' => "{$order->id|intval}"], true)|escape:'html':'UTF-8'}" method="post">
        <div id="order-detail-content" class="table_block table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th class="first_item">{l s='Reference' mod='dropshipsystem'}</th>
                        <th class="item">{l s='Product' mod='dropshipsystem'}</th>
                        <th class="item">{l s='Quantity' mod='dropshipsystem'}</th>
                        {if $order->hasProductReturned()}
                            <th class="item">{l s='Returned' mod='dropshipsystem'}</th>
                        {/if}
                        <th class="item">{l s='Unit price' mod='dropshipsystem'}</th>
                        <th class="last_item">{l s='Total price' mod='dropshipsystem'}</th>
                    </tr>
                </thead>
                <tfoot>
                    {if $priceDisplay && $use_tax}
                        <tr class="item">
                            <td colspan="{if $order->hasProductReturned()}5{else}4{/if}">
                                <strong>{l s='Items (tax excl.)' mod='dropshipsystem'}</strong>
                            </td>
                            <td>
                                <span class="price">{displayWtPriceWithCurrency price=$order->getTotalProductsWithoutTaxes() currency=$currency}</span>
                            </td>
                        </tr>
                    {/if}
                    <tr class="item">
                        <td colspan="{if $order->hasProductReturned()}5{else}4{/if}">
                            <strong>{l s='Items' mod='dropshipsystem'} {if $use_tax}{l s='(tax incl.)' mod='dropshipsystem'}{/if} </strong>
                        </td>
                        <td>
                            <span class="price">{displayWtPriceWithCurrency price=$order->getTotalProductsWithTaxes() currency=$currency}</span>
                        </td>
                    </tr>
                    {if $order->total_wrapping > 0}
                    <tr class="item">
                        <td colspan="{if $order->hasProductReturned()}5{else}4{/if}">
                            <strong>{l s='Total gift wrapping cost' mod='dropshipsystem'}</strong>
                        </td>
                        <td>
                            <span class="price-wrapping">{displayWtPriceWithCurrency price=$order->total_wrapping currency=$currency}</span>
                        </td>
                    </tr>
                    {/if}
                    <tr class="item">
                        <td colspan="{if $order->hasProductReturned()}5{else}4{/if}">
                            <strong>{l s='Shipping & handling' mod='dropshipsystem'} {if $use_tax}{l s='(tax incl.)' mod='dropshipsystem'}{/if} </strong>
                        </td>
                        <td>
                            <span class="price-shipping">{displayWtPriceWithCurrency price=$order->total_shipping currency=$currency}</span>
                        </td>
                    </tr>
                    <tr class="totalprice item">
                        <td colspan="{if $order->hasProductReturned()}5{else}4{/if}">
                            <strong>{l s='Total' mod='dropshipsystem'}</strong>
                        </td>
                        <td>
                            <span class="price">{displayWtPriceWithCurrency price=$order->total_paid currency=$currency}</span>
                        </td>
                    </tr>
                </tfoot>
                <tbody>
                {foreach from=$products item=product name=products}
                    {if !isset($product.deleted)}
                        {assign var='productId' value=$product.product_id}
                        {assign var='productAttributeId' value=$product.product_attribute_id}
                        {assign var='productQuantity' value=$product.product_quantity}
                        <!-- Classic products -->
                        {if $product.product_quantity > $product.customizationQuantityTotal}
                            <tr class="item">
                                <td><label for="cb_{$product.id_order_detail|intval}">{if $product.product_reference}{$product.product_reference|escape:'html':'UTF-8'}{else}--{/if}</label></td>
                                <td class="bold">
                                    <label for="cb_{$product.id_order_detail|intval}">
                                        {if $product.download_hash && $logable && $product.display_filename != '' && $product.product_quantity_refunded == 0 && $product.product_quantity_return == 0}
                                            <a href="{$link->getPageLink('get-file', true, NULL, "key={$product.filename|escape:'html':'UTF-8'}-{$product.download_hash|escape:'html':'UTF-8'}")|escape:'html':'UTF-8'}" title="{l s='Download this product' mod='dropshipsystem'}">
                                                <img src="{$img_dir|escape:'htmlall':'UTF-8'}icon/download_product.gif" class="icon" alt="{l s='Download product' mod='dropshipsystem'}" />
                                            </a>
                                            <a href="{$link->getPageLink('get-file', true, NULL, "key={$product.filename|escape:'html':'UTF-8'}-{$product.download_hash|escape:'html':'UTF-8'}")|escape:'html':'UTF-8'}" title="{l s='Download this product' mod='dropshipsystem'}"> {$product.product_name|escape:'html':'UTF-8'}</a>
                                        {else}
                                            {$product.product_name|escape:'html':'UTF-8'}
                                        {/if}
                                    </label>
                                </td>
                                <td class="return_quantity">
                                    <label for="cb_{$product.id_order_detail|intval}"><span class="order_qte_span editable">{$productQuantity|intval}</span></label>
                                </td>
                                {if $order->hasProductReturned()}
                                    <td>
                                        {$product['qty_returned']|escape:'htmlall':'UTF-8'}
                                    </td>
                                {/if}
                                <td class="price">
                                    <label for="cb_{$product.id_order_detail|intval}">
                                    {if $group_use_tax}
                                        {convertPriceWithCurrency price=$product.unit_price_tax_incl currency=$currency}
                                    {else}
                                        {convertPriceWithCurrency price=$product.unit_price_tax_excl currency=$currency}
                                    {/if}
                                    </label>
                                </td>
                                <td class="price">
                                    <label for="cb_{$product.id_order_detail|intval}">
                                    {if $group_use_tax}
                                        {convertPriceWithCurrency price=$product.total_price_tax_incl currency=$currency}
                                    {else}
                                        {convertPriceWithCurrency price=$product.total_price_tax_excl currency=$currency}
                                    {/if}
                                    </label>
                                </td>
                            </tr>
                        {/if}
                    {/if}
                {/foreach}
                </tbody>
            </table>
        </div>
        </form>
        {assign var='carriers' value=$order->getShipping()}
        {if $carriers|count > 0 && isset($carriers.0.carrier_name) && $carriers.0.carrier_name}
            <table class="table table-bordered footab">
                <thead>
                    <tr>
                        <th class="first_item">{l s='Date' mod='dropshipsystem'}</th>
                        <th class="item" data-sort-ignore="true">{l s='Carrier' mod='dropshipsystem'}</th>
                        <th data-hide="phone" class="item">{l s='Weight' mod='dropshipsystem'}</th>
                        <th data-hide="phone" class="item">{l s='Shipping cost' mod='dropshipsystem'}</th>
                        <th data-hide="phone" class="last_item" data-sort-ignore="true">{l s='Tracking number' mod='dropshipsystem'}</th>
                    </tr>
                </thead>
                <tbody>
                    {foreach from=$carriers item=line}
                    <tr class="item">
                        <td data-value="{$line.date_add|escape:'htmlall':'UTF-8'|regex_replace:"/[\-\:\ ]/":""}">{dateFormat date=$line.date_add full=0}</td>
                        <td>{$line.carrier_name|escape:'htmlall':'UTF-8'}</td>
                        <td data-value="{if $line.weight > 0}{$line.weight|escape:'htmlall':'UTF-8'|string_format:"%.3f"}{else}0{/if}">{if $line.weight > 0}{$line.weight|escape:'htmlall':'UTF-8'|string_format:"%.3f"} {Configuration::get('PS_WEIGHT_UNIT')|escape:'htmlall':'UTF-8'}{else}-{/if}</td>
                        <td data-value="{if $order->getTaxCalculationMethod() == $smarty.const.PS_TAX_INC}{$line.shipping_cost_tax_incl|floatval}{else}{$line.shipping_cost_tax_excl|floatval}{/if}">{if $order->getTaxCalculationMethod() == $smarty.const.PS_TAX_INC}{displayPrice price=$line.shipping_cost_tax_incl currency=$currency->id}{else}{displayPrice price=$line.shipping_cost_tax_excl currency=$currency->id}{/if}</td>
                        <td>
                            <span class="shipping_number_show">{if $line.tracking_number}{if $line.url && $line.tracking_number}<a href="{$line.url|escape:'htmlall':'UTF-8'|replace:'@':$line.tracking_number}">{$line.tracking_number|escape:'htmlall':'UTF-8'}</a>{else}{$line.tracking_number|escape:'htmlall':'UTF-8'}{/if}{else}-{/if}</span>
                        </td>
                    </tr>
                    {/foreach}
                </tbody>
            </table>
        {/if}
        {if count($messages)}
        <h3 class="page-heading">{l s='Messages' mod='dropshipsystem'}</h3>
         <div class="table_block">
            <table class="detail_step_by_step table table-bordered">
                <thead>
                    <tr>
                        <th class="first_item" style="width:150px;">{l s='From' mod='dropshipsystem'}</th>
                        <th class="last_item">{l s='Message' mod='dropshipsystem'}</th>
                    </tr>
                </thead>
                <tbody>
                {foreach from=$messages item=message name="messageList"}
                    <tr class="{if $smarty.foreach.messageList.first}first_item{elseif $smarty.foreach.messageList.last}last_item{/if} {if $smarty.foreach.messageList.index % 2}alternate_item{else}item{/if}">
                        <td>
                            <strong class="dark">
                                {if isset($message.elastname) && $message.elastname}
                                    {$message.efirstname|escape:'html':'UTF-8'} {$message.elastname|escape:'html':'UTF-8'}
                                {elseif $message.clastname}
                                    {$message.cfirstname|escape:'html':'UTF-8'} {$message.clastname|escape:'html':'UTF-8'}
                                {else}
                                    {$shop_name|escape:'html':'UTF-8'}
                                {/if}
                            </strong>
                            <br />
                            {dateFormat date=$message.date_add full=1}
                        </td>
                        <td>{$message.message|escape:'html':'UTF-8'|nl2br}</td>
                    </tr>
                {/foreach}
                </tbody>
            </table>
        </div>
        {/if}
        {if isset($errors) && $errors}
            <div class="alert alert-danger">
                <p>{if $errors|@count > 1}{l s='There are %d errors' sprintf=$errors|@count mod='dropshipsystem'}{else}{l s='There is %d error' sprintf=$errors|@count mod='dropshipsystem'}{/if}</p>
                <ol>
                {foreach from=$errors key=k item=error}
                    <li>{$error|escape:'htmlall':'UTF-8'}</li>
                {/foreach}
                </ol>
            </div>
        {/if}
        {if isset($message_confirmation) && $message_confirmation}
        <p class="alert alert-success">
            {l s='Message successfully sent' mod='dropshipsystem'}
        </p>
        {/if}
        <form action="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'orderdetails', 'id_order' => "{$order->id|intval}"], true)|escape:'html':'UTF-8'}" method="post" class="std" id="sendOrderMessage">
            <h3 class="page-heading bottom-indent">{l s='Add a message' mod='dropshipsystem'}</h3>
            <p>{l s='If you would like to add a comment about your order, please write it in the field below.' mod='dropshipsystem'}</p>
            <p class="form-group">
            <label for="id_product">{l s='Product' mod='dropshipsystem'}</label>
                <select name="id_product" class="form-control">
                    <option value="0">{l s='-- Choose --' mod='dropshipsystem'}</option>
                    {foreach from=$products item=product name=products}
                        <option value="{$product.product_id|escape:'htmlall':'UTF-8'}">{$product.product_name|escape:'htmlall':'UTF-8'}</option>
                    {/foreach}
                </select>
            </p>
            <p class="form-group">
                <textarea class="form-control" cols="67" rows="3" name="msgText"></textarea>
            </p>
            <div class="submit">
                <input type="hidden" name="id_order" value="{$order->id|intval}" />
                <input type="submit" class="unvisible" name="submitMessage" value="{l s='Send' mod='dropshipsystem'}"/>
                <button type="submit" name="submitMessage" class="button btn btn-default button-medium"><span>{l s='Send' mod='dropshipsystem'}<i class="icon-chevron-right right"></i></span></button>
            </div>
        </form>
    {/if}
</div>
