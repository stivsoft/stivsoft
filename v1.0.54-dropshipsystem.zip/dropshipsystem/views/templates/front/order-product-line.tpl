{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div class="product-line-grid">
    <div class="product-line-grid-left col-md-3 col-xs-4">
        <div class="product-reference">
            <div class="product-line-info text-center h4">
                <span>{$product.reference|escape:'html':'UTF-8'}</span>
            </div>
        </div>
    </div>

    <div class="product-line-grid-body col-md-4 col-xs-8">
        <div class="product-line-info">
            <a href="{$product.url|escape:'html':'UTF-8'}">{$product.name|escape:'html':'UTF-8'}</a>
        </div>

        {if $product.attributes}
            {foreach from=$product.attributes key="attribute" item="value"}
            <div class="product-line-info">
                <span class="label">{$attribute|escape:'html':'UTF-8'}:</span>
                <span class="value">{$value|escape:'html':'UTF-8'}</span>
            </div>
            {/foreach}
        {/if}
    </div>

    <div class="product-line-grid-right col-md-5 col-xs-12">
        <div class="row">
            <div class="col-md-10 col-xs-6">
                <div class="row">
                    <div class="col-md-4 col-xs-3 product-line-info h5">
                        <span class="product-price">{$product.formatted_price|escape:'html':'UTF-8'}</span>
                    </div>
                    <div class="col-md-4 col-xs-3 qty">
                        <input class="text-center form-control dss-cart-product-quantity" type="text" value="{$product.quantity|intval}" name="product-quantity" />
                    </div>
                    <div class="col-md-4 col-xs-3 product-line-info h5">
                        <span class="product-price total">{$product.formatted_total|escape:'html':'UTF-8'}</span>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-xs-2 text-xs-right">
                <div class="dss-cart-line-product-actions">
                    <a class="remove-from-dss-cart" href="#"
                        data-link-action="delete-from-dss-cart"
                        data-id-product="{$product.id_product|escape:'javascript':'UTF-8'}"
                        data-id-product-attribute="{$product.id_product_attribute|escape:'javascript':'UTF-8'}"
                        data-price="{$product.price|floatval}"
                        data-quantity="{$product.quantity|intval}">
                            <i class="fa-dss fa-dss-trash float-left"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="clearfix"></div>
</div>
