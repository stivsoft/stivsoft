{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}
<div class="table table-heading">
    <div class="col-md-3 col-xs-4">{l s='Product reference' mod='dropshipsystem'}</div>
    <div class="col-md-4 col-xs-8">{l s='Description' mod='dropshipsystem'}</div>
    <div class="col-md-5 col-xs-10">
        <div class="row">
            <div class="col-md-10 col-xs-6">
                <div class="row">
                    <div class="col-md-4 col-xs-3">{l s='Price' mod='dropshipsystem'}</div>
                    <div class="col-md-4 col-xs-3">{l s='Quantity' mod='dropshipsystem'}</div>
                    <div class="col-md-4 col-xs-3">{l s='Total' mod='dropshipsystem'}</div>
                </div>
            </div>
            <div class="col-md-2 col-xs-2">&nbsp;</div>
        </div>
    </div>
</div>
<hr class="separator">
<div class="cart-overview">
    <ul class="cart-items">
    {if $dss_cart.products}
        {foreach from=$dss_cart.products item=product}
        <li class="cart-item">
        {include file='./order-product-line.tpl' product=$product}
        </li>
        {/foreach}
        <li>
            <hr class="separator">
        </li>
    {/if}
        <li class="cart-item template">
            <div class="product-line-grid">
                <div class="product-line-grid-left col-md-3 col-xs-4">
                    <div class="product-reference">
                        <input class="text-left form-control js-product-search search" type="text" placeholder="{l s='Enter reference or name...' mod='dropshipsystem'}" autocomplete="off" />
                        <div id="search-result"></div>
                    </div>
                </div>

                <div class="product-line-grid-body col-md-4 col-xs-8">
                    <div class="product-line-info">
                        <a class="product-name" href="#">...</a>
                    </div>
                    
                    <div class="product-line-info">
                        <button id="set_attributes" type="button" class="btn btn-default" style="display:none;">
                            {l s='Choose variants' mod='dropshipsystem'}
                            <i class="fa-dss fa-dss-angle-down"></i>
                        </button>
                        <div class="product-variants"></div>
                    </div>
                </div>

                <div class="product-line-grid-right col-md-5 col-xs-12">
                    <div class="row">
                        <div class="col-md-10 col-xs-6">
                            <div class="row">
                                <div class="col-md-4 col-xs-3 product-line-info h5">
                                    <span class="product-price">...</span>
                                </div>
                                <div class="col-md-4 col-xs-3 qty">
                                    <input class="text-center form-control dss-cart-product-quantity" type="text" value="1" name="product-quantity" />
                                </div>
                                <div class="col-md-4 col-xs-3 product-line-info h5">
                                    <span class="product-price total">...</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2 col-xs-2 text-right">
                            <div class="dss-cart-line-product-actions">
                                <a class="add-from-dss-cart action" href="#"
                                    data-link-action="add-to-dss-cart"
                                    data-id-product="0"
                                    data-id-product-attribute="0"
                                    data-has-attributes="0"
                                    data-price="0"
                                    data-quantity="1">
                                        <i class="fa-dss fa-dss-plus-circle float-left"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </li>
    </ul>
</div>
<hr class="separator">
