{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<!-- MODULE Dropship System Server -->
{if $dropshipper && $dropshipper->id}
    {if $dropshipper->active == 1 || $dropshipper->active == 2}
    <li class="lnk_dropship">
        <a href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', array(), true)|escape:'html':'UTF-8'}" title="{l s='My Dropship Account' mod='dropshipsystem'}">
            <i class="icon-money"></i>
            <span>{l s='My Dropship Account' mod='dropshipsystem'}</span>
        </a>
    </li>
    {else}
    <li class="lnk_dropship disabled">
        <a href="#" title="{l s='My Dropship Account' mod='dropshipsystem'}">
            <i class="icon-money"></i>
            <span>{l s='My Dropship Account' mod='dropshipsystem'}</span>
        </a>
    </li>
    {/if}
{else}
    {if $allow_dropshippers_registration}
    <li class="lnk_dropship">
        <a href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'signup'], true)|escape:'html':'UTF-8'}" title="{l s='Signup for Dropship Account' mod='dropshipsystem'}">
            <i class="icon-money"></i>
            <span>{l s='Signup for Dropship Account' mod='dropshipsystem'}</span>
        </a>
    </li>
    {/if}
{/if}
<!-- END : MODULE Dropship System Server -->
