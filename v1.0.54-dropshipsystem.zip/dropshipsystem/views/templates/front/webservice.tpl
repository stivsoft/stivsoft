{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{if $action == 'apitest'}
    {if $is_logged}
    <apitest>OK</apitest>
    {else}
    <apitest>ERROR</apitest>
    {/if}

{elseif $action == 'getclients'}
<clients>
{foreach $clients as $key => $client}
    <client>
        <name><![CDATA[{$client['name']|escape:'html':'UTF-8'}]]></name>
        <version>{$client['version']|escape:'html':'UTF-8'}</version>
        <date>{$client['date']|escape:'html':'UTF-8'}</date>
    </client>
{/foreach}
</clients>

{elseif $action == 'getinfo'}

<infos>
{foreach $langs as $key => $lang}
    <lang id="{$key|intval}" iso="{$lang['iso_code']|escape:'html':'UTF-8'}">{$lang['name']|escape:'html':'UTF-8'}</lang>
{/foreach}
    <shop_name><![CDATA[{$shop_name|escape:'html':'UTF-8'}]]></shop_name>
    <currency>{$currency->iso_code|escape:'html':'UTF-8'}</currency>
    <payment_type>{$dropshippers->payment_type|escape:'html':'UTF-8'}</payment_type>
    <current_credit>{$dropshippers->credit|floatval}</current_credit>
    <tax_percent>{$dropshippers->customer_tax_value|floatval}</tax_percent>
    <last_order>{$dropshippers->last_order|escape:'html':'UTF-8'}</last_order>
    <expiration_date>{if !empty($dropshippers->date_end)}{$dropshippers->date_end|escape:'html':'UTF-8'}{/if}</expiration_date>
    <categories>{count($categories)|intval}</categories>
    <shipping_methods>
    {for $i=1 to 3}

    {/for}
    </shipping_methods>

</infos>

{elseif $action == 'sync'}

{elseif $action == 'getcategories'}

{elseif $action == 'getquantities'}

{elseif $action == 'checkproducts'}

{elseif $action == 'getproducts'}

{elseif $action == 'getorder'}

{elseif $action == 'setorder'}

{/if}
