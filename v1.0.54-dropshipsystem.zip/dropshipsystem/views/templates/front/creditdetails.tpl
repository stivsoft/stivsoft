{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div id="mydropshipaccount">
    <h1 class="page-heading">{l s='Credit details' mod='dropshipsystem'}</h1>

    <div class="col-xs-12 col-sm-8">
        <p class="text">
            {l s='Request date' mod='dropshipsystem'}:
            <span class="pull-right">
                {$creditdetails->request_date|escape:'html':'UTF-8'}
            </span>
        </p>
        <p class="text">
            {l s='Operated by' mod='dropshipsystem'}:
            <span class="pull-right">
                {$creditdetails->operator_name|escape:'html':'UTF-8'}
            </span>
        </p>
        <p class="text">
            {l s='Status' mod='dropshipsystem'}:
            <span class="pull-right">
                <strong>{$creditdetails->status|ucfirst|escape:'html':'UTF-8'}</strong>
            </span>
        </p>
        <p class="text">
            {l s='Currency' mod='dropshipsystem'}:
            <span class="pull-right">
                {$creditdetails->currency|escape:'html':'UTF-8'}
            </span>
        </p>
        <p class="text">
            {l s='Previous credit' mod='dropshipsystem'}:
            <span class="pull-right">
                {displayPrice price=$creditdetails->previous_credit currency=$creditdetails->currency no_utf8=false convert=false}
            </span>
        </p>
        <p class="text">
            {l s='Buyed credit' mod='dropshipsystem'}:
            <span class="pull-right">
                {displayPrice price=$creditdetails->buyed_credit currency=$creditdetails->currency no_utf8=false convert=false}
            </span>
        </p>
        <p class="text">
            {l s='Current credit' mod='dropshipsystem'}:
            <span class="pull-right">
                <strong>{displayPrice price=$creditdetails->current_credit currency=$creditdetails->currency no_utf8=false convert=false}</strong>
            </span>
        </p>
        <p class="text">
            {l s='Order reference' mod='dropshipsystem'}:
            <span class="pull-right">
                {$creditdetails->reference|escape:'html':'UTF-8'}
            </span>
        </p>
        <p class="text">
            {l s='Product' mod='dropshipsystem'}:
            <span class="pull-right">
                {$creditdetails->product_name|escape:'html':'UTF-8'}
            </span>
        </p>
        <p class="text">
            {l s='Paypal transaction id' mod='dropshipsystem'}:
            <span class="pull-right">
                {$creditdetails->transaction_id|escape:'html':'UTF-8'}
            </span>
        </p>
        <p class="text">
            {l s='Paypal payment status' mod='dropshipsystem'}:
            <span class="pull-right">
                {$creditdetails->payment_status|escape:'html':'UTF-8'}
            </span>
        </p>
        <p class="text">
            {l s='Paypal payment date' mod='dropshipsystem'}:
            <span class="pull-right">
                {if strtotime($creditdetails->payment_date) > 0}
                    {$creditdetails->payment_date|escape:'html':'UTF-8'}
                {/if}
            </span>
        </p>
    </div>
    
    <div class="clearfix">
        <ul class="footer_links">
            <li class="pull-right">
                <a name="close" class="btn btn-default button button-small" onclick="parent.jQuery.fancybox.close()" href="javascript:void(0);">
                    <span>{l s='Close' mod='dropshipsystem'}<i class="icon-close right"></i></span>
                </a>
            </li>
        </ul>
    </div>

</div>
