{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{if $groups}
    {foreach from=$groups key=id_attribute_group item=group}
    <fieldset class="attribute_fieldset">
        <label class="attribute_label" {if $group.group_type != 'color' && $group.group_type != 'radio'}for="group_{$id_attribute_group|intval}"{/if}>{$group.name|escape:'html':'UTF-8'}&nbsp;</label>
        {assign var="groupName" value="group_$id_attribute_group"}
        <div class="attribute_list">
        {if $group.group_type == 'select'}
            <select class="form-control attribute_select no-print"
                id="group_{$id_attribute_group|intval}"
                data-product-attribute="{$id_attribute_group|intval}"
                name="group[{$id_attribute_group|intval}]">
                {foreach from=$group.attributes key=id_attribute item=group_attribute}
                    <option value="{$id_attribute|intval}"{if $group.default == $id_attribute} selected="selected"{/if} title="{$group_attribute.name|escape:'html':'UTF-8'}">{$group_attribute.name|escape:'html':'UTF-8'}</option>
                {/foreach}
            </select>
        {elseif $group.group_type == 'color'}
            <ul id="group_{$id_attribute_group|intval}" class="color_to_pick_list clearfix">
                {foreach from=$group.attributes key=id_attribute item=group_attribute}
                    {assign var='img_color_exists' value=file_exists($img_col_dir|cat:$id_attribute|cat:'.jpg')}
                    <li{if $group.default == $id_attribute} class="selected"{/if}>
                        <input type="radio" class="color_pick_hidden" name="group[{$id_attribute_group|intval}]" value="{$id_attribute|intval}"{if $group.default == $id_attribute} checked="checked"{/if} style="display:none;">
                        <a href="#" id="color_{$id_attribute|intval}" name="group[{$id_attribute_group|intval}]" 
                            data-id_attribute="{$id_attribute|intval}" class="color_pick{if $group.default == $id_attribute} selected{/if}" title="group[{$id_attribute_group|intval}]"
                            {if !$img_color_exists && $group_attribute.html_color_code}class="color" style="background-color: {$group_attribute.html_color_code|escape:'html':'UTF-8'}" {/if}>
                            {if $img_color_exists}
                                <img src="{$img_col_uri|escape:'htmlall':'UTF-8'}{$id_attribute|intval}.jpg" alt="{$colors.$id_attribute.name|escape:'html':'UTF-8'}" title="{$colors.$id_attribute.name|escape:'html':'UTF-8'}" width="20" height="20" />
                            {/if}
                        </a>
                    </li>
                {/foreach}
            </ul>
        {elseif $group.group_type == 'radio'}
            <ul id="group_{$id_attribute_group|intval}">
                {foreach from=$group.attributes key=id_attribute item=group_attribute}
                    <li>
                        <input type="radio" class="attribute_radio" name="group[{$id_attribute_group|intval}]" value="{$id_attribute|intval}" {if $group.default == $id_attribute} checked="checked"{/if} />
                        <span>{$group_attribute|escape:'html':'UTF-8'}</span>
                    </li>
                {/foreach}
            </ul>
        {/if}
        </div>
    </fieldset>
    {/foreach}
{/if}
