{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}
{extends file='page.tpl'}

{block name='page_title'}
    {l s='Dropship Order Confirmation' mod='dropshipsystem'}
{/block}

{block name='page_content'}
    <div id="mydropshipaccount">
    {if $status == 1}
        <center>
        <p class="h3">
          {l s='Your dropship order on %s is complete.' sprintf=[$shop_name] mod='dropshipsystem'}
        </p>

        {if $dropshipper->payment_type == 'prepayed'}
            <p>
              {l s='Below the details of the credit payment' mod='dropshipsystem'}
            </p>
            <dl>
                <dt>{l s='Total Amount' mod='dropshipsystem'}</dt>
                <dd>{$total|escape:'htmlall':'UTF-8'}</dd>
                <dt>{l s='Previous Credit' mod='dropshipsystem'}</dt>
                <dd>{$dss_order->formatted_previous_credit|escape:'htmlall':'UTF-8'}</dd>
                <dt>{l s='Current Credit' mod='dropshipsystem'}</dt>
                <dd>{$dss_order->formatted_current_credit|escape:'htmlall':'UTF-8'}</dd>
            </dl>
        {elseif $dropshipper->payment_type == 'postpayed'}
            {if $payment_method|strpos:'payment_' === 0}
            <p>
              {l s='Please click the button below to pay the order.' mod='dropshipsystem'}
            </p>
            <dl>
                <dt>{l s='Total Amount' mod='dropshipsystem'}</dt>
                <dd>{$total|escape:'htmlall':'UTF-8'}</dd>
            </dl>
            <a href="{$payment_link|escape:'htmlall':'UTF-8'}" title="{l s='Pay now' mod='dropshipsystem'}" class="btn btn-primary">
                <span>
                    {l s='Pay now' mod='dropshipsystem'}
                    <i class="icon-chevron-right right"></i>
                </span>
            </a>
            {/if}

            {if $bankwire}
            <br><br>
            <p>
              {l s='Please send us a bank wire with:' mod='dropshipsystem'}
            </p>
            <dl>
                <dt>{l s='Total Amount' mod='dropshipsystem'}</dt>
                <dd>{$total|escape:'htmlall':'UTF-8'}</dd>
                <dt>{l s='Name of account owner' mod='dropshipsystem'}</dt>
                <dd>{$bankwire_owner|escape:'htmlall':'UTF-8'}</dd>
                <dt>{l s='Bank name' mod='dropshipsystem'}</dt>
                <dd>{$bankwire_name|escape:'htmlall':'UTF-8'}</dd>
                <dt>{l s='IBAN' mod='dropshipsystem'}</dt>
                <dd>{$bankwire_iban|escape:'htmlall':'UTF-8'}</dd>
                <dt>{l s='SWIFT' mod='dropshipsystem'}</dt>
                <dd>{$bankwire_swift|escape:'htmlall':'UTF-8'}</dd>
            </dl>
            <p>
              {l s='Please specify your order reference %s in the bankwire description.' sprintf=[$reference] mod='dropshipsystem'}
            </p>
            {/if}
        {/if}

        <br><br>
        <p>
          {l s='We\'ve also sent you this information by e-mail.' mod='dropshipsystem'}
        </p>
        <strong>{l s='Your order will be sent as soon as we receive payment.' mod='dropshipsystem'}</strong>
        </center>
    {else}
        <p class="warning">
          {l s='We noticed a problem with your dropship order. If you think this is an error, feel free to contact our [1]expert customer support team[/1].' mod='dropshipsystem' sprintf=['[1]' => "<a href='{$contact_url}'>", '[/1]' => '</a>']}
        </p>
    {/if}
    </div>
{/block}
