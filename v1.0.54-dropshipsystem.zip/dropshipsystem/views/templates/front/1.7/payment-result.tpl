{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{extends file='page.tpl'}

{block name='page_title'}
    {if $iscredit}
        {l s='Dropship credit details' mod='dropshipsystem'}
    {else}
        {l s='Dropship order status' mod='dropshipsystem'}
    {/if}
{/block}

{block name='page_content'}
<div id="mydropshipaccount">
    {if $status == 'success'}
    <p>
        {if $iscredit}
            <span class="h3">{l s='Your dropship credit on %s is charged.' sprintf=[$shop_name] mod='dropshipsystem'}</span>
            <br /><br />{l s='Amount' mod='dropshipsystem'} <span class="price"><strong>{Tools::displayPrice($total)}</strong></span>
            <br /><br />{l s='Current credit' mod='dropshipsystem'} <span class="price"><strong>{Tools::displayPrice($credit)}</strong></span>
        {else}
            <span class="h3">{l s='Your dropship order on %s is complete.' sprintf=[$shop_name] mod='dropshipsystem'}</span>
            <br /><br />{l s='Amount' mod='dropshipsystem'} <span class="price"><strong>{Tools::displayPrice($total)}</strong></span>
        {/if}
        <br /><br />{l s='An email has been sent with this information.' mod='dropshipsystem'}
        <br /><br />{l s='If you have questions, comments or concerns, please contact our' mod='dropshipsystem'} <a href="{$contact_url|escape:'htmlall':'UTF-8'}">{l s='expert customer support team' mod='dropshipsystem'}</a>.
    </p>
    {elseif $status == 'cancel'}
    <p class="warning">
        {if $iscredit}
            <span class="h3">{l s='Your dropship credit on %s is not charged.' sprintf=[$shop_name] mod='dropshipsystem'}</span>
        {else}
            <span class="h3">{l s='Your dropship order on %s is not complete.' sprintf=[$shop_name] mod='dropshipsystem'}</span>
        {/if}
        <br /><br />
        {l s='The payment has been cancelled by the user.' mod='dropshipsystem'}
        {if !$iscredit}
        <br /><br />
        <a class="btn btn-primary btn-lg" href="{$payment_link|escape:'htmlall':'UTF-8'}">
            {l s='Retry the payment' mod='dropshipsystem'}
        </a>
        {/if}
        <br /><br />{l s='If you think this is an error, feel free to contact our' mod='dropshipsystem'} <a href="{$contact_url|escape:'htmlall':'UTF-8'}">{l s='expert customer support team' mod='dropshipsystem'}</a>.
    </p>
    {else}
    <p class="warning">
        {if $iscredit}
            <span class="h3">{l s='We noticed a problem with your credit.' mod='dropshipsystem'}</span>
        {else}
            <span class="h3">{l s='We noticed a problem with your order.' mod='dropshipsystem'}</span>
        {/if}

        {if $errors}
        <div class="error">
            <ul>
                {foreach $errors as $error}
                    <li>{$error}</li>
                {/foreach}
            </ul>
        </div>
        {/if}

        {l s='If you think this is an error, feel free to contact our' mod='dropshipsystem'} <a href="{$contact_url|escape:'htmlall':'UTF-8'}">{l s='expert customer support team' mod='dropshipsystem'}</a>.
    </p>
    {/if}
</div>
{/block}

{block name='page_footer'}
    {if $iscredit}
        {block name='my_account_links'}
            {include file='module:dropshipsystem/views/templates/front/1.7/_partials/my-account-links.tpl'}
        {/block}
    {/if}
{/block}
