{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}
{extends file='page.tpl'}

{block name='page_title'}
    {l s='My Dropship Account' mod='dropshipsystem'}
{/block}

{block name='page_content'}
<div id="mydropshipaccount">
    {if $dss_customer->id|intval neq 0}
        {if $dropshipper->id|intval neq 0}
            <div class="row">
                <div class="col-xs-12 col-sm-7">
                    <p class="text">
                        <span>{l s='Welcome' mod='dropshipsystem'} <strong class="dark">{$dss_customer->company|escape:'html':'UTF-8'}</strong>,</span>
                        {if $operator->id_employee|intval neq 0} 
                        <br />
                        {l s='From this page, you can see your last operations, download your invoices and change the data of your account.' mod='dropshipsystem'}
                        <br /><br />
                        {l s='your commercial referrer is' mod='dropshipsystem'} <strong>{$operator->firstname|escape:'html':'UTF-8'}</strong>
                        {*(<a href="mailto:{$operator->email|escape:'html':'UTF-8'}">{$operator->email|escape:'html':'UTF-8'}</a>)*}
                        {/if}
                    </p>
                    {if $dropshipper->active == 2}
                    <p class="text">
                        <strong class="red">
                            {l s='Your account is waiting to be approved. Please try again later, or contact us.' mod='dropshipsystem'}
                        </strong>
                    </p>
                    {/if}
                    <p class="text">
                        <strong class="dark">
                            {if $dropshipper->wholesale_reduction < 0}
                                {math equation="abs(x)" x=$dropshipper->wholesale_reduction assign="wholesale_reduction"} 
                                {l s='Your reserved discount is' mod='dropshipsystem'} <font class="red">{$wholesale_reduction|escape:'htmlall':'UTF-8'|string_format:"%.1f"}%</font>
                            {elseif $dropshipper->wholesale_reduction > 0}
                                {l s='Your charge is' mod='dropshipsystem'} <font class="red">{$dropshipper->wholesale_reduction|escape:'htmlall':'UTF-8'|string_format:"%.1f"}%</font>
                            {/if}
                        </strong>
                    </p>
                    {*
                    <p class="text">
                        <strong class="dark">{l s='Your annual revenues matured' mod='dropshipsystem'} <font class="red">€ 0,00</font></strong>
                    </p>
                    *}
                </div>
                <div class="col-xs-12 col-sm-5 preferences">
                    <div class="form-group">
                        <a class="btn btn-primary float-xs-right" href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'preferences'])|escape:'html':'UTF-8'}" title="{l s='Preferences' mod='dropshipsystem'}">
                            <span><i class="material-icons">settings</i>{l s='Preferences' mod='dropshipsystem'}</span>
                        </a>
                    </div>
                    {if $dropshipper->payment_type == 'prepayed' && $dropshipper->active == 1}
                    <div class="row">
                        <div class="col-xs-12 credit float-xs-right">
                            <ul class="box">
                                <li class="form-group">
                                    <span class="h3 page-subheading">{l s='Your credit' mod='dropshipsystem'}</span>
                                    <a class="credit-history" data-mode="modal" data-size="large" href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'credithistory', 'content_only' => 1], true)|escape:'html':'UTF-8'}" title="{l s='Credit history' mod='dropshipsystem'}">
                                        <span><i class="material-icons">history</i>{l s='History' mod='dropshipsystem'}</span>
                                    </a>
                                </li>
                                <li class="form-group">
                                    <div class="text">
                                        {l s='Current credit' mod='dropshipsystem'}:
                                        <span class="big pull-right">
                                            {Tools::displayPrice((float)$dropshipper->credit)}
                                        </span>
                                    </div>
                                </li>
                                <li class="form-group">
                                    <a class="btn btn-primary float-xs-right" data-mode="modal" data-size="small" href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'addcredit', 'content_only' => 1], true)|escape:'html':'UTF-8'}">
                                        <span><i class="icon-money"></i>{l s='Add credit' mod='dropshipsystem'}</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    {/if}
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <hr class="separator">
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-6 billing">
                    <ul class="box">
                        <li>
                            <span class="h4 page-subheading">{l s='Billing data' mod='dropshipsystem'}</span>
                        </li>
                        <li>
                            <label>{l s='Company' mod='dropshipsystem'}:</label>
                            <span class="pull-right">
                                {$dropshipper->invoice->company|escape:'html':'UTF-8'}
                            </span>
                        </li>
                        <li>
                            <label>{l s='Address' mod='dropshipsystem'}:</label>
                            <span class="pull-right">
                                {$dropshipper->invoice->address1|escape:'html':'UTF-8'}
                            </span>
                        </li>
                        <li>
                            <label>{l s='Postcode' mod='dropshipsystem'}:</label>
                            <span class="pull-right">
                                {$dropshipper->invoice->postcode|escape:'html':'UTF-8'}
                            </span>
                        </li>
                        <li>
                            <label>{l s='City' mod='dropshipsystem'}:</label>
                            <span class="pull-right">
                                {$dropshipper->invoice_state->name|escape:'html':'UTF-8'} ({$dropshipper->invoice_state->iso_code|escape:'html':'UTF-8'})
                            </span>
                        </li>
                        <li>
                            <label>{l s='Country' mod='dropshipsystem'}:</label>
                            <span class="pull-right">
                                {$dropshipper->invoice_country->name|escape:'html':'UTF-8'}
                            </span>
                        </li>
                        <li>
                            <label>{l s='Vat Number' mod='dropshipsystem'}:</label>
                            <span class="pull-right">
                                {$dropshipper->invoice->vat_number|escape:'html':'UTF-8'}
                            </span>
                        </li>
                        <li>
                            <label>{l s='DNI' mod='dropshipsystem'}:</label>
                            <span class="pull-right">
                                {$dropshipper->invoice->dni|escape:'html':'UTF-8'}
                            </span>
                        </li>
                        {*
                        <li class="form-group text-right">
                            <a class="btn btn-default float-xs-right" href="{$link->getPageLink('address', true, null, "id_address={$address.object.id|intval}")|escape:'html':'UTF-8'}" title="{l s='Update' mod='dropshipsystem'}">
                                <span><i class="material-icons">&#xE254;</i>{l s='Modify data' mod='dropshipsystem'}</span>
                            </a>
                        </li>
                        *}
                    </ul>
                </div>
                <div class="col-xs-12 col-sm-6 contact">
                    <ul class="box">
                        <li>
                            <span class="h4 page-subheading">{l s='Contact data' mod='dropshipsystem'}</span>
                        </li>
                        <li>
                            <label>{l s='Name' mod='dropshipsystem'}:</label>
                            <span class="pull-right">
                                {$dropshipper->contact_name|escape:'html':'UTF-8'}
                            </span>
                        </li>
                        <li>
                            <label>{l s='Email' mod='dropshipsystem'}:</label>
                            <span class="pull-right">
                                {$dropshipper->contact_email|escape:'html':'UTF-8'}
                            </span>
                        </li>
                        <li>
                            <label>{l s='Phone' mod='dropshipsystem'}:</label>
                            <span class="pull-right">
                                {$dropshipper->contact_phone|escape:'html':'UTF-8'}
                            </span>
                        </li>
                        <li>
                            <label>{l s='Mobile' mod='dropshipsystem'}:</label>
                            <span class="pull-right">
                                {$dropshipper->contact_mobile|escape:'html':'UTF-8'}
                            </span>
                        </li>
                        <li>
                            <label>{l s='Web Site' mod='dropshipsystem'}:</label>
                            <span class="pull-right">
                                {$dropshipper->website|escape:'html':'UTF-8'}
                            </span>
                        </li>
                        <li class="form-group text-right">
                            <a class="btn btn-primary float-xs-right" href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'changecontact'])|escape:'html':'UTF-8'}" title="{l s='Modify data' mod='dropshipsystem'}">
                                <span><i class="material-icons">&#xE254;</i>{l s='Modify data' mod='dropshipsystem'}</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <hr class="separator">
                </div>
            </div>

            <div class="clearfix main-page-indent"></div>

            {if $dropshipper->active == 1}
            <div class="box">
                <span class="h3 page-subheading">{l s='Your orders' mod='dropshipsystem' mod='dropshipsystem'}</span>
                {if $dropshipper->direct_order == 1}
                <a class="btn btn-default" href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'neworder'])|escape:'html':'UTF-8'}" title="{l s='Add new dropship order' mod='dropshipsystem'}">
                    <span><i class="material-icons">add_circle</i> {l s='Add new dropship order' mod='dropshipsystem'}</span>
                </a>
                {/if}
                {if $orders && count($orders)}
                    <table id="order-list" class="table footab">
                        <thead>
                            <tr>
                                <th class="first_item" data-sort-ignore="true">{l s='Order reference' mod='dropshipsystem'}</th>
                                <th class="item">{l s='Date' mod='dropshipsystem'}</th>
                                <th data-hide="price" class="item">{l s='Total price' mod='dropshipsystem'}</th>
                                <th class="item">{l s='Status' mod='dropshipsystem'}</th>
                                <th data-sort-ignore="true" data-hide="phone,tablet" class="item">{l s='Invoice' mod='dropshipsystem'}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {foreach from=$orders item=order name=myLoop}
                                <tr class="{if $smarty.foreach.myLoop.first}first_item{elseif $smarty.foreach.myLoop.last}last_item{else}item{/if} {if $smarty.foreach.myLoop.index % 2}alternate_item{/if}">
                                    <td class="history_link bold">
                                        {if isset($order.invoice) && $order.invoice && isset($order.virtual) && $order.virtual}
                                            <img class="icon" src="{$img_dir|escape:'htmlall':'UTF-8'}icon/download_product.gif" alt="{l s='Products to download' mod='dropshipsystem'}" title="{l s='Products to download' mod='dropshipsystem'}" />
                                        {/if}
                                        <a class="color-myaccount" href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'orderdetails', 'id_order' => "{$order.id_order|intval}"], true)|escape:'html':'UTF-8'}">
                                            {Order::getUniqReferenceOf($order.id_order)|escape:'htmlall':'UTF-8'}
                                        </a>
                                    </td>
                                    <td data-value="{$order.date_add|escape:'htmlall':'UTF-8'|regex_replace:"/[\-\:\ ]/":""}" class="history_date bold">
                                        {dateFormat date=$order.date_add full=0}
                                    </td>
                                    <td class="history_price" data-value="{$order.total_paid|escape:'htmlall':'UTF-8'}">
                                        <span class="price">
                                            {Tools::displayPrice((float)$order.total_paid, (int)$order.id_currency, false)}
                                        </span>
                                    </td>
                                    <td{if isset($order.order_state)} data-value="{$order.id_order_state|intval}"{/if} class="history_state">
                                        {if isset($order.order_state)}
                                            <span class="label{if isset($order.order_state_color) && Tools::getBrightness($order.order_state_color) > 128} dark{/if}"{if isset($order.order_state_color) && $order.order_state_color} style="background-color:{$order.order_state_color|escape:'html':'UTF-8'}; border-color:{$order.order_state_color|escape:'html':'UTF-8'};"{/if}>
                                                {$order.order_state|escape:'html':'UTF-8'}
                                            </span>
                                        {/if}
                                    </td>
                                    <td class="history_invoice">
                                        {if (isset($order.invoice) && $order.invoice && isset($order.invoice_number) && $order.invoice_number) && isset($invoiceAllowed) && $invoiceAllowed == true}
                                            <a class="link-button" href="{$link->getPageLink('pdf-invoice', true, NULL, "id_order={$order.id_order}")|escape:'html':'UTF-8'}" title="{l s='Invoice' mod='dropshipsystem'}" target="_blank">
                                                <i class="icon-file-text large"></i>{l s='PDF' mod='dropshipsystem'}
                                            </a>
                                        {else}
                                            -
                                        {/if}
                                    </td>
                                </tr>
                            {/foreach}
                        </tbody>
                    </table>
                    <div id="block-order-detail" class="unvisible">&nbsp;</div>
                {else}
                    <p class="alert alert-warning">{l s='You have not placed any orders.' mod='dropshipsystem'}</p>
                {/if}
            </div>
            {/if}
        {else}
            {l s='You have not access to this page.' mod='dropshipsystem'}
        {/if}
    {/if}
</div>
<div id="modal" class="modal fade">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="{l s='Close' mod='dropshipsystem'}">
                <span aria-hidden="true">&times;</span>
            </button>
            <div class="js-modal-content"></div>
        </div>
    </div>
</div>
<div id="modal2" class="modal fade">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="{l s='Close' mod='dropshipsystem'}">
                <span aria-hidden="true">&times;</span>
            </button>
            <div class="js-modal-content"></div>
        </div>
    </div>
</div>
{/block}

{block name='page_footer'}
    {block name='my_account_links'}
        {include file='module:dropshipsystem/views/templates/front/1.7/_partials/my-account-links.tpl'}
    {/block}
{/block}