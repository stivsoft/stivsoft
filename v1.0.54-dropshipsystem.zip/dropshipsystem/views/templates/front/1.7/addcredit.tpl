{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div id="mydropshipaccount">
    <h1 class="page-heading">{l s='Add your credit' mod='dropshipsystem'}</h1>
    <form name="formAddCredit" action="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', array(), true)|escape:'html':'UTF-8'}" method="post">
        <p class="form-group credits">
            <h3 for="credits">{l s='Credit' mod='dropshipsystem'}</h3>
            <select name="credits" class="form-control">
                <option value="0">{l s='-- Choose --' mod='dropshipsystem'}</option>
                {foreach from=$credits item=credit name=credits}
                    <option value="{$credit.reference|escape:'html':'UTF-8'}">{l s='Recharge credit' mod='dropshipsystem'} {Tools::displayPrice($credit.price)}</option>
                {/foreach}
            </select>
        </p>
        <div class="clearfix">
            <ul class="footer_links">
                <li class="pull-right">
                    <button type="submit" name="submitAddCredit" class="btn btn-primary" data-loading-text="{l s='Waiting' mod='dropshipsystem'}...">
                        <span>{l s='Confirm' mod='dropshipsystem'}<i class="material-icons">&#xE315;</i></span>
                    </button>
                </li>
            </ul>
        </div>
    </form>
</div>
