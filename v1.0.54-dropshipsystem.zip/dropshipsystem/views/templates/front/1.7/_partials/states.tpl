{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}
{if $states}
<div class="form-group row js-dss-states">
    <label class="col-md-3 form-control-label required">
        {l s='State' mod='dropshipsystem'}
        <sup>*</sup>
    </label>
    <div class="col-md-9">
        <select class="form-control form-control-select" name="dss_address_state">
            <option value disabled selected>{l s='-- please choose --' mod='dropshipsystem'}</option>
            {foreach from=$states key="value" item="label"}
                <option value="{$value}" {if isset($dss_cart.delivery_address->id_state)}{if $value eq $dss_cart.delivery_address->id_state} selected {/if}{/if}>{$label}</option>
            {/foreach}
        </select>
    </div>
</div>
{/if}
