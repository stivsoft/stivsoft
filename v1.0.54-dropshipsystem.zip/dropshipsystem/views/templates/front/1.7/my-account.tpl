{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<!-- MODULE Dropship System Server -->
{if $dropshipper && $dropshipper->id}
    {if $dropshipper->active == 1 || $dropshipper->active == 2}
    <a class="col-lg-4 col-md-6 col-sm-6 col-xs-12" href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', array(), true)|escape:'html':'UTF-8'}" title="{l s='My Dropship Account' mod='dropshipsystem'}">
        <span class="link-item lnk_dropship">
            <i class="material-icons">&#xE227;</i>
            <span>{l s='My Dropship Account' mod='dropshipsystem'}</span>
        </span>
    </a>
    {else}
    <a class="col-lg-4 col-md-6 col-sm-6 col-xs-12 disabled" href="#" title="{l s='My Dropship Account' mod='dropshipsystem'}">
        <span class="link-item lnk_dropship">
            <i class="material-icons">&#xE227;</i>
            <span>{l s='My Dropship Account' mod='dropshipsystem'}</span>
        </span>
    </a>
    {/if}
{else}
    {if $allow_dropshippers_registration}
    <a class="col-lg-4 col-md-6 col-sm-6 col-xs-12" href="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'signup'], true)|escape:'html':'UTF-8'}" title="{l s='Signup for Dropship Account' mod='dropshipsystem'}">
        <span class="link-item lnk_dropship">
            <i class="material-icons">&#xE227;</i>
            <span>{l s='Signup for Dropship Account' mod='dropshipsystem'}</span>
        </span>
    </a>
    {/if}
{/if}
<!-- END : MODULE Dropship System Server -->
