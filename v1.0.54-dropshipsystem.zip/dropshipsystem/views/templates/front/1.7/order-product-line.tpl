{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div class="product-line-grid">
    <div class="product-line-grid-left col-md-3 col-xs-4">
        <div class="product-reference">
            <div class="product-line-info text-xs-center h4">
                <span>{$product.reference}</span>
            </div>
        </div>
    </div>

    <div class="product-line-grid-body col-md-4 col-xs-8">
        <div class="product-line-info">
            <a class="label" href="{$product.url}">{$product.name}</a>
        </div>

        <br/>

        {if $product.attributes}
            {foreach from=$product.attributes key="attribute" item="value"}
            <div class="product-line-info">
                <span class="label">{$attribute}:</span>
                <span class="value">{$value}</span>
            </div>
            {/foreach}
        {/if}
    </div>

    <div class="product-line-grid-right col-md-5 col-xs-12">
        <div class="row">
            <div class="col-md-10 col-xs-6">
                <div class="row">
                    <div class="col-md-4 col-xs-3 product-line-info h5">
                        <span class="product-price">{$product.formatted_price}</span>
                    </div>
                    <div class="col-md-4 col-xs-3 qty">
                        <input class="text-xs-center form-control dss-cart-product-quantity" type="text" value="{$product.quantity}" name="product-quantity" />
                    </div>
                    <div class="col-md-4 col-xs-3 product-line-info h5">
                        <span class="product-price total">{$product.formatted_total}</span>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-xs-2 text-xs-right">
                <div class="dss-cart-line-product-actions">
                    <a class="remove-from-dss-cart" href="#"
                        data-link-action="delete-from-dss-cart"
                        data-id-product="{$product.id_product|escape:'javascript':'UTF-8'}"
                        data-id-product-attribute="{$product.id_product_attribute|escape:'javascript':'UTF-8'}"
                        data-price="{$product.price|floatval}"
                        data-quantity="{$product.quantity|intval}">
                            <i class="material-icons float-xs-left">delete</i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="clearfix"></div>
</div>
