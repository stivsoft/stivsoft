{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}
{extends file='page.tpl'}

{block name='page_title'}
    {l s='Signup for Dropship Account' mod='dropshipsystem'}
{/block}

{block name='page_content'}
<div id="mydropshipaccount">
    <div class="text-left">
        {if $dss_customer->id|intval neq 0}
            <p class="required"><sup>*</sup>{l s='Required field' mod='dropshipsystem'}</p>
            <form name="dropship_signup" action="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'signup'], true)|escape:'html':'UTF-8'}" method="post" class="std">
                <div class="row form-group">
                    <label class="col-sm-2">{l s='Customer' mod='dropshipsystem'}</label>
                    <div class="col-sm-5">
                        {if !isset($dropshipper->contact_name)}
                            {$dss_customer->lastname|escape:'html':'UTF-8'} {$dss_customer->firstname|escape:'html':'UTF-8'}
                        {else}
                            {$dss_customer->company|escape:'html':'UTF-8'}
                        {/if}
                    </div>
                </div>
                <div class="row required form-group">
                    <label class="col-sm-2" for="contact_name">{l s='Contact name' mod='dropshipsystem'} <sup>*</sup></label>
                    <div class="col-sm-5">
                        <input class="is_required validate form-control" data-validate="{$signup_validation.contact_name.validate|escape:'htmlall':'UTF-8'}" type="text" id="contact_name" name="contact_name" value="{if isset($smarty.post.contact_name)}{$smarty.post.contact_name|escape:'htmlall':'UTF-8'}{else}{if isset($dropshipper->contact_name)}{$dropshipper->contact_name|escape:'html':'UTF-8'}{/if}{/if}" />
                    </div>
                </div>
                <div class="row required form-group">
                    <label class="col-sm-2" for="contact_email">{l s='Contact email' mod='dropshipsystem'} <sup>*</sup></label>
                    <div class="col-sm-5">
                        <input class="is_required validate form-control" data-validate="{$signup_validation.contact_email.validate|escape:'htmlall':'UTF-8'}" type="text" id="contact_email" name="contact_email" value="{if isset($smarty.post.contact_email)}{$smarty.post.contact_email|escape:'htmlall':'UTF-8'}{else}{if isset($dropshipper->contact_email)}{$dropshipper->contact_email|escape:'html':'UTF-8'}{/if}{/if}" />
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-sm-2" for="contact_phone">{l s='Contact phone' mod='dropshipsystem'}</label>
                    <div class="col-sm-5">
                        <input class="validate form-control" data-validate="{$signup_validation.contact_phone.validate|escape:'htmlall':'UTF-8'}" type="text" id="contact_phone" name="contact_phone" value="{if isset($smarty.post.contact_phone)}{$smarty.post.contact_phone|escape:'htmlall':'UTF-8'}{else}{if isset($dropshipper->contact_phone)}{$dropshipper->contact_phone|escape:'html':'UTF-8'}{/if}{/if}" />
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-sm-2" for="contact_mobile">{l s='Contact mobile' mod='dropshipsystem'}</label>
                    <div class="col-sm-5">
                        <input class="validate form-control" data-validate="{$signup_validation.contact_mobile.validate|escape:'htmlall':'UTF-8'}" type="text" id="contact_mobile" name="contact_mobile" value="{if isset($smarty.post.contact_mobile)}{$smarty.post.contact_mobile|escape:'htmlall':'UTF-8'}{else}{if isset($dropshipper->contact_mobile)}{$dropshipper->contact_mobile|escape:'html':'UTF-8'}{/if}{/if}" />
                    </div>
                </div>
                <div class="row required form-group">
                    <label class="col-sm-2" for="website">{l s='Website' mod='dropshipsystem'} <sup>*</sup></label>
                    <div class="col-sm-5">
                        <input class="validate form-control" data-validate="{$signup_validation.website.validate|escape:'htmlall':'UTF-8'}" type="text" id="website" name="website" value="{if isset($smarty.post.website)}{$smarty.post.website|escape:'htmlall':'UTF-8'}{else}{if isset($dropshipper->website)}{$dropshipper->website|escape:'html':'UTF-8'}{/if}{/if}" />
                    </div>
                </div>
                <div class="row required form-group">
                    <label class="col-sm-2" for="payment_type">{l s='Payment Type' mod='dropshipsystem'} <sup>*</sup></label>
                    <div class="col-sm-5 select">
                        <select id="payment_type" name="payment_type" class="form-control">
                            {foreach from=$payment_type item=p}
                                <option value="{$p.id_payment_type|escape:'htmlall':'UTF-8'}"{if (isset($smarty.post.id_payment_type) AND $smarty.post.id_payment_type == $p.id_payment_type)} selected="selected"{/if}>{$p.name|escape:'htmlall':'UTF-8'}</option>
                            {/foreach}
                        </select>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-sm-2" for="website">{l s='Contract' mod='dropshipsystem'} </label>
                    <div class="col-sm-5">
                        <a href="{$link->getModuleLink('dropshipsystem', 'downloads', ['action' => 'signup', 'file' => 'dropship_agreement.pdf'], true)|escape:'htmlall':'UTF-8'}" title="{l s='Dropship agreement' mod='dropshipsystem'}" target="_blank">
                            <img src="{$module_dir|escape:'html':'UTF-8'}dropshipsystem/views/img/pdf.gif"> {l s='Dropship agreement' mod='dropshipsystem'}
                        </a>
                    </div>
                </div>
                <div class="row required checkbox form-group">
                    <label class="col-md-2 form-control-label"></label>
                    <div class="col-md-6">
                        <span class="custom-checkbox">
                            <input id="check_agreement" name="check_agreement" required type="checkbox" value="1" class="ps-shown-by-js" {if isset($smarty.post.check_agreement) && $smarty.post.check_agreement == '1'}checked="checked"{/if}>
                            <span><i class="material-icons checkbox-checked">&#xE5CA;</i></span>
                            <label>{if ($agreement)}{$agreement|escape:'htmlall':'UTF-8'}{else}{l s='I have read and accept the agreement' mod='dropshipsystem'}{/if}</label>
                        </span>
                    </div>
                </div>
                {hook h='displayGDPRConsent' mod='psgdpr' id_module=$id_module}
                <p class="submit2">
                    <input type="hidden" name="token" value="{$token|escape:'htmlall':'UTF-8'}" />
                    <input type="hidden" name="id_customer" value="{$dss_customer->id|intval}" />
                    <button type="submit" name="submitSignup" id="submitSignup" class="btn btn-primary">{l s='Send request' mod='dropshipsystem'}</button>
                </p>
            </form>
        {/if}
    </div>
</div>
{/block}

{block name='page_footer'}
    {block name='my_account_links'}
        {include file='module:dropshipsystem/views/templates/front/1.7/_partials/my-account-links.tpl'}
    {/block}
{/block}
