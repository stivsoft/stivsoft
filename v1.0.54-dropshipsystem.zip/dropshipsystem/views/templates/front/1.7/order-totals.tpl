{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div class="card-block">
    <div class="card-block">
        <div class="cart-summary-line dss-cart-shipping">
            <span class="label">{l s='Shipping Cost' mod='dropshipsystem'}</span>
            <span class="value">{$dss_cart.totals.formatted_shipping}</span>
        </div>
        <div class="cart-summary-line dss-cart-subtotal">
            <span class="label">{l s='Subtotal' mod='dropshipsystem'}</span>
            <span class="value">{$dss_cart.totals.formatted_subtotal}</span>
        </div>
    </div>
    <hr class="separator">
    <div class="card-block">
        <div class="cart-summary-line dss-cart-total">
            <span class="label">{l s='Total' mod='dropshipsystem'}</span>
            <span class="value">{$dss_cart.totals.formatted_total}</span>
        </div>
    </div>
    <hr class="separator">
    {if $dropshipper->payment_type == 'prepayed'}
    <div class="card-block">
        <div class="cart-summary-line dss-cart-current-credit">
            <span class="label">{l s='Current credit' mod='dropshipsystem'}</span>
            <span class="value">{$dss_cart.totals.formatted_current_credit}</span>
        </div>
        <div class="cart-summary-line dss-cart-remain-credit">
            <span class="label">{l s='Remain credit' mod='dropshipsystem'}</span>
            <span class="value">{$dss_cart.totals.formatted_remain_credit}</span>
        </div>
    </div>
    {/if}
</div>
