{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}
{extends file='page.tpl'}

{block name='page_title'}
    {l s='Credit details' mod='dropshipsystem'}
{/block}

{block name='page_content'}
<div id="mydropshipaccount">
    <div class="col-xs-12">
        <p class="text">
            {l s='Request date' mod='dropshipsystem'}:
            <span class="pull-right">
                {$creditdetails->request_date|escape:'html':'UTF-8'}
            </span>
        </p>
        <p class="text">
            {l s='Operated by' mod='dropshipsystem'}:
            <span class="pull-right">
                {$creditdetails->operator_name|escape:'html':'UTF-8'}
            </span>
        </p>
        <p class="text">
            {l s='Status' mod='dropshipsystem'}:
            <span class="pull-right">
                <strong>{$creditdetails->status|ucfirst|escape:'html':'UTF-8'}</strong>
            </span>
        </p>
        <p class="text">
            {l s='Currency' mod='dropshipsystem'}:
            <span class="pull-right">
                {$creditdetails->currency|escape:'html':'UTF-8'}
            </span>
        </p>
        <p class="text">
            {l s='Previous credit' mod='dropshipsystem'}:
            <span class="pull-right">
                {Tools::displayPrice($creditdetails->previous_credit)}
            </span>
        </p>
        <p class="text">
            {l s='Buyed credit' mod='dropshipsystem'}:
            <span class="pull-right">
                {Tools::displayPrice($creditdetails->buyed_credit)}
            </span>
        </p>
        <p class="text">
            {l s='Current credit' mod='dropshipsystem'}:
            <span class="pull-right">
                <strong>{Tools::displayPrice($creditdetails->current_credit)}</strong>
            </span>
        </p>
        <p class="text">
            {l s='Order reference' mod='dropshipsystem'}:
            <span class="pull-right">
                {$creditdetails->reference|escape:'html':'UTF-8'}
            </span>
        </p>
        <p class="text">
            {l s='Product' mod='dropshipsystem'}:
            <span class="pull-right">
                {$creditdetails->product_name|escape:'html':'UTF-8'}
            </span>
        </p>
        <p class="text">
            {l s='Paypal transaction id' mod='dropshipsystem'}:
            <span class="pull-right">
                {$creditdetails->transaction_id|escape:'html':'UTF-8'}
            </span>
        </p>
        <p class="text">
            {l s='Paypal payment status' mod='dropshipsystem'}:
            <span class="pull-right">
                {$creditdetails->payment_status|escape:'html':'UTF-8'}
            </span>
        </p>
        <p class="text">
            {l s='Paypal payment date' mod='dropshipsystem'}:
            <span class="pull-right">
                {if strtotime($creditdetails->payment_date) > 0}
                    {$creditdetails->payment_date|escape:'html':'UTF-8'}
                {/if}
            </span>
        </p>
    </div>
</div>
{/block}

{block name='page_footer'}
<div class="clearfix">
    <div class="pull-right">
        <button type="button" data-dismiss="modal" class="btn btn-primary">{l s='Close' mod='dropshipsystem'}</button>
    </div>
</div>
{/block}
