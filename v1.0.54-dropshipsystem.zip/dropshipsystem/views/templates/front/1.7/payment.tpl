{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{extends file='page.tpl'}

{block name='page_title'}
    {if $iscredit}
        {l s='Dropship credit payment' mod='dropshipsystem'}
    {else}
        {l s='Dropship order payment' mod='dropshipsystem'}
    {/if}
{/block}

{block name='page_content'}
    {include file=$tplfile}
{/block}

{block name='page_footer'}
    {if $iscredit}
        {block name='my_account_links'}
            {include file='module:dropshipsystem/views/templates/front/1.7/_partials/my-account-links.tpl'}
        {/block}
    {/if}
{/block}
