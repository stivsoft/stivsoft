{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div class="card-block">
    <div class="js-shipping-method-form">
        {block name="shipping_method_form_fields"}
        <section class="form-fields">
            <div class="form-group row">
                <label class="col-md-3 form-control-label required">
                    {l s='Shipping' mod='dropshipsystem'}
                </label>
                <div class="col-md-9">
                    <select class="form-control form-control-select" name="dss_order_shipping_method" required>
                        <option value disabled selected>{l s='-- please choose --' mod='dropshipsystem'}</option>
                        {foreach from=$shipping_methods key="value" item="label"}
                            <option value="{$value}" {if $value == $dss_cart.id_carrier}selected{/if}>{$label}</option>
                        {/foreach}
                    </select>
                </div>
            </div>
        </section>
        {/block}
    </div>
</div>
