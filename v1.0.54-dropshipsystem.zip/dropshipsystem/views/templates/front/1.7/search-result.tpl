{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}
<div class="search-title">
    <div class="row">
        <div class="col-md-2 text-xs-center">{l s='Image' mod='dropshipsystem'}</div>
        <div class="col-md-8 text-xs-left">{l s='Name' mod='dropshipsystem'}</div>
        <div class="col-md-2 text-xs-right">{l s='Price' mod='dropshipsystem'}</div>
    </div>
</div>
<hr class="separator">
<div class="search-results">
    {if $results|count > 0}
    <ul class="search-items">
        {foreach from=$results item=product}
        <li class="search-item" 
            data-id-product="{$product.id_product|intval}"
            data-product-reference="{$product.reference|escape:'html':'UTF-8'}"
            data-product-name="{$product.name|escape:'html':'UTF-8'}"
            data-product-price="{$product.price|floatval}"
            data-product-url="{$link->getProductLink($product.id_product)|escape:'html':'UTF-8'}"
            data-has-attributes="{$product.has_attributes|intval}">
            <div class="row">
                <div class="col-md-2 text-xs-center">
                    <img src="{$link->getImageLink($product.link_rewrite, $product.id_image, 'large_default')}" />
                </div>
                <div class="col-md-8 text-xs-left">
                    <span>{$product.name}</span><br>
                    <span>{$product.reference}</span>
                </div>
                <div class="col-md-2 text-xs-right price">
                    <span>{$product.formatted_price}</span>
                </div>
            </div>
        </li>
        {/foreach}
    </ul>
    {else}
    <div class="no-result col-xs-12 text-xs-center">{l s='No product found' mod='dropshipsystem'}</div>
    {/if}
</div>
<hr class="separator">
