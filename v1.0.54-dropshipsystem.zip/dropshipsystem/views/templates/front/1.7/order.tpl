{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}
{extends file='page.tpl'}

{block name='page_title'}
    {l s='Add New Dropship Order' mod='dropshipsystem'}
{/block}

{block name='page_content'}
<div id="mydropshipaccount">
    <p class="text">{l s='Here you can send the dropship orders for your customers.' mod='dropshipsystem'}</p>
{if $dss_customer->id|intval neq 0}
    {if $dropshipper->id|intval neq 0}
    {*<p class="required"><sup>*</sup>{l s='Required field' mod='dropshipsystem'}</p>*}
    <form id="form_dss_order" action="{$link->getModuleLink('dropshipsystem', 'mydropshipaccount', ['action' => 'neworder'], true)|escape:'html':'UTF-8'}" method="post" class="std">
        <div class="card cart-container">
        {block name='order_form'}
            {include file='module:dropshipsystem/views/templates/front/1.7/order-form.tpl'}
        {/block}
        </div>
        <div class="row">
            <div class="col-sm-7">
                <h5>{l s='Shipping Address' mod='dropshipsystem'}</h5>
                <div class="card address-container">
                {block name='order_address'}
                    {include file='module:dropshipsystem/views/templates/front/1.7/order-address.tpl'}
                {/block}
                </div>
            </div>
            <div class="col-sm-5">
                <h5>{l s='Shipping Method' mod='dropshipsystem'}</h5>
                <div class="card shipping-methods-container">
                {block name='order_shipping_methods'}
                    {include file='module:dropshipsystem/views/templates/front/1.7/order-shipping-methods.tpl'}
                {/block}
                </div>
                <div class="clearfix"></div>
                <h5>{l s='Totals' mod='dropshipsystem'}</h5>
                <div class="totals-container">
                {block name='order_totals'}
                    {include file='module:dropshipsystem/views/templates/front/1.7/order-totals.tpl'}
                {/block}
                </div>
                <div class="clearfix"></div>
                <div class="col-sm-12">
                    <input type="hidden" name="token" value="{$token|escape:'htmlall':'UTF-8'}" />
                    <button type="submit" name="submitOrder" id="submitOrder" class="btn btn-primary float-xs-right disabled">
                        <span>
                            {l s='Confirm Order' mod='dropshipsystem'}
                            <i class="icon-chevron-right right"></i>
                        </span>
                    </button>
                </div>
            </div>
        </div>
    </form>
    {else}
        {l s='You have not access to this page.' mod='dropshipsystem'}
    {/if}
{/if}
</div>
{/block}

{block name='page_footer'}
    {block name='my_account_links'}
        {include file='module:dropshipsystem/views/templates/front/1.7/_partials/my-account-links.tpl'}
    {/block}
{/block}