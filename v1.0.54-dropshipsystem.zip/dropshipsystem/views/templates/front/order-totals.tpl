{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div class="col-xs-12">
    <ul class="row">
        <li class="dss-cart-shipping">
            <label>{l s='Shipping Cost' mod='dropshipsystem'}</label>
            <span class="pull-right">{$dss_cart.totals.formatted_shipping|escape:'html':'UTF-8'}</span>
        </li>
        <li class="cart-summary-line dss-cart-subtotal">
            <label>{l s='Subtotal' mod='dropshipsystem'}</label>
            <span class="pull-right">{$dss_cart.totals.formatted_subtotal|escape:'html':'UTF-8'}</span>
        </li>
        <li>
            <hr class="separator">
        </li>
        <li class="dss-cart-total">
            <label class="big">{l s='Total' mod='dropshipsystem'}</label>
            <span class="pull-right big">{$dss_cart.totals.formatted_total|escape:'html':'UTF-8'}</span>
        </li>
        <li>
            <hr class="separator">
        </li>
        {if $dropshipper->payment_type == 'prepayed'}
        <li class="dss-cart-current-credit">
            <label>{l s='Current credit' mod='dropshipsystem'}</label>
            <span class="pull-right">{$dss_cart.totals.formatted_current_credit|escape:'html':'UTF-8'}</span>
        </li>
        <li class="dss-cart-remain-credit">
            <label>{l s='Remain credit' mod='dropshipsystem'}</label>
            <span class="pull-right">{$dss_cart.totals.formatted_remain_credit|escape:'html':'UTF-8'}</span>
        </li>
        {/if}
    </ul>
</div>
