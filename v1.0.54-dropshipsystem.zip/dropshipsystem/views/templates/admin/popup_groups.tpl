{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div class="row">
    <div class="label col-xs-12">
        {l s='Enabled groups' mod='dropshipsystem'}
    </div>
    <div class="content col-xs-12">
    {if count($groups) && isset($groups)}
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="fixed-width-xs">
                        <span class="title_box">
                            <input type="checkbox" name="checkme" id="checkme" onclick="checkGroupBoxes();" />
                        </span>
                    </th>
                    <th class="fixed-width-xs"><span class="title_box">{l s='ID' mod='dropshipsystem'}</span></th>
                    <th>
                        <span class="title_box">
                            {l s='Group name' mod='dropshipsystem'}
                        </span>
                    </th>
                </tr>
            </thead>
            <tbody>
            {foreach $groups as $key => $group}
                {assign var=id_checkbox value=groupBox|cat:'_'|cat:$group.id_group}
                <tr>
                    <td>
                        <input type="checkbox" name="groupBox[]" class="groupBox" id="{$id_checkbox|escape:'htmlall':'UTF-8'}" value="{$group.id_group|intval}" {if isset($selected_groups[$group.id_group]) && $selected_groups[$group.id_group]}checked="checked"{/if} />
                    </td>
                    <td>{$group.id_group|intval}</td>
                    <td>
                        <label for="{$id_checkbox|escape:'htmlall':'UTF-8'}">{$group.name|escape:'htmlall':'UTF-8'}</label>
                    </td>
                </tr>
            {/foreach}
            </tbody>
        </table>
    {else}
        <center>
            {l s='No group created' mod='dropshipsystem'}
        </center>
    {/if}
    </div>
    <div class="footer col-xs-12">
        <button type="button" class="btn btn-default closebtn">
            {l s='Close' mod='dropshipsystem'}
        </button>
        <button name="submitgroups" type="button" class="btn btn-primary submitgroups" 
            data-action="{$dss_action|escape:'htmlall':'UTF-8'}"
            data-url="{$dss_ajaxurl|escape:'htmlall':'UTF-8'}"
            data-id="{$dss_id|intval}"
            data-token="{$dss_token|escape:'htmlall':'UTF-8'}">
            {l s='Save' mod='dropshipsystem'}
        </button>
    </div>
</div>
