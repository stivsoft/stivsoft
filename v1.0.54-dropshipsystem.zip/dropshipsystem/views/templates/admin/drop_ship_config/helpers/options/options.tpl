{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{extends file="helpers/options/options.tpl"}

{block name="label"}
    {if $field['type'] == 'html'}
        {if isset($field['html_content'])}{$field['html_content']}{/if}
    {else}
        {$smarty.block.parent}
    {/if}
{/block}

{block name="input"}
    {if $field['type'] == 'password'}
        {assign var='value_text' value=$fields_value[$field['name']]}
        <div class="col-lg-9">
            <div class="input-group{if isset($field.class)} {$field.class|escape:'html':'UTF-8'}{/if}">
                <span class="input-group-addon">
                    <i class="icon-key"></i>
                </span>
                <input type="{$field['type']|escape:'html':'UTF-8'}"
                   {if isset($field['id'])} id="{$field['id']|escape:'html':'UTF-8'}"{/if}
                   size="{if isset($field['size'])}{$field['size']|intval}{else}5{/if}" 
                   name="{$key|escape:'html':'UTF-8'}" 
                   value="{if isset($field['string_format']) && $field['string_format']}{$value_text|string_format:$field['string_format']|escape:'html':'UTF-8'}{else}{$value_text|escape:'html':'UTF-8'}{/if}"
                   {if isset($field['autocomplete']) && !$field['autocomplete']} autocomplete="off"{/if} />
            </div>
        </div>
    {elseif $field['type'] == 'checklist'}
        <div class="col-lg-9 checklist">
        {foreach $field['choices'] as $k => $v}
            {assign var=id_checkbox value=$field['name']|cat:'_'|cat:$v['id']}
            <div class="checkbox">
                {strip}
                    <label for="{$id_checkbox|escape:'html':'UTF-8'}">
                        <input type="checkbox" name="{$field['name']|escape:'html':'UTF-8'}[]" id="{$id_checkbox|escape:'html':'UTF-8'}" class="{if isset($field['class'])}{$field['class']|escape:'html':'UTF-8'}{/if}" value="{$v['id']|escape:'html':'UTF-8'}"{if isset($fields_value[$field['name']]) && in_array($v['id'], $fields_value[$field['name']])} checked="checked"{/if} />
                        {$v['name']|escape:'html':'UTF-8'}
                    </label>
                {/strip}
            </div>
        {/foreach}
        </div>
    {else}
        {$smarty.block.parent}
    {/if}
{/block}
