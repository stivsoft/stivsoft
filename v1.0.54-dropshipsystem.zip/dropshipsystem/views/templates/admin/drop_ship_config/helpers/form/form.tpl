{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{extends file="helpers/form/form.tpl"}

{block name="input"}
    {if $input.type == 'password'}
        {assign var='value_text' value=$fields_value[$input.name]}
        <div class="input-group fixed-width-lg">
            <span class="input-group-addon">
                <i class="icon-key"></i>
            </span>
            <input type="password"
                id="{if isset($input.id)}{$input.id|intval}{else}{$input.name|escape:'html':'UTF-8'}{/if}"
                name="{$input.name|escape:'html':'UTF-8'}"
                class="{if isset($input.class)}{$input.class|escape:'html':'UTF-8'}{/if}"
                value="{if isset($input.string_format) && $input.string_format}{$value_text|string_format:$input.string_format|escape:'html':'UTF-8'}{else}{$value_text|escape:'html':'UTF-8'}{/if}"
                {if isset($input.autocomplete) && !$input.autocomplete}autocomplete="off"{/if}
                {if isset($input.required) && $input.required } required="required" {/if} />
        </div>
    {elseif $input.type == 'checklist'}
        {foreach $input.values.query as $value}
            {assign var=id_checkbox value=$input.name|cat:'_'|cat:$value[$input.values.id]}
            <div class="checkbox">
                {strip}
                    <label for="{$id_checkbox|escape:'html':'UTF-8'}">
                        <input type="checkbox" name="{$input.name|escape:'html':'UTF-8'}[]" id="{$id_checkbox|escape:'html':'UTF-8'}" class="{if isset($input.class)}{$input.class|escape:'html':'UTF-8'}{/if}" value="{$value[$input.values.id]|escape:'html':'UTF-8'}"{if isset($fields_value[$input.name]) && in_array($value[$input.values.id], $fields_value[$input.name])} checked="checked"{/if} />
                        {$value[$input.values.name]|escape:'html':'UTF-8'}
                    </label>
                {/strip}
            </div>
        {/foreach}
    {elseif $input.type == 'generateuniquecodes'}
        <div class="col-xs-12 col-sm-3">
            <button id="generateuniquecodes" class="btn btn-danger"
                data-title="{l s='Confirmation required' mod='dropshipsystem'}"
                data-text="{l s='Do you want to generate unique codes for all categories ?' mod='dropshipsystem'}"
                data-confirm-button="{l s='Yes, only missing!' mod='dropshipsystem'}"
                data-confirm-button-overwrite="{l s='Yes, overwrite all!' mod='dropshipsystem'}"
                data-cancel-button="{l s='Close' mod='dropshipsystem'}">
                <i class="icon-warning"></i>
                {l s='Generate' mod='dropshipsystem'}
            </button>
        </div>
    {else}
        {$smarty.block.parent}
    {/if}
{/block}
