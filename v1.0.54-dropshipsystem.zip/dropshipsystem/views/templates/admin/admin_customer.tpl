{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div class="col-lg-6"><div class="panel">
    <div class="panel-heading">
        <i class="icon-cog"></i>{l s='Dropshipper' mod='dropshipsystem'}
    </div>
    <div class="form-horizontal">
    {if !$id_dropshipper}
        <div class="row text-center">
            <div class="form-control-static">
                <strong>{$customer->lastname|escape:'html':'UTF-8'} {$customer->firstname|escape:'html':'UTF-8'}</strong> {l s='is not a dropshipper.' mod='dropshipsystem'}
            </div>
            <div class="form-control-static">
                {l s='To configure dropshipper profile for this customer, click the button below.' mod='dropshipsystem'}
            </div>
            <div class="form-control-static">
                <a href="{$link->getAdminLink('AdminDropShip')|escape:'html':'UTF-8'}&id_customer={$customer->id|intval}&adddss_dropshipper" class="btn btn-primary" role="button">
                    {l s='Configure profile' mod='dropshipsystem'}
                </a>
            </div>
        </div>
    {else}
        <form action="{$form|escape:'html':'UTF-8'}" method="post" id="listing">
            <div class="row">
                <label class="control-label col-lg-3">{l s='Status' mod='dropshipsystem'}</label>
                <p class="form-control-static">
                    {if $dropshipper->active}
                    <span class="label label-success">
                        <i class="icon-check"></i>{l s='Active' mod='dropshipsystem'}
                    </span>
                    {else}
                    <span class="label label-danger">
                        <i class="icon-remove"></i>{l s='Disabled' mod='dropshipsystem'}
                    </span>
                    {/if}
                </p>
            </div>
            <div class="row">
                <label class="control-label col-lg-3">{l s='Activation Date' mod='dropshipsystem'}</label>
                <div class="col-lg-9">
                    <p class="form-control-static">{$dropshipper->date_add|escape:'html':'UTF-8'}</p>
                </div>
            </div>
            <div class="row">
                <label class="control-label col-lg-3">{l s='Payment type' mod='dropshipsystem'}</label>
                <div class="col-lg-9">
                    <p class="form-control-static">{$dropshipper->payment_type|escape:'html':'UTF-8'}</p>
                </div>
            </div>
            <div class="row">
                <label class="control-label col-lg-3">{l s='Credit' mod='dropshipsystem'}</label>
                <div class="col-lg-9">
                    <p class="form-control-static">
                        <a href="{$link->getAdminLink('AdminDropShip')|escape:'html':'UTF-8'}&id_dss_dropshipper={$id_dropshipper|intval}&updatedss_dropshipper">
                            {displayPrice price=$dropshipper->credit currency=$currency->id no_utf8=false convert=false}
                        </a>
                    </p>
                </div>
            </div>
            <div class="row">
                <label class="control-label col-lg-3">{l s='Wholesale reduction' mod='dropshipsystem'}</label>
                <div class="col-lg-9">
                    <p class="form-control-static">{$dropshipper->wholesale_reduction|escape:'html':'UTF-8'} %</p>
                </div>
            </div>
            <div class="row">
                <label class="control-label col-lg-3">{l s='Reduction' mod='dropshipsystem'}</label>
                <div class="col-lg-9">
                    <p class="form-control-static">{$dropshipper->reduction|escape:'html':'UTF-8'} %</p>
                </div>
            </div>
            <div class="row">
                <label class="control-label col-lg-3">{l s='Last connection' mod='dropshipsystem'}</label>
                <div class="col-lg-9">
                    <p class="form-control-static">{$dropshipper->last_connection|escape:'html':'UTF-8'}</p>
                </div>
            </div>
            <div class="row">
                <div class="text-center">
                    <a href="{$link->getAdminLink('AdminDropShip')|escape:'html':'UTF-8'}&id_dss_dropshipper={$id_dropshipper|intval}&updatedss_dropshipper" class="btn btn-primary" role="button">
                        {l s='Edit profile' mod='dropshipsystem'}
                    </a>
                </div>
            </div>
        </form>
    {/if}
    </div>
</div>
</div>
