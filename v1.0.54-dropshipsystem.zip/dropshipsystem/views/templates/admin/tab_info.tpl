{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div class="panel">
    <div class="panel-heading">
        <i class="icon-info"></i> {l s='Informations' mod='dropshipsystem'}
    </div>
    <div class="form-wrapper">
        {if $registered == 0}
        <form id="dss_registration_form" method="post" class="form-horizontal">
            <p>
            {l s='Please activate the module by entering your order reference and registration key. This way, if you are eligible for further updates you will be able to claim for them automatically.' mod='dropshipsystem'}
            <br/><strong></strong>{l s='To receive your registration key, please contact us using' mod='dropshipsystem'}</strong>&nbsp;<a href="//addons.prestashop.com/{$suffix|escape:'html':'UTF-8'}/contact-us?id_product=24993" target="_blank">{l s='Addons contact form' mod='dropshipsystem'}</a>
            </p>    
            <div class="form-group">
                <label class="control-label col-lg-3">{l s='Your order reference' mod='dropshipsystem'}</label>
                <div class="col-lg-9">
                    <input id="DSS_REGISTRATION_ORDER" name="DSS_REGISTRATION_ORDER" type="text" class="fixed-width-xxl" value="{$registration_order|escape:'html':'UTF-8'}" autocomplete="off">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-lg-3">{l s='Your registration key' mod='dropshipsystem'}</label>
                <div class="col-lg-9">
                    <input id="DSS_REGISTRATION_KEY" name="DSS_REGISTRATION_KEY" type="text" class="fixed-width-xxl" value="{$registration_key|escape:'html':'UTF-8'}" autocomplete="off">
                </div>
            </div>
            <div class="form-group">
                <div class="col-lg-offset-3 col-lg-9">
                    <input type="submit" name="submitRegistration" class="btn btn-primary" value="{l s='Register' mod='dropshipsystem'}">
                </div>
            </div>
        </form>
        {else}
        <div style="display: block; line-height: 25px; padding: 10px 10px 0px;">
            {if $exist_new_version}
            <font color="red"><b>{l s='New version available' mod='dropshipsystem'} {$dss_new_version|escape:'html':'UTF-8'}</b></font><br>
            {/if}
            {l s='Author' mod='dropshipsystem'} <b>Ruggiero Marco - by PrestaBiz</b><br>
            {l s='Read the' mod='dropshipsystem'}&nbsp;
            <a href="http://www.prestabiz.com/manuals/modules/dropshipsystem/readme_{$suffix|escape:'html':'UTF-8'}.pdf" target="_blank" download="readme_{$suffix|escape:'html':'UTF-8'}.pdf">
                <img src="{$module_dir|escape:'html':'UTF-8'}dropshipsystem/views/img/pdf.gif"> {l s='Installation guide' mod='dropshipsystem'}
            </a>
            <br/>{l s='If you have any questions about this module, please contact me using' mod='dropshipsystem'} <a href="https://addons.prestashop.com/{$suffix|escape:'html':'UTF-8'}/contact-us?id_product=24993" target="_blank">{l s='Addons contact form' mod='dropshipsystem'}</a>
            <br/>{l s='If you bought this module on Addons and you like it, help me to improve it by giving 5 stars in your' mod='dropshipsystem'} <a href="http://addons.prestashop.com/{$suffix|escape:'html':'UTF-8'}/ratings.php" target="_blank">{l s='Addons account' mod='dropshipsystem'}</a>
        </div>
        <div style="display: block; line-height: 25px; padding: 10px 10px 0px;">
            {l s='Define the settings and place the following string in the crontab:' mod='dropshipsystem'}<br/>
            &nbsp;&nbsp;&nbsp;
            <font color="#00B015"><strong>{$cron_string|escape:'html':'UTF-8'}</strong></font>
        </div>
        <div style="display: block; line-height: 25px; padding: 10px 10px 0px;">
            <label>{l s='News' mod='dropshipsystem'}</label>
            {html_entity_decode(($xmlrss|escape:'html':'UTF-8'), $smarty.const.ENT_QUOTES)}
        </div>
        {/if}
    </div>
</div>
