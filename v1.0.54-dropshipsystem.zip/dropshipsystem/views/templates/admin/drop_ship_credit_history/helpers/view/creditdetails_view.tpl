{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div class="row">
    <div class="col-lg-12">
        <div class="defaultForm form-horizontal">
            <div class="panel">
                <div class="panel-heading">
                    <i class="icon-bar-chart"></i>
                    {l s='Credit details' mod='dropshipsystem'}
                </div>
                <div class="form-wrapper">
                    <div class="form-group">
                        <label class="control-label col-lg-3">{l s='Request date' mod='dropshipsystem'}</label>
                        <div class="col-lg-9">
                            <label class="control-label"><strong>{$creditdetails->request_date|escape:'html':'UTF-8'}</strong></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-lg-3">{l s='Operated by' mod='dropshipsystem'}</label>
                        <div class="col-lg-9">
                            <label class="control-label"><strong>{$creditdetails->operator_name|escape:'html':'UTF-8'}</strong></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-lg-3">{l s='Status' mod='dropshipsystem'}</label>
                        <div class="col-lg-9">
                            <label class="control-label"><strong>{$creditdetails->status|ucfirst|escape:'html':'UTF-8'}</strong></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-lg-3">{l s='Currency' mod='dropshipsystem'}</label>
                        <div class="col-lg-9">
                            <label class="control-label"><strong>{$creditdetails->currency|escape:'html':'UTF-8'}</strong></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-lg-3">{l s='Previous credit' mod='dropshipsystem'}</label>
                        <div class="col-lg-9">
                            <label class="control-label"><strong>{displayPrice price=$creditdetails->previous_credit currency=$creditdetails->currency no_utf8=false convert=false}</strong></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-lg-3">{l s='Buyed credit' mod='dropshipsystem'}</label>
                        <div class="col-lg-9">
                            <label class="control-label"><strong>{displayPrice price=$creditdetails->buyed_credit currency=$creditdetails->currency no_utf8=false convert=false}</strong></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-lg-3">{l s='Current credit' mod='dropshipsystem'}</label>
                        <div class="col-lg-9">
                            <label class="control-label"><strong>{displayPrice price=$creditdetails->current_credit currency=$creditdetails->currency no_utf8=false convert=false}</strong></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-lg-3">{l s='Order reference' mod='dropshipsystem'}</label>
                        <div class="col-lg-9">
                            <label class="control-label"><strong>{$creditdetails->reference|escape:'html':'UTF-8'}</strong></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-lg-3">{l s='Product' mod='dropshipsystem'}</label>
                        <div class="col-lg-9">
                            <label class="control-label"><strong>{$creditdetails->product_name|escape:'html':'UTF-8'}</strong></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-lg-3">{l s='Paypal transaction id' mod='dropshipsystem'}</label>
                        <div class="col-lg-9">
                            <label class="control-label"><strong>{$creditdetails->transaction_id|escape:'html':'UTF-8'}</strong></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-lg-3">{l s='Paypal payment status' mod='dropshipsystem'}</label>
                        <div class="col-lg-9">
                            <label class="control-label"><strong>{$creditdetails->payment_status|escape:'html':'UTF-8'}</strong></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-lg-3">{l s='Paypal payment date' mod='dropshipsystem'}</label>
                        <div class="col-lg-9">
                            <label class="control-label">
                                {if strtotime($creditdetails->payment_date) > 0}
                                    <strong>{$creditdetails->payment_date|escape:'html':'UTF-8'}</strong>
                                {/if}
                            </label>
                        </div>
                    </div>
                </div>
    
                <div class="panel-footer">
                    <a class="btn btn-default" href="{$back_url|escape:'html':'UTF-8'}">
                        <i class="process-icon-back"></i>
                        {l s='Back' mod='dropshipsystem'}
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
