{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{strip}
{addJsDef dss_ajaxurl=$dss_ajaxurl|escape:'quotes':'UTF-8'}
{addJsDef dss_token=$dss_token|escape:'quotes':'UTF-8'}
{/strip}