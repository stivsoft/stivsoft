{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{extends file="helpers/form/form.tpl"}
select
{block name="input"}
    {if $input.type == 'text' && $input.name == 'secret'}
        <div class="row">
            <div class="col-lg-4 col-sm-6">
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-key"></i>
                    </span>
                    <input id="{$input.name|escape:'html':'UTF-8'}" name="{$input.name|escape:'html':'UTF-8'}"
                        type="{$input.type|escape:'html':'UTF-8'}" required="required" maxlength="{$input.maxlength|intval}"
                        value="{$fields_value[$input.name]|escape:'html':'UTF-8'}">
                </div>
            </div>
            <div class="col-xs-1">
                <button id="generatesecret" class="btn btn-primary"
                    data-title="{l s='Confirmation required' mod='dropshipsystem'}"
                    data-text="{l s='Do you want to generate a new secret key ?' mod='dropshipsystem'}"
                    data-confirm-button="{l s='Yes, i confirm' mod='dropshipsystem'}"
                    data-cancel-button="{l s='No, close' mod='dropshipsystem'}">
                    <i class="icon-key"></i>
                    {l s='Generate' mod='dropshipsystem'}
                </button>
            </div>
        </div>
    {elseif $input.type == 'text' && $input.name == 'credit'}
        <div class="row">
            <div class="col-sm-2">
                <div class="input-group">
                    <span class="input-group-addon">
                        {$input.prefix|escape:'htmlall':'UTF-8'}
                    </span>
                    <input id="{$input.name|escape:'html':'UTF-8'}" name="{$input.name|escape:'html':'UTF-8'}"
                        type="{$input.type|escape:'html':'UTF-8'}"
                        value="{$fields_value[$input.name]|floatval|string_format:'%.2f'}">
                </div>
            </div>
            <div class="col-sm-8">
                <a id="credithistory" class="btn btn-default {if !$fields_value['id_dss_dropshipper']|intval}disabled{/if}" href="{$link->getAdminLink('AdminDropShipCreditHistory')|escape:'html':'UTF-8'}&id_dss_dropshipper={$fields_value['id_dss_dropshipper']|intval}">
                    <span>
                        <i class="icon-bar-chart"></i>
                        {l s='Show credit history' mod='dropshipsystem'}
                    </span>
                </a>
            </div>
        </div>
    {elseif $input.type == 'switch' && $smarty.const._PS_VERSION_|@addcslashes:'\'' < '1.6'}
        {foreach $input.values as $value}
            <input type="radio" name="{$input.name|escape:'htmlall':'UTF-8'}" id="{$value.id|escape:'htmlall':'UTF-8'}" value="{$value.value|escape:'html':'UTF-8'}"
                    {if $fields_value[$input.name] == $value.value}checked="checked"{/if}
                    {if isset($input.disabled) && $input.disabled}disabled="disabled"{/if} />
            <label class="t" for="{$value.id|escape:'htmlall':'UTF-8'}">
             {if isset($input.is_bool) && $input.is_bool == true}
                {if $value.value == 1}
                    <img src="../img/admin/enabled.gif" alt="{$value.label|escape:'htmlall':'UTF-8'}" title="{$value.label|escape:'htmlall':'UTF-8'}" />
                {else}
                    <img src="../img/admin/disabled.gif" alt="{$value.label|escape:'htmlall':'UTF-8'}" title="{$value.label|escape:'htmlall':'UTF-8'}" />
                {/if}
             {else}
                {$value.label|escape:'htmlall':'UTF-8'}
             {/if}
            </label>
            {if isset($input.br) && $input.br}<br />{/if}
            {if isset($value.p) && $value.p}<p>{$value.p|escape:'htmlall':'UTF-8'}</p>{/if}
        {/foreach}
    {elseif $input.type == 'select' && $input.name == 'id_customer'}
        {if isset($input.options.query) && !$input.options.query && isset($input.empty_message)}
            {$input.empty_message|escape:'html':'UTF-8'}
            {$input.required = false}
            {$input.desc = null}
        {else}
        <div class="row">
            <div class="col-lg-4 col-sm-6">
                <select name="{$input.name|escape:'html':'UTF-8'}"
                        class="{if isset($input.class)}{$input.class|escape:'html':'UTF-8'}{/if} fixed-width-xl"
                        id="{if isset($input.id)}{$input.id|escape:'html':'UTF-8'}{else}{$input.name|escape:'html':'UTF-8'}{/if}"
                        {if isset($input.multiple) && $input.multiple} multiple="multiple"{/if}
                        {if isset($input.size)} size="{$input.size|escape:'html':'UTF-8'}"{/if}
                        {if isset($input.onchange)} onchange="{$input.onchange|escape:'html':'UTF-8'}"{/if}
                        {if isset($input.disabled) && $input.disabled} disabled="disabled"{/if}>
                    {if isset($input.options.default)}
                        <option value="{$input.options.default.value|escape:'html':'UTF-8'}">{$input.options.default.label|escape:'html':'UTF-8'}</option>
                    {/if}
                    {if isset($input.options.optiongroup)}
                        {foreach $input.options.optiongroup.query AS $optiongroup}
                            <optgroup label="{$optiongroup[$input.options.optiongroup.label]|escape:'html':'UTF-8'}">
                                {foreach $optiongroup[$input.options.options.query] as $option}
                                    <option value="{$option[$input.options.options.id]|escape:'html':'UTF-8'}"
                                        {if isset($input.multiple)}
                                            {foreach $fields_value[$input.name] as $field_value}
                                                {if $field_value == $option[$input.options.options.id]}selected="selected"{/if}
                                            {/foreach}
                                        {else}
                                            {if $fields_value[$input.name] == $option[$input.options.options.id]}selected="selected"{/if}
                                        {/if}
                                    >{$option[$input.options.options.name]|escape:'html':'UTF-8'}</option>
                                {/foreach}
                            </optgroup>
                        {/foreach}
                    {else}
                        {foreach $input.options.query AS $option}
                            {if is_object($option)}
                                <option value="{$option->$input.options.id|escape:'html':'UTF-8'}"
                                    {if isset($input.multiple)}
                                        {foreach $fields_value[$input.name] as $field_value}
                                            {if $field_value == $option->$input.options.id}
                                                selected="selected"
                                            {/if}
                                        {/foreach}
                                    {else}
                                        {if $fields_value[$input.name] == $option->$input.options.id}
                                            selected="selected"
                                        {/if}
                                    {/if}
                                >{$option->$input.options.name|escape:'html':'UTF-8'}</option>
                            {elseif $option == "-"}
                                <option value="">-</option>
                            {else}
                                <option value="{$option[$input.options.id]|escape:'html':'UTF-8'}"
                                    {if isset($input.multiple)}
                                        {foreach $fields_value[$input.name] as $field_value}
                                            {if $field_value == $option[$input.options.id]}
                                                selected="selected"
                                            {/if}
                                        {/foreach}
                                    {else}
                                        {if $fields_value[$input.name] == $option[$input.options.id]}
                                            selected="selected"
                                        {/if}
                                    {/if}
                                >{$option[$input.options.name]|escape:'html':'UTF-8'}</option>
                            {/if}
                        {/foreach}
                    {/if}
                </select>
            </div>
            <div class="col-xs-1">
                <button id="gotocustomer" class="btn btn-primary">
                    <i class="icon-user"></i>
                    {l s='Open customer' mod='dropshipsystem'}
                </button>
            </div>
        </div>
        {/if}
    {elseif $input.type == 'timerange'}
        {assign var="input_from_name" value=$input.name|cat:"_from"}
        {assign var="input_to_name" value=$input.name|cat:"_to"}
        <div class="row">
            <div class="col-sm-5">

                <select name="{$input_from_name|escape:'html':'UTF-8'}" style="margin-right: 5px;"
                    class="{if isset($input.class)}{$input.class|escape:'html':'UTF-8'}{else}fixed-width-sm{/if} pull-left"
                    id="{if isset($input.id)}{$input.id|escape:'html':'UTF-8'}{else}{$input_from_name|escape:'html':'UTF-8'}{/if}"
                    {if isset($input.size)} size="{$input.size|escape:'html':'UTF-8'}"{/if}
                    {if isset($input.disabled) && $input.disabled} disabled="disabled"{/if}>
                    {if isset($input.options.from.default)}
                        <option value="{$input.options.from.default.value|escape:'html':'UTF-8'}">{$input.options.from.default.label|escape:'html':'UTF-8'}</option>
                    {/if}
                    {if isset($input.options.from.query)}
                        {foreach $input.options.from.query AS $option}
                            {if is_object($option)}
                                <option value="{$option->$input.options.from.id|escape:'html':'UTF-8'}"
                                    {if $fields_value[$input_from_name] == $option->$input.options.from.id}
                                        selected="selected"
                                    {/if}
                                >{$option->$input.options.from.name|escape:'html':'UTF-8'}</option>
                            {elseif $option == "-"}
                                <option value="">-</option>
                            {else}
                                <option value="{$option[$input.options.from.id]|escape:'html':'UTF-8'}"
                                    {if $fields_value[$input_from_name] == $option[$input.options.from.id]}
                                        selected="selected"
                                    {/if}
                                >{$option[$input.options.from.name]|escape:'html':'UTF-8'}</option>
                            {/if}
                        {/foreach}
                    {/if}
                </select>
                <div class="pull-left" style="margin-right: 10px;">&nbsp;</div>
                <select name="{$input_to_name|escape:'html':'UTF-8'}" style="margin-right: 5px;"
                    class="{if isset($input.class)}{$input.class|escape:'html':'UTF-8'}{else}fixed-width-sm{/if} pull-left"
                    id="{if isset($input.id)}{$input.id|escape:'html':'UTF-8'}{else}{$input_to_name|escape:'html':'UTF-8'}{/if}"
                    {if isset($input.size)} size="{$input.size|escape:'html':'UTF-8'}"{/if}
                    {if isset($input.disabled) && $input.disabled} disabled="disabled"{/if}>
                    {if isset($input.options.to.default)}
                        <option value="{$input.options.to.default.value|escape:'html':'UTF-8'}">{$input.options.to.default.label|escape:'html':'UTF-8'}</option>
                    {/if}
                    {if isset($input.options.to.query)}
                        {foreach $input.options.to.query AS $option}
                            {if is_object($option)}
                                <option value="{$option->$input.options.to.id|escape:'html':'UTF-8'}"
                                    {if $fields_value[$input_to_name] == $option->$input.options.to.id}
                                        selected="selected"
                                    {/if}
                                >{$option->$input.options.to.name|escape:'html':'UTF-8'}</option>
                            {elseif $option == "-"}
                                <option value="">-</option>
                            {else}
                                <option value="{$option[$input.options.to.id]|escape:'html':'UTF-8'}"
                                    {if $fields_value[$input_to_name] == $option[$input.options.to.id]}
                                        selected="selected"
                                    {/if}
                                >{$option[$input.options.to.name]|escape:'html':'UTF-8'}</option>
                            {/if}
                        {/foreach}
                    {/if}
                </select>
                {if $fields_value[$input_from_name] > $fields_value[$input_to_name]}
                    <div class="pull-left" style="margin-right: 10px;">{l s='of next day' mod='dropshipsystem'}</div>
                {/if}
            </div>
        </div>
    {else}
        {$smarty.block.parent}
    {/if}
{/block}
