{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{extends file="helpers/form/form.tpl"}

{block name="input"}
    {if $input.type == 'checkboxlist'}
        {foreach $input.values.query as $value}
            {assign var=id_checkbox value=$input.name|cat:'_'|cat:strval($value[$input.values.id])}
            <p class="checkbox">
                <label for="{$id_checkbox|escape:'htmlall':'UTF-8'}" class="control-label">
                    <input type="checkbox" name="{$id_checkbox|escape:'htmlall':'UTF-8'}" id="{$id_checkbox|escape:'htmlall':'UTF-8'}" value="1" {if isset($fields_value[$id_checkbox]) && $fields_value[$id_checkbox]}checked="checked"{/if} />
                    {if $value[$input.values.type] == 'info'}
                        <span class="label label-info">
                    {elseif $value[$input.values.type] == 'alert'}
                        <span class="label label-warning">
                    {elseif $value[$input.values.type] == 'error'}
                        <span class="label label-danger">
                    {/if}
                    {$checkboxlist[$value['id']]|escape:'htmlall':'UTF-8'}
                    {$value[$input.values.name]|escape:'htmlall':'UTF-8'}
                    </span>
                </label>
            </p>
        {/foreach}
    {else}
        {$smarty.block.parent}
    {/if}
{/block}
