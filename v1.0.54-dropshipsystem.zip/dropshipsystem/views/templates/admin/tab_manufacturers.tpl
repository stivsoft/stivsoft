{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div class="panel">
    <div class="panel-heading">
        <i class="icon-building"></i> {l s='Manufacturers' mod='dropshipsystem'}
    </div>
    <div class="form-wrapper">
        <table class="dss table" style="border: 0; cellspacing: 0;">
            <thead>
                <tr>
                    <th class="title"><strong>{l s='Manufacturers' mod='dropshipsystem'}</strong></th>
                    {if isset($groups) && $groups}
                        {foreach $groups as $group}
							<th class="rotate title_box"><div><span title="{$group|escape:'html':'UTF-8'}">{$group|escape:'html':'UTF-8'}</span></div></th>
                        {/foreach}
                    {/if}
                </tr>
            </thead>
            <tbody>
                {if isset($manufacturers) && $manufacturers}
					{if count($manufacturers) > 10}
                    <tr>
                        <td><strong>{l s='Select all' mod='dropshipsystem'}</strong></td>
                        {foreach $groups as $key => $group}
                        <td>
                            <button class="list-action-enable-all action-enabled"
                               data-type="manufacturer"
							   data-id="check"
                               data-group="{$key|intval}">
                                <i class="icon-check"></i>
                            </button>
                            <button class="list-action-enable-all action-disabled"
                               data-type="manufacturer"
							   data-id="remove"
                               data-group="{$key|intval}">
                                <i class="icon-remove"></i>
                            </button>
                        </td>
                        {/foreach}
                    </tr>
					{/if}
                    {foreach $manufacturers as $manufacturer}
                    <tr>
                        <td>{$manufacturer['name']|escape:'html':'UTF-8'}</td>
                        {foreach $groups as $key => $group}
                            {assign var='active' value=$dss_manufacturers[$manufacturer['id_manufacturer']][$key]|intval}
                        <td class="items">
                            {if $active == 1}
                            <a class="list-action-enable action-enabled" href="#"
                               data-type="manufacturer"
                               data-id="{$manufacturer['id_manufacturer']|intval}"
                               data-group="{$key|intval}"
                               title="{l s='Enabled' mod='dropshipsystem'}">
                                <i class="icon-check"></i>
                                <i class="icon-remove hidden"></i>
                            </a>
                            {else}
                            <a class="list-action-enable action-disabled" href="#"
                               data-type="manufacturer"
                               data-id="{$manufacturer['id_manufacturer']|intval}"
                               data-group="{$key|intval}"
                               title="{l s='Disabled' mod='dropshipsystem'}">
                                <i class="icon-check hidden"></i>
                                <i class="icon-remove"></i>
                            </a>
                            {/if}
                        </td>
                        {/foreach}
                    </tr>
                    {/foreach}
				{else}
				<tr>
					<td class="text-centered" colspan="{count($groups)|intval}">{l s='No manufacturer to list' mod='dropshipsystem'}</td>
				</tr>
                {/if}
            </tbody>
        </table>
    </div>
</div>
