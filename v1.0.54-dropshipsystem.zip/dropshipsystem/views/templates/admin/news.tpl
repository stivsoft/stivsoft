{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{if $news}
    <div id="news_list" style="display: block; padding: 10px 10px 0px; overflow-y: auto; height: 115px;">
    {foreach from=$news item=new name=news}
        <div class="col-sm-2" style="font-weight: bold">{$new['date']|escape:'html':'UTF-8'}</div>
        <div class="col-sm-10">
            <div style="font-weight: bold">
                {if $new['isnew'] == true}<img src="../img/admin/news-new.gif">{/if}
                {$new['title']|escape:'html':'UTF-8'}
            </div>
            <div style="text-align: justify">{html_entity_decode(($new['text']|escape:'html':'UTF-8'), $smarty.const.ENT_QUOTES)}</div>
        </div>
        <div class="clear clearfix" style="padding-bottom: 20px"></div>
    {/foreach}
    </div>
{/if}
