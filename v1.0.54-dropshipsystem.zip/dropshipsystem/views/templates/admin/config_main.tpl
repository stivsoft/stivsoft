{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div class="dss panel panel-default">
    <div class="panel-heading">
        <img src="{$module_dir|escape:'html':'UTF-8'}dropshipsystem/logo.gif" />
        {l s='Drop Ship System' mod='dropshipsystem'} - v.{$dss_version|escape:'html':'UTF-8'}
    </div>
    <div style="padding:0px;" class="panel-body">
        <div class="col-md-2">
            <ul class="nav nav-pills nav-stacked">
                <li role="presentation" class="active">
                    <a href="#info" aria-controls="info" role="tab" data-toggle="tab">
                        <i class="icon-info"></i>
                        {l s='INFORMATIONS' mod='dropshipsystem'}
                    </a>
                </li>
                {if $registered > 0}
                <li role="presentation">
                    <a href="#settings" aria-controls="settings" role="tab" data-toggle="tab">
                        <i class="icon-cogs"></i>
                        {l s='SETTINGS' mod='dropshipsystem'}
                    </a>
                </li>
                {/if}
                {if $registered > 0}
                <li role="presentation">
                    <a href="#categories_group" aria-controls="categories_group" role="tab" data-toggle="tab">
                        <i class="icon-folder-open"></i>
                        {l s='CATEGORIES GROUP' mod='dropshipsystem'}
                    </a>
                </li>
                {/if}
                {if $registered > 0}
                <li role="presentation">
                    <a href="#manufacturers" aria-controls="manufacturers" role="tab" data-toggle="tab">
                        <i class="icon-building"></i>
                        {l s='MANUFACTURERS' mod='dropshipsystem'}
                    </a>
                </li>
                {/if}
                {if $registered > 0}
                <li role="presentation">
                    <a href="#suppliers" aria-controls="suppliers" role="tab" data-toggle="tab">
                        <i class="icon-users"></i>
                        {l s='SUPPLIERS' mod='dropshipsystem'}
                    </a>
                </li>
                {/if}
                {if $registered > 0}
                <li role="presentation">
                    <a href="#shipping" aria-controls="shipping" role="tab" data-toggle="tab">
                        <i class="icon-truck"></i>
                        {l s='SHIPPING' mod='dropshipsystem'}
                    </a>
                </li>
                {/if}
                {if $registered > 0}
                <li role="presentation">
                    <a href="#payments" aria-controls="payments" role="tab" data-toggle="tab">
                        <i class="icon-money"></i>
                        {l s='PAYMENTS' mod='dropshipsystem'}
                    </a>
                </li>
                {/if}
                {if $registered > 0}
                <li role="presentation">
                    <a href="#documents" aria-controls="documents" role="tab" data-toggle="tab">
                        <i class="icon-AdminCatalog"></i>
                        {l s='DOCUMENTS' mod='dropshipsystem'}
                    </a>
                </li>
                {/if}
                {if $registered > 0}
                <li role="presentation">
                    <a href="http://addons.prestashop.com/{$suffix|escape:'html':'UTF-8'}/ratings.php" target="_blank">
                        <i class="icon-star yellow"></i>
                        {l s='RATE MODULE' mod='dropshipsystem'}
                    </a>
                </li>
                {/if}
            </ul>
        </div>
        <div class="col-md-10">
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane fade in active" id="info">{html_entity_decode(($tab.info|escape:'htmlall':'UTF-8'), $smarty.const.ENT_QUOTES)}</div>
                {if $registered > 0}<div role="tabpanel" class="tab-pane fade" id="settings">{html_entity_decode(($tab.settings|escape:'htmlall':'UTF-8'), $smarty.const.ENT_QUOTES)}</div>{/if}
                {if $registered > 0}<div role="tabpanel" class="tab-pane fade" id="categories_group">{html_entity_decode(($tab.categories_group|escape:'htmlall':'UTF-8'), $smarty.const.ENT_QUOTES)}</div>{/if}
                {if $registered > 0}<div role="tabpanel" class="tab-pane fade" id="manufacturers">{html_entity_decode(($tab.manufacturers|escape:'htmlall':'UTF-8'), $smarty.const.ENT_QUOTES)}</div>{/if}
                {if $registered > 0}<div role="tabpanel" class="tab-pane fade" id="suppliers">{html_entity_decode(($tab.suppliers|escape:'htmlall':'UTF-8'), $smarty.const.ENT_QUOTES)}</div>{/if}
                {if $registered > 0}<div role="tabpanel" class="tab-pane fade" id="shipping">{html_entity_decode(($tab.shipping|escape:'htmlall':'UTF-8'), $smarty.const.ENT_QUOTES)}</div>{/if}
                {if $registered > 0}<div role="tabpanel" class="tab-pane fade" id="payments">{html_entity_decode(($tab.payments|escape:'htmlall':'UTF-8'), $smarty.const.ENT_QUOTES)}</div>{/if}
                {if $registered > 0}<div role="tabpanel" class="tab-pane fade" id="documents">{html_entity_decode(($tab.documents|escape:'htmlall':'UTF-8'), $smarty.const.ENT_QUOTES)}</div>{/if}
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    var dss_l = {ldelim}
        'cancel'                : "{l s='Cancel' mod='dropshipsystem' js=1}",
        'remove'                : "{l s='remove' mod='dropshipsystem' js=1}",
        'do_you_want_remove'    : "{l s='Do you want remove this plugin ?' mod='dropshipsystem' js=1}",
	{rdelim};
</script>
{strip}
{addJsDef dss_ajaxurl=$dss_ajaxurl|escape:'quotes':'UTF-8'}
{addJsDef dss_token=$dss_token|escape:'quotes':'UTF-8'}
{/strip}
