{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{if isset($specificWholesalePriceModificationForm)}
<div id="moduledropship-product-wholesale-price" class="panel product-tab hidden">
    <h3>
        <img src="{$base_url|escape:'html':'UTF-8'}modules/dropshipsystem/logo.gif" />
        {l s='Dropship specific wholesale prices (Only for resellers)' mod='dropshipsystem'}
    </h3>
    <div class="alert alert-info">
        {l s='You can set specific prices for clients belonging to different groups, different countries, etc.' mod='dropshipsystem'}
    </div>
    {if $id_product == 0}
    <div class="alert alert-warning">
        {l s='You must save this product before adding custom options.' mod='dropshipsystem'}
    </div>
    {else}
    <div class="form-group">
        <div class="col-lg-12">
            <a class="btn btn-default" href="#" id="show_specific_wholesale_price">
                <i class="icon-plus-sign"></i> {l s='Add a new specific price' mod='dropshipsystem'}
            </a>
            <a class="btn btn-default" href="#" id="hide_specific_wholesale_price" style="display:none">
                <i class="icon-remove text-danger"></i> {l s='Cancel new specific price' mod='dropshipsystem'}
            </a>
        </div>
    </div>
	<div id="add_specific_wholesale_price" class="well clearfix" style="display: none;">
		<div class="col-lg-12">
			<div class="form-group">
				<label class="control-label col-lg-2" for="{if !$multi_shop}swpm_currency_0{else}swp_id_shop{/if}">{l s='For' mod='dropshipsystem'}</label>
				<div class="col-lg-9">
					<div class="row">
					{if !$multi_shop}
						<input type="hidden" name="swp_id_shop" value="0" />
					{else}
						<div class="col-lg-3">
							<select name="swp_id_shop" id="swp_id_shop">
								{if !$admin_one_shop}<option value="0">{l s='All shops' mod='dropshipsystem'}</option>{/if}
								{foreach from=$shops item=shop}
								<option value="{$shop.id_shop|intval}">{$shop.name|escape:'htmlall':'UTF-8'}</option>
								{/foreach}
							</select>
						</div>
					{/if}
						<div class="col-lg-3">
							<select name="swp_id_currency" id="swpm_currency_0" onchange="changeCurrencySpecificWholesalePrice(0);">
								<option value="0">{l s='All currencies' mod='dropshipsystem'}</option>
								{foreach from=$currencies item=curr}
								<option value="{$curr.id_currency|intval}">{$curr.name|escape:'htmlall':'UTF-8'}</option>
								{/foreach}
							</select>
						</div>
						<div class="col-lg-3">
							<select name="swp_id_country" id="swp_id_country">
								<option value="0">{l s='All countries' mod='dropshipsystem'}</option>
								{foreach from=$countries item=country}
								<option value="{$country.id_country|intval}">{$country.name|escape:'htmlall':'UTF-8'}</option>
								{/foreach}
							</select>
						</div>
						<div class="col-lg-3">
							<select name="swp_id_group" id="swp_id_group">
								<option value="0">{l s='All groups' mod='dropshipsystem'}</option>
								{foreach from=$groups item=group}
								<option value="{$group.id_group|intval}">{$group.name|escape:'htmlall':'UTF-8'}</option>
								{/foreach}
							</select>
						</div>
					</div>
				</div>
			</div>
			{if $combinations|@count != 0}
			<div class="form-group">
				<label class="control-label col-lg-2" for="swp_id_product_attribute">{l s='Combination:' mod='dropshipsystem'}</label>
				<div class="col-lg-4">
					<select id="swp_id_product_attribute" name="swp_id_product_attribute">
						<option value="0">{l s='Apply to all combinations' mod='dropshipsystem'}</option>
					{foreach from=$combinations item='combination'}
						<option value="{$combination.id_product_attribute|intval}">{$combination.attributes|escape:'htmlall':'UTF-8'}</option>
					{/foreach}
					</select>
				</div>
			</div>
			{/if}
			<div class="form-group">
				<label class="control-label col-lg-2" for="swp_from">{l s='Available' mod='dropshipsystem'}</label>
				<div class="col-lg-9">
					<div class="row">
						<div class="col-lg-4">
							<div class="input-group">
								<span class="input-group-addon">{l s='from' mod='dropshipsystem'}</span>
								<input type="text" name="swp_from" class="datepicker" value="" style="text-align: center" id="swp_from" />
								<span class="input-group-addon"><i class="icon-calendar-empty"></i></span>
							</div>
						</div>
						<div class="col-lg-4">
							<div class="input-group">
								<span class="input-group-addon">{l s='to' mod='dropshipsystem'}</span>
								<input type="text" name="swp_to" class="datepicker" value="" style="text-align: center" id="swp_to" />
								<span class="input-group-addon"><i class="icon-calendar-empty"></i></span>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-lg-2" for="swp_value">{l s='Reduction / Charge' mod='dropshipsystem'}</label>
				<div class="col-lg-10">
					<div class="row">
						<div class="col-lg-3">
						    <div class="input-group">
                                <span class="input-group-addon">%</span>
                                <input type="text" class="fixed-width-sm" name="swp_value" id="swp_value" value="0.00" onchange="noComma('swp_value');"/>
                            </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

    <script type="text/javascript">
    $(document).ready(function() {
        $('#moduledropship-product-wholesale-price').detach().insertAfter('#product-prices');
        $('#moduledropship-product-wholesale-price').removeClass('hidden');

        $('.datepicker').datetimepicker({
            prevText: '',
            nextText: '',
            dateFormat: 'yy-mm-dd',
            currentText: '{l s='Now' mod='dropshipsystem' js=1}',
            closeText: '{l s='Done' mod='dropshipsystem' js=1}',
            ampm: false,
            amNames: ['AM', 'A'],
            pmNames: ['PM', 'P'],
            timeFormat: 'hh:mm:ss tt',
            timeSuffix: '',
            timeOnlyTitle: '{l s='Choose Time' mod='dropshipsystem' js=1}',
            timeText: '{l s='Time' mod='dropshipsystem' js=1}',
            hourText: '{l s='Hour' mod='dropshipsystem' js=1}',
            minuteText: '{l s='Minute' mod='dropshipsystem' js=1}'
        });
    });
    </script>
    <div class="table-responsive">
        <table id="specific_wholesale_prices_list" class="table table-bordered">
            <thead>
                <tr>
                    <th>{l s='Combination' mod='dropshipsystem'}</th>
                    {if $multi_shop}<th>{l s='Shop' mod='dropshipsystem'}</th>{/if}
                    <th>{l s='Currency' mod='dropshipsystem'}</th>
                    <th>{l s='Country' mod='dropshipsystem'}</th>
                    <th>{l s='Group' mod='dropshipsystem'}</th>
                    <th>{l s='Reduction / Charge' mod='dropshipsystem'}</th>
                    <th>{l s='Period' mod='dropshipsystem'}</th>
                    <th>{l s='Action' mod='dropshipsystem'}</th>
                </tr>
            </thead>
            <tbody>
                {$specificWholesalePriceModificationForm}
                <script type="text/javascript">
                    $(document).ready(function() {
                        delete_wholesale_price_rule = "{l s='Do you really want to remove this wholesale price rule?' mod='dropshipsystem'}";
                        //calcPriceTI();
                        //unitPriceWithTax('unit');
                    });
                </script>
    {/if}
{/if}

