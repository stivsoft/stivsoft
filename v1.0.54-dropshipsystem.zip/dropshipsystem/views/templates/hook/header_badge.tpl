{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<li id="dropshippers_notif" class="dropdown" data-type="dropshipper" style="display:none;">
    <a href="javascript:void(0);" class="dropdown-toggle dss-notifs" data-toggle="dropdown">
        <i class="icon-handshake"></i>
        <span id="dropshippers_notif_number_wrapper" class="notifs_badge hide">
            <span id="dropshippers_notif_value">0</span>
        </span>
    </a>
    <div class="dropdown-menu notifs_dropdown">
        <section id="dropshippers_notif_wrapper" class="notifs_panel">
            <div class="notifs_panel_header">
                <h3>{l s='Latest Dropshipper Registrations' mod='dropshipsystem'}</h3>
            </div>
            <div id="list_dropshippers_notif" class="list_notif">
                <span class="no_notifs">
                    {l s='No new dropshipper have registered on your shop.' mod='dropshipsystem'}
                </span>
            </div>
            <div class="notifs_panel_footer">
                <a href="index.php?controller=AdminDropShip&amp;token={getAdminToken tab='AdminDropShip'}">{l s='Show all dropshippers' mod='dropshipsystem'}</a>
            </div>
        </section>
    </div>
</li>
