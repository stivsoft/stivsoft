{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{if $id_product == 0}
    <div class="alert alert-warning">
        {l s='You must save this product before adding custom options.' mod='dropshipsystem'}
    </div>
{else}
    <div class="row">
        <ul class="nav nav-tabs js-nav-tabs" id="dss-form-nav" role="tablist">
            <li id="dss_tab_step1" class="nav-item"><a href="#dss_step1" role="tab" data-toggle="tab" class="nav-link active" aria-expanded="true">{l s='Specific wholesale prices' mod='dropshipsystem'}</a></li>
            <li id="dss_tab_step2" class="nav-item"><a href="#dss_step2" role="tab" data-toggle="tab" class="nav-link">{l s='Options' mod='dropshipsystem'}</a></li>
        </ul>
        <div class="tab-content">
            <div role="tabpanel" class="form-contenttab tab-pane active" id="dss_step1" aria-expanded="true">
                <div id="moduledropship-product-wholesale-price">
                    <input id="swp_id_product" type="hidden" value="{$id_product}" />
                    <div class="col-md-12">
                        <h2>{l s='Specific wholesale prices (Only for resellers)' mod='dropshipsystem'}</h2>
                        <div class="alert alert-info">
                            {l s='You can set specific prices for clients belonging to different groups, different countries, etc.' mod='dropshipsystem'}
                        </div>
                        <div class="specific-wholesale-price" class="m-b-2">
                            <div class="col-lg-12">
                                <a class="btn btn-action m-b-2" href="#" id="show_specific_wholesale_price">
                                    <i class="material-icons">add_circle</i> {l s='Add a new specific price' mod='dropshipsystem'}
                                </a>
                                <a class="btn btn-action m-b-2" href="#" id="hide_specific_wholesale_price" style="display:none">
                                    <i class="material-icons">remove_circle</i> {l s='Cancel new specific price' mod='dropshipsystem'}
                                </a>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div id="specific-wholesale-price-form" class="clearfix" style="display: none;"
                            data-action="{$dss_ajaxurl}&add">
                            <div class="card card-block">
                                <h4><b>{l s='Specific conditions on wholesale price' mod='dropshipsystem'}</b></h4>
                                {if !$multi_shop}
                                    <input type="hidden" name="swp_id_shop" value="0" />
                                {else}
                                <div class="row">
                                    <div class="col-md-6">
                                        <fieldset class="form-group">
                                            <label class="control-label">{l s='Shop' mod='dropshipsystem'}</label>
                                            <select name="swp_id_shop" id="swp_id_shop" class="form-control">
                                                {if !$admin_one_shop}<option value="0">{l s='All shops' mod='dropshipsystem'}</option>{/if}
                                                {foreach from=$shops item=shop}
                                                <option value="{$shop.id_shop}">{$shop.name|htmlentitiesUTF8}</option>
                                                {/foreach}
                                            </select>
                                        </fieldset>
                                    </div>
                                </div>
                                {/if}
                                <div class="row">
                                    <div class="col-md-3">
                                        <fieldset class="form-group">
                                            <label class="control-label" for="{if !$multi_shop}swpm_currency_0{else}swp_id_shop{/if}">{l s='For' mod='dropshipsystem'}</label>
                                            <select name="swp_id_currency" id="swpm_currency_0" class="form-control">
                                                <option value="0">{l s='All currencies' mod='dropshipsystem'}</option>
                                                {foreach from=$currencies item=curr}
                                                <option value="{$curr.id_currency}">{$curr.name|htmlentitiesUTF8}</option>
                                                {/foreach}
                                            </select>
                                        </fieldset>
                                    </div>
                                    <div class="col-md-3">
                                        <fieldset class="form-group">
                                            <label class="control-label"> </label>
                                            <select name="swp_id_country" id="swp_id_country" class="form-control">
                                                <option value="0">{l s='All countries' mod='dropshipsystem'}</option>
                                                {foreach from=$countries item=country}
                                                <option value="{$country.id_country}">{$country.name|htmlentitiesUTF8}</option>
                                                {/foreach}
                                            </select>
                                        </fieldset>
                                    </div>
                                    <div class="col-md-3">
                                        <fieldset class="form-group">
                                            <label class="control-label"> </label>
                                            <select name="swp_id_group" id="swp_id_group" class="form-control">
                                                <option value="0">{l s='All groups' mod='dropshipsystem'}</option>
                                                {foreach from=$groups item=group}
                                                <option value="{$group.id_group}">{$group.name}</option>
                                                {/foreach}
                                            </select>
                                        </fieldset>
                                    </div>
                                </div>
                                {if $combinations|@count != 0}
                                <div class="row">
                                    <div class="col-md-6">
                                        <fieldset class="form-group">
                                            <label class="control-label" for="swp_id_product_attribute">{l s='Combination:' mod='dropshipsystem'}</label>
                                            <select id="swp_id_product_attribute" name="swp_id_product_attribute" class="form-control"
                                                data-action="{url entity='sf' route='admin_get_product_combinations' sf-params=['idProduct' => {$id_product}]}">
                                                <option value="0">{l s='Apply to all combinations' mod='dropshipsystem'}</option>
                                            {foreach from=$combinations item='combination'}
                                                <option value="{$combination.id_product_attribute}">{$combination.attributes}</option>
                                            {/foreach}
                                            </select>
                                        </fieldset>
                                    </div>
                                </div>
                                {/if}
                                <div class="clearfix"></div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <fieldset class="form-group">
                                            <label class="control-label">{l s='Available from' mod='dropshipsystem'}</label>
                                            <div class="input-group datepicker">
                                                <input class="form-control" id="swp_from" name="swp_from" placeholder="YYYY-MM-DD" type="text">
                                                <div class="input-group-addon">
                                                    <i class="material-icons">date_range</i>
                                                </div>
                                            </div>
                                        </fieldset>
                                    </div>
                                    <div class="col-md-3">
                                        <fieldset class="form-group">
                                            <label class="control-label">{l s='Available to' mod='dropshipsystem'}</label>
                                            <div class="input-group datepicker">
                                                <input class="form-control" id="swp_to" name="swp_to" placeholder="YYYY-MM-DD" type="text">
                                                <div class="input-group-addon">
                                                    <i class="material-icons">date_range</i>
                                                </div>
                                            </div>
                                        </fieldset>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <fieldset class="form-group">
                                            <label class="control-label">{l s='Reduction / Charge' mod='dropshipsystem'}</label>
                                            <div class="input-group money-type">
                                                <span class="input-group-addon">%</span>
                                                <input type="text" class="form-control" name="swp_value" id="swp_value" value="0.00" onchange="noComma('swp_value');"/>
                                            </div>
                                        </fieldset>
                                    </div>
                                </div>
                                <div class="col-md-12 text-xs-right">
                                    <button type="button" id="swp_cancel" name="swp_cancel" class="btn-tertiary-outline js-cancel btn">{l s='Cancel' mod='dropshipsystem'}</button>
                                    <button type="button" id="swp_save" name="swp_save" class="btn-primary-outline js-save btn">{l s='Apply' mod='dropshipsystem'}</button>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>

                        <table id="js-specific-wholesale-price-list" class="table table-striped seo-table hide"
                            data="{$dss_ajaxurl}"
                            data-action-delete="{$dss_products_url}&id_product={$id_product}">
                            <thead>
                                <tr>
                                    <th>{l s='Combination' mod='dropshipsystem'}</th>
                                    {if $multi_shop}<th>{l s='Shop' mod='dropshipsystem'}</th>{/if}
                                    <th>{l s='Currency' mod='dropshipsystem'}</th>
                                    <th>{l s='Country' mod='dropshipsystem'}</th>
                                    <th>{l s='Group' mod='dropshipsystem'}</th>
                                    <th>{l s='Reduction / Charge' mod='dropshipsystem'}</th>
                                    <th>{l s='Period' mod='dropshipsystem'}</th>
                                    <th>{l s='Action' mod='dropshipsystem'}</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div role="tabpanel" class="form-contenttab tab-pane" id="dss_step2" aria-expanded="true">
                <div id="product-moduledropship">
                    <div class="col-md-12">
                        <h2>{l s='Options' mod='dropshipsystem'}</h2>
                        <div class="form-group">
                            <div class="col-lg-12">
                                <label class="col-lg-2">
                                    {l s='Credit product' mod='dropshipsystem'}
                                </label>
                                <div class="col-lg-9">
                                    <div class="radio">
                                        <label class="radioCheck" for="is_credit_product_on">
                                            <input id="is_credit_product_on" name="is_credit_product" type="radio" value="1" {if $is_credit_product}checked="checked"{/if}>
                                            {l s='Yes' mod='dropshipsystem'}
                                        </label>
                                        <label class="radioCheck" for="is_credit_product_off">
                                            <input id="is_credit_product_off" name="is_credit_product" type="radio" value="0" {if !$is_credit_product}checked="checked"{/if}>
                                            {l s='No' mod='dropshipsystem'}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-12">
                                <label class="col-lg-2">
                                    {l s='Excluded groups' mod='dropshipsystem'}
                                </label>
                                <div class="col-lg-6">
                                {if count($groups) && isset($groups)}
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th class="fixed-width-xs">
                                                    <span class="title_box">
                                                        <input type="checkbox" name="checkme" id="checkme" onclick="checkDelBoxes(this.form, 'groupBox[]', this.checked)" />
                                                    </span>
                                                </th>
                                                <th class="fixed-width-xs"><span class="title_box">{l s='ID' mod='dropshipsystem'}</span></th>
                                                <th>
                                                    <span class="title_box">
                                                        {l s='Group name' mod='dropshipsystem'}
                                                    </span>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        {foreach $groups as $key => $group}
                                            {assign var=id_checkbox value=groupBox|cat:'_'|cat:$group['id_group']}
                                            <tr>
                                                <td>
                                                    <input type="checkbox" name="groupBox[]" class="groupBox" id="{$id_checkbox|escape:'htmlall':'UTF-8'}" value="{$group['id_group']|intval}" {if isset($selected_groups[$group['id_group']]) && $selected_groups[$group['id_group']]}checked="checked"{/if} />
                                                </td>
                                                <td>{$group['id_group']|intval}</td>
                                                <td>
                                                    <label for="{$id_checkbox|escape:'htmlall':'UTF-8'}">{$group['name']|escape:'htmlall':'UTF-8'}</label>
                                                </td>
                                            </tr>
                                        {/foreach}
                                        </tbody>
                                    </table>
                                {else}
                                    <p>{l s='No group created' mod='dropshipsystem'}</p>
                                {/if}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
{/if}