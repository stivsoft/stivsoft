{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div class="dss-product-add-to-cart">
    <div class="product-prices">
        <span class="label">{l s='Your reserved price' mod='dropshipsystem'}</span>
        <div class="product-price h5" data-price="{$dss_product_price}" data-hidden="{if $dss_hidden_price}true{else}false{/if}">
            <span class="{if $dss_hidden_price}price-hide{/if}"><span>{$dss_formatted_product_price}</span></span>
        </div>
    </div>

    <div class="product-quantity clearfix">
        <div class="qty">
            <input class="text-xs-center dss-cart-product-quantity" type="text" value="1" name="product-quantity" min="1" />
        </div>
        <div class="add">
            <button type="button" class="btn btn-primary dss-add-to-cart"
                {if !$product.availability == 'available' && !$product.availability == 'last_remaining_items'}disabled{/if}>
                <i class="material-icons shopping-cart">&#xE547;</i>
                {l s='Add to dropship cart' mod='dropshipsystem'}
            </button>
        </div>
    </div>
</div>

<div id="dss-blockcart-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title h6 text-sm-center" id="myModalLabel"><i class="material-icons rtl-no-flip"></i>{l s='Product added to your dropship cart' mod='dropshipsystem'}</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-5 divide-right">
                        <div class="row">
                            <div class="col-md-6">
                                <img class="product-image" src="" alt="" title="">
                            </div>
                            <div class="col-md-6">
                                <h6 class="h6 product-name"></h6>
                                <p class="product-price">
                                    {l s='Price' mod='dropshipsystem'}:&nbsp;
                                    <span></span>
                                </p>
                                <div class="variants"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="cart-content">
                            <p class="cart-products-count">&nbsp;</p>
                            <p class="cart-total"><strong>{l s='Total products' mod='dropshipsystem'}:</strong>
                                <span>&nbsp;</span>
                            </p>
                            <div class="cart-content-btn">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">{l s='Continue shopping' mod='dropshipsystem'}</button>
                                <a href="{$dss_cart_url}" class="btn btn-primary"><i class="material-icons rtl-no-flip"></i>{l s='Proceed with checkout' mod='dropshipsystem'}</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
