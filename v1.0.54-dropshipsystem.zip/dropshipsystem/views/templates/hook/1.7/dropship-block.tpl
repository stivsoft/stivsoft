{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<!-- Block dropship module -->
{if isset($page.page_name) && $page.page_name == 'module-dropshipsystem-mydropshipaccount' && $DSS_DOWNLOAD_BLOCK_ENABLE|intval neq 0}

{block name='page_content'}
<div class="dropship page-header"><h1>{l s='Actions' mod='dropshipsystem'}</h1></div>
<div class="block dropship">
    <h6 class="title_block">{l s='Catalog Feeds' mod='dropshipsystem'}</h6>
    <div class="block_content list-block">
        <ul>
            {if $DSS_FILE_CATEGORIES_ENABLE|intval neq 0}
            <li><a href="{$link->getModuleLink('dropshipsystem', 'downloads', ['file' => 'categories.csv'], true)|escape:'htmlall':'UTF-8'}" title="{l s='Categories CSV' mod='dropshipsystem'}" target="_blank">{l s='Categories CSV' mod='dropshipsystem'}</a></li>
            <li><a href="{$link->getModuleLink('dropshipsystem', 'downloads', ['file' => 'categories.xml'], true)|escape:'htmlall':'UTF-8'}" title="{l s='Categories XML' mod='dropshipsystem'}" target="_blank">{l s='Categories XML' mod='dropshipsystem'}</a></li>
            {/if}
            {if $DSS_FILE_PRODUCTS_ENABLE|intval neq 0}
            <li><a href="{$link->getModuleLink('dropshipsystem', 'downloads', ['file' => 'products.csv'], true)|escape:'htmlall':'UTF-8'}" title="{l s='Products CSV' mod='dropshipsystem'}" target="_blank">{l s='Products CSV' mod='dropshipsystem'}</a></li>
            <li><a href="{$link->getModuleLink('dropshipsystem', 'downloads', ['file' => 'products.xml'], true)|escape:'htmlall':'UTF-8'}" title="{l s='Products XML' mod='dropshipsystem'}" target="_blank">{l s='Products XML' mod='dropshipsystem'}</a></li>
            {/if}
            {if $DSS_FILE_PRICELIST_ENABLE|intval neq 0}
            <li><a href="{$link->getModuleLink('dropshipsystem', 'downloads', ['file' => 'pricelist.csv'], true)|escape:'htmlall':'UTF-8'}" title="{l s='Pricelist CSV' mod='dropshipsystem'}" target="_blank">{l s='Pricelist CSV' mod='dropshipsystem'}</a></li>
            <li><a href="{$link->getModuleLink('dropshipsystem', 'downloads', ['file' => 'pricelist.xml'], true)|escape:'htmlall':'UTF-8'}" title="{l s='Pricelist XML' mod='dropshipsystem'}" target="_blank">{l s='Pricelist XML' mod='dropshipsystem'}</a></li>
            {/if}
            {if $DSS_FILE_ALL_ENABLE|intval neq 0}
            <li><a href="{$link->getModuleLink('dropshipsystem', 'downloads', ['file' => 'all.zip'], true)|escape:'htmlall':'UTF-8'}" title="{l s='All Zip' mod='dropshipsystem'}" target="_blank">{l s='All Zip' mod='dropshipsystem'}</a></li>
            {/if}
        </ul>
        <div class="form-group">
            <label class="align_right" for="name">{l s='Modules / Plugins' mod='dropshipsystem'}</label>
            <select id="dropshipclient" name="dropshipclient" class="form-control">
                <option value disabled selected>{l s='-Select one-' mod='dropshipsystem'}</option>
                <optgroup label="{l s='Prestashop' mod='dropshipsystem'}">
                    <option value="dropshipclient_presta.zip">{l s='PrestaShop v 1.7' mod='dropshipsystem'}</option>
                    <option value="dropshipclient_presta.zip">{l s='PrestaShop v 1.6' mod='dropshipsystem'}</option>
                </optgroup>
                <!--<optgroup label="{l s='Magento' mod='dropshipsystem'}">-->
                </optgroup>
            </select>
        </div>
        <div class="form-group">
            <a id="submitDownloadPlugin" name="submitDownloadPlugin" class="btn btn-primary disabled" href="#" target="_blank">
                <span>
                    <i class="icon-download"></i>
                    {l s='Download' mod='dropshipsystem'}
                </span>
            </a>
        </div>
    </div>
</div>
<div class="block dropship">
    <h6 class="title_block">{l s='Documents' mod='dropshipsystem'}</h6>
    <div class="block_content list-block">
        <ul>
            <li><a href="{$link->getModuleLink('dropshipsystem', 'downloads', ['file' => 'webservice_manual.pdf'], true)|escape:'htmlall':'UTF-8'}" title="{l s='WebService Manual' mod='dropshipsystem'}" target="_blank">{l s='WebService Manual' mod='dropshipsystem'}</a></li>
        </ul>
    </div>
</div>
{/block}
{/if}
<!-- /Block dropship module -->
