{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<div class="dss component pull-right hidden">
    <div id="dropshippers_notif" class="dropdown">
        <div class="dss_notification js-notification dropdown-toggle">
            <i class="material-icons">business</i>
            <span id="dropshippers_notif_number_wrapper" class="notifs_badge hidden">
                <span id="dropshippers_notif_value">0</span>
            </span>
        </div>
        <div class="dropdown-menu dropdown-menu-right js-notifs_dropdown">
            <section id="dropshippers_notif_wrapper" class="notifs_panel">
                <header class="notifs_panel_header">
                    {l s='Latest Dropshipper Registrations' mod='dropshipsystem'}
                </header>
                <div id="list_dropshippers_notif" class="list_notif">
                    <span class="no_notifs">
                        {l s='No new dropshipper have registered on your shop.' mod='dropshipsystem'}
                    </span>
                </div>
                <footer class="panel-footer">
                    <a href="index.php?controller=AdminDropShip&amp;token={getAdminToken tab='AdminDropShip'}">{l s='Show all dropshippers' mod='dropshipsystem'}</a>
                </footer>
            </section>
        </div>
    </div>
</div>
<script type="text/javascript">
$(document).ready(function() {
    $('#dropshippers_notif').parent().detach().appendTo('nav.main-header, .navbar-header');
    $('#dropshippers_notif').parent().removeClass('hidden');
});
</script>
