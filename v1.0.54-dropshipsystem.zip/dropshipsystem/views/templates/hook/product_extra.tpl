{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

{if $id_product == 0}
    <div class="alert alert-warning">
        <button class="close" data-dismiss="alert" type="button">×</button>
        {l s='There is 1 alert' mod='dropshipsystem'}
        <ul id="seeMore" style="display:block;">
            <li>{l s='You must save this product before adding custom options.' mod='dropshipsystem'}</li>
        </ul>
    </div>
{else}
    <div id="product-moduledropship" class="panel product-tab">
        <h3 class="tab">
            <img src="{$base_url|escape:'html':'UTF-8'}modules/dropshipsystem/logo.gif" />
            {l s='Drop Ship - Options' mod='dropshipsystem'}
        </h3>
        <div class="form-group">
            <label class="control-label col-lg-2">
                {l s='Credit product' mod='dropshipsystem'}
            </label>
            <div class="col-lg-9">
                <span class="switch prestashop-switch fixed-width-lg">
                    <input id="is_credit_product_on" name="is_credit_product" type="radio" value="1" {if $is_credit_product}checked="checked"{/if}>
                    <label class="radioCheck" for="is_credit_product_on">{l s='Yes' mod='dropshipsystem'}</label>
                    <input id="is_credit_product_off" name="is_credit_product" type="radio" value="0" {if !$is_credit_product}checked="checked"{/if}>
                    <label class="radioCheck" for="is_credit_product_off">{l s='No' mod='dropshipsystem'}</label>
                    <a class="slide-button btn"></a>
                </span>
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-lg-2">
                {l s='Excluded groups' mod='dropshipsystem'}
            </label>
            <div class="col-lg-9">
            {if count($groups) && isset($groups)}
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="fixed-width-xs">
                                <span class="title_box">
                                    <input type="checkbox" name="checkme" id="checkme" onclick="checkDelBoxes(this.form, 'groupBox[]', this.checked)" />
                                </span>
                            </th>
                            <th class="fixed-width-xs"><span class="title_box">{l s='ID' mod='dropshipsystem'}</span></th>
                            <th>
                                <span class="title_box">
                                    {l s='Group name' mod='dropshipsystem'}
                                </span>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    {foreach $groups as $key => $group}
                        {assign var=id_checkbox value=groupBox|cat:'_'|cat:$group['id_group']}
                        <tr>
                            <td>
                                <input type="checkbox" name="groupBox[]" class="groupBox" id="{$id_checkbox|escape:'htmlall':'UTF-8'}" value="{$group['id_group']|intval}" {if isset($selected_groups[$group['id_group']]) && $selected_groups[$group['id_group']]}checked="checked"{/if} />
                            </td>
                            <td>{$group['id_group']|intval}</td>
                            <td>
                                <label for="{$id_checkbox|escape:'htmlall':'UTF-8'}">{$group['name']|escape:'htmlall':'UTF-8'}</label>
                            </td>
                        </tr>
                    {/foreach}
                    </tbody>
                </table>
            {else}
                <p>
                    {l s='No group created' mod='dropshipsystem'}
                </p>
            {/if}
            </div>
        </div>
        <div class="panel-footer">
            <a href="{$dss_back_link|escape:'html':'UTF-8'}" class="btn btn-default"><i class="process-icon-cancel"></i> {l s='Cancel' mod='dropshipsystem'}</a>
            <button type="submit" name="submitAddproduct" class="btn btn-default pull-right"><i class="process-icon-save"></i> {l s='Save' mod='dropshipsystem'}</button>
            <button type="submit" name="submitAddproductAndStay" class="btn btn-default pull-right"><i class="process-icon-save"></i> {l s='Save and stay' mod='dropshipsystem'}</button>
        </div>
    </div>
{/if}