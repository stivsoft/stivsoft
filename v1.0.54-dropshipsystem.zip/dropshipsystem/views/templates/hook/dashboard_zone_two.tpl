{**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
*}

<section id="dropship" class="panel widget {if $allow_push} allow_push{/if}">
    <header class="panel-heading">
        <i class="icon-bar-chart"></i> {l s='Dropship system' mod='dropshipsystem'}
        <span class="panel-heading-action">
            <a class="list-toolbar-btn" href="#" onclick="toggleDashConfig('dropshipsystem'); return false;" title="{l s='Configure' mod='dropshipsystem'}">
                <i class="process-icon-configure"></i>
            </a>
            <a class="list-toolbar-btn" href="#"  onclick="refreshDashboard('dropshipsystem'); return false;"  title="{l s='Refresh' mod='dropshipsystem'}">
                <i class="process-icon-refresh"></i>
            </a>
        </span>
    </header>

    <section id="dropship_config" class="dash_config hide">
        <header><i class="icon-wrench"></i> {l s='Configuration' mod='dropshipsystem'}</header>
        {html_entity_decode($dssdash_config_form|escape:'htmlall':'UTF-8')}
    </section>

    <section class="loading">
        <nav>
            <ul class="nav nav-pills">
                <li class="active">
                    <a href="#dash_dropship_events" data-toggle="tab">
                        <i class="icon-cogs"></i>
                        <span class="hidden-inline-xs">{l s='Events' mod='dropshipsystem'}</span>
                    </a>
                </li>
                <li>
                    <a href="#dash_dropship_recent_orders" data-toggle="tab">
                        <i class="icon-flag"></i>
                        <span class="hidden-inline-xs">{l s='Recent Dropship Orders' mod='dropshipsystem'}</span>
                    </a>
                </li>
                <li>
                    <a href="#dash_dropship_best_dropshippers" data-toggle="tab">
                        <i class="icon-trophy"></i>
                        <span class="hidden-inline-xs">{l s='Best Dropshippers' mod='dropshipsystem'}</span>
                    </a>
                </li>
                <li>
                    <a href="#dash_dropship_info" data-toggle="tab">
                        <i class="icon-info"></i>
                        <span class="hidden-inline-xs">{l s='Info' mod='dropshipsystem'}</span>
                    </a>
                </li>
            </ul>
        </nav>

        <div class="tab-content panel">
            <div class="tab-pane active" id="dash_dropship_events">
                <h3>
                    {l s='Events' mod='dropshipsystem'}
                    <span class="pull-right">
                        {l s='Filters' mod='dropshipsystem'}:
                        <span class="label label-info">
                            <input name="DSS_FILTER_INFO" class="dss_filters" type="checkbox" value="1" {if $DSS_FILTER_INFO}checked{/if} />
                            <span>{l s='Info' mod='dropshipsystem'}</span>
                        </span>
                        <span class="label label-warning">
                            <input name="DSS_FILTER_ALERT" class="dss_filters" type="checkbox" value="1" {if $DSS_FILTER_ALERT}checked{/if} />
                            <span>{l s='Alert' mod='dropshipsystem'}</span>
                        </span>
                        <span class="label label-danger">
                            <input name="DSS_FILTER_ERROR" class="dss_filters" type="checkbox" value="1" {if $DSS_FILTER_ERROR}checked{/if} />
                            <span>{l s='Error' mod='dropshipsystem'}</span>
                        </span>
                    </span>
                </h3>
                <div class="table-responsive">
                    <table class="table data_table" id="dss_table_events">
                        <thead></thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane" id="dash_dropship_recent_orders">
                <h3>{l s='Last %d dropship orders' sprintf=$DSS_NBR_SHOW_LAST_ORDER|intval mod='dropshipsystem'}</h3>
                <div class="table-responsive">
                    <table class="table data_table" id="dss_table_recent_orders">
                        <thead></thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane" id="dash_dropship_best_dropshippers">
                <h3>
                    {l s='Top %d dropshippers' sprintf=$DSS_NBR_SHOW_BEST_DROPSHIPPERS|intval mod='dropshipsystem'}
                    <span>{l s='From' mod='dropshipsystem'} {$date_from|escape:'htmlall':'UTF-8'} {l s='to' mod='dropshipsystem'} {$date_to|escape:'htmlall':'UTF-8'}</span>
                </h3>
                <div class="table-responsive">
                    <table class="table data_table" id="dss_table_best_dropshippers">
                        <thead></thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane" id="dash_dropship_info">
                <h3>
                    {l s='Info' mod='dropshipsystem'}
                </h3>
                <span class="data_value">
                    <span id="messages"></span>
                </span>
            </div>
        </div>
    </section>
</section>
{strip}
{addJsDef dss_token=$dss_token}
{addJsDef dss_ajaxurl=$dss_ajaxurl|escape:'quotes':'UTF-8'}
{addJsDefL name=dashboad_filter_edit}{l s='Filter edit successfull' mod='dropshipsystem' js=1}{/addJsDefL}
{addJsDefL name=err_dashboad_filter_edit}{l s='Error during edit filter' mod='dropshipsystem' js=1}{/addJsDefL}
{/strip}
