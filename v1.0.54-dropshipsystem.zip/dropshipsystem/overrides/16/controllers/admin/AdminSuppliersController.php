<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class AdminSuppliersController extends AdminSuppliersControllerCore
{
    public function ajaxProcessDropshipSupplierGroups()
    {
        if (!$this->context) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;
        if (!(int)Tools::getValue('save')) {
            $id_supplier = (int)Tools::getValue('id_supplier');
            $groups = Group::getGroups($this->context->language->id, $id_shop);
            $groupsdef = array(Configuration::get('PS_UNIDENTIFIED_GROUP', null, null, $id_shop), Configuration::get('PS_GUEST_GROUP', null, null, $id_shop), Configuration::get('PS_CUSTOMER_GROUP', null, null, $id_shop));
            $selected_groups = array();
            $exlgrps = DssSuppliersClass::getSupplierGroups((int)$id_supplier);
            foreach ($groups as $key => $group) {
                $id_group = (int)$group['id_group'];
                if (in_array($id_group, $groupsdef)) {
                    unset($groups[$key]);
                    continue;
                }
                foreach ($exlgrps as $exlgrp) {
                    if ((int)$exlgrp['group'] == (int)$id_group) {
                        $selected_groups[$id_group] = 1;
                        continue;
                    }
                }
            }
            $this->context->smarty->assign(array(
                'groups' => $groups,
                'selected_groups' => $selected_groups,
                'dss_id' => (int)$id_supplier,
                'dss_action' => 'dropshipsuppliergroups',
                'dss_ajaxurl' => $this->context->link->getAdminLink('AdminSuppliers', true),
                'dss_token' => Tools::getAdminTokenLite('AdminSuppliers'),
            ));
            $html = $this->context->smarty->fetch(dirname(__FILE__).'/../../../modules/dropshipsystem/views/templates/admin/popup_groups.tpl');
            die(Tools::jsonEncode(array('success' => true, 'html' => $html)));
        } else {
            $id_supplier = (int)Tools::getValue('id_dss');
            $groups = explode(',', (string)Tools::getValue('selected_groups'));
            $count = 0;
            if (isset($groups) && count($groups) > 0) {
                foreach ($groups as $group) {
                    if ((int)$group > 0) {
                        $count++;
                        $dss_groups = new DssSuppliersClass();
                        $dss_group_exist = (int)$dss_groups->existsSupplierGroup((int)$id_supplier, (int)$group);
                        if ($dss_group_exist) {
                            continue;
                        }
                        $dss_groups->id_supplier = (int)$id_supplier;
                        $dss_groups->id_shop = (int)$id_shop;
                        $dss_groups->group = (int)$group;
                        $dss_groups->add();
                    }
                }
            }
            DssSuppliersClass::clearSupplierGroups($id_supplier, $groups);
            die(Tools::jsonEncode(array('success' => true, 'count' => (int)$count, 'text' => $this->l('Supplier group has been updated successfully'))));
        }
    }
}
