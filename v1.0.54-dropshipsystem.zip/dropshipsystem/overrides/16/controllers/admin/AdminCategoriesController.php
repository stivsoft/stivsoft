<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class AdminCategoriesController extends AdminCategoriesControllerCore
{
    public function ajaxProcessDropshipStatusCategory()
    {
        if (!$id_category = (int)Tools::getValue('id_category')) {
            die(Tools::jsonEncode(array('success' => false, 'error' => true, 'text' => $this->l('Failed to update the dropship status'))));
        } else {
            $id_dss_category = (int)DssCategoriesClass::getDssCategoryID($id_category);
            $dss_categories = new DssCategoriesClass((int)$id_dss_category);
            if (Validate::isLoadedObject($dss_categories)) {
                $dss_category_code = $dss_categories->dss_category_code;
                if (!empty($dss_category_code)) {
                    $dss_categories->dss_category_active = $dss_categories->dss_category_active == 1 ? 0 : 1;
                    if ($dss_categories->dss_category_active == 1) {
                        Db::getInstance()->execute('
                            UPDATE `'._DB_PREFIX_.'dss_categories`
                            SET `dss_category_code_parent` = \''.pSql($dss_category_code).'\'
                            WHERE dss_category_active` = 1 
                            AND `id_category` IN (SELECT `id_category` 
                                FROM `'._DB_PREFIX_.'category` c 
                                '.Shop::addSqlAssociation('category', 'c').'
                                WHERE c.`id_parent` = '.(int)$id_category.'
                            )'.Shop::addSqlRestrictionOnLang());
                    } else {
                        Db::getInstance()->execute('
                            UPDATE `'._DB_PREFIX_.'dss_categories`
                            SET `dss_category_code_parent` = NULL
                            WHERE `id_category` IN (SELECT `id_category` 
                                FROM `'._DB_PREFIX_.'category` c 
                                '.Shop::addSqlAssociation('category', 'c').'
                                WHERE c.`id_parent` = '.(int)$id_category.'
                            )'.Shop::addSqlRestrictionOnLang());
                    }
                    $dss_categories->save() ?
                    die(Tools::jsonEncode(array('success' => true, 'text' => $this->l('The dropship status has been updated successfully')))) :
                    die(Tools::jsonEncode(array('success' => false, 'error' => true, 'text' => $this->l('Failed to update the dropship status'))));
                } else {
                    die(Tools::jsonEncode(array('success' => false, 'error' => true, 'text' => $this->l('Can\'t enable dropship status with empty unique code'))));
                }
            }
        }
    }
}
