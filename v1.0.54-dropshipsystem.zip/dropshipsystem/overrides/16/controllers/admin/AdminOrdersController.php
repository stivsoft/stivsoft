<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class AdminOrdersController extends AdminOrdersControllerCore
{
    public function initToolbar()
    {
        parent::initToolbar();

        if ($this->display == 'view') {
            $order = $this->loadObject();
            $customer = $this->context->customer;

            if (!Validate::isLoadedObject($order)) {
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminOrders'));
            }

            $dss = Module::getInstanceByName('dropshipsystem');
            if ($dss->active) {
                $dropshipper = DssOrderClass::getDssOrderIDByOrderID($order->id);
                if (isset($dropshipper) && $dropshipper) {
                    $this->addJS(_PS_MODULE_DIR_.'dropshipsystem/views/js/orders.js');
                    $this->toolbar_title[] = sprintf($this->l('%1$s Order %2$s from %3$s %4$s'), 'Dropshipper', $order->reference, $customer->firstname, $customer->lastname);
                }
            }
        }
    }
}
