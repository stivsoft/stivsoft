<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class AdminProductsController extends AdminProductsControllerCore
{
    public function ajaxProcessdeletespecificwholesaleprice()
    {
        $id_specific_wholesale_price = (int)Tools::getValue('id_specific_wholesale_price');
        if (!$id_specific_wholesale_price || !Validate::isUnsignedId($id_specific_wholesale_price)) {
            $error = Tools::displayError('The specific wholesale price ID is invalid.');
        } else {
            require_once(_PS_MODULE_DIR_.'/dropshipsystem/classes/DssSpecificWholesalePriceClass.php');
            $specificWholesalePrice = new DssSpecificWholesalePriceClass((int)$id_specific_wholesale_price);
            if (!$specificWholesalePrice->delete()) {
                $error = Tools::displayError('An error occurred while attempting to delete the specific wholesale price.');
            }
        }
 
        if (isset($error)) {
            $json = array(
                'status' => 'error',
                'message'=> $error
            );
        } else {
            $json = array(
                'status' => 'ok',
                'message'=> $this->_conf[1]
            );
        }
        die(Tools::jsonEncode($json));
    }
}
