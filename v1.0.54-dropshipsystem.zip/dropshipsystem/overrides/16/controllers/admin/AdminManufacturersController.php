<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class AdminManufacturersController extends AdminManufacturersControllerCore
{
    public function ajaxProcessDropshipManufacturerGroups()
    {
        if (!$this->context) {
            $this->context = Context::getContext();
        }
        $id_shop = (int)$this->context->shop->id;
        if (!(int)Tools::getValue('save')) {
            $id_manufacturer = (int)Tools::getValue('id_manufacturer');
            $groups = Group::getGroups($this->context->language->id, $id_shop);
            $groupsdef = array(Configuration::get('PS_UNIDENTIFIED_GROUP', null, null, $id_shop), Configuration::get('PS_GUEST_GROUP', null, null, $id_shop), Configuration::get('PS_CUSTOMER_GROUP', null, null, $id_shop));
            $selected_groups = array();
            $exlgrps = DssManufacturersClass::getManufacturerGroups((int)$id_manufacturer);
            foreach ($groups as $key => $group) {
                $id_group = (int)$group['id_group'];
                if (in_array($id_group, $groupsdef)) {
                    unset($groups[$key]);
                    continue;
                }
                foreach ($exlgrps as $exlgrp) {
                    if ((int)$exlgrp['group'] == (int)$id_group) {
                        $selected_groups[$id_group] = 1;
                        continue;
                    }
                }
            }
            $this->context->smarty->assign(array(
                'groups' => $groups,
                'selected_groups' => $selected_groups,
                'dss_id' => (int)$id_manufacturer,
                'dss_action' => 'dropshipmanufacturergroups',
                'dss_ajaxurl' => $this->context->link->getAdminLink('AdminManufacturers', true),
                'dss_token' => Tools::getAdminTokenLite('AdminManufacturers'),
            ));
            $html = $this->context->smarty->fetch(dirname(__FILE__).'/../../../modules/dropshipsystem/views/templates/admin/popup_groups.tpl');
            die(Tools::jsonEncode(array('success' => true, 'html' => $html)));
        } else {
            $id_manufacturer = (int)Tools::getValue('id_dss');
            $groups = explode(',', (string)Tools::getValue('selected_groups'));
            $count = 0;
            if (isset($groups) && count($groups) > 0) {
                foreach ($groups as $group) {
                    if ((int)$group > 0) {
                        $count++;
                        $dss_groups = new DssManufacturersClass();
                        $dss_group_exist = (int)$dss_groups->existsManufacturerGroup((int)$id_manufacturer, (int)$group);
                        if ($dss_group_exist) {
                            continue;
                        }
                        $dss_groups->id_manufacturer = (int)$id_manufacturer;
                        $dss_groups->id_shop = (int)$id_shop;
                        $dss_groups->group = (int)$group;
                        $dss_groups->add();
                    }
                }
            }
            DssManufacturersClass::clearManufacturerGroups($id_manufacturer, $groups);
            die(Tools::jsonEncode(array('success' => true, 'count' => (int)$count, 'text' => $this->l('Manufacturer group has been updated successfully'))));
        }
    }
}
