<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class HistoryController extends HistoryControllerCore
{
    public function initContent()
    {
        parent::initContent();

        $dss = Module::getInstanceByName('dropshipsystem');
        if ($dss->active) {
            if ($orders = Order::getCustomerOrders($this->context->customer->id)) {
                $id_customer = (int)$this->context->customer->id;
                $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($id_customer);
                if ($id_dropshipper) {
                    $dss_orders = DssOrderClass::getOrdersIDByDropshipperID($id_dropshipper);
                }
                foreach ($orders as $key => &$order) {
                    if (isset($dss_orders) && in_array((int)$order['id_order'], $dss_orders)) {
                        unset($orders[$key]);
                    }
                    $myOrder = new Order((int)$order['id_order']);
                    if (Validate::isLoadedObject($myOrder)) {
                        $order['virtual'] = $myOrder->isVirtual(false);
                    }
                }
            }
            $this->context->smarty->assign(array(
                'orders' => $orders,
            ));
        }
    }
}
