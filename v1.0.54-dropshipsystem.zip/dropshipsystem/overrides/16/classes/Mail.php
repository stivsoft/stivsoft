<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class Mail extends MailCore
{
    public static function send(
        $id_lang,
        $template,
        $subject,
        $template_vars,
        $to,
        $to_name = null,
        $from = null,
        $from_name = null,
        $file_attachment = null,
        $mode_smtp = null,
        $template_path = _PS_MAIL_DIR_,
        $die = false,
        $id_shop = null,
        $bcc = null,
        $reply_to = null,
        $reply_to_name = null
    ) {
        $keepGoing = array_reduce(Hook::exec(
            'actionEmailSendBefore',
            array(
                'idLang' => &$id_lang,
                'template' => &$template,
                'subject' => &$subject,
                'templateVars' => &$template_vars,
                'to' => &$to,
                'toName' => &$to_name,
                'from' => &$from,
                'fromName' => &$from_name,
                'fileAttachment' => &$file_attachment,
                'mode_smtp' => &$mode_smtp,
                'templatePath' => &$template_path,
                'die' => &$die,
                'idShop' => &$id_shop,
                'bcc' => &$bcc,
                'replyTo' => &$reply_to
            ),
            null,
            true
        ), function ($carry, $item) {
            return ($item === false) ? false : $carry;
        }, true);

        if (!$keepGoing) {
            return true;
        }

        return parent::send(
            $id_lang,
            $template,
            $subject,
            $template_vars,
            $to,
            $to_name,
            $from,
            $from_name,
            $file_attachment,
            $mode_smtp,
            $template_path,
            $die,
            $id_shop,
            $bcc,
            $reply_to
        );
    }
}
