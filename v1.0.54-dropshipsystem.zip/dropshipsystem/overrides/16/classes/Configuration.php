<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class Configuration extends ConfigurationCore
{
    public static function showPrices()
    {
        $context = Context::getContext();
        if (isset($context->cookie->is_dropshipper_customer) && $context->cookie->is_dropshipper_customer) {
            return true;
        }
        return Group::isFeatureActive() ? (bool) Group::getCurrent()->show_prices : true;
    }
}
