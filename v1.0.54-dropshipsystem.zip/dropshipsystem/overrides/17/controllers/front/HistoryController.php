<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

class HistoryController extends HistoryControllerCore
{
    public function initContent()
    {
        parent::initContent();
    }

    public function getTemplateVarOrders()
    {
        $dss = Module::getInstanceByName('dropshipsystem');
        if ($dss->active) {
            $orders = array();
            $customer_orders = Order::getCustomerOrders($this->context->customer->id);
            $id_customer = (int)$this->context->customer->id;
            $id_dropshipper = (int)DssDropshippersClass::getDrophipperIDByCustomerID($id_customer);
            if ($id_dropshipper) {
                $dss_orders = DssOrderClass::getOrdersIDByDropshipperID($id_dropshipper);
            }
            foreach ($customer_orders as $key => $customer_order) {
                if (isset($dss_orders) && in_array((int)$customer_order['id_order'], $dss_orders)) {
                    unset($customer_orders[$key]);
                }
                $order = new Order((int) $customer_order['id_order']);
                $orders[$customer_order['id_order']] = $this->order_presenter->present($order);
            }

            return $orders;
        }
    }
}
