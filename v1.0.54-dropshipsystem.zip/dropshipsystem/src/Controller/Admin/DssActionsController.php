<?php
/**
 * Dropship System Server
 *
 * @author    Ruggiero Marco
 * @copyright Copyright (c) 2017, PrestaBiz.com
 * @license   End User License Agreement (EULA)
 * @link      http://www.prestabiz.com
 * @email     info@prestabiz.com
 *
 * E' vietata la vendita, la distribuzione e la modifica anche parziale del codice sorgente
 * senza il consenso scritto del produttore.
 */

namespace DropshipSystem\Controller\Admin;

require_once(dirname(__FILE__).'/../../../classes/DssCategoriesClass.php');

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use DB;
use Validate;
use Shop;
use DssCategoriesClass;
use Context;

class DssActionsController extends FrameworkBundleAdminController
{
    public function toggleDropshipStatusCategory($categoryId)
    {
        $id_dss_category = (int)DssCategoriesClass::getDssCategoryID($categoryId);
        $dss_categories = new DssCategoriesClass((int)$id_dss_category);
        if (Validate::isLoadedObject($dss_categories)) {
            $dss_category_code = $dss_categories->dss_category_code;
            if (!empty($dss_category_code)) {
                $dss_categories->dss_category_active = $dss_categories->dss_category_active == 1 ? 0 : 1;
                if ($dss_categories->dss_category_active == 1) {
                    Db::getInstance()->execute('
                        UPDATE `'._DB_PREFIX_.'dss_categories` dssc
                        SET dssc.`dss_category_code_parent` = \''.pSql($dss_category_code).'\'
                        WHERE dssc.`dss_category_active` = 1 
                        AND dssc.`id_category` IN (SELECT c.`id_category` 
                            FROM `'._DB_PREFIX_.'category` c 
                            '.Shop::addSqlAssociation('category', 'c').'
                            WHERE c.`id_parent` = '.(int)$categoryId.'
                        )'.Shop::addSqlRestrictionOnLang());
                } else {
                    Db::getInstance()->execute('
                        UPDATE `'._DB_PREFIX_.'dss_categories` dssc
                        SET dssc.`dss_category_code_parent` = NULL
                        WHERE dssc.`id_category` IN (SELECT c.`id_category` 
                            FROM `'._DB_PREFIX_.'category` c 
                            '.Shop::addSqlAssociation('category', 'c').'
                            WHERE c.`id_parent` = '.(int)$categoryId.'
                        )'.Shop::addSqlRestrictionOnLang());
                }
                if ($dss_categories->save()) {
                    $response = array('status' => true, 'message' => $this->trans('The dropship status has been updated successfully', 'Modules.DropshipSystem.Admin'));
                } else {
                    $response = array('status' => false, 'message' => $this->trans('Failed to update the dropship status', 'Modules.DropshipSystem.Admin'));
                }
            } else {
                $response = array('status' => false, 'message' => $this->trans('Can\'t enable dropship status with empty unique code', 'Modules.DropshipSystem.Admin'));
            }
        }

        return $this->json($response);
    }

    public function processDropshipSupplierGroups($supplierId)
    {
        return $this->json(array('status' => true, 'message' => 'to do'));
    }

    public function processDropshipManufacturerGroups($manufacturerId)
    {
        return $this->json(array('status' => true, 'message' => 'to do'));
    }
}
